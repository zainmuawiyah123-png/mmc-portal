'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const TMP=fs.mkdtempSync(path.join(os.tmpdir(),'mmc-ai-api-'));
process.env.NODE_ENV='test';
process.env.MAIL_HOST='json'; // isolated in-memory mail transport for OTP tests
process.env.DB_PATH=path.join(TMP,'test.db');
process.env.REQUIRE_ORG_VERIFICATION='false';
process.env.UPLOAD_DIR=path.join(TMP,'uploads');
process.env.JWT_SECRET='mmc-ai-isolation-test-secret';
process.env.BCRYPT_ROUNDS='4';
const {migrate}=require('../src/migrate');
const {createApp}=require('../src/index');
const {closeDB}=require('../src/db');
let server,base;
const jar={};
async function call(user,method,url,body){
 const headers={...(jar[user]?{Cookie:jar[user]}:{})};
 let payload;
 if(body!==undefined){headers['Content-Type']='application/json';payload=JSON.stringify(body);}
 const r=await fetch(base+url,{method,headers,body:payload,redirect:'manual'});
 for(const c of (r.headers.getSetCookie?r.headers.getSetCookie():[])){
  const first=c.split(';')[0]; if(first.startsWith('tpkit_session=')) jar[user]=first;
 }
 const data=(r.headers.get('content-type')||'').includes('application/json')?await r.json():await r.text();
 return {status:r.status,data};
}
const uniq=()=>Math.random().toString(36).slice(2,10);
async function register(key){const email=key+uniq()+'@test.local';const r=await call(key,'POST','/api/auth/register',{name:key,email,password:'Password123',company:key});assert.equal(r.status,201,JSON.stringify(r.data));const db=require('../src/db').getDB();const user=db.prepare('SELECT id FROM users WHERE email=?').get(email);const now=Math.floor(Date.now()/1000);db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now,user.id);db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);const login=await call(key,'POST','/api/auth/login',{email,password:'Password123'});assert.equal(login.status,200,JSON.stringify(login.data));return user.id;}
test.before(async()=>{
 migrate(process.env.DB_PATH);
 const app=createApp();
 await new Promise(resolve=>{server=app.listen(0,'127.0.0.1',()=>{base='http://127.0.0.1:'+server.address().port;resolve();});});
});
test.after(async()=>{if(server)await new Promise(r=>server.close(r));closeDB();fs.rmSync(TMP,{recursive:true,force:true});});


const CSV='رقم البند;البيان;الوحدة;الكمية;سعر الوحدة\nأعمال الحفر;;;;\n1.1;حفر عام;م3;1250.5;\n1.2;خرسانة عادية;م3;85;120\n1.3;دهان;م2;abc;\n';
test('BOQ import: preview, rejection gate, commit and permissions',async()=>{
 await register('boq-owner');const viewerId=await register('boq-viewer');
 const created=await call('boq-owner','POST','/api/mmc-ai/projects',{name:'Import Project',country:'JO',currency:'JOD'});
 assert.equal(created.status,201,JSON.stringify(created.data));
 const projectId=created.data.project.project_id||created.data.project.id;
 await call('boq-owner','POST','/api/mmc-ai/projects/'+projectId+'/members',{userId:viewerId,role:'viewer'});
 const url='/api/mmc-ai/projects/'+projectId+'/boq/import';
 const preview=await call('boq-owner','POST',url,{csv:CSV});
 assert.equal(preview.status,200,JSON.stringify(preview.data));
 assert.equal(preview.data.dryRun,true);assert.equal(preview.data.preview.accepted,2);assert.equal(preview.data.preview.rejected.length,1);
 const before=await call('boq-owner','GET','/api/mmc-ai/projects/'+projectId+'/boq');
 assert.equal(before.data.items.length,0,'preview must not write');
 const blocked=await call('boq-owner','POST',url,{csv:CSV,dryRun:false});
 assert.equal(blocked.status,409,JSON.stringify(blocked.data));
 const viewer=await call('boq-viewer','POST',url,{csv:CSV,dryRun:false,skipRejected:true});
 assert.equal(viewer.status,403);
 const ok=await call('boq-owner','POST',url,{csv:CSV,dryRun:false,skipRejected:true});
 assert.equal(ok.status,201,JSON.stringify(ok.data));assert.equal(ok.data.imported,2);
 const after=await call('boq-owner','GET','/api/mmc-ai/projects/'+projectId+'/boq');
 assert.equal(after.data.items.length,2);
 assert.equal(after.data.items[0].unit,'m3');assert.equal(after.data.items[1].line_total,10200);
 const bad=await call('boq-owner','POST',url,{nothing:true});
 assert.equal(bad.status,422);
});
