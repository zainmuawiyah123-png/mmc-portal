'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseCsv, parseBoqRows, parseNumber, normalizeUnit } = require('../src/lib/mmc-ai/boq-import');

const CSV = 'المشروع: مبنى\n\nرقم البند;البيان;الوحدة;الكمية;سعر الوحدة\nأعمال الحفر;;;;\n1.1;حفر عام;م٣;1,250.50;\n1.2;"خرسانة، عادية";م3;85;120\n1.3;حديد;طن;١٢٫٥;\n1.4;دهان;م2;abc;\n';

test('finds header after preamble and keeps file line numbers', () => {
  const r = parseBoqRows(parseCsv(CSV));
  assert.equal(r.ok, true);
  assert.equal(r.headerRow, 3);
  assert.deepEqual(r.accepted.map(x => x.line), [5, 6, 7]);
});

test('parses Arabic digits, thousands separators and normalizes units', () => {
  assert.equal(parseNumber('1,250.50'), 1250.5);
  assert.equal(parseNumber('١٢٫٥'), 12.5);
  assert.equal(parseNumber('abc'), null);
  assert.equal(normalizeUnit('م٣'), 'm3');
  assert.equal(normalizeUnit('طن'), 'ton');
  assert.equal(normalizeUnit('weird'), 'weird');
});

test('unreadable quantity is rejected, never zero', () => {
  const r = parseBoqRows(parseCsv(CSV));
  assert.equal(r.rejected.length, 1);
  assert.equal(r.rejected[0].line, 8);
});

test('section headings are skipped and unpriced rows warn', () => {
  const r = parseBoqRows(parseCsv(CSV));
  assert.equal(r.skipped[0].text, 'أعمال الحفر');
  assert.ok(r.warnings.some(w => w.includes('بلا سعر')));
  assert.equal(r.accepted[0].rate, 0);
});

test('quoted commas stay inside one cell', () => {
  const r = parseBoqRows(parseCsv(CSV));
  assert.equal(r.accepted[1].description, 'خرسانة، عادية');
});

test('missing header columns fail clearly', () => {
  const r = parseBoqRows([['a', 'b'], ['1', '2']]);
  assert.equal(r.ok, false);
});
