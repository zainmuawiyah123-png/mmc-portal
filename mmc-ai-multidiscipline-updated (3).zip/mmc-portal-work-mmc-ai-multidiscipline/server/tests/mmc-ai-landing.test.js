'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '..', '..', 'webpages', 'technical-proposal-kit_v5', 'mmc-ai', 'landing.html'), 'utf8');

function englishDictionary() {
  const start = html.indexOf('var EN={') + 'var EN='.length;
  const end = html.indexOf('};\n var AR=', start) + 1;
  return new Function('return ' + html.slice(start, end))();
}

test('every data-k key has an English translation', () => {
  const keys = [...html.matchAll(/data-k="([^"]+)"/g)].map(m => m[1]);
  assert.ok(keys.length > 30);
  const en = englishDictionary();
  const missing = [...new Set(keys)].filter(k => typeof en[k] !== 'string' || !en[k].trim());
  assert.deepEqual(missing, []);
});

test('English dictionary has no unused keys except meta and runtime messages', () => {
  const used = new Set([...html.matchAll(/data-k="([^"]+)"/g)].map(m => m[1]));
  const extra = Object.keys(englishDictionary()).filter(k => !used.has(k) && !['title', 'desc'].includes(k) && !/^m\d$/.test(k));
  assert.deepEqual(extra, []);
});

test('page declares language, direction, viewport and honesty notices', () => {
  assert.match(html, /<html lang="ar" dir="rtl">/);
  assert.match(html, /name="viewport"/);
  assert.match(html, /وليست مرجعاً للتسعير/);
  assert.match(html, /ليس لقطة شاشة حقيقية|وليس لقطة شاشة حقيقية/);
});
