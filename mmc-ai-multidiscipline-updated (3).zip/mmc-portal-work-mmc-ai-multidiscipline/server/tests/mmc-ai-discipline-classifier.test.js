'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { classifyLayer, summarizeByDiscipline } = require('../src/lib/mmc-ai/discipline-layer-classifier');

test('AIA prefixes map to disciplines', () => {
  assert.equal(classifyLayer('A-WALL').discipline, 'architectural');
  assert.equal(classifyLayer('S-COLS').discipline, 'structural');
  assert.equal(classifyLayer('E-LITE').discipline, 'electrical');
  assert.equal(classifyLayer('M-DUCT').discipline, 'mechanical');
  assert.equal(classifyLayer('P-SANR-PIPE').discipline, 'plumbing');
  assert.equal(classifyLayer('FP-SPRK').discipline, 'fire_protection');
});

test('pattern/hatch layers are excluded from quantities', () => {
  const c = classifyLayer('A-WALL-PATT');
  assert.equal(c.basis, 'excluded');
});

test('unknown layers stay unclassified instead of being guessed', () => {
  assert.equal(classifyLayer('XYZ').discipline, 'unclassified');
  assert.equal(classifyLayer('0').discipline, 'unclassified');
});

test('user layerMap overrides automatic rules', () => {
  const c = classifyLayer('XYZ', { XYZ: { discipline: 'plumbing', category: 'pipes' } });
  assert.equal(c.discipline, 'plumbing');
  assert.equal(c.source, 'user_layer_map');
});

test('summary totals length and closed area per discipline', () => {
  const rows = [
    { layer: 'A-WALL', quantity: 3, unit: 'm' },
    { layer: 'A-WALL', quantity: 2, unit: 'm', area_m2: 0.5 },
    { layer: 'M-DUCT', quantity: 4, unit: 'm' }
  ];
  const out = summarizeByDiscipline(rows);
  const arch = out.find(d => d.discipline === 'architectural').categories[0];
  assert.equal(arch.linework_length_m, 5);
  assert.equal(arch.closed_area_m2, 0.5);
  assert.ok(out.find(d => d.discipline === 'mechanical'));
});
