'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const TMP=fs.mkdtempSync(path.join(os.tmpdir(),'mmc-ai-api-'));
process.env.NODE_ENV='test';
process.env.MAIL_HOST='json'; // isolated in-memory mail transport for OTP tests
process.env.DB_PATH=path.join(TMP,'test.db');
process.env.REQUIRE_ORG_VERIFICATION='false';
process.env.UPLOAD_DIR=path.join(TMP,'uploads');
process.env.JWT_SECRET='mmc-ai-isolation-test-secret';
process.env.BCRYPT_ROUNDS='4';
const {migrate}=require('../src/migrate');
const {createApp}=require('../src/index');
const {closeDB}=require('../src/db');
let server,base;
const jar={};
async function call(user,method,url,body){
 const headers={...(jar[user]?{Cookie:jar[user]}:{})};
 let payload;
 if(body!==undefined){headers['Content-Type']='application/json';payload=JSON.stringify(body);}
 const r=await fetch(base+url,{method,headers,body:payload,redirect:'manual'});
 for(const c of (r.headers.getSetCookie?r.headers.getSetCookie():[])){
  const first=c.split(';')[0]; if(first.startsWith('tpkit_session=')) jar[user]=first;
 }
 const data=(r.headers.get('content-type')||'').includes('application/json')?await r.json():await r.text();
 return {status:r.status,data};
}
const uniq=()=>Math.random().toString(36).slice(2,10);
async function register(key){const email=key+uniq()+'@test.local';const r=await call(key,'POST','/api/auth/register',{name:key,email,password:'Password123',company:key});assert.equal(r.status,201,JSON.stringify(r.data));const db=require('../src/db').getDB();const user=db.prepare('SELECT id FROM users WHERE email=?').get(email);const now=Math.floor(Date.now()/1000);db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now,user.id);db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);const login=await call(key,'POST','/api/auth/login',{email,password:'Password123'});assert.equal(login.status,200,JSON.stringify(login.data));return user.id;}
test.before(async()=>{
 migrate(process.env.DB_PATH);
 const app=createApp();
 await new Promise(resolve=>{server=app.listen(0,'127.0.0.1',()=>{base='http://127.0.0.1:'+server.address().port;resolve();});});
});
test.after(async()=>{if(server)await new Promise(r=>server.close(r));closeDB();fs.rmSync(TMP,{recursive:true,force:true});});


test('demo project: created once, valid CPM, usable, landing served',async()=>{
 const uid1=await register('demo-user');
 const first=await call('demo-user','POST','/api/mmc-ai/demo-project');
 assert.equal(first.status,201,JSON.stringify(first.data));
 const pid=first.data.project.project_id||first.data.project.id;
 const again=await call('demo-user','POST','/api/mmc-ai/demo-project');
 assert.equal(again.status,200);assert.equal(again.data.reused,true);
 assert.equal(again.data.project.project_id||again.data.project.id,pid);
 const boq=await call('demo-user','GET','/api/mmc-ai/projects/'+pid+'/boq');
 assert.equal(boq.data.items.length,11);assert.ok(boq.data.summary.total>0);
 const sch=await call('demo-user','GET','/api/mmc-ai/projects/'+pid+'/schedule');
 assert.equal(sch.status,200,JSON.stringify(sch.data).slice(0,300));
 const days=sch.data.analysis?.projectDurationWorkingDays??sch.data.projectDuration??sch.data.summary?.projectDurationWorkingDays;
 assert.equal(days,7+10+4+20+25+20+22+15+20+7);
 const risks=await call('demo-user','GET','/api/mmc-ai/projects/'+pid+'/risks');
 assert.equal((risks.data.risks||risks.data.items).length,4);
 const list=await call('demo-user','GET','/api/mmc-ai/projects');
 assert.equal((list.data.projects||[]).filter(p=>String(p.name).includes('تجريبي')).length,1);
 const anon=await fetch(base+'/api/mmc-ai/demo-project',{method:'POST'});
 assert.ok([401,403].includes(anon.status));
 const page=await fetch(base+'/mmc-ai/start');
 assert.equal(page.status,200);assert.match(await page.text(),/المشروع التجريبي/);
 void uid1;
});
