'use strict';
/**
 * خادم بوابة العروض الفنية — المرحلة الأولى
 * Express + SQLite (better-sqlite3) + مصادقة JWT في httpOnly cookie.
 *
 * التشغيل:  npm start        (أو: node src/index.js)
 */
const fs = require('fs');
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const config = require('./config');
const { migrate } = require('./migrate');
const { errorHandler } = require('./lib/errors');

const authRoutes = require('./routes/auth');
const publicBrowseRoutes = require('./routes/public-browse');
const { router: tenderRoutes } = require('./routes/tenders');
const fileRoutes = require('./routes/files');
const accountRoutes = require('./routes/account');
const procurementRoutes = require('./routes/procurement');
const billingRoutes = require('./routes/billing');
const verificationRoutes = require('./routes/verification');
const orgRoutes = require('./routes/org');
const requestRoutes = require('./routes/requests');
const projectFinanceRoutes = require('./routes/project-finance');
const opportunitiesRoutes = require('./routes/opportunities');
const consultingRoutes = require('./routes/consulting');
const mmcAiRoutes = require('./routes/mmc-ai');
const mmcAiDocumentRoutes = require('./routes/mmc-ai-documents');
const mmcAiOcrRoutes = require('./routes/mmc-ai-ocr');
const mmcAiImageRoutes = require('./routes/mmc-ai-images');
const mmcAiTakeoffRoutes = require('./routes/mmc-ai-takeoff');
const mmcAiBoqRoutes = require('./routes/mmc-ai-boq');
const mmcAiScheduleRoutes = require('./routes/mmc-ai-schedule');
const mmcAiRiskRoutes = require('./routes/mmc-ai-risks');
const mmcAiContractEventRoutes = require('./routes/mmc-ai-contract-events');
const mmcAiBimRoutes = require('./routes/mmc-ai-bim');
const mmcAiBimModelRoutes = require('./routes/mmc-ai-bim-models');

function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: false, limit: '1mb' }));
  app.use(cookieParser());

  // ترويسات أمان أساسية
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    next();
  });

  // Optional fail-closed HTTP Basic Auth gate for public staging deployments.
  // Enable with STAGING_BASIC_AUTH_REQUIRED=true and set a private username/password.
  app.use((req, res, next) => {
    if (process.env.STAGING_BASIC_AUTH_REQUIRED !== 'true') return next();
    const expectedUser = String(process.env.STAGING_BASIC_AUTH_USER || '');
    const expectedPassword = String(process.env.STAGING_BASIC_AUTH_PASSWORD || '');
    if (!expectedUser || !expectedPassword) {
      res.setHeader('Cache-Control', 'no-store');
      return res.status(503).type('text').send('بيئة الاختبار مقفلة حتى يكتمل إعداد بيانات دخول الحماية.');
    }

    const authorization = String(req.headers.authorization || '');
    const match = /^Basic\s+([A-Za-z0-9+/=]+)$/i.exec(authorization);
    let suppliedUser = '';
    let suppliedPassword = '';
    if (match) {
      try {
        const decoded = Buffer.from(match[1], 'base64').toString('utf8');
        const separator = decoded.indexOf(':');
        if (separator >= 0) {
          suppliedUser = decoded.slice(0, separator);
          suppliedPassword = decoded.slice(separator + 1);
        }
      } catch (_) {}
    }
    const safeEqual = (actual, expected) => {
      const a = Buffer.from(actual);
      const b = Buffer.from(expected);
      return a.length === b.length && require('crypto').timingSafeEqual(a, b);
    };
    if (safeEqual(suppliedUser, expectedUser) && safeEqual(suppliedPassword, expectedPassword)) return next();

    res.setHeader('WWW-Authenticate', 'Basic realm="MMC AI staging", charset="UTF-8"');
    res.setHeader('Cache-Control', 'no-store');
    return res.status(401).type('text').send('يلزم تسجيل الدخول إلى بيئة الاختبار.');
  });

  // CORS اختياري — فقط إن كانت الواجهة على أصل مختلف
  if (config.CORS_ORIGIN) {
    app.use((req, res, next) => {
      res.setHeader('Access-Control-Allow-Origin', config.CORS_ORIGIN);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      if (req.method === 'OPTIONS') return res.sendStatus(204);
      next();
    });
  }

  const WEB_ROOT_HEALTH = config.WEB_ROOT || path.resolve(config.ROOT, '..', 'webpages', 'technical-proposal-kit_v5');

  /* ---------------- API ---------------- */
  // Strictly read-only, sanitized public listings; protected routers remain unchanged.
  app.use('/api/public', publicBrowseRoutes);
  app.get('/api/health', (req, res) => {
    const db = require('./db').getDB();
    const users = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
    const tenders = db.prepare('SELECT COUNT(*) AS n FROM tenders').get().n;
    res.json({
      ok: true, service: 'tpkit-portal', phase: 2, env: config.NODE_ENV,
      time: new Date().toISOString(),
      storage: { driver: config.STORAGE_DRIVER, signedUrlTtl: config.SIGNED_URL_TTL },
      scheduler: require('./lib/scheduler').schedulerStatus(),
      counts: { users, tenders },
      web: { // أعلام فقط — بلا مسارات الخادم
        rootExists: fs.existsSync(WEB_ROOT_HEALTH),
        login: fs.existsSync(path.join(WEB_ROOT_HEALTH, 'portal', 'pt-9f3c7a1e5b2d', 'login.html')),
        procurement: fs.existsSync(path.join(WEB_ROOT_HEALTH, 'procurement', 'index.html')),
        bid: fs.existsSync(path.join(WEB_ROOT_HEALTH, 'bid', 'index.html')),
        admin: fs.existsSync(path.join(WEB_ROOT_HEALTH, 'admin', 'index.html')),
        consultant: fs.existsSync(path.join(WEB_ROOT_HEALTH, 'consultant', 'index.html')),
        tenderDirectory: fs.existsSync(path.join(WEB_ROOT_HEALTH, 'tender-opportunities', 'index.html'))
      }
    });
  });

  /* بيانات الدفع للعرض في الصفحات — عامة وبلا أسرار */
  app.get('/api/payment-info', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({ payment: config.PAYMENT, ibanValid: config.PAYMENT_IBAN_VALID });
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/tenders', tenderRoutes);
  app.use('/api', fileRoutes);
  app.use('/api', accountRoutes);
  app.use('/api/billing', billingRoutes);
  app.use('/api/verification', verificationRoutes);
  app.use('/api/org', orgRoutes);
  app.use('/api/requests', requestRoutes);
  app.use('/api/project-finance', projectFinanceRoutes);
  app.use('/api/opportunities', opportunitiesRoutes);
  app.use('/api/procurement', procurementRoutes);
  app.use('/api/consulting', consultingRoutes);
  app.use('/api/mmc-ai', mmcAiRoutes);
  app.use('/api/mmc-ai', mmcAiDocumentRoutes);
  app.use('/api/mmc-ai', mmcAiOcrRoutes);
  app.use('/api/mmc-ai', mmcAiImageRoutes);
  app.use('/api/mmc-ai', mmcAiTakeoffRoutes);
  app.use('/api/mmc-ai', mmcAiBoqRoutes);
  app.use('/api/mmc-ai', mmcAiScheduleRoutes);
  app.use('/api/mmc-ai', mmcAiRiskRoutes);
  app.use('/api/mmc-ai', mmcAiContractEventRoutes.router);
  app.use('/api/mmc-ai', mmcAiBimRoutes);
  app.use('/api/mmc-ai', mmcAiBimModelRoutes);
  app.use('/api/committee', require('./routes/committee'));

  app.use('/api', (req, res) => {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'نقطة API غير موجودة: ' + req.method + ' ' + req.originalUrl } });
  });

  /* ---------------- الواجهة (صفحات البوابة والحزمة) ---------------- */
  // WEB_ROOT: جذر الملفات الثابتة. في المرحلة الأولى كان الخادم داخل مجلد الحزمة،
  // والآن أصبح مجلداً مستقلاً (portal-server-v5) — افتراضياً نخدم مجلد النسخة v5،
  // ويُضبط صراحةً عبر WEB_ROOT حين تُنشر الحزمة في مسار آخر.
  const WEB_ROOT = config.WEB_ROOT || path.resolve(config.ROOT, '..', 'webpages', 'technical-proposal-kit_v5');
  if (!fs.existsSync(WEB_ROOT)) {
    console.warn('  ⚠ WEB_ROOT غير موجود: ' + WEB_ROOT + ' — الواجهة لن تُخدم. اضبط WEB_ROOT.');
  }
  // المعاينة العامة لدورة الترسية والفواتير متاحة دون تسجيل دخول.
  // لا تعرض الصفحة العامة بيانات مالية خاصة؛ وتظل جميع عمليات القراءة/الكتابة الحساسة
  // محمية بصلاحيات API المستقلة، لذلك لا يمنح فتح الواجهة أي صلاحية تنفيذية.
  app.get(['/project-finance', '/project-finance/', '/project-finance/index.html'], (req, res, next) => {
    return sendFromWeb('project-finance/index.html', res, next);
  });

  // Independent consulting-firm portal entry. Keep it separate from the evaluator workspace at /consultant/.
  app.get(['/consulting', '/consulting/', '/consulting/index.html'], (req, res, next) => {
    // Public landing and directory are viewable without an account; all private firm actions
    // remain protected by the consulting API's authentication, role and tenant checks.
    return sendFromWeb('consulting/index.html', res, next);
  });

  // Legacy consultant browse URL now opens the full consulting-office portal, not the read-only market page.
  app.get('/public-browse/consultant.html', (req, res) => res.redirect(302, '/consulting/'));

  // Separate requester workspace for the consultancy marketplace; not the procurement portal.
  app.get(['/consulting/requester', '/consulting/requester/', '/consulting/requester/index.html'], (req, res, next) => {
    const A = require('./lib/auth');
    A.requireAuth(req, res, (err) => {
      if (err) return res.redirect(302, '/portal/pt-9f3c7a1e5b2d/login.html?next=/consulting/requester/');
      if (req.user.role !== 'buyer') return res.status(403).type('text').send('هذه المساحة مخصصة للجهات الطالبة للخدمات الاستشارية.');
      return sendFromWeb('consulting/requester/index.html', res, next);
    });
  });

  // Explicit entry route for the MMC tender directory.
  app.get(['/tender-opportunities', '/tender-opportunities/', '/tender-opportunities/index.html'], (req, res, next) => {
    return sendFromWeb('tender-opportunities/index.html', res, next);
  });

  // ملفات التنزيل (Excel/PDF) فقط من مجلد documents — بقية ملفاته داخلية ولا تُخدم أبداً
  const DOCS_ROOT = config.DOCS_ROOT || path.resolve(config.ROOT, '..', 'documents');
  app.use('/documents', (req, res, next) => {
    if (!/\.(xlsx|pdf)$/i.test(req.path)) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'غير موجود.' } });
    next();
  }, express.static(DOCS_ROOT, {
    index: false, dotfiles: 'deny',
    setHeaders: (res, filePath) => {
      if (/\.xlsx$/i.test(filePath)) {
        // بدون هذا الرأس لا تعرض المتصفحات المدمجة (مثل متصفح التطبيقات على الآيفون) شيئاً عند فتح ملف Excel
        res.setHeader('Content-Disposition', "attachment; filename*=UTF-8''" + encodeURIComponent(require('path').basename(filePath)));
      }
    }
  }));

  // مسارات صريحة للبوابات + /portal، مع رسالة 404 واضحة (دون كشف مسارات الخادم)
  function sendFromWeb(relPath, res, next) {
    const root = path.resolve(WEB_ROOT);
    const target = path.resolve(root, relPath);
    if (!target.startsWith(root + path.sep)) return res.status(400).type('text').send('Bad path');
    if (!fs.existsSync(target)) return res.status(404).type('text').send('File not found: /' + relPath.replace(/\\/g, '/'));
    // Explicit portal routes bypass express.static; prevent stale HTML from being retained by browsers or proxies.
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    return res.sendFile(target, (err) => { if (err) next(err); });
  }
  app.get(['/procurement', '/procurement/', '/procurement/index.html'], (req, res, next) => {
    const A = require('./lib/auth');
    A.requireAuth(req, res, (err) => {
      if (err) return sendFromWeb('procurement/index.html', res, next);
      return sendFromWeb('procurement/index.html', res, next);
    });
  });
  app.get(['/bid', '/bid/', '/bid/index.html'], (req, res, next) => {
    const A = require('./lib/auth');
    A.requireAuth(req, res, (err) => {
      if (err) return sendFromWeb('bid/index.html', res, next);
      return sendFromWeb('bid/index.html', res, next);
    });
  });
  app.get(['/admin', '/admin/', '/admin/index.html'], (req, res, next) => {
    const A = require('./lib/auth');
    A.requireAuth(req, res, (err) => {
      if (err) return res.redirect(302, '/portal/pt-9f3c7a1e5b2d/login.html?next=/admin/');
      if (req.user.role !== 'admin') return res.status(403).type('text').send('ليس لديك صلاحية الوصول إلى هذه الصفحة.');
      return sendFromWeb('admin/index.html', res, next);
    });
  });
  app.get(['/consultant', '/consultant/', '/consultant/index.html'], (req, res, next) => sendFromWeb('consultant/index.html', res, next));
  app.get(['/org', '/org/', '/org/index.html'], (req, res, next) => sendFromWeb('org/index.html', res, next));

  // MMC AI public landing preview. Private project workspace is separately authenticated.
  app.get(['/mmc-ai', '/mmc-ai/', '/mmc-ai/index.html'], (req, res, next) => {
    res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    return sendFromWeb('mmc-ai/index.html', res, next);
  });
  app.get(['/mmc-ai/start', '/mmc-ai/start/'], (req, res, next) => {
    res.setHeader('X-Robots-Tag', 'noindex, nofollow'); // remove at public launch
    return sendFromWeb('mmc-ai/landing.html', res, next);
  });
  app.get(['/mmc-ai/workspace', '/mmc-ai/workspace/'], (req, res, next) => {
    const A = require('./lib/auth');
    A.requireAuth(req, res, (err) => {
      if (err) return res.redirect(302, '/portal/pt-9f3c7a1e5b2d/login.html?next=/mmc-ai/workspace/');
      return sendFromWeb('mmc-ai/index.html', res, next);
    });
  });

  app.get(/^\/portal(\/.*)?$/, (req, res, next) => {
    let rel = req.path.replace(/^\/portal\/?/, '') || 'pt-9f3c7a1e5b2d/login.html';
    if (rel.endsWith('/')) rel += 'index.html';
    sendFromWeb(path.join('portal', rel), res, next);
  });

  // Static files must be last: protected HTML routes above must run first.
  // Otherwise express.static can serve /admin/index.html and /mmc-ai/index.html
  // before their authentication/authorization handlers are reached.
  app.use(express.static(WEB_ROOT, {
    extensions: ['html'],
    setHeaders: (res, filePath) => {
      if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
    }
  }));

  app.use(errorHandler);
  return app;
}

/** يبدأ الخادم بعد التهيئة */
function start() {
  fs.mkdirSync(config.UPLOAD_DIR, { recursive: true });
  fs.mkdirSync(config.BACKUP_DIR, { recursive: true });
  migrate(config.DB_PATH);              // idempotent

  // The verified GAM snapshot is curated in source control; import it after
  // migrations so new deployments populate the tender directory automatically.
  const gamSyncStartedAt = Date.now();
  try {
    const result = require('./lib/gam-curated-sync').syncGAMCurated();
    require('./lib/scheduler').persistOpportunitySync('amman', gamSyncStartedAt, { ok: true, ...result });
    console.log(`[GAM] snapshot imported: received=${result.received}, added=${result.added}, updated=${result.updated}, verified=${result.verifiedAt}`);
  } catch (err) {
    try { require('./lib/scheduler').persistOpportunitySync('amman', gamSyncStartedAt, { ok: false, error: err.message }); } catch (_) {}
    console.error('[GAM] snapshot import failed; server will continue:', err.message);
  }

  const jpmcSyncStartedAt = Date.now();
  try {
    const result = require('./lib/jpmc-curated-sync').syncJPMCCurated();
    require('./lib/scheduler').persistOpportunitySync('jpmc', jpmcSyncStartedAt, { ok: true, ...result });
    console.log(`[JPMC] verified snapshot imported: received=${result.received}, added=${result.added}, updated=${result.updated}, verified=${result.verifiedAt}`);
  } catch (err) {
    try { require('./lib/scheduler').persistOpportunitySync('jpmc', jpmcSyncStartedAt, { ok: false, error: err.message }); } catch (_) {}
    console.error('[JPMC] snapshot import failed; server will continue:', err.message);
  }

  const app = createApp();
  const server = app.listen(config.PORT, config.HOST, async () => {
    console.log('');
    console.log('  ╔══════════════════════════════════════════════════════════╗');
    console.log('  ║  بوابة العروض الفنية — الخادم يعمل  (المرحلة الثانية)    ║');
    console.log('  ╚══════════════════════════════════════════════════════════╝');
    console.log('  العنوان      : http://localhost:' + config.PORT);
    console.log('  البيئة       : ' + config.NODE_ENV);
    console.log('  قاعدة البيانات: ' + config.DB_PATH);
    console.log('  مشغّل التخزين : ' + config.STORAGE_DRIVER +
      (config.STORAGE_DRIVER === 's3' ? '  → ' + (config.S3_ENDPOINT || 'AWS S3') + ' / ' + config.S3_BUCKET : '  → ' + config.UPLOAD_DIR));
    console.log('  النسخ الاحتياطي: ' + config.BACKUP_DIR);

    // فحص التخزين عند الإقلاع — نُحذّر ولا نُسقط الخادم
    try {
      const store = require('./lib/storage').getStorage();
      const h = await store.health();
      console.log('  صحة التخزين  : ' + (h.ok ? '✓ متصل' : '✗ غير متاح — ' + JSON.stringify(h.detail)));
      if (!h.ok) console.log('  ⚠ الرفع/التحميل سيفشل حتى تُصلح إعدادات التخزين. راجع /api/health/storage');
    } catch (e) {
      console.log('  صحة التخزين  : ✗ خطأ في التهيئة — ' + e.message);
    }

    require('./lib/scheduler').startScheduler();

    console.log('  البوابة      : http://localhost:' + config.PORT + '/portal/pt-9f3c7a1e5b2d/login.html');
    console.log('  الملفات      : ' + (config.WEB_ROOT || path.resolve(config.ROOT, '..', 'webpages', 'technical-proposal-kit_v5')));
    if (config.IS_DEFAULT_SECRET) {
      console.log('  ⚠ JWT_SECRET افتراضي — عيّنه قبل أي استخدام حقيقي.');
    }
    console.log('');
  });

  const shutdown = (sig) => {
    console.log('\\n[' + sig + '] إيقاف الخادم...');
    server.close(() => {
      try { require('./db').closeDB(); } catch (_) {}
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  return server;
}

if (require.main === module) start();

module.exports = { createApp, start };
