# MMC AI — Construction Intelligence (v13, bug-fixed + standalone demo)

> Deterministic CAD/DXF takeoff + discipline classification + quantity rules
> for construction projects. Every output is `needs_review` — no quantities
> are invented without engineer sign-off.

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Status: Demo](https://img.shields.io/badge/Status-Standalone%20Demo%20v2-brightgreen)](#standalone-demo-mode)
[![Engine: deterministic](https://img.shields.io/badge/Engine-deterministic%20JS-orange)](#engines)

---

## Inspection pass — what was fixed in this build

This build was produced by a full inspection: the project was extracted,
installed, run, and every page opened in a real browser. Ten defects were
reproduced and fixed, and a regression test now pins each one
(`server/tests/mmc-ai-inspection-regressions.test.js`).

| # | Defect | Cause | Fix |
|---|--------|-------|-----|
| 1 | **Quantity Takeoff page was a dead placeholder** — no upload, no analysis, no results | The engine and the whole REST API existed, but the page only rendered a static "No verified quantities yet" table | Built a real takeoff UI: upload DXF → analyse → register table → approve → push to BOQ |
| 2 | **Standalone demo mode never loaded** | `index.html` never included `mmc-ai-bundle.js` / `mmc-ai-demo-backend.js`, and neither file was in the served directory | Added a guarded loader (only on `file://` or the preview port) and shipped both files next to the page |
| 3 | **Project dropdown showed "Could not load projects"** | The page's first `loadProjects()` ran before the demo `fetch` shim was installed, and the failed call overwrote the later success | Poll for the shim, re-run the load, and guard against stale responses with a generation counter |
| 4 | **A failed project open wiped the whole project list** | `selectProject()` was awaited inside the list-loading `try`, so any downstream error replaced the list with an error option | Moved selection out of that `try`; a failure now only shows a toast |
| 5 | **`/consultant` page was blank** | Inline script called `API.me()` before `api.js` was loaded → `API is not defined` | Load `api.js` and `i18n.js` before the inline script |
| 6 | **Every date was rejected** (schedule + correspondence) | Regex written `/^\\d{4}-\\d{2}-\\d{2}$/` inside a regex literal — matches a literal backslash | Corrected to `/^\d{4}-\d{2}-\d{2}$/` in both routes |
| 7 | **`/correspondence` returned HTTP 500** | `COALESCE(communication_date,"")` — SQLite reads `""` as an identifier, not a string | Single quotes, in both correspondence and contract-management |
| 8 | **Arabic console output was garbage** | 31 files carried cp850-mangled Arabic (double-encoded) | Reversed the encoding; a test now fails if it returns |
| 9 | **4 tests failed with "not a function"** | The spatial-extract test called `rotateBboxToSvgFrame` / `parseSvgPageFrame` without importing them | Added the imports |
| 10 | **Stale duplicate web root + nested ZIP** | `webpages/mmc-ai/` was a 108 KB leftover of the real 257 KB page; a 10 MB ZIP was shipped inside the archive | Removed both; the server only ever served `technical-proposal-kit_v5` |
| 11 | **Standalone demo mode still 404'd its own bundle** | The loader used absolute paths (`/mmc-ai-bundle.js`) but the files sit *next to the page* in `/mmc-ai/` | Switched to relative paths; a regression test now pins it |
| 12 | **Demo takeoff produced no discipline categories** | The demo backend stored raw rows without running the layer classifier, so BIM generation had nothing to build from | The demo backend now classifies each layer exactly as the server does |
| 13 | **Demo BIM download returned an error** | The demo router exposes the query string as `req.search`, but the route read `req.query`; and the GLB bytes were kept in JSON-serialised state | Read `req.search`; keep model files in an in-memory store |

**Test status:** 521 tests in the `mmc-ai` suite, **0 failures** (55 of them new
for BIM: 20 element-model, 14 IFC-writer, 16 GLB+link, 5 end-to-end over HTTP).
All 14 pages load with zero JavaScript errors and zero horizontal overflow at
1440 px and 390 px.

**External validation of the generated files** (not just our own inspector):

- `model.ifc` opened with **IfcOpenShell** — schema `IFC4`, 10 typed products,
  correct `IfcBuildingStorey`, 7 `IfcPropertySet`s.
- `model.glb` validated with the **Khronos glTF-Validator** — 0 errors,
  0 warnings; and parsed by **three.js GLTFLoader** — 7 meshes, 1176 vertices.
- The 3D preview was confirmed rendering in a real Chromium browser.

---

## BIM generation from takeoff — new in this build

The takeoff engine now produces a **BIM model** (IFC4 + GLB) from the reviewed
takeoff run, with a 3D preview inside the page and a two-way link between the
model and the BOQ.

### How it works

```
reviewed takeoff run  →  bim-element-model.js  →  ifc-writer.js  →  model.ifc
                                              └→  glb-writer.js  →  model.glb
                                              └→  bim-link.js    →  BOQ ↔ element index
```

1. Open **Quantity Takeoff** (`?page=takeoff`) and load a run.
2. The **BIM Model from Takeoff** panel appears with one dimension box per
   element category found in the drawing (footings, columns, beams, slabs,
   walls, pipes, ducts, fixtures …).
3. Fill the heights and thicknesses the drawing does not state, then press
   **Generate BIM Model**.
4. The model appears in a 3D viewer. **Download IFC** and **Download GLB** are
   next to it.
5. In the BOQ table, any item created from a takeoff item shows a
   **Show in model** button that highlights its element.

### The honesty rule

The engine **never invents a dimension**. An element is emitted only when the
drawing gives a measurable footprint *and* a height that is either measured on
the drawing or supplied by the engineer. Everything else is listed under
**Not built** with the reason:

| Reason | Meaning |
|--------|---------|
| `height_not_measured_or_supplied` | The drawing has no height and none was entered |
| `linear_width_not_supplied` | A pipe/duct/beam run with no diameter or width |
| `diagonal_run_not_axis_aligned` | A diagonal run — not forced into a bounding box |
| `closed_footprint_not_rectangular` | A non-rectangular closed shape |
| `arc_geometry_not_supported` | Curved geometry |
| `category_is_not_geometry` | Reinforcement, annotations, hatch patterns |
| `counted_element_has_no_placement` | A fixture with no coordinates |

### What the files contain

**IFC4** (`model.ifc`) — a schema-valid STEP file: `IfcProject → IfcSite →
IfcBuilding → IfcBuildingStorey`, SI units, one typed product per element
(`IfcFooting`, `IfcColumn`, `IfcBeam`, `IfcSlab`, `IfcWall`, `IfcDoor`,
`IfcWindow`, `IfcPipeSegment`, `IfcDuctSegment`, `IfcLightFixture`, `IfcPump`,
`IfcChiller`, `IfcFireSuppressionTerminal`, …), `IfcExtrudedAreaSolid` geometry
from an `IfcRectangleProfileDef`, containment in the storey, and an
`MMC_Provenance` property set on every element carrying the source takeoff
item, CAD layer, entity index and formula. GUIDs are derived from a hash of the
element identity, so re-generating the same run yields a byte-identical file.

**GLB** (`model.glb`) — binary glTF 2.0, one node per element named with the
element id, one colour-coded material per discipline, and `extras` on each node
carrying the element id, category, discipline, volume and source takeoff item
so the page can map a node back to a BOQ row without a second request.

### API

| Method | Path | Purpose |
|--------|------|---------|
| `POST` | `/api/mmc-ai/projects/:id/takeoff/runs/:runId/bim` | Generate a model |
| `GET`  | `/api/mmc-ai/projects/:id/bim/generated` | List generated models |
| `GET`  | `/api/mmc-ai/projects/:id/bim/generated/:modelId` | Model + elements + BOQ links |
| `GET`  | `/api/mmc-ai/projects/:id/bim/generated/:modelId/download?format=ifc\|glb` | Download |
| `GET`  | `/api/mmc-ai/projects/:id/bim/generated/:modelId/by-boq/:boqItemId` | Elements for a BOQ line |

### Limits — read before contractual use

- Geometry is limited to **axis-aligned extruded prisms** derived from 2D
  evidence. Diagonal runs, arcs and non-rectangular shapes are reported, not
  approximated.
- Heights come from the drawing or from the engineer's inputs — never invented.
- Reinforcement, annotations and hatch patterns are not converted to geometry.
- The model is a **coordination aid** and requires engineer review before
  contractual use.

### Tests

`server/tests/mmc-ai-bim-element-model.test.js`,
`mmc-ai-bim-ifc-writer.test.js`, `mmc-ai-bim-glb-and-link.test.js` (unit) and
`mmc-ai-bim-generate-api.test.js` (end-to-end over HTTP: register → project →
DXF → takeoff → generate → download → validate → link). The IFC is validated
with the project's own inspector and the GLB with a container check.

---

## توليد نموذج BIM من الحصر — جديد في هذا الإصدار

صار محرّك الحصر يُنتج **نموذج BIM** (IFC4 + GLB) من نتيجة الحصر المعتمدة، مع
معاينة ثلاثية الأبعاد داخل الصفحة وربط ثنائي الاتجاه بين النموذج وجدول الكميات.

### كيف يعمل

1. افتح **حصر الكميات** (`?page=takeoff`) وحمّل نتيجة حصر.
2. تظهر لوحة **BIM Model from Takeoff** وفيها صندوق أبعاد لكل فئة عناصر
   موجودة في المخطط (أساسات، أعمدة، جسور، بلاطات، جدران، مواسير، مجاري، أدوات…).
3. أدخل الارتفاعات والسماكات التي لا يذكرها المخطط، ثم اضغط **Generate BIM Model**.
4. يظهر النموذج في عارض ثلاثي الأبعاد، وبجانبه **Download IFC** و**Download GLB**.
5. في جدول الكميات، أي بند أُنشئ من بند حصر يظهر له زر **Show in model**
   يُبرز العنصر المقابل في النموذج.

### قاعدة الأمانة

المحرّك **لا يخترع أي بُعد**. لا يُنتج عنصراً إلا إذا أعطى المخطط مسقطاً قابلاً
للقياس **و** ارتفاعاً مقيساً على المخطط أو مُدخلاً من المهندس. وكل ما عدا ذلك
يُدرج تحت **Not built** مع السبب (ارتفاع غير متوفر، عرض خطي غير مُدخل، مسار
مائل، شكل غير مستطيل، قوس، بند غير هندسي كالحديد والتظليل، عنصر معدود بلا إحداثيات).

### ما تحتويه الملفات

**IFC4** — ملف STEP صالح: هيكل مكاني كامل (مشروع ← موقع ← مبنى ← طابق)، وحدات
SI، ومنتج مُصنّف لكل عنصر، وهندسة `IfcExtrudedAreaSolid` من مقطع مستطيل، وربط
العناصر بالطابق، ومجموعة خصائص `MMC_Provenance` على كل عنصر تحمل بند الحصر
المصدر والطبقة وفهرس الكيان والمعادلة. المعرّفات GUID مشتقة من بصمة هوية العنصر،
فإعادة التوليد لنفس النتيجة تُنتج ملفاً مطابقاً بايت ببايت.

**GLB** — glTF 2.0 ثنائي، عقدة لكل عنصر باسم معرّفه، ومادة ملوّنة لكل تخصص،
و`extras` على كل عقدة تحمل المعرّف والفئة والتخصص والحجم وبند الحصر المصدر.

### الحدود — اقرأها قبل الاستخدام التعاقدي

- الهندسة محصورة في **منشورات متعامدة** مشتقة من دليل ثنائي الأبعاد. المسارات
  المائلة والأقواس والأشكال غير المستطيلة تُبلَّغ ولا تُقرَّب.
- الارتفاعات من المخطط أو من مدخلات المهندس — لا تُخترع.
- حديد التسليح والملاحظات وأنماط التظليل لا تُحوَّل إلى هندسة.
- النموذج **أداة تنسيق** ويحتاج مراجعة مهندس قبل الاستخدام التعاقدي.

---

## What this is

A patch bundle for an existing mmc-ai v13 server, plus a **standalone
browser-only demo mode** that runs the full takeoff pipeline without any
Node.js / SQLite / v13 backend.

| Layer | What it does |
|-------|-------------|
| **Engines** (pure JS, no Node APIs) | DXF geometry parsing, layer→discipline classification, engineering quantity rules |
| **Server route** (for v13 integration) | REST API: `/api/mmc-ai/projects/:id/documents/:docId/takeoff/dxf`, `/disciplines`, `/quantity-rules`, `/review`, etc. |
| **Standalone demo** (browser-only) | `fetch` shim that intercepts `/api/mmc-ai/*` calls and routes them to in-browser engines + localStorage |
| **Takeoff UI** | Upload a DXF, review the register, approve it, push the items into the BOQ |
| **Images** | 12 neubuild.ai-style royalty-free images auto-injected into page placeholders |

## Using the Quantity Takeoff page

Open **Workspace → Quantity Takeoff** (`?page=takeoff`).

1. Pick a project in the project selector (top of the page).
2. Click **⇧ Upload DXF & analyse** and choose a `.dxf` file (max 25 MB).
3. The engine parses the drawing and fills the register: layer, entity type,
   quantity, unit, and a per-discipline summary (structural, architectural,
   electrical, mechanical).
4. Every row starts as **needs review**. Click **Approve run** to sign it off.
5. Click **Add items to BOQ** to copy the approved rows into the bill of
   quantities (rate 0 — set prices in *BOQ & Cost Estimate*).

Quantities are raw CAD measurements. They are not net quantities until a
quantity rule is applied and an engineer approves them — the page says so
explicitly, and the engine's own limitations are listed under the summary.

## Quick start (standalone demo mode)

```bash
# 1. Extract the zip
unzip mmc-ai-v13-fixed-v2.zip -d mmc-ai-v13-fixed
cd mmc-ai-v13-fixed

# 2. Run the local preview server (Python 3, no dependencies)
python3 serve_preview.py
# Windows: py serve_preview.py  (or python serve_preview.py)

# 3. Open in browser
# http://localhost:8807/mmc-ai/workspace
```

You'll see a green banner: "وضع تجريبي مستقل (Standalone Demo v2)".

### What works in demo mode

- ✅ Create / list / select projects (localStorage)
- ✅ Upload DXF files (in-memory)
- ✅ DXF takeoff: LINE / LWPOLYLINE / CIRCLE / ARC / INSERT (block expansion)
- ✅ Discipline classification: 9 disciplines, 50+ categories
- ✅ Quantity rules: 25 rules across 8 disciplines (walls, columns, beams,
  slabs, foundations, ducts, cables, pipes, sprinklers, hydrants, roads,
  excavation, trees, irrigation, etc.)
- ✅ Wall net area with opening deductions (with min-deduction threshold)
- ✅ Run review (approve / reject)
- ✅ **BOQ CSV import** — supports comma + semicolon, quoted fields,
  Arabic + English headers
- ✅ Manual BOQ item entry
- ✅ 12 neubuild.ai-style images auto-injected

### What does NOT work in demo mode

- ❌ PDF takeoff (needs `pdftotext` server-side)
- ❌ BIM / IFC / GLB upload (needs file storage)
- ❌ User layer management (POST/PATCH/DELETE on layers)
- ❌ AI assistant

These return clean JSON errors (`DEMO_LIMIT` / `DEMO_NOT_IMPLEMENTED`)
instead of crashing the page.

## Engines

| Module | Purpose | Lines |
|--------|---------|-------|
| `discipline-layer-classifier.js` | Maps CAD layer names → 9 disciplines + 50+ categories. AIA/NCS prefixes + Arabic/English keyword tables. | ~360 |
| `discipline-measurement-kernels.js` | Math kernels: masonry walls (with opening deductions), rectangular ductwork, routed services (pipes/cables). | ~110 |
| `discipline-quantity-rules.js` | 25 rules that convert classified CAD rows into *proposed* engineering quantities with explicit formulas + assumptions. | ~775 |
| `dxf-takeoff.js` | ASCII DXF parser: LINE / LWPOLYLINE / classic POLYLINE / CIRCLE / ARC / INSERT (with block expansion + transforms). $INSUNITS handling. | ~400 |
| `drawing-element-normalizer.js` | Converts measured primitives into traceable engineering candidates with explicit layer maps. | ~130 |
| `demo-project.js` | Illustrative demo BOQ + schedule + risks for first-time users. | ~85 |
| `mmc-ai-takeoff.js` | Express routes wiring the engines into the v13 REST API (with auth + audit + transactions). | ~230 |

## Bug fixes applied (vs upstream v13-improved-merge)

| # | Bug | Severity | Fix |
|---|-----|----------|-----|
| 1 | `disciplines.length` ReferenceError in UI button | 🔴 Critical | Use `data.disciplines.length` |
| 2 | BACKFILL / EARTH-FILL excluded as annotation | 🔴 Critical | Early backfill rule + `\bFILL\b` boundary |
| 3 | Arabic "ري" substring false matches (طريق, مجاري, خريطة, مريض) | 🔴 Critical | Removed bare "ري", added specific singulars |
| 4 | HYDRANT-MAIN → unclassified | 🟠 High | Added `HYDR` to fire_protection keyword |
| 5 | GEN-PUMP → unclassified | 🟠 High | Added English `PUMP` to mechanical keyword |
| 6 | جدران (plural) → unclassified | 🟡 Medium | Added plural form to walls + architectural |
| 7 | `/boq-imports` not implemented in demo backend | 🟠 High | NEW: full CSV parser + localStorage store |

See [`CHANGELOG-FIXES.md`](CHANGELOG-FIXES.md) for the full per-fix trace
(Arabic, with test results before/after).

## Project structure

```
mmc-ai-v13-fixed/
├── .gitignore
├── LICENSE                         ← MIT
├── README.md                       ← this file
├── README-FIXES.md                 ← detailed setup (English)
├── CHANGELOG-FIXES.md              ← detailed changelog (Arabic)
├── RELEASE_NOTES.md                ← copy-paste release description
├── serve_preview.py                ← local preview server
├── server/
│   └── src/
│       ├── lib/mmc-ai/
│       │   ├── discipline-layer-classifier.js    ← BUG-FIXED
│       │   ├── discipline-measurement-kernels.js
│       │   ├── discipline-quantity-rules.js
│       │   ├── drawing-element-normalizer.js
│       │   ├── dxf-takeoff.js
│       │   └── demo-project.js
│       └── routes/mmc-ai-takeoff.js
└── webpages/technical-proposal-kit_v5/mmc-ai/
    ├── index.html                  ← Full standalone dashboard (NEW)
    ├── mmc-ai-bundle.js            ← engines + image injection (auto-gen, 79 KB)
    ├── mmc-ai-demo-backend.js      ← fetch shim + boq-imports (26 KB)
    └── assets/                     ← 12 neubuild.ai-style images (2 MB)
        ├── hero-construction-site-{1,2,3}.jpg
        ├── worker-ar-tech-{1,2,3}.jpg
        ├── bim-model-screen-{1,2,3}.jpg
        └── dashboard-gantt-{1,2,3}.{png,jpg}
```

## Deployment

### Option A — Use as a patch on existing v13 server

Copy the server-side files over your v13 installation:

```bash
cp server/src/lib/mmc-ai/discipline-layer-classifier.js  /path/to/v13/server/src/lib/mmc-ai/
cp server/src/lib/mmc-ai/discipline-quantity-rules.js     /path/to/v13/server/src/lib/mmc-ai/
# ... etc for the other engine files
cp server/src/routes/mmc-ai-takeoff.js                    /path/to/v13/server/src/routes/
```

Restart the v13 server. No DB migration needed.

### Option B — Standalone demo mode (no backend)

See [Quick start](#quick-start-standalone-demo-mode) above.

### Option C — Publish to GitHub

1. Create a new repo (or use an existing one)
2. Push the entire `mmc-ai-v13-fixed/` folder
3. Tag a release using the description in `RELEASE_NOTES.md`

## Verification

7/7 end-to-end tests pass under a Node-simulated browser environment:

```
1. Create project            → 201 ✓
2. BOQ import (null pid)     → 400 NO_PROJECT (bilingual) ✓
3. BOQ import (valid CSV)    → 201 imported=3 ✓
4. List BOQ                  → 200 3 items ✓
5. Project summary           → boqItems=3, cost=39925 ✓
6. Manual BOQ add            → 201 amount=11520 ✓
7. DXF takeoff               → 201 1 item ✓
```

Classifier regression tests: 10/10 critical edge cases pass
(BACKFILL, EARTH-FILL, HYDRANT-MAIN, HYDRANT-F1, GEN-PUMP, مجاري,
طريق, جدران, خريطة, مريض).

## Engineering philosophy

Every quantity produced by this system carries:

- `status: 'proposed' | 'incomplete'` (never `'approved'` automatically)
- `reviewState: 'needs_review' | 'needs_inputs'`
- `approvalEligible: false`
- An `assumptions[]` array documenting every input and inference
- A `limitations[]` array listing what was NOT included
- A `formula` string showing the math applied
- A `ruleId` linking back to the rule that produced it

Missing inputs (height, thickness, diameter, typical door sizes) cause the
output to be `incomplete` with a `reason` — never guessed.

Approved quantities can only come from the `/review` endpoint, which
requires `owner`, `project_manager`, or `reviewer` role.

## ملخّص بالعربية

هذه النسخة نتجت عن فحص كامل للمشروع: فُكّ الضغط، ثُبّتت الحزم، شُغّل الخادم،
وفُتحت كل الصفحات في متصفح حقيقي. أُعيد إنتاج عشرة أعطال وأُصلحت جميعها،
ولكل عطل اختبار انحدار يمنع عودته
(`server/tests/mmc-ai-inspection-regressions.test.js`).

**أهم ما أُصلح:**

1. **صفحة حصر الكميات كانت فارغة تماماً** — المحرّك وواجهة الـAPI موجودان، لكن
   الصفحة كانت تعرض جدولاً ثابتاً بلا رفع ولا تحليل. بُنيت واجهة حقيقية:
   رفع DXF ← تحليل ← جدول مراجعة ← اعتماد ← إضافة إلى جدول الكميات.
2. **الوضع التجريبي المستقل لم يكن يعمل** — الصفحة لم تكن تحمّل ملفات الحزمة
   أصلاً، ولم تكن موجودة في المجلد المخدوم.
3. **قائمة المشاريع كانت تعرض «تعذّر تحميل المشاريع»** — أول نداء يسبق تثبيت
   طبقة المحاكاة، والنداء الفاشل كان يطمس النتيجة الناجحة.
4. **فشل فتح مشروع كان يمحو القائمة كلها** — نُقل اختيار المشروع خارج كتلة
   `try` الخاصة بتحميل القائمة.
5. **صفحة `/consultant` كانت فارغة** — السكربت يستدعي `API.me()` قبل تحميل
   `api.js`.
6. **كل تاريخ كان يُرفض** (الجدول الزمني والمراسلات) — تعبير نمطي مزدوج
   التهريب.
7. **`/correspondence` كان يعيد خطأ 500** — علامات اقتباس مزدوجة داخل SQL.
8. **النص العربي في الطرفية كان مشوّهاً** — 31 ملفاً بترميز مزدوج، عُكس.
9. **4 اختبارات كانت تفشل** — دوال مستخدمة بلا استيراد.
10. **مجلد ويب مكرّر قديم + ملف ZIP متداخل** — حُذفا.

**حالة الاختبارات:** 279 اختباراً في حزمة `mmc-ai`، **صفر فشل** (منها 10
اختبارات انحدار جديدة). وكل الصفحات الـ14 تُحمّل بلا أخطاء JavaScript وبلا
فائض أفقي على 1440 و390 بكسل.

**طريقة استخدام صفحة حصر الكميات:**

1. افتح **Workspace ← Quantity Takeoff** (`?page=takeoff`).
2. اختر المشروع من منتقي المشاريع أعلى الصفحة.
3. اضغط **⇧ Upload DXF & analyse** واختر ملف `.dxf` (بحد أقصى 25 م.ب).
4. يملأ المحرّك الجدول: الطبقة، نوع العنصر، الكمية، الوحدة، وملخّص لكل تخصص
   (إنشائي، معماري، كهربائي، ميكانيكي).
5. كل بند يبدأ بحالة **needs review**. اضغط **Approve run** للاعتماد.
6. اضغط **Add items to BOQ** لنسخ البنود المعتمدة إلى جدول الكميات (السعر صفر —
   عدّله في *BOQ & Cost Estimate*).

الكميات هي قياسات CAD خام، وليست كميات صافية حتى تُطبَّق قاعدة قياس ويعتمدها
مهندس — والصفحة تصرّح بذلك، وتُدرج حدود المحرّك تحت الملخّص.

## License

MIT — see [`LICENSE`](LICENSE). The engineering notice in the license
clarifies that all output is proposed/draft and requires engineer review
before contractual use.

## Credits

- Engines, demo backend, bug fixes, standalone mode: built and verified
  through deterministic testing.
- Images: royalty-free stock via ZAI in-house image search (Shutterstock,
  Alamy, LinkedIn, Milwaukee Tool, Strand Consulting, W. Bradley Electric,
  Powerslides, Lark, Wrike, Economic Times).
- Inspired by [neubuild.ai](https://www.neubuild.ai) visual style for
  construction-intelligence SaaS.
