'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { writeGlb, boxGeometry, DISCIPLINE_COLORS } = require('../src/lib/mmc-ai/glb-writer');
const { buildLinkIndex, elementsForBoqItem, boqItemsForElement } = require('../src/lib/mmc-ai/bim-link');

function element(over) {
  return Object.assign({
    id: 'bime_0001', category: 'columns', kind: 'column', discipline: 'structural',
    label: { ar: 'عمود', en: 'Column' }, volumeM3: 0.27, baseM: 0, topM: 3,
    footprint: { minX: 0, minY: 0, maxX: 0.3, maxY: 0.3, width: 0.3, depth: 0.3 },
    centroid: { x: 0.15, y: 0.15 },
    source: { takeoffItemId: 't1', layer: 'S-COLS' }
  }, over);
}

/** Minimal GLB reader: validates the container and returns the JSON chunk. */
function readGlb(buf) {
  const bytes = Buffer.from(buf.buffer || buf, buf.byteOffset || 0, buf.length);
  assert.equal(bytes.toString('ascii', 0, 4), 'glTF', 'magic must be glTF');
  assert.equal(bytes.readUInt32LE(4), 2, 'version must be 2');
  assert.equal(bytes.readUInt32LE(8), bytes.length, 'declared length must match the file');
  const jsonLen = bytes.readUInt32LE(12);
  assert.equal(bytes.toString('ascii', 16, 20), 'JSON');
  const json = JSON.parse(bytes.toString('utf8', 20, 20 + jsonLen));
  const binOffset = 20 + jsonLen;
  const binLen = bytes.readUInt32LE(binOffset);
  assert.equal(bytes.toString('ascii', binOffset + 4, binOffset + 8), 'BIN\0');
  return { json, bin: bytes.subarray(binOffset + 8, binOffset + 8 + binLen) };
}

test('boxGeometry produces 24 vertices and 36 indices', () => {
  const g = boxGeometry(element());
  assert.equal(g.positions.length, 24 * 3);
  assert.equal(g.normals.length, 24 * 3);
  assert.equal(g.indices.length, 36);
});

test('boxGeometry refuses degenerate geometry', () => {
  assert.equal(boxGeometry(element({ heightM: 0, topM: 0 })), null);
  assert.equal(boxGeometry(element({ footprint: { minX: 0, maxX: 0, minY: 0, maxY: 1, width: 0, depth: 1 } })), null);
});

test('writes a valid GLB container', () => {
  const glb = writeGlb({ elements: [element()] });
  const { json } = readGlb(glb);
  assert.equal(json.asset.version, '2.0');
  assert.equal(json.meshes.length, 1);
  assert.equal(json.nodes.length, 1);
});

test('one node per element, named with the element id', () => {
  const glb = writeGlb({ elements: [element(), element({ id: 'bime_0002', discipline: 'architectural' })] });
  const { json } = readGlb(glb);
  assert.deepEqual(json.nodes.map((n) => n.name), ['bime_0001', 'bime_0002']);
});

test('node extras carry the takeoff link so the UI can map back to a BOQ row', () => {
  const glb = writeGlb({ elements: [element()] });
  const { json } = readGlb(glb);
  assert.equal(json.nodes[0].extras.sourceTakeoffItemId, 't1');
  assert.equal(json.nodes[0].extras.category, 'columns');
  assert.equal(json.nodes[0].extras.discipline, 'structural');
});

test('one material per discipline, colour-coded', () => {
  const glb = writeGlb({ elements: [element(), element({ id: 'b2', discipline: 'electrical' }), element({ id: 'b3', discipline: 'structural' })] });
  const { json } = readGlb(glb);
  assert.equal(json.materials.length, 2);
  assert.deepEqual(json.materials[0].pbrMetallicRoughness.baseColorFactor, DISCIPLINE_COLORS.structural);
});

test('accessors declare min/max so viewers can frame the model', () => {
  const glb = writeGlb({ elements: [element()] });
  const { json } = readGlb(glb);
  const pos = json.accessors[0];
  assert.equal(pos.type, 'VEC3');
  assert.equal(pos.count, 24);
  assert.equal(pos.min.length, 3);
  assert.equal(pos.max.length, 3);
});

test('the binary chunk is non-empty and matches the declared buffer length', () => {
  const glb = writeGlb({ elements: [element()] });
  const { json, bin } = readGlb(glb);
  assert.equal(bin.length, json.buffers[0].byteLength);
  assert.ok(bin.length > 0);
});

test('an empty element list still produces a valid, parseable GLB', () => {
  const glb = writeGlb({ elements: [] });
  const { json } = readGlb(glb);
  assert.equal(json.nodes.length, 0);
  assert.equal(json.meshes.length, 0);
});

test('is deterministic for the same input', () => {
  const a = writeGlb({ elements: [element()] });
  const b = writeGlb({ elements: [element()] });
  assert.deepEqual(Array.from(a), Array.from(b));
});

// ── Link mapper ─────────────────────────────────────────────────────────────

test('links a BOQ item to the element built from its takeoff item', () => {
  const idx = buildLinkIndex([element()], [{ id: 'b1', source_takeoff_item_id: 't1' }]);
  assert.deepEqual(elementsForBoqItem(idx, 'b1'), ['bime_0001']);
  assert.deepEqual(boqItemsForElement(idx, 'bime_0001'), ['b1']);
});

test('reports a BOQ item with no geometry instead of inventing a link', () => {
  const idx = buildLinkIndex([element()], [{ id: 'b2', source_takeoff_item_id: 't9' }]);
  assert.deepEqual(elementsForBoqItem(idx, 'b2'), []);
  assert.equal(idx.summary.unlinkedBoqItems, 1);
});

test('reports elements that are not yet priced', () => {
  const idx = buildLinkIndex(
    [element(), element({ id: 'bime_0002', source: { takeoffItemId: 't2', layer: 'S-COLS' } })],
    [{ id: 'b1', source_takeoff_item_id: 't1' }]
  );
  assert.equal(idx.summary.elementsWithoutBoq, 1);
  assert.equal(idx.summary.linkedBoqItems, 1);
});

test('one takeoff item can drive several elements and several BOQ items', () => {
  const idx = buildLinkIndex(
    [element(), element({ id: 'bime_0002' })],
    [{ id: 'b1', source_takeoff_item_id: 't1' }, { id: 'b2', source_takeoff_item_id: 't1' }]
  );
  assert.deepEqual(elementsForBoqItem(idx, 'b1'), ['bime_0001', 'bime_0002']);
  assert.deepEqual(boqItemsForElement(idx, 'bime_0001'), ['b1', 'b2']);
});

test('unknown ids resolve to an empty list rather than throwing', () => {
  const idx = buildLinkIndex([], []);
  assert.deepEqual(elementsForBoqItem(idx, 'nope'), []);
  assert.deepEqual(boqItemsForElement(idx, 'nope'), []);
  assert.deepEqual(elementsForBoqItem(null, 'nope'), []);
});

test('accepts the camelCase takeoff link used by the API layer', () => {
  const idx = buildLinkIndex([element()], [{ id: 'b1', sourceTakeoffItemId: 't1' }]);
  assert.deepEqual(elementsForBoqItem(idx, 'b1'), ['bime_0001']);
});
