'use strict';
/**
 * Integration test — BIM generation over the real HTTP API.
 *
 * Boots the actual server on a random port with a temporary database, then:
 *   register → create project → upload a DXF → run takeoff → generate BIM
 *   → list models → fetch model detail → download IFC → download GLB
 *   → create a BOQ item from a takeoff item → resolve it to an element.
 *
 * The IFC is validated with the project's own inspector and the GLB with a
 * container check, so a passing test means the files really open.
 */
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mmc-bim-test-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json';
process.env.DB_PATH = path.join(TMP, 'test.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false';
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'test-secret-not-for-production';
process.env.BCRYPT_ROUNDS = '4';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { getDB, closeDB } = require('../src/db');
const { parseIfc } = require('../src/lib/mmc-ai/ifc-inspector');

let server, base, cookie = '';

async function call(method, p, { body, form } = {}) {
  const h = {};
  if (cookie) h.Cookie = cookie;
  let payload;
  if (form) payload = form;
  else if (body !== undefined) { h['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const res = await fetch(base + p, { method, headers: h, body: payload, redirect: 'manual' });
  const setCookie = res.headers.getSetCookie ? res.headers.getSetCookie() : [res.headers.get('set-cookie')].filter(Boolean);
  for (const c of setCookie) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) cookie = first;
  }
  const ct = res.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await res.json() : await res.arrayBuffer();
  return { status: res.status, data, headers: res.headers };
}


/** Registers a user, marks the account active (bypassing MMC review), and logs in. */
async function registerAndLogin(email, name) {
  const reg = await call('POST', '/api/auth/register', { body: { name, email, password: 'Str0ngPass!23', company: 'Test Co' } });
  assert.ok([200, 201].includes(reg.status), 'register failed: ' + JSON.stringify(reg.data));
  const db = getDB();
  const user = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(Math.floor(Date.now() / 1000), user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);
  const login = await call('POST', '/api/auth/login', { body: { email, password: 'Str0ngPass!23' } });
  assert.equal(login.status, 200, 'login failed: ' + JSON.stringify(login.data));
  return user.id;
}

/** A minimal but valid DXF with structural layers and real geometry. */
function sampleDxf() {
  const lines = [];
  const push = (...v) => lines.push(...v);
  push('0', 'SECTION', '2', 'HEADER', '9', '$INSUNITS', '70', '6', '0', 'ENDSEC');
  push('0', 'SECTION', '2', 'ENTITIES');
  // 2 footings (1.5 × 1.5 closed polylines)
  for (const [x, y] of [[0, 0], [4, 0]]) {
    push('0', 'LWPOLYLINE', '8', 'S-FNDN', '90', '4', '70', '1');
    push('10', String(x), '20', String(y), '10', String(x + 1.5), '20', String(y),
      '10', String(x + 1.5), '20', String(y + 1.5), '10', String(x), '20', String(y + 1.5));
  }
  // 2 columns (0.3 × 0.3)
  for (const [x, y] of [[0.6, 0.6], [4.6, 0.6]]) {
    push('0', 'LWPOLYLINE', '8', 'S-COLS', '90', '4', '70', '1');
    push('10', String(x), '20', String(y), '10', String(x + 0.3), '20', String(y),
      '10', String(x + 0.3), '20', String(y + 0.3), '10', String(x), '20', String(y + 0.3));
  }
  // 1 beam (line)
  push('0', 'LINE', '8', 'S-BEAM', '10', '0', '20', '0.75', '11', '5.7', '21', '0.75');
  // 1 slab (6 × 6)
  push('0', 'LWPOLYLINE', '8', 'S-SLAB', '90', '4', '70', '1');
  push('10', '0', '20', '0', '10', '6', '20', '0', '10', '6', '20', '6', '10', '0', '20', '6');
  // 1 wall (line)
  push('0', 'LINE', '8', 'A-WALL', '10', '0', '20', '0', '11', '6', '21', '0');
  push('0', 'ENDSEC', '0', 'EOF');
  return lines.join('\n');
}

test.before(async () => {
  migrate();
  const app = createApp();
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { base = 'http://127.0.0.1:' + server.address().port; resolve(); });
  });
});

test.after(async () => {
  if (server) await new Promise((r) => server.close(r));
  try { closeDB(); } catch (_) {}
  fs.rmSync(TMP, { recursive: true, force: true });
});

test('full BIM flow: register → project → DXF takeoff → generate → download → link', async () => {
  // 1. Register + verify + login
  await registerAndLogin('bim' + Date.now() + '@example.com', 'BIM Tester');

  // 2. Create a project
  const proj = await call('POST', '/api/mmc-ai/projects', { body: { name: 'BIM Integration Tower', country: 'JO', currency: 'JOD' } });
  assert.equal(proj.status, 201, 'project create failed: ' + JSON.stringify(proj.data));
  const projectId = proj.data.project.project_id || proj.data.project.id;

  // 3. Upload the DXF as a project document
  const form = new FormData();
  form.append('file', new Blob([sampleDxf()], { type: 'application/dxf' }), 'plan.dxf');
  const up = await call('POST', '/api/mmc-ai/projects/' + projectId + '/documents', { form });
  assert.ok([200, 201].includes(up.status), 'upload failed: ' + JSON.stringify(up.data));
  const documentId = up.data.document.id;

  // 4. Run the DXF takeoff
  const tk = await call('POST', '/api/mmc-ai/projects/' + projectId + '/documents/' + documentId + '/takeoff/dxf', { body: {} });
  assert.ok([200, 201].includes(tk.status), 'takeoff failed: ' + JSON.stringify(tk.data));
  const runId = tk.data.run.id;
  assert.ok(tk.data.run.items.length > 0, 'takeoff produced no items');

  // 5. Generate the BIM model with engineer-supplied dimensions
  const gen = await call('POST', '/api/mmc-ai/projects/' + projectId + '/takeoff/runs/' + runId + '/bim', {
    body: {
      storeyName: 'Level 0',
      inputs: {
        foundations: { heightM: 0.5, baseM: -1.5 },
        columns: { heightM: 3.0, baseM: 0 },
        beams: { widthM: 0.25, heightM: 0.3, baseM: 2.7 },
        slabs: { heightM: 0.2, baseM: 3.0 },
        walls: { thicknessM: 0.2, heightM: 3.0, baseM: 0 }
      }
    }
  });
  assert.equal(gen.status, 201, 'BIM generation failed: ' + JSON.stringify(gen.data));
  const modelId = gen.data.model.id;
  assert.ok(gen.data.model.element_count >= 5, 'expected at least 5 elements, got ' + gen.data.model.element_count);
  assert.ok(gen.data.model.ifc_size_bytes > 1000, 'IFC too small');
  assert.ok(gen.data.model.glb_size_bytes > 1000, 'GLB too small');

  // 6. List models
  const list = await call('GET', '/api/mmc-ai/projects/' + projectId + '/bim/generated');
  assert.equal(list.status, 200);
  assert.ok(list.data.models.some((m) => m.id === modelId), 'generated model missing from list');

  // 7. Model detail with elements and links
  const detail = await call('GET', '/api/mmc-ai/projects/' + projectId + '/bim/generated/' + modelId);
  assert.equal(detail.status, 200);
  assert.equal(detail.data.elements.length, gen.data.model.element_count);
  assert.ok(detail.data.links && detail.data.links.byElement, 'link index missing');
  const firstElement = detail.data.elements[0];
  assert.ok(firstElement.source_takeoff_item_id, 'element lost its takeoff link');
  assert.ok(firstElement.volume_m3 > 0, 'element has no volume');

  // 8. Download the IFC and validate it with the project inspector
  const ifcRes = await call('GET', '/api/mmc-ai/projects/' + projectId + '/bim/generated/' + modelId + '/download?format=ifc');
  assert.equal(ifcRes.status, 200);
  const ifcText = Buffer.from(ifcRes.data).toString('utf8');
  assert.match(ifcText, /^ISO-10303-21;/);
  assert.match(ifcText, /END-ISO-10303-21;\s*$/);
  const report = parseIfc(ifcText);
  assert.equal(report.schema, 'IFC4');
  assert.equal(report.lengthUnit, 'm');
  assert.equal(report.buildingElementCount, gen.data.model.element_count, 'IFC element count must match the model');

  // 9. Download the GLB and validate the container
  const glbRes = await call('GET', '/api/mmc-ai/projects/' + projectId + '/bim/generated/' + modelId + '/download?format=glb');
  assert.equal(glbRes.status, 200);
  const glb = Buffer.from(glbRes.data);
  assert.equal(glb.toString('ascii', 0, 4), 'glTF');
  assert.equal(glb.readUInt32LE(4), 2);
  assert.equal(glb.readUInt32LE(8), glb.length, 'GLB declared length must match the file');
  const jsonLen = glb.readUInt32LE(12);
  const gltf = JSON.parse(glb.toString('utf8', 20, 20 + jsonLen));
  assert.equal(gltf.nodes.length, gen.data.model.element_count, 'one GLB node per element');

  // 10. Approve the run (required before a BOQ item may link to it), then
  //     create a BOQ item from a takeoff item and resolve it to an element.
  const approve = await call('PATCH', '/api/mmc-ai/projects/' + projectId + '/takeoff/runs/' + runId + '/review', { body: { status: 'approved' } });
  assert.equal(approve.status, 200, 'approve failed: ' + JSON.stringify(approve.data));
  // The BOQ quantity and unit must match the approved takeoff item.
  const takeoffItem = tk.data.run.items.find((it) => it.id === firstElement.source_takeoff_item_id);
  assert.ok(takeoffItem, 'the element\'s takeoff item must exist in the run');
  const boq = await call('POST', '/api/mmc-ai/projects/' + projectId + '/boq', {
    body: {
      description: 'Concrete columns',
      unit: takeoffItem.unit,
      quantity: takeoffItem.quantity,
      rate: 120,
      sourceTakeoffItemId: firstElement.source_takeoff_item_id
    }
  });
  assert.ok([200, 201].includes(boq.status), 'BOQ create failed: ' + JSON.stringify(boq.data));
  const boqId = boq.data.item.id;
  const byBoq = await call('GET', '/api/mmc-ai/projects/' + projectId + '/bim/generated/' + modelId + '/by-boq/' + boqId);
  assert.equal(byBoq.status, 200);
  assert.ok(byBoq.data.elementCodes.length > 0, 'BOQ item did not resolve to any element');
  assert.ok(byBoq.data.elementCodes.includes(firstElement.element_code), 'resolved element does not match');
  assert.equal(byBoq.data.basis, 'takeoff_item');

  // 11. The second link path: a BOQ item rolled up from a takeoff *proposal*
  //     carries source_takeoff_run_id + source_proposal_key ("category:key")
  //     instead of a single takeoff item. It must resolve to every element of
  //     that category in the same run.
  const summary = tk.data.run.summary || {};
  const proposal = (summary.quantityProposals && summary.quantityProposals.results || [])
    .find((r) => r.status === 'proposed' && (r.proposed || []).length);
  if (proposal) {
    const key = proposal.proposed[0].key;
    const rolled = await call('POST', '/api/mmc-ai/projects/' + projectId + '/boq/from-takeoff', {
      body: { runId, category: proposal.category, proposalKey: key }
    });
    assert.ok([200, 201].includes(rolled.status), 'roll-up failed: ' + JSON.stringify(rolled.data));
    const rolledId = rolled.data.item.id;
    const byProposal = await call('GET', '/api/mmc-ai/projects/' + projectId + '/bim/generated/' + modelId + '/by-boq/' + rolledId);
    assert.equal(byProposal.status, 200);
    assert.equal(byProposal.data.basis, 'proposal_category');
    assert.ok(byProposal.data.elementCodes.length > 0, 'proposal BOQ item did not resolve to any element');
    const expected = elements.filter((e) => e.category === proposal.category).map((e) => e.element_code);
    assert.deepEqual(byProposal.data.elementCodes.slice().sort(), expected.slice().sort(),
      'proposal link must resolve to every element of its category');
  }
});

test('BIM generation rejects a run with no buildable geometry', async () => {
  await registerAndLogin('bim2' + Date.now() + '@example.com', 'BIM Tester 2');

  const proj = await call('POST', '/api/mmc-ai/projects', { body: { name: 'Empty Geometry Project', country: 'JO', currency: 'JOD' } });
  const projectId = proj.data.project.project_id || proj.data.project.id;

  const form = new FormData();
  form.append('file', new Blob([sampleDxf()], { type: 'application/dxf' }), 'plan.dxf');
  const up = await call('POST', '/api/mmc-ai/projects/' + projectId + '/documents', { form });
  const tk = await call('POST', '/api/mmc-ai/projects/' + projectId + '/documents/' + up.data.document.id + '/takeoff/dxf', { body: {} });
  const runId = tk.data.run.id;

  // No dimensions supplied → nothing can be built → 422 with a reason, not a 500.
  const gen = await call('POST', '/api/mmc-ai/projects/' + projectId + '/takeoff/runs/' + runId + '/bim', { body: { inputs: {} } });
  assert.equal(gen.status, 422, 'expected a validation error, got ' + gen.status + ': ' + JSON.stringify(gen.data));
  assert.ok(/height|ارتفاع|dimension|أبعاد/i.test(JSON.stringify(gen.data)), 'error must explain the missing dimension');
});

test('BIM endpoints require authentication', async () => {
  const saved = cookie;
  cookie = '';
  const res = await call('GET', '/api/mmc-ai/projects/any/bim/generated');
  cookie = saved;
  assert.equal(res.status, 401);
});

test('a non-member cannot read another project\'s BIM model', async () => {
  await registerAndLogin('bim3' + Date.now() + '@example.com', 'Outsider');

  const res = await call('GET', '/api/mmc-ai/projects/does-not-exist/bim/generated');
  assert.equal(res.status, 404, 'a non-member must get 404, not data');
});
