'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  buildBimElements, rectangleFromVertices, stripFromLine, boxAt, CATEGORY_TO_BIM
} = require('../src/lib/mmc-ai/bim-element-model');

const rect = (x, y, w, d) => ({
  type: 'LWPOLYLINE', closed: true,
  vertices: [{ x, y }, { x: x + w, y }, { x: x + w, y: y + d }, { x, y: y + d }]
});
const line = (x1, y1, x2, y2) => ({ type: 'LINE', start: { x: x1, y: y1 }, end: { x: x2, y: y2 } });

function row(over) {
  return Object.assign({
    id: 't1', category: 'columns', layer_name: 'S-COLS', entity_type: 'LWPOLYLINE',
    quantity: 0.09, unit: 'm2', geometry: rect(0, 0, 0.3, 0.3), detail: {}
  }, over);
}

test('rectangleFromVertices accepts an axis-aligned rectangle', () => {
  const r = rectangleFromVertices([{ x: 0, y: 0 }, { x: 4, y: 0 }, { x: 4, y: 3 }, { x: 0, y: 3 }]);
  assert.equal(r.width, 4);
  assert.equal(r.depth, 3);
  assert.deepEqual(r.centroid, { x: 2, y: 1.5 });
});

test('rectangleFromVertices rejects a non-rectangular quad instead of approximating', () => {
  assert.equal(rectangleFromVertices([{ x: 0, y: 0 }, { x: 4, y: 0 }, { x: 3, y: 3 }, { x: 0, y: 3 }]), null);
});

test('rectangleFromVertices rejects a triangle', () => {
  assert.equal(rectangleFromVertices([{ x: 0, y: 0 }, { x: 4, y: 0 }, { x: 0, y: 3 }]), null);
});

test('stripFromLine builds a strip for a horizontal run', () => {
  const s = stripFromLine({ x: 0, y: 0 }, { x: 6, y: 0 }, 0.2);
  assert.equal(s.width, 6);
  assert.equal(s.depth, 0.2);
  assert.equal(s.lengthM, 6);
});

test('stripFromLine refuses a diagonal run rather than overstating its footprint', () => {
  assert.equal(stripFromLine({ x: 0, y: 0 }, { x: 3, y: 4 }, 0.2), null);
});

test('boxAt centres a counted element on its placement', () => {
  const b = boxAt({ x: 3, y: 3 }, 0.6);
  assert.equal(b.width, 0.6);
  assert.deepEqual(b.centroid, { x: 3, y: 3 });
});

test('builds a column element with volume from supplied height', () => {
  const m = buildBimElements({ items: [row()] }, { inputs: { columns: { heightM: 3 } } });
  assert.equal(m.elements.length, 1);
  const el = m.elements[0];
  assert.equal(el.ifcType, 'IfcColumn');
  assert.equal(el.discipline, 'structural');
  assert.equal(el.heightM, 3);
  assert.equal(el.volumeM3, 0.27); // 0.3 × 0.3 × 3
  assert.equal(el.source.takeoffItemId, 't1');
});

test('refuses to invent a height and reports the element as unresolved', () => {
  const m = buildBimElements({ items: [row()] }, { inputs: {} });
  assert.equal(m.elements.length, 0);
  assert.equal(m.unresolved.length, 1);
  assert.equal(m.unresolved[0].reason, 'height_not_measured_or_supplied');
  assert.equal(m.unresolved[0].suggestedHeightM, 3);
});

test('a measured height on the drawing is used and marked as measured', () => {
  const m = buildBimElements({ items: [row({ detail: { heightM: 2.5 } })] }, { inputs: {} });
  assert.equal(m.elements[0].heightM, 2.5);
  assert.equal(m.elements[0].heightSource, 'measured_on_drawing');
});

test('a linear element without a supplied width is unresolved, not guessed', () => {
  const m = buildBimElements({ items: [row({ category: 'beams', geometry: line(0, 0, 5, 0), unit: 'm' })] }, { inputs: {} });
  assert.equal(m.elements.length, 0);
  assert.equal(m.unresolved[0].reason, 'linear_width_not_supplied');
});

test('a beam with width and height becomes an IfcBeam with the right volume', () => {
  const m = buildBimElements(
    { items: [row({ category: 'beams', geometry: line(0, 0, 5, 0), unit: 'm' })] },
    { inputs: { beams: { widthM: 0.25, heightM: 0.3 } } }
  );
  assert.equal(m.elements[0].ifcType, 'IfcBeam');
  assert.equal(m.elements[0].volumeM3, 0.375); // 5 × 0.25 × 0.3
});

test('reinforcement is reported as non-geometric, never extruded', () => {
  const m = buildBimElements({ items: [row({ category: 'reinforcement', unit: 'kg' })] }, { inputs: { reinforcement: { heightM: 1 } } });
  assert.equal(m.elements.length, 0);
  assert.equal(m.unresolved[0].reason, 'category_is_not_geometry');
});

test('an unmapped category is reported with its own reason', () => {
  const m = buildBimElements({ items: [row({ category: 'not_a_real_category' })] }, { inputs: { not_a_real_category: { heightM: 1 } } });
  assert.equal(m.unresolved[0].reason, 'category_has_no_bim_mapping');
});

test('millimetre inputs are converted to metres', () => {
  const m = buildBimElements(
    { items: [row({ category: 'walls', geometry: line(0, 0, 6, 0), unit: 'm' })] },
    { inputs: { walls: { thicknessMm: 200, heightMm: 3000 } } }
  );
  assert.equal(m.elements[0].heightM, 3);
  assert.equal(m.elements[0].widthM, 0.2);
});

test('a circle footprint uses its radius and is flagged as a bounding box', () => {
  const m = buildBimElements(
    { items: [row({ category: 'columns', geometry: { type: 'CIRCLE', center: { x: 2, y: 2 }, radius: 0.25 }, radius_m: 0.25 })] },
    { inputs: { columns: { heightM: 3 } } }
  );
  assert.equal(m.elements[0].footprint.width, 0.5);
  assert.equal(m.elements[0].geometryBasis, 'circle_bounding_box');
});

test('an arc is reported as unsupported geometry', () => {
  const m = buildBimElements(
    { items: [row({ geometry: { type: 'ARC', center: { x: 0, y: 0 }, radius: 2 } })] },
    { inputs: { columns: { heightM: 3 } } }
  );
  assert.equal(m.unresolved[0].reason, 'arc_geometry_not_supported');
});

test('summary counts elements by discipline and kind and totals volume', () => {
  const items = [
    row({ id: 'a', category: 'columns' }),
    row({ id: 'b', category: 'slabs', geometry: rect(0, 0, 6, 6) }),
    row({ id: 'c', category: 'pipes', geometry: line(0, 0, 4, 0), unit: 'm' })
  ];
  const m = buildBimElements({ items }, {
    inputs: { columns: { heightM: 3 }, slabs: { heightM: 0.2 }, pipes: { diameterM: 0.1, heightM: 0.1 } }
  });
  assert.equal(m.summary.totalElements, 3);
  assert.equal(m.summary.byDiscipline.structural, 2);
  assert.equal(m.summary.byDiscipline.plumbing, 1);
  assert.equal(m.summary.byKind.column, 1);
  assert.equal(m.summary.byKind.slab, 1);
  assert.equal(m.summary.byKind.pipe, 1);
  assert.ok(m.summary.totalVolumeM3 > 0);
});

test('bounds cover every element in three dimensions', () => {
  const items = [
    row({ id: 'a', category: 'columns', geometry: rect(0, 0, 0.3, 0.3) }),
    row({ id: 'b', category: 'slabs', geometry: rect(0, 0, 6, 6) })
  ];
  const m = buildBimElements({ items }, { inputs: { columns: { heightM: 3, baseM: 0 }, slabs: { heightM: 0.2, baseM: 3 } } });
  assert.equal(m.summary.bounds.minX, 0);
  assert.equal(m.summary.bounds.maxX, 6);
  assert.equal(m.summary.bounds.minZ, 0);
  assert.equal(m.summary.bounds.maxZ, 3.2);
});

test('an empty run produces no elements and no crash', () => {
  const m = buildBimElements({ items: [] }, {});
  assert.equal(m.elements.length, 0);
  assert.equal(m.summary.bounds, null);
});

test('every mapped category declares an IFC type and a discipline', () => {
  for (const [category, d] of Object.entries(CATEGORY_TO_BIM)) {
    assert.ok(d.ifc && d.ifc.startsWith('Ifc'), category + ' must declare an IFC type');
    assert.ok(d.discipline, category + ' must declare a discipline');
    assert.ok(d.label && d.label.ar && d.label.en, category + ' must be labelled in Arabic and English');
  }
});

test('element ids are stable and sequential', () => {
  const items = [row({ id: 'a' }), row({ id: 'b' })];
  const m = buildBimElements({ items }, { inputs: { columns: { heightM: 3 } } });
  assert.deepEqual(m.elements.map((e) => e.id), ['bime_0001', 'bime_0002']);
});
