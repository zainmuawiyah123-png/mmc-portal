'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { analyzePdfDrawingText } = require('../src/lib/mmc-ai/pdf-drawing-text-intelligence');

test('extracts drawing register clues and explicit callouts without claiming takeoff', () => {
  const result = analyzePdfDrawingText({
    engine: 'mmc-pdf-text-basic-v1',
    pageCount: 2,
    characterCount: 180,
    text: [
      'ARCHITECTURAL GROUND FLOOR PLAN',
      'DRAWING NO: A-101',
      'REVISION: B',
      'SCALE 1:100',
      'Overall dimensions 6000 mm x 4000 mm',
      'SEE DETAIL 05',
      'DOOR SCHEDULE',
      'LIGHTING SCHEDULE'
    ].join('\n')
  }, { documentId: 'PDF-1', revision: 'B', sheetOrPage: 'A-101' });
  assert.equal(result.status, 'text_clues_found');
  assert.deepEqual(result.metadata.textualSheetNumberCandidates, ['A-101']);
  assert.deepEqual(result.metadata.textualRevisionCandidates, ['B']);
  assert.deepEqual(result.metadata.textualScaleCandidates, ['1:100']);
  assert.equal(result.metadata.explicitDimensionCallouts[0].values[0], 6000);
  assert.equal(result.metadata.explicitDimensionCallouts[0].units[0], 'mm');
  assert.ok(result.metadata.disciplineClues.includes('architectural'));
  assert.ok(result.metadata.scheduleTypeMentions.includes('DOOR SCHEDULE'));
  assert.ok(result.metadata.detailAndSectionReferenceCandidates.includes('DETAIL 05'));
  assert.equal(result.metadata.extractedPageCount, 2);
  assert.ok(result.unresolved.some(item => item.includes('No engineering element classification')));
});

test('flags a revision conflict between extracted text and document register', () => {
  const result = analyzePdfDrawingText({
    text: 'DRAWING NO: S-201\nREVISION C\nSCALE 1:50'
  }, { documentId: 'D-2', revision: 'B', sheetOrPage: 'S-201' });
  assert.equal(result.status, 'text_clues_with_register_conflicts');
  assert.equal(result.conflicts[0].field, 'revision');
});

test('does not invent drawing metadata when PDF text is empty', () => {
  const result = analyzePdfDrawingText({ text: '', characterCount: 0 }, {});
  assert.equal(result.status, 'insufficient_text_clues');
  assert.deepEqual(result.metadata.textualSheetNumberCandidates, []);
  assert.deepEqual(result.metadata.explicitDimensionCallouts, []);
  assert.equal(result.evidence.evidenceCount, 0);
});


test('records OCR provenance when raster text was recognized', () => {
  const result = analyzePdfDrawingText({
    text: 'STRUCTURAL FOUNDATION PLAN\\nDRAWING NO: S-101',
    ocrPerformed: true,
    ocrPageCount: 2,
    ocrAverageConfidence: 87.5,
    ocrWords: [{ page: 1, text: 'FOUNDATION', confidence: 91.2, box: { left: 100, top: 200, width: 120, height: 30 } }]
  }, { documentId: 'OCR-1' });
  assert.equal(result.metadata.ocrPerformed, true);
  assert.equal(result.metadata.ocrPageCount, 2);
  assert.equal(result.metadata.ocrAverageConfidence, 87.5);
  assert.equal(result.metadata.ocrWordCount, 1);
  assert.deepEqual(result.metadata.ocrWordEvidence[0].box, { left: 100, top: 200, width: 120, height: 30 });
  assert.equal(result.evidence.source, 'PDF text extractor and OCR output');
  assert.ok(!result.unresolved.some(item => item.includes('OCR was not performed')));
});


test('groups OCR words by page and visual line while retaining bounding boxes', () => {
  const result = analyzePdfDrawingText({
    text: 'DIMENSION 6000 mm',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 2, text: '6000', confidence: 95, box: { left: 100, top: 200, width: 40, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: 'mm', confidence: 90, box: { left: 145, top: 200, width: 18, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: 'NOTE', confidence: 96, box: { left: 100, top: 240, width: 35, height: 15 } }
    ]
  });
  assert.equal(result.metadata.ocrSpatialLines.length, 2);
  assert.equal(result.metadata.ocrSpatialLines[0].text, '6000 mm');
  assert.deepEqual(result.metadata.ocrSpatialLines[0].box, { left: 100, top: 200, width: 63, height: 15 });
  assert.equal(result.metadata.ocrDimensionCallouts[0].status, 'candidate_requires_drawing_verification');
});


test('classifies spatial OCR callouts as discipline candidates without treating them as measured quantities', () => {
  const result = analyzePdfDrawingText({
    text: 'STRUCTURAL AND MEP NOTES',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'B1', confidence: 96, box: { left: 100, top: 100, width: 20, height: 12 } },
      { page: 1, block: 1, paragraph: 1, line: 1, text: '300x600', confidence: 96, box: { left: 125, top: 100, width: 55, height: 12 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: 'AHU-01', confidence: 94, box: { left: 100, top: 130, width: 55, height: 12 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: 'DN', confidence: 92, box: { left: 100, top: 160, width: 20, height: 12 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: '100', confidence: 92, box: { left: 125, top: 160, width: 30, height: 12 } },
      { page: 1, block: 1, paragraph: 1, line: 4, text: 'SPRINKLER', confidence: 91, box: { left: 100, top: 190, width: 70, height: 12 } }
    ]
  });
  const candidates = result.metadata.spatialEngineeringAnnotations;
  assert.ok(candidates.some(item => item.candidateTypes.includes('structural')));
  assert.ok(candidates.some(item => item.candidateTypes.includes('mechanical_hvac')));
  assert.ok(candidates.some(item => item.candidateTypes.includes('plumbing_drainage')));
  assert.ok(candidates.some(item => item.candidateTypes.includes('fire_protection')));
  assert.ok(candidates.every(item => item.measurementEligible === false));
  const dimensionPair = result.metadata.ocrSpatialDimensionCandidates.find(item => item.raw === '300x600');
  assert.ok(dimensionPair && dimensionPair.kind === 'dimension_pair');
  assert.equal(dimensionPair.measurementEligible, false);
  assert.ok(candidates.every(item => item.box && item.page === 1));
});


test('recognizes Arabic engineering discipline terms as non-measured candidates', () => {
  const result = analyzePdfDrawingText({
    text: 'ملاحظات المشروع',
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'خرسانة', confidence: 94, box: { left: 10, top: 10, width: 45, height: 12 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: 'بلاط', confidence: 93, box: { left: 10, top: 30, width: 30, height: 12 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: 'تكييف', confidence: 92, box: { left: 10, top: 50, width: 35, height: 12 } },
      { page: 1, block: 1, paragraph: 1, line: 4, text: 'حفر', confidence: 91, box: { left: 10, top: 70, width: 20, height: 12 } }
    ]
  });
  const types = result.metadata.spatialEngineeringAnnotations.flatMap(item => item.candidateTypes);
  assert.ok(types.includes('structural'));
  assert.ok(types.includes('architectural'));
  assert.ok(types.includes('mechanical_hvac'));
  assert.ok(types.includes('earthworks_levels'));
  assert.ok(result.metadata.spatialEngineeringAnnotations.every(item => item.measurementEligible === false));
});

test('rejects a missing extraction result', () => {
  assert.throws(() => analyzePdfDrawingText(null), /PDF text extraction result is required/);
});


test('extracts spatial OCR dimension candidates with source boxes but never marks them measured', () => {
  const result = analyzePdfDrawingText({
    text: 'STRUCTURAL PLAN',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: '6000', confidence: 96, box: { left: 100, top: 200, width: 42, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'mm', confidence: 95, box: { left: 146, top: 200, width: 20, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: '300x600', confidence: 92, box: { left: 100, top: 240, width: 60, height: 15 } }
    ]
  });
  const candidates = result.metadata.ocrSpatialDimensionCandidates;
  assert.ok(candidates.some(item => item.raw === '6000 mm' && item.kind === 'explicit_length'));
  assert.ok(candidates.some(item => item.raw === '300x600' && item.kind === 'dimension_pair'));
  assert.ok(candidates.every(item => item.measurementEligible === false));
  assert.ok(candidates.every(item => item.page === 1 && item.box && item.ocrConfidence >= 90));
  const explicit = candidates.find(item => item.raw === '6000 mm');
  const pair = candidates.find(item => item.raw === '300x600');
  assert.deepEqual(explicit.box, { left: 100, top: 200, width: 66, height: 15 });
  assert.deepEqual(pair.box, { left: 100, top: 240, width: 60, height: 15 });
  assert.equal(explicit.sourceWordCount, 2);
  assert.equal(pair.sourceWordCount, 1);
});


test('recognizes Arabic-Indic numerals and Arabic engineering units without approving takeoff', () => {
  const result = analyzePdfDrawingText({
    text: 'مخطط إنشائي',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: '٦٠٠٠', confidence: 96, box: { left: 10, top: 10, width: 40, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'مم', confidence: 95, box: { left: 53, top: 10, width: 18, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: '٣٠٠×٦٠٠', confidence: 94, box: { left: 10, top: 35, width: 65, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: '٢٫٥', confidence: 92, box: { left: 10, top: 60, width: 22, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: 'م', confidence: 92, box: { left: 35, top: 60, width: 10, height: 15 } }
    ]
  });
  const candidates = result.metadata.ocrSpatialDimensionCandidates;
  assert.ok(candidates.some(item => item.raw === '٦٠٠٠ مم' && item.values[0] === 6000 && item.units[0] === 'mm'));
  assert.ok(candidates.some(item => item.raw === '٣٠٠×٦٠٠' && item.values[0] === 300 && item.values[1] === 600));
  assert.ok(candidates.some(item => item.raw === '٢٫٥ م' && item.values[0] === 2.5 && item.units[0] === 'm'));
  assert.ok(candidates.every(item => item.measurementEligible === false));
  assert.deepEqual(candidates.find(item => item.raw === '٦٠٠٠ مم').normalizedValuesMm, [6000]);
  assert.equal(candidates.find(item => item.raw === '٣٠٠×٦٠٠').normalizedValuesMm, null);
  assert.deepEqual(candidates.find(item => item.raw === '٢٫٥ م').normalizedValuesMm, [2500]);
});


test('associates structural OCR labels with nearby dimensions as review-only candidates', () => {
  const result = analyzePdfDrawingText({
    text: 'مخطط إنشائي',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'B1', confidence: 97, box: { left: 100, top: 100, width: 20, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: '300x600', confidence: 96, box: { left: 125, top: 120, width: 60, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: 'C1', confidence: 97, box: { left: 400, top: 100, width: 20, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 4, text: '400x400', confidence: 96, box: { left: 425, top: 120, width: 60, height: 15 } }
    ]
  });
  const elements = result.metadata.spatialElementCandidates;
  const beam = elements.find(item => item.elementTagCandidate === 'B1');
  const column = elements.find(item => item.elementTagCandidate === 'C1');
  assert.ok(beam && column);
  assert.equal(beam.dimensionCandidate.raw, '300x600');
  assert.equal(column.dimensionCandidate.raw, '400x400');
  assert.equal(beam.associationStatus, 'spatially_associated_candidate');
  assert.equal(column.associationStatus, 'spatially_associated_candidate');
  assert.ok(elements.every(item => item.measurementEligible === false));
});

test('does not force an association when multiple dimension candidates are equally close', () => {
  const result = analyzePdfDrawingText({
    text: 'STRUCTURAL PLAN',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'B2', confidence: 96, box: { left: 100, top: 100, width: 20, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: '300x600', confidence: 95, box: { left: 30, top: 120, width: 60, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: '350x700', confidence: 95, box: { left: 130, top: 120, width: 60, height: 15 } }
    ]
  });
  const beam = result.metadata.spatialElementCandidates.find(item => item.elementTagCandidate === 'B2');
  assert.equal(beam.associationStatus, 'ambiguous_nearby_dimensions');
  assert.equal(beam.dimensionCandidate, null);
  assert.equal(beam.measurementEligible, false);
});


test('extracts reinforcement count and bar diameter as non-approved candidates', () => {
  const result = analyzePdfDrawingText({
    text: 'STRUCTURAL REINFORCEMENT PLAN',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'B1', confidence: 97, box: { left: 100, top: 100, width: 20, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 1, text: '4T20', confidence: 96, box: { left: 125, top: 100, width: 42, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: 'C1', confidence: 97, box: { left: 300, top: 100, width: 20, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: '8Ø16', confidence: 96, box: { left: 325, top: 100, width: 42, height: 15 } }
    ]
  });
  const elements = result.metadata.spatialElementCandidates;
  const beam = elements.find(item => item.elementTagCandidate === 'B1');
  const column = elements.find(item => item.elementTagCandidate === 'C1');
  assert.equal(beam.elementFamilyCandidate, 'beam');
  assert.deepEqual(beam.reinforcementCandidates.map(item => [item.barCount, item.diameterMm]), [[4, 20]]);
  assert.deepEqual(column.reinforcementCandidates.map(item => [item.barCount, item.diameterMm]), [[8, 16]]);
  assert.ok(beam.reinforcementCandidates.every(item => item.totalSteelMassKg === null && item.measurementEligible === false));
});


test('does not assign one OCR dimension callout to multiple nearby elements', () => {
  const result = analyzePdfDrawingText({
    text: 'STRUCTURAL PLAN',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'B1', confidence: 97, box: { left: 100, top: 100, width: 20, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: 'B2', confidence: 97, box: { left: 110, top: 105, width: 20, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: '300x600', confidence: 96, box: { left: 105, top: 130, width: 60, height: 15 } }
    ]
  });
  const elements = result.metadata.spatialElementCandidates.filter(item =>
    ['B1', 'B2'].includes(item.elementTagCandidate));
  assert.equal(elements.length, 2);
  assert.equal(elements.filter(item => item.dimensionCandidate).length, 1);
  assert.equal(elements.filter(item => item.associationStatus === 'dimension_candidate_already_assigned_or_unresolved').length, 1);
  assert.ok(elements.every(item => item.measurementEligible === false));
});


test('reads reinforcement diameter and spacing notations without inventing bar counts or lengths', () => {
  const result = analyzePdfDrawingText({
    text: 'STRUCTURAL REINFORCEMENT',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'T16@200', confidence: 95, box: { left: 10, top: 10, width: 60, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: '4T20@150', confidence: 96, box: { left: 10, top: 35, width: 70, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 3, text: 'Ø12', confidence: 94, box: { left: 10, top: 60, width: 35, height: 15 } }
    ]
  });
  const candidates = result.metadata.spatialElementCandidates.flatMap(item => item.reinforcementCandidates);
  assert.ok(candidates.some(item => item.diameterMm === 16 && item.spacingMm === 200 && item.barCount === null));
  assert.ok(candidates.some(item => item.diameterMm === 20 && item.spacingMm === 150 && item.barCount === 4));
  assert.ok(candidates.some(item => item.diameterMm === 12 && item.spacingMm === null && item.barCount === null));
  assert.ok(candidates.every(item => item.totalSteelMassKg === null && item.measurementEligible === false));
});


test('captures reinforcement distribution hints such as each way and each face', () => {
  const result = analyzePdfDrawingText({
    text: 'SLAB REINFORCEMENT PLAN',
    ocrPerformed: true,
    ocrWords: [
      { page: 1, block: 1, paragraph: 1, line: 1, text: 'T12@150 EW', confidence: 95, box: { left: 10, top: 10, width: 80, height: 15 } },
      { page: 1, block: 1, paragraph: 1, line: 2, text: 'Y16-200 EF', confidence: 95, box: { left: 10, top: 35, width: 80, height: 15 } }
    ]
  });
  const candidates = result.metadata.spatialElementCandidates.flatMap(item => item.reinforcementCandidates);
  assert.ok(candidates.some(item => item.diameterMm === 12 && item.spacingMm === 150 && item.distribution === 'each_way'));
  assert.ok(candidates.some(item => item.diameterMm === 16 && item.spacingMm === 200 && item.distribution === 'each_face'));
  assert.ok(candidates.every(item => item.measurementEligible === false && item.totalSteelMassKg === null));
});


test('native PDF text boxes are grouped spatially and dimension callouts remain unverified',()=>{
 const result=analyzePdfDrawingText({
  text:'PLAN',
  nativeSpatialWords:[
   {text:'6000',box:{xMin:100,yMin:100,xMax:140,yMax:112}},
   {text:'mm',box:{xMin:142,yMin:100,xMax:158,yMax:112}},
   {text:'B1',box:{xMin:160,yMin:100,xMax:176,yMax:112}},
   {text:'300',box:{xMin:100,yMin:160,xMax:124,yMax:172}},
   {text:'x',box:{xMin:126,yMin:160,xMax:132,yMax:172}},
   {text:'600',box:{xMin:134,yMin:160,xMax:158,yMax:172}}
  ],
  nativeSpatialPageNumber:1,nativeSpatialPageWidth:2000,nativeSpatialPageHeight:1400
 });
 assert.equal(result.metadata.nativeSpatialLines.length,2);
 assert.match(result.metadata.nativeSpatialLines[0].text,/6000 mm B1/);
 assert.equal(result.metadata.nativeSpatialDimensionCandidates[0].raw,'6000 mm');
 assert.equal(result.metadata.nativeSpatialDimensionCandidates[0].measurementEligible,false);
 assert.equal(result.metadata.nativeSpatialElementCandidates[0].measurementEligible,false);
 assert.equal(result.metadata.nativeSpatialElementCandidates[0].source,'native PDF text and page-coordinate proximity; not verified geometry');
});
