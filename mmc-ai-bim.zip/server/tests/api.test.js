'use strict';
/**
 * اختبارات التكامل — node --test tests/
 * تشغّل الخادم على منفذ عشوائي بقاعدة بيانات مؤقتة، وتستخدم fetch الحقيقي.
 */
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

/* ---------------- بيئة اختبار معزولة (قبل أي require آخر) ---------------- */
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'tpkit-test-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json'; // isolated in-memory mail transport for OTP tests
process.env.DB_PATH = path.join(TMP, 'test.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false'; // يُفعَّل داخل اختبارات التوثيق فقط
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'test-secret-not-for-production';
process.env.BCRYPT_ROUNDS = '4';      // أسرع في الاختبارات

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { getDB, closeDB } = require('../src/db');

let server, base;
const cookies = {};   // مفتاح: اسم الجلسة → قيمة الكوكي

/* ---------------- helpers ---------------- */
function cookieFor(name) {
  return cookies[name] ? { Cookie: cookies[name] } : {};
}

async function call(name, method, p, { body, form, headers } = {}) {
  const h = Object.assign({}, cookieFor(name), headers || {});
  let payload;
  if (form) payload = form;
  else if (body instanceof FormData) payload = body;
  else if (body !== undefined) {
    // Keep legacy integration fixtures aligned with the current required company field.
    if (p === '/api/auth/register' && body && typeof body === 'object' && !Object.prototype.hasOwnProperty.call(body, 'company') && body.name && body.email && body.password) body = { ...body, company: 'Automated test company' };
    h['Content-Type'] = 'application/json'; payload = JSON.stringify(body);
  }

  const res = await fetch(base + p, { method, headers: h, body: payload, redirect: 'manual' });

  // التقاط كوكي الجلسة
  const setCookie = res.headers.getSetCookie
    ? res.headers.getSetCookie()
    : [res.headers.get('set-cookie')].filter(Boolean);
  for (const c of setCookie) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) {
      const val = first.split('=').slice(1).join('=');
      if (val === '' || /Max-Age=0/i.test(c)) delete cookies[name];
      else cookies[name] = first;
    }
  }

  const ct = res.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await res.json() : await res.text();

  // Simulate completion of the OTP step in the isolated test database.
  // The test then obtains a session through the normal login endpoint.
  if (p === '/api/auth/register' && res.status === 201 && body?.email) {
    const db = getDB();
    const user = db.prepare('SELECT id FROM users WHERE email = ?').get(body.email);
    if (user) {
      const now = Math.floor(Date.now() / 1000);
      db.prepare('UPDATE email_verifications SET verified_at = ? WHERE user_id = ?').run(now, user.id);
      db.prepare("UPDATE users SET account_status = 'active' WHERE id = ?").run(user.id);
      const login = await call(name, 'POST', '/api/auth/login', {
        body: { email: body.email, password: body.password }
      });
      if (login.status !== 200) {
        throw new Error('Test fixture could not establish a session after OTP verification: ' + JSON.stringify(login.data));
      }
      const me = await call(name, 'GET', '/api/auth/me');
      if (me.status !== 200) {
        throw new Error('Test fixture login did not persist its session cookie: ' + JSON.stringify(me.data));
      }
      return { status: res.status, data: { ...data, user: me.data.user }, headers: res.headers };
    }
  }

  return { status: res.status, data, headers: res.headers };
}

function makeForm(files, extra = {}) {
  const fd = new FormData();
  for (const f of files) {
    fd.append('files', new Blob([f.content], { type: f.type || 'application/pdf' }), f.name);
  }
  for (const [k, v] of Object.entries(extra)) fd.append(k, v);
  return fd;
}

const uniq = () => Math.random().toString(36).slice(2, 9);

/* ---------------- setup / teardown ---------------- */
test.before(async () => {
  migrate(process.env.DB_PATH);
  const app = createApp();
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      base = 'http://127.0.0.1:' + server.address().port;
      resolve();
    });
  });
});

test.after(async () => {
  await new Promise((r) => server.close(r));
  closeDB();
  fs.rmSync(TMP, { recursive: true, force: true });
});

let userAId = null;

/* ==========================================================
   1) الصحة والتسجيل
   ========================================================== */
test('01 — /api/health يستجيب', async () => {
  const r = await call('anon', 'GET', '/api/health');
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.ok, true);
  // المرحلة الثانية: التخزين المجرّد + الجدولة + النسخ الاحتياطي
  assert.strictEqual(r.data.phase, 2);
  assert.ok(r.data.storage, 'يجب أن يعرض /api/health مشغّل التخزين');
  assert.ok(['local', 's3'].includes(r.data.storage.driver), 'مشغّل تخزين غير معروف: ' + r.data.storage.driver);
  assert.ok(r.data.scheduler, 'يجب أن يعرض /api/health حالة الجدولة');
});

test('01A — صفحة دورة المالية العامة متاحة دون جلسة', async () => {
  const r = await call('anon', 'GET', '/project-finance/index.html');
  assert.strictEqual(r.status, 200);
  assert.match(r.data, /MMC Project Finance Workflow/);
});

test('02 — تسجيل مستخدم جديد يعيد 201 ويضبط الكوكي', async () => {
  const r = await call('userA', 'POST', '/api/auth/register', {
    body: { name: 'مستخدم أ', email: 'a' + uniq() + '@test.com', password: 'Password123', company: 'شركة أ' }
  });
  assert.strictEqual(r.status, 201, JSON.stringify(r.data));
  userAId = r.data.user.id;
  assert.ok(r.data.user.id.startsWith('usr_'));
  assert.strictEqual(r.data.user.planKey, 'free');
  assert.ok(cookies.userA, 'يجب أن يُضبط كوكي الجلسة');
  assert.strictEqual(r.data.user.country, 'JO');
  assert.ok(!JSON.stringify(r.data).includes('password'), 'يجب ألا تُرجع كلمة المرور');
});

test('02B — التسجيل يحفظ دولة الحساب المختارة', async () => {
  const r = await call('userCountry', 'POST', '/api/auth/register', {
    body: { name: 'مستخدم الإمارات', email: 'ae' + uniq() + '@test.com', password: 'Password123', country: 'AE' }
  });
  assert.strictEqual(r.status, 201, JSON.stringify(r.data));
  assert.strictEqual(r.data.user.country, 'AE');
  const me = await call('userCountry', 'GET', '/api/auth/me');
  assert.strictEqual(me.status, 200);
  assert.strictEqual(me.data.user.country, 'AE');
});

test('02C — رمز دولة غير مدعوم مرفوض عند التسجيل', async () => {
  const r = await call('invalidCountry', 'POST', '/api/auth/register', {
    body: { name: 'مستخدم غير صحيح', email: 'bad' + uniq() + '@test.com', password: 'Password123', country: 'US' }
  });
  assert.strictEqual(r.status, 422);
});

test('02A — المقاول المسجل يستطيع فتح صفحة دورة المالية', async () => {
  const r = await call('userA', 'GET', '/project-finance/index.html');
  assert.strictEqual(r.status, 200);
  assert.match(r.data, /MMC Project Finance Workflow/);
});

test('03 — تسجيل ببريد مكرر يُرفض 409', async () => {
  const email = 'dup' + uniq() + '@test.com';
  const a = await call('tmp1', 'POST', '/api/auth/register', { body: { name: 'أحمد', email, password: 'Password123' } });
  assert.strictEqual(a.status, 201);
  const b = await call('tmp2', 'POST', '/api/auth/register', { body: { name: 'بشار', email, password: 'Password123' } });
  assert.strictEqual(b.status, 409);
  assert.strictEqual(b.data.error.code, 'CONFLICT');
});

test('04 — تسجيل ببيانات ناقصة يُرجع 422 مع تفاصيل الحقول', async () => {
  const r = await call('anon', 'POST', '/api/auth/register', { body: { name: 'x', email: 'not-an-email', password: '123' } });
  assert.strictEqual(r.status, 422);
  assert.strictEqual(r.data.error.code, 'VALIDATION');
  assert.ok(Array.isArray(r.data.error.details) && r.data.error.details.length >= 2, 'يجب إرجاع تفاصيل لكل حقل');
});

test('05 — كلمة المرور مخزّنة bcrypt وليست نصاً صريحاً', async () => {
  const email = 'hash' + uniq() + '@test.com';
  const plain = 'SuperSecret123';
  const r = await call('hashU', 'POST', '/api/auth/register', { body: { name: 'اختبار التشفير', email, password: plain } });
  assert.strictEqual(r.status, 201);

  const row = getDB().prepare('SELECT password_hash FROM users WHERE email = ?').get(email);
  assert.notStrictEqual(row.password_hash, plain, 'كلمة المرور يجب ألا تُخزَّن نصاً');
  assert.ok(/^\$2[aby]\$/.test(row.password_hash), 'يجب أن تكون bcrypt hash: ' + row.password_hash.slice(0, 10));
  assert.ok(row.password_hash.length >= 59);
  assert.ok(!row.password_hash.includes(plain));

  const bcrypt = require('bcryptjs');
  assert.strictEqual(await bcrypt.compare(plain, row.password_hash), true, 'bcrypt يجب أن يطابق');
});

/* ==========================================================
   2) الدخول والخروج
   ========================================================== */
test('06 — دخول صحيح يعيد 200 وبيانات المستخدم', async () => {
  const email = 'login' + uniq() + '@test.com';
  await call('reg1', 'POST', '/api/auth/register', { body: { name: 'دخول', email, password: 'Password123' } });

  const r = await call('userB', 'POST', '/api/auth/login', { body: { email, password: 'Password123' } });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.user.email, email);
  assert.ok(cookies.userB);
});

test('07 — دخول بكلمة مرور خاطئة يُرفض 401', async () => {
  const email = 'wrong' + uniq() + '@test.com';
  await call('reg2', 'POST', '/api/auth/register', { body: { name: 'خطأ', email, password: 'Password123' } });
  const r = await call('anon', 'POST', '/api/auth/login', { body: { email, password: 'WrongPassword' } });
  assert.strictEqual(r.status, 401);
  assert.strictEqual(r.data.error.code, 'UNAUTHORIZED');
});

test('08 — دخول ببريد غير مسجّل يُرجع نفس رسالة كلمة المرور الخاطئة', async () => {
  const a = await call('anon', 'POST', '/api/auth/login', { body: { email: 'nobody' + uniq() + '@test.com', password: 'Password123' } });
  assert.strictEqual(a.status, 401);
  assert.match(a.data.error.message, /البريد الإلكتروني أو كلمة المرور/);
});

test('09 — /api/auth/me بدون جلسة يُرفض 401', async () => {
  const r = await call('anon', 'GET', '/api/auth/me');
  assert.strictEqual(r.status, 401);
});

test('10 — /api/auth/me مع الجلسة يعيد المستخدم والباقة', async () => {
  const r = await call('userA', 'GET', '/api/auth/me');
  assert.strictEqual(r.status, 200);
  assert.ok(r.data.user.email.endsWith('@test.com'));
  assert.strictEqual(r.data.plan.plan.key, 'free');
  assert.strictEqual(r.data.plan.usage.tenders, 0);
});

/* ==========================================================
   3) العطاءات
   ========================================================== */
let tenderA;

test('11 — إنشاء عطاء يعيد 201', async () => {
  const r = await call('userA', 'POST', '/api/tenders', {
    body: { name: 'عمارة سكنية — 6 طوابق', authority: 'أمانة عمان', closing: '2026-12-01', notes: 'نطاق كامل' }
  });
  assert.strictEqual(r.status, 201, JSON.stringify(r.data));
  assert.strictEqual(r.data.tender.status, 'new');
  assert.strictEqual(r.data.tender.name, 'عمارة سكنية — 6 طوابق');
  assert.strictEqual(r.data.tender.authority, 'أمانة عمان');
  tenderA = r.data.tender;
});

test('12 — إنشاء عطاء باسم فارغ يُرفض 422', async () => {
  const r = await call('userA', 'POST', '/api/tenders', { body: { name: '' } });
  assert.strictEqual(r.status, 422);
});

test('13 — إنشاء عطاء بتاريخ إغلاق بصيغة خاطئة يُرفض 422', async () => {
  const r = await call('userA', 'POST', '/api/tenders', { body: { name: 'عطاء', closing: '01/12/2026' } });
  assert.strictEqual(r.status, 422);
});

test('14 — قائمة العطاءات تعيد عطاءات المستخدم فقط', async () => {
  const r = await call('userA', 'GET', '/api/tenders');
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.count, 1);
  assert.strictEqual(r.data.tenders[0].id, tenderA.id);
});

test('15 — قراءة عطاء واحد تعيد ملفاته وطلباته', async () => {
  const r = await call('userA', 'GET', '/api/tenders/' + tenderA.id);
  assert.strictEqual(r.status, 200);
  assert.ok(Array.isArray(r.data.files));
  assert.ok(Array.isArray(r.data.requests));
});

test('16 — تحديث العطاء يعمل ويحدّث updated_at', async () => {
  const before = (await call('userA', 'GET', '/api/tenders/' + tenderA.id)).data.tender.updatedAt;
  const r = await call('userA', 'PATCH', '/api/tenders/' + tenderA.id, { body: { authority: 'بلدية جديدة', notes: 'محدّث' } });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.tender.authority, 'بلدية جديدة');
  assert.ok(r.data.tender.updatedAt >= before);
});

test('17 — حالة غير معروفة في التحديث تُرفض 422', async () => {
  const r = await call('userA', 'PATCH', '/api/tenders/' + tenderA.id, { body: { status: 'bogus' } });
  assert.strictEqual(r.status, 422);
});

/* ==========================================================
   4) الملفات
   ========================================================== */
let fileA;

test('18 — رفع ملف PDF يعمل ويعيد 201', async () => {
  const form = makeForm([{ name: 'arch-plan.pdf', content: 'PDF-FAKE-CONTENT-' + 'x'.repeat(200), type: 'application/pdf' }], { category: 'arch' });
  const r = await call('userA', 'POST', '/api/tenders/' + tenderA.id + '/files', { form });
  assert.strictEqual(r.status, 201, JSON.stringify(r.data));
  assert.strictEqual(r.data.count, 1);
  assert.strictEqual(r.data.files[0].name, 'arch-plan.pdf');
  assert.strictEqual(r.data.files[0].category, 'arch');
  assert.ok(r.data.files[0].size > 0);
  fileA = r.data.files[0];
});

test('19 — رفع عدة ملفات بتصنيفات مختلفة في طلب واحد', async () => {
  const form = makeForm([
    { name: 'struct-slab.pdf', content: 'STRUCT', type: 'application/pdf' },
    { name: 'mep-hvac.pdf', content: 'MEP', type: 'application/pdf' },
    { name: 'boq.xlsx', content: 'BOQ', type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }
  ], { categories: JSON.stringify(['struct', 'mep', 'boq']) });
  const r = await call('userA', 'POST', '/api/tenders/' + tenderA.id + '/files', { form });
  assert.strictEqual(r.status, 201, JSON.stringify(r.data));
  assert.strictEqual(r.data.count, 3);
  const byName = Object.fromEntries(r.data.files.map((f) => [f.name, f.category]));
  assert.strictEqual(byName['struct-slab.pdf'], 'struct');
  assert.strictEqual(byName['mep-hvac.pdf'], 'mep');
  assert.strictEqual(byName['boq.xlsx'], 'boq');
});

test('20 — رفع ملف بامتداد خطر (.exe) يُرفض 415', async () => {
  const form = makeForm([{ name: 'malware.exe', content: 'MZ', type: 'application/octet-stream' }]);
  const r = await call('userA', 'POST', '/api/tenders/' + tenderA.id + '/files', { form });
  assert.strictEqual(r.status, 415);
  assert.strictEqual(r.data.error.code, 'UNSUPPORTED_MEDIA_TYPE');
});

test('21 — رفع ملف بسكربت (.sh) يُرفض 415', async () => {
  const form = makeForm([{ name: 'run.sh', content: '#!/bin/sh', type: 'text/x-sh' }]);
  const r = await call('userA', 'POST', '/api/tenders/' + tenderA.id + '/files', { form });
  assert.strictEqual(r.status, 415);
});

test('22 — قائمة ملفات العطاء تعيد 4 ملفات', async () => {
  const r = await call('userA', 'GET', '/api/tenders/' + tenderA.id + '/files');
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.count, 4);
});

test('23 — العطاء يصبح جاهزاً بعد الرفع', async () => {
  const r = await call('userA', 'GET', '/api/tenders/' + tenderA.id);
  assert.strictEqual(r.data.tender.status, 'ready');
  assert.strictEqual(r.data.tender.fileCount, 4);
});

test('24 — تحميل الملف المحمي يعيد المحتوى الأصلي', async () => {
  const res = await fetch(base + '/api/files/' + fileA.id + '/download', { headers: cookieFor('userA') });
  assert.strictEqual(res.status, 200);
  const text = await res.text();
  assert.ok(text.startsWith('PDF-FAKE-CONTENT-'), 'المحتوى يجب أن يطابق ما رُفع');
  assert.match(res.headers.get('content-disposition'), /attachment/);
});

test('25 — تحميل ملف بدون جلسة يُرفض 401', async () => {
  const res = await fetch(base + '/api/files/' + fileA.id + '/download');
  assert.strictEqual(res.status, 401);
});

test('26 — التصنيف غير المعروف يُحوَّل إلى other', async () => {
  const form = makeForm([{ name: 'weird.pdf', content: 'X', type: 'application/pdf' }], { category: 'nonsense' });
  const r = await call('userA', 'POST', '/api/tenders/' + tenderA.id + '/files', { form });
  assert.strictEqual(r.status, 201);
  assert.strictEqual(r.data.files[0].category, 'other');
});

/* ==========================================================
   5) عزل المستخدمين — الأهم
   ========================================================== */
test('27 — مستخدم آخر لا يقدر يقرأ عطاء غيره (404)', async () => {
  await call('userC', 'POST', '/api/auth/register', { body: { name: 'مستخدم ج', email: 'c' + uniq() + '@test.com', password: 'Password123' } });
  const r = await call('userC', 'GET', '/api/tenders/' + tenderA.id);
  assert.strictEqual(r.status, 404, 'يجب إخفاء وجود العطاء بـ 404 لا 403');
  assert.strictEqual(r.data.error.code, 'NOT_FOUND');
});

test('28 — مستخدم آخر لا يقدر يعدّل عطاء غيره', async () => {
  const r = await call('userC', 'PATCH', '/api/tenders/' + tenderA.id, { body: { name: 'استوليت عليه' } });
  assert.strictEqual(r.status, 404);
  // تأكيد أن الاسم لم يتغير
  const check = await call('userA', 'GET', '/api/tenders/' + tenderA.id);
  assert.strictEqual(check.data.tender.name, 'عمارة سكنية — 6 طوابق');
});

test('29 — مستخدم آخر لا يقدر يحذف عطاء غيره', async () => {
  const r = await call('userC', 'DELETE', '/api/tenders/' + tenderA.id);
  assert.strictEqual(r.status, 404);
  const check = await call('userA', 'GET', '/api/tenders/' + tenderA.id);
  assert.strictEqual(check.status, 200, 'العطاء يجب أن يبقى');
});

test('30 — مستخدم آخر لا يقدر يرفع ملفاً على عطاء غيره', async () => {
  const form = makeForm([{ name: 'intrude.pdf', content: 'X', type: 'application/pdf' }]);
  const r = await call('userC', 'POST', '/api/tenders/' + tenderA.id + '/files', { form });
  assert.strictEqual(r.status, 404);
});

test('31 — مستخدم آخر لا يقدر يحمّل ملف غيره', async () => {
  const res = await fetch(base + '/api/files/' + fileA.id + '/download', { headers: cookieFor('userC') });
  assert.strictEqual(res.status, 404);
});

test('32 — مستخدم آخر لا يقدر يحذف ملف غيره', async () => {
  const r = await call('userC', 'DELETE', '/api/files/' + fileA.id);
  assert.strictEqual(r.status, 404);
  // تأكيد بقاء الملف
  const list = await call('userA', 'GET', '/api/tenders/' + tenderA.id + '/files');
  assert.ok(list.data.files.some((f) => f.id === fileA.id));
});

test('33 — قائمة عطاءات المستخدم ج لا تحتوي عطاءات المستخدم أ', async () => {
  const r = await call('userC', 'GET', '/api/tenders');
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.count, 0);
});

test('34 — طلب على عطاء غيره يُرفض', async () => {
  const r = await call('userC', 'POST', '/api/tenders/' + tenderA.id + '/requests', { body: { text: 'اختراق', kind: 'note' } });
  assert.strictEqual(r.status, 404);
});

/* ==========================================================
   6) الطلبات
   ========================================================== */
test('35 — إنشاء طلب على عطاء مملوك', async () => {
  const r = await call('userA', 'POST', '/api/tenders/' + tenderA.id + '/requests', { body: { text: 'أرجو تعديل جدول الدفعات', kind: 'change' } });
  assert.strictEqual(r.status, 201);
  assert.strictEqual(r.data.request.kind, 'change');
  assert.strictEqual(r.data.request.status, 'open');
});

test('36 — طلب بنص قصير جداً يُرفض 422', async () => {
  const r = await call('userA', 'POST', '/api/tenders/' + tenderA.id + '/requests', { body: { text: 'ا', kind: 'note' } });
  assert.strictEqual(r.status, 422);
});

test('37 — قائمة الطلبات تعيد الطلب', async () => {
  const r = await call('userA', 'GET', '/api/tenders/' + tenderA.id + '/requests');
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.count, 1);
});

/* ==========================================================
   7) الباقة والاستهلاك
   ========================================================== */
test('38 — الاستهلاك يعكس العطاءات والملفات الفعلية', async () => {
  const r = await call('userA', 'GET', '/api/usage');
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.usage.tenders, 1);
  assert.strictEqual(r.data.usage.tendersMax, 1);
  assert.strictEqual(r.data.usage.tendersPct, 100);
  assert.strictEqual(r.data.usage.files, 5);
  assert.ok(r.data.usage.bytes > 0);
});

test('39 — العطاء الثاني على الباقة المجانية يُرفض 402', async () => {
  const r = await call('userA', 'POST', '/api/tenders', { body: { name: 'عطاء ثانٍ' } });
  assert.strictEqual(r.status, 402, JSON.stringify(r.data));
  assert.strictEqual(r.data.error.code, 'PLAN_LIMIT');
  assert.strictEqual(r.data.error.details.limit, 1);
});

test('40 — لا يمكن تفعيل باقة مقاول مدفوعة دون اعتماد فاتورة', async () => {
  const up = await call('userA', 'POST', '/api/plan', { body: { planKey: 'starter' } });
  assert.strictEqual(up.status, 403, JSON.stringify(up.data));
  const me = await call('userA', 'GET', '/api/auth/me');
  assert.strictEqual(me.data.plan.plan.key, 'free');
  const r = await call('userA', 'POST', '/api/tenders', { body: { name: 'عطاء ثانٍ' } });
  assert.strictEqual(r.status, 402);
});

test('41 — الرجوع لباقة أصغر من الاستهلاك يُرفض 409', async () => {
  const user = { id: userAId };
  assert.ok(user.id, 'يجب أن يكون حساب الاختبار 02 هو الحساب الذي تُعدّل باقته');
  getDB().prepare("UPDATE subscriptions SET status='cancelled' WHERE user_id=? AND status='active'").run(user.id);
  getDB().prepare("UPDATE users SET plan_key='starter' WHERE id=?").run(user.id);
  getDB().prepare("INSERT INTO subscriptions (id,user_id,plan_key,status,source) VALUES (?,?,?,'active','manual')").run('sub_downgrade_' + uniq(), user.id, 'starter');
  const extra = await call('userA', 'POST', '/api/tenders', { body: { name: 'عطاء إضافي على باقة Starter' } });
  assert.strictEqual(extra.status, 201);
  const r = await call('userA', 'POST', '/api/plan', { body: { planKey: 'free' } });
  assert.strictEqual(r.status, 409);
  assert.strictEqual(r.data.error.code, 'CONFLICT');
});

test('42 — باقة غير معروفة تُرفض 422', async () => {
  const r = await call('userA', 'POST', '/api/plan', { body: { planKey: 'gold' } });
  assert.strictEqual(r.status, 422);
});

test('43 — قائمة الباقات تعيد الأربع', async () => {
  const r = await call('userA', 'GET', '/api/plans');
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.plans.length, 4);
  assert.deepStrictEqual(r.data.plans.map((p) => p.key), ['free', 'starter', 'pro', 'ent']);
  assert.strictEqual(r.data.plans[3].maxTenders, null, 'Enterprise يجب أن تكون غير محدودة');
});

/* ==========================================================
   8) الحذف والخروج
   ========================================================== */
test('44 — حذف ملف يعمل ويحدّث العدد', async () => {
  const before = (await call('userA', 'GET', '/api/tenders/' + tenderA.id + '/files')).data.count;
  const r = await call('userA', 'DELETE', '/api/files/' + fileA.id);
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.data.remaining, before - 1);
  const after = (await call('userA', 'GET', '/api/tenders/' + tenderA.id + '/files')).data.count;
  assert.strictEqual(after, before - 1);
});

test('45 — حذف نفس الملف مرة أخرى يعيد 404', async () => {
  const r = await call('userA', 'DELETE', '/api/files/' + fileA.id);
  assert.strictEqual(r.status, 404);
});

test('46 — الملف المحذوف لم يبق على القرص', async () => {
  const db = getDB();
  const row = db.prepare('SELECT 1 FROM files WHERE id = ?').get(fileA.id);
  assert.strictEqual(row, undefined);
  const abs = path.join(process.env.UPLOAD_DIR, row ? row.rel_path : 'nonexistent');
  assert.strictEqual(fs.existsSync(abs), false);
});

test('47 — حذف العطاء يحذف ملفاته وطلباته', async () => {
  const r = await call('userA', 'DELETE', '/api/tenders/' + tenderA.id);
  assert.strictEqual(r.status, 200);
  const db = getDB();
  assert.strictEqual(db.prepare('SELECT COUNT(*) AS n FROM files WHERE tender_id = ?').get(tenderA.id).n, 0);
  assert.strictEqual(db.prepare('SELECT COUNT(*) AS n FROM requests WHERE tender_id = ?').get(tenderA.id).n, 0);
  const get = await call('userA', 'GET', '/api/tenders/' + tenderA.id);
  assert.strictEqual(get.status, 404);
});

test('48 — تسجيل الخروج يبطل الجلسة', async () => {
  const out = await call('userA', 'POST', '/api/auth/logout');
  assert.strictEqual(out.status, 200);
  const me = await call('userA', 'GET', '/api/auth/me');
  assert.strictEqual(me.status, 401);
});

test('49 — نقطة API غير موجودة تعيد 404 بصيغة موحّدة', async () => {
  const r = await call('userA', 'GET', '/api/nope');
  assert.strictEqual(r.status, 404);
  assert.strictEqual(r.data.error.code, 'NOT_FOUND');
});

test('50 — توكن مُلفَّق يُرفض 401', async () => {
  const res = await fetch(base + '/api/auth/me', { headers: { Cookie: 'tpkit_session=malformed.token.here' } });
  assert.strictEqual(res.status, 401);
});

/* ==========================================================
   9) انحدار: الواجهة ترسل null للحقول الاختيارية الفارغة
   (اكتُشف هذا الخلل بتشغيل الصفحة في متصفح حقيقي، وليس بـ curl)
   ========================================================== */
test('51 — إنشاء عطاء بحقول اختيارية = null (كما يرسلها المتصفح)', async () => {
  const email = 'nulltest' + uniq() + '@test.com';
  await call('nul', 'POST', '/api/auth/register', { body: { name: 'اختبار null', email, password: 'Password123' } });
  const r = await call('nul', 'POST', '/api/tenders', {
    body: { name: 'عطاء بحقول فارغة', authority: null, closing: null, notes: null }
  });
  assert.strictEqual(r.status, 201, 'null في الحقول الاختيارية يجب أن يُقبل: ' + JSON.stringify(r.data));
  assert.strictEqual(r.data.tender.authority, null);
  assert.strictEqual(r.data.tender.closing, null);
  assert.strictEqual(r.data.tender.notes, null);
});

test('52 — تحديث عطاء بحقول اختيارية = null', async () => {
  // نستخدم العطاء الموجود (الباقة المجانية تسمح بعطاء واحد فقط)
  const list = await call('nul', 'GET', '/api/tenders');
  assert.strictEqual(list.status, 200);
  assert.ok(list.data.tenders.length >= 1, 'يجب أن يوجد العطاء من الاختبار السابق');
  const id = list.data.tenders[0].id;

  const u = await call('nul', 'PATCH', '/api/tenders/' + id, {
    body: { authority: null, closing: null, notes: null }
  });
  assert.strictEqual(u.status, 200, JSON.stringify(u.data));
  assert.strictEqual(u.data.tender.authority, null);
  assert.strictEqual(u.data.tender.closing, null);
  assert.strictEqual(u.data.tender.notes, null);
});

test('53 — تسجيل بحقل شركة = null', async () => {
  const r = await call('nul2', 'POST', '/api/auth/register', {
    body: { name: 'بلا شركة', email: 'noco' + uniq() + '@test.com', password: 'Password123', company: null }
  });
  assert.strictEqual(r.status, 422, JSON.stringify(r.data));
  assert.strictEqual(r.data.error.code, 'VALIDATION');
});

test('54 — سلسلة كاملة كما تفعل الواجهة: إنشاء ثم رفع ثم حذف', async () => {
  const email = 'ui' + uniq() + '@test.com';
  await call('ui', 'POST', '/api/auth/register', { body: { name: 'محاكاة الواجهة', email, password: 'Password123' } });

  const created = await call('ui', 'POST', '/api/tenders', {
    body: { name: 'عمارة سكنية — محاكاة', authority: null, closing: null, notes: null }
  });
  assert.strictEqual(created.status, 201, 'إنشاء: ' + JSON.stringify(created.data));
  const tid = created.data.tender.id;

  const up = await call('ui', 'POST', '/api/tenders/' + tid + '/files', {
    form: makeForm([{ name: 'arch-plan.pdf', content: 'X', type: 'application/pdf' }], { categories: JSON.stringify(['arch']) })
  });
  assert.strictEqual(up.status, 201, 'رفع: ' + JSON.stringify(up.data));
  const fid = up.data.files[0].id;

  const after = await call('ui', 'GET', '/api/tenders/' + tid);
  assert.strictEqual(after.data.tender.status, 'ready');
  assert.strictEqual(after.data.files.length, 1);

  const del = await call('ui', 'DELETE', '/api/files/' + fid);
  assert.strictEqual(del.status, 200);
  const back = await call('ui', 'GET', '/api/tenders/' + tid);
  assert.strictEqual(back.data.tender.status, 'new', 'بعد حذف كل الملفات يرجع العطاء إلى new');
});

/* ==========================================================
   بوابة المشتريات: مجانية دائمة دون اشتراك أو تجربة
   ========================================================== */
const reqs4 = () => [{ title: 'الخبرة', weight: 50, mandatory: true }, { title: 'المنهجية', weight: 50, mandatory: false }];
const mkTender = (who, n) => call(who, 'POST', '/api/procurement/tenders', { body: { name: 'عطاء ' + n, reference: 'R-' + uniq(), requirements: reqs4() } });

test('55 — لا تعرض المنصة باقات مدفوعة لبوابة المشتريات', async () => {
  const r = await call('anon', 'GET', '/api/billing/plans?audience=buyer');
  assert.strictEqual(r.status, 200);
  assert.deepStrictEqual(r.data.plans, []);
  assert.strictEqual(r.data.buyerCoreFree, true);
});

test('56 — لا يستطيع حساب المشتريات بدء تجربة أو إصدار فاتورة اشتراك', async () => {
  await call('buy', 'POST', '/api/auth/register', { body: { name: 'مشتريات', email: 'b' + uniq() + '@t.com', password: 'Password123', role: 'buyer' } });
  const me = await call('buy', 'GET', '/api/auth/me');
  assert.strictEqual(me.data.user.planKey, 'free');
  assert.strictEqual(me.data.plan.plan.key, 'free');
  assert.strictEqual((await call('buy', 'POST', '/api/billing/trial', { body: { planKey: 'proc_pro' } })).status, 403);
  assert.strictEqual((await call('buy', 'POST', '/api/billing/invoices', { body: { planKey: 'proc_pro' } })).status, 403);
  assert.strictEqual((await call('buy', 'GET', '/api/billing/invoices')).data.count, 0);
  const legacyPlans = await call('buy', 'GET', '/api/plans');
  assert.strictEqual(legacyPlans.status, 200);
  assert.deepStrictEqual(legacyPlans.data.plans.map((p) => p.key), ['free']);
  assert.strictEqual(legacyPlans.data.buyerCoreFree, true);
  assert.strictEqual((await call('buy', 'POST', '/api/plan', { body: { planKey: 'pro' } })).status, 403);
  assert.strictEqual((await call('buy', 'POST', '/api/upgrade-interest', { body: { planKey: 'pro' } })).status, 403);
});

test('57 — تبقى عمليات المشتريات الأساسية متاحة دون حد عطاءات أو اشتراك', async () => {
  const buyerEmail = 'f' + uniq() + '@t.com';
  await call('free', 'POST', '/api/auth/register', { body: { name: 'جهة مجانية', email: buyerEmail, password: 'Password123', role: 'buyer' } });
  for (let i = 0; i < 15; i++) {
    const created = await mkTender('free', i + 1);
    assert.strictEqual(created.status, 201, JSON.stringify(created.data));
  }
  const me = await call('free', 'GET', '/api/auth/me');
  assert.strictEqual(me.data.plan.plan.key, 'free');
  assert.strictEqual(me.data.plan.plan.maxTenders, null);
  assert.strictEqual(me.data.plan.plan.maxBytes, null);
  assert.strictEqual(me.data.plan.usage.tenders, 15);

  // A legacy paid plan key must not reintroduce buyer subscription limits.
  const buyerRow = getDB().prepare('SELECT id FROM users WHERE email=?').get(buyerEmail);
  assert.ok(buyerRow);
  getDB().prepare("UPDATE users SET plan_key='proc_basic' WHERE id=?").run(buyerRow.id);
  const forcedPaidKey = await call('free', 'GET', '/api/auth/me');
  assert.strictEqual(forcedPaidKey.data.user.planKey, 'free');
  assert.strictEqual(forcedPaidKey.data.plan.plan.key, 'free');

  // Buyer storage bypasses plan quotas, while multer file-size/count/type limits remain active.
  const originalMax = getDB().prepare("SELECT max_bytes FROM plans WHERE key='free'").get().max_bytes;
  getDB().prepare("UPDATE plans SET max_bytes=1 WHERE key='free'").run();
  try {
    const legacyTender = await call('free', 'POST', '/api/tenders', { body: { name: 'ملف جهة مشتريات' } });
    assert.strictEqual(legacyTender.status, 201);
    const uploaded = await call('free', 'POST', '/api/tenders/' + legacyTender.data.tender.id + '/files', {
      form: makeForm([{ name: 'buyer-document.pdf', content: 'buyer file exceeds plan quota', type: 'application/pdf' }])
    });
    assert.strictEqual(uploaded.status, 201, JSON.stringify(uploaded.data));
  } finally {
    getDB().prepare("UPDATE plans SET max_bytes=? WHERE key='free'").run(originalMax);
  }
});

test('58 — المقاول لا يستطيع استخدام باقات المشتريات أو تجربتها', async () => {
  await call('con', 'POST', '/api/auth/register', { body: { name: 'مقاول', email: 'c' + uniq() + '@t.com', password: 'Password123' } });
  assert.strictEqual((await call('con', 'POST', '/api/billing/trial', { body: { planKey: 'proc_basic' } })).status, 403);
  assert.strictEqual((await call('con', 'POST', '/api/billing/invoices', { body: { planKey: 'proc_pro' } })).status, 403);
});

test('61 — بيانات الدفع تُقرأ من الإعدادات وتُعرض عبر /api/payment-info', async () => {
  const r = await call('anon2', 'GET', '/api/payment-info');
  assert.strictEqual(r.status, 200);
  // لا تُضمَّن بيانات حساب مصرفي شخصية في إعدادات المصدر الافتراضية.
  assert.strictEqual(r.data.payment.swift, '');
  assert.strictEqual(r.data.payment.iban, '');
  assert.strictEqual(r.data.payment.accountHolder, '');
  assert.strictEqual(r.data.payment.cliqAlias, '');
  assert.strictEqual(r.data.ibanValid, false);
});

test('62 — ملفات Excel/PDF تُخدم من /documents، وبقية ملفات المجلد مغلقة', async () => {
  const b = base;
  const ok = await fetch(b + '/documents/technical-proposal-kit_v5/quantity-takeoff-en.xlsx');
  assert.strictEqual(ok.status, 200);
  assert.ok((await ok.arrayBuffer()).byteLength > 1000);
  assert.strictEqual((await fetch(b + '/documents/technical-proposal-kit/quantity-takeoff.xlsx')).status, 200);
  assert.strictEqual((await fetch(b + '/documents/technical-proposal-kit_v5/technical-proposal-kit-en.pdf')).status, 200);
  for (const hidden of ['/documents/billing-implementation-ar.md', '/documents/technical-proposal-kit_v5/env.example', '/documents/technical-proposal-kit_v5/test-results.txt', '/documents/technical-proposal-kit_v2/quantity-takeoff-en.xlsx']) {
    assert.notStrictEqual((await fetch(b + hidden)).status, 200, hidden);
  }
});

/* ==========================================================
   موعد الإغلاق + حد التقديم الإلكتروني حسب باقة المقاول
   ========================================================== */
async function publish(who, closing) {
  const r = await call(who, 'POST', '/api/procurement/tenders', { body: { name: 'عطاء ' + uniq(), reference: 'Q-' + uniq(), closing, requirements: reqs4() } });
  assert.strictEqual(r.status, 201, JSON.stringify(r.data));
  return r.data.tender;
}
function grantPlan(email, planKey) {
  const u = getDB().prepare('SELECT id FROM users WHERE email=?').get(email);
  getDB().prepare("UPDATE subscriptions SET status='cancelled' WHERE user_id=? AND status='active'").run(u.id);
  getDB().prepare("INSERT INTO subscriptions (id,user_id,plan_key,status,source,started_at,ends_at) VALUES (?,?,?,?,?,unixepoch(),unixepoch()+2592000)").run('sub_t' + uniq(), u.id, planKey, 'active', 'manual');
  getDB().prepare('UPDATE users SET plan_key=? WHERE id=?').run(planKey, u.id);
}
const bidBody = (t, amount = 1000, currency = 'JOD') => { const fd = new FormData(); fd.append('answers', JSON.stringify(t.requirements.map((q) => ({ requirementId: q.id, answer: 'إجابة' })))); fd.append('financialAmount', String(amount)); fd.append('financialCurrency', currency); fd.append('declarationAccepted', 'true'); fd.append('technicalFiles', new Blob(['technical test document'], { type: 'application/pdf' }), 'technical.pdf'); fd.append('financialFiles', new Blob(['financial test document'], { type: 'application/pdf' }), 'financial.pdf'); return fd; };

test('63 — لا تقديم بعد موعد الإغلاق، ويُقبل في يوم الإغلاق نفسه وبدون موعد', async () => {
  const ymd = (d) => new Date(d).toISOString().slice(0, 10);
  await call('qbuy', 'POST', '/api/auth/register', { body: { name: 'جهة', email: 'qb' + uniq() + '@t.com', password: 'Password123', role: 'buyer' } });
  const qcEmail = 'qc' + uniq() + '@t.com';
  await call('qcon', 'POST', '/api/auth/register', { body: { name: 'مقاول', email: qcEmail, password: 'Password123' } });
  grantPlan(qcEmail, 'ent');
  const past = await publish('qbuy', ymd(Date.now() - 3 * 86400000));
  const noDate = await publish('qbuy', undefined);
  const today = await publish('qbuy', new Date(Date.now() + 3 * 3600000).toISOString().slice(0, 10));
  const list = await call('qcon', 'GET', '/api/procurement/open-tenders');
  assert.strictEqual(list.data.tenders.find((t) => t.id === past.id).expired, true);
  assert.strictEqual(list.data.tenders.find((t) => t.id === noDate.id).expired, false);
  const late = await call('qcon', 'POST', '/api/procurement/tenders/' + past.id + '/submit', { body: bidBody(past) });
  assert.strictEqual(late.status, 409);
  assert.ok(/انتهى موعد/.test(late.data.error.message));
  assert.strictEqual((await call('qcon', 'POST', '/api/procurement/tenders/' + noDate.id + '/submit', { body: bidBody(noDate) })).status, 201);
  assert.strictEqual((await call('qcon', 'POST', '/api/procurement/tenders/' + today.id + '/submit', { body: bidBody(today) })).status, 201);
});

test('64 — حد التقديم الإلكتروني: المجاني 2، ويُرفع بالترقية', async () => {
  const email = 'ql' + uniq() + '@t.com';
  await call('qfree', 'POST', '/api/auth/register', { body: { name: 'مجاني', email, password: 'Password123' } });
  const me = await call('qfree', 'GET', '/api/auth/me');
  assert.strictEqual(me.data.plan.plan.maxSubmissions, 2);
  assert.strictEqual(me.data.plan.usage.submissions, 0);
  const a = await publish('qbuy'), b = await publish('qbuy'), c = await publish('qbuy');
  assert.strictEqual((await call('qfree', 'POST', '/api/procurement/tenders/' + a.id + '/submit', { body: bidBody(a) })).status, 201);
  assert.strictEqual((await call('qfree', 'POST', '/api/procurement/tenders/' + b.id + '/submit', { body: bidBody(b) })).status, 201);
  const blocked = await call('qfree', 'POST', '/api/procurement/tenders/' + c.id + '/submit', { body: bidBody(c) });
  assert.strictEqual(blocked.status, 403);
  assert.ok(/حد باقتك/.test(blocked.data.error.message));
  assert.strictEqual((await call('qfree', 'GET', '/api/auth/me')).data.plan.usage.submissions, 2);
  grantPlan(email, 'starter');
  assert.strictEqual((await call('qfree', 'POST', '/api/procurement/tenders/' + c.id + '/submit', { body: bidBody(c) })).status, 201);
});

test('65 — قائمة باقات المقاول تُظهر حدّ التقديمات', async () => {
  const r = await call('qfree', 'GET', '/api/plans');
  assert.deepStrictEqual(r.data.plans.map((p) => [p.key, p.maxSubmissions]), [['free', 2], ['starter', 10], ['pro', 40], ['ent', null]]);
});

/* ==========================================================
   توثيق الجهات + دول الخليج
   ========================================================== */
const cfg = require('../src/config');
function verForm(over = {}, withDoc = true) {
  const fd = new FormData();
  const f = { orgName: 'شركة الخليج للمشاريع', orgType: 'company', country: 'AE', regNumber: 'CR-123456', officialPhone: '+971 4 123 4567', officialEmail: 'procurement@gulf-projects.example', onBehalfOf: '', website: '', ...over };
  Object.entries(f).forEach(([k, v]) => fd.append(k, v));
  if (withDoc) fd.append('docs', new Blob(['%PDF-1.4 commercial registration'], { type: 'application/pdf' }), 'registration.pdf');
  return fd;
}
async function makeAdmin(name) {
  const email = 'ad' + uniq() + '@t.com';
  await call(name, 'POST', '/api/auth/register', { body: { name: 'مدير', email, password: 'Password123' } });
  getDB().prepare("UPDATE users SET role='admin' WHERE email=?").run(email);
  await call(name, 'POST', '/api/auth/login', { body: { email, password: 'Password123' } });
}

test('66 — لا نشر قبل التوثيق؛ الطلب والمراجعة والرفض والاعتماد والسحب', async () => {
  cfg.REQUIRE_ORG_VERIFICATION = true;
  try {
    await call('vb', 'POST', '/api/auth/register', { body: { name: 'جهة', email: 'vb' + uniq() + '@t.com', password: 'Password123', role: 'buyer' } });
    const blocked = await mkTender('vb', 1);
    assert.strictEqual(blocked.status, 403);
    assert.strictEqual(blocked.data.error.code, 'ORG_NOT_VERIFIED');
    // تحقق من المدخلات
    assert.strictEqual((await call('vb', 'POST', '/api/verification', { form: verForm({ country: 'XX' }) })).status, 422);
    assert.strictEqual((await call('vb', 'POST', '/api/verification', { form: verForm({}, false) })).status, 422, 'وثيقة واحدة على الأقل');
    const sent = await call('vb', 'POST', '/api/verification', { form: verForm() });
    assert.strictEqual(sent.status, 201, JSON.stringify(sent.data));
    assert.strictEqual(sent.data.verification.status, 'pending');
    assert.strictEqual((await call('vb', 'POST', '/api/verification', { form: verForm() })).status, 409, 'لا طلب ثانٍ أثناء المراجعة');
    assert.strictEqual((await mkTender('vb', 2)).status, 403, 'ما زال محظوراً أثناء المراجعة');
    // غير المدير لا يرى لوحة المراجعة
    assert.strictEqual((await call('vb', 'GET', '/api/verification/admin')).status, 403);
    await makeAdmin('vadm');
    const list = await call('vadm', 'GET', '/api/verification/admin?status=pending');
    const row = list.data.verifications.find((v) => v.orgName === 'شركة الخليج للمشاريع' && v.status === 'pending');
    assert.ok(row && row.docs.length === 1 && row.countryAr === 'الإمارات');
    const doc = await fetch(base + '/api/verification/admin/' + row.id + '/docs/' + row.docs[0].id, { headers: cookieFor('vadm') });
    assert.strictEqual(doc.status, 200);
    assert.strictEqual((await call('vadm', 'POST', '/api/verification/admin/' + row.id + '/reject', { body: {} })).status, 422, 'السبب إلزامي');
    assert.strictEqual((await call('vadm', 'POST', '/api/verification/admin/' + row.id + '/reject', { body: { note: 'السجل غير واضح' } })).status, 200);
    const mine = await call('vb', 'GET', '/api/verification');
    assert.strictEqual(mine.data.verification.status, 'rejected');
    assert.strictEqual(mine.data.verification.reviewNote, 'السجل غير واضح');
    // إعادة التقديم ثم الاعتماد
    assert.strictEqual((await call('vb', 'POST', '/api/verification', { form: verForm({ orgName: 'شركة الخليج للمشاريع ذ.م.م' }) })).status, 201);
    assert.strictEqual((await call('vadm', 'POST', '/api/verification/admin/' + row.id + '/approve', { body: { days: 365 } })).status, 200);
    const pub = await mkTender('vb', 3);
    assert.strictEqual(pub.status, 201, JSON.stringify(pub.data));
    assert.strictEqual(pub.data.tender.country, 'AE');
    assert.strictEqual(pub.data.tender.currency, 'AED');
    // المقاول يرى الشارة
    await call('vc', 'POST', '/api/auth/register', { body: { name: 'مقاول', email: 'vc' + uniq() + '@t.com', password: 'Password123' } });
    const open = await call('vc', 'GET', '/api/procurement/open-tenders');
    const seen = open.data.tenders.find((t) => t.id === pub.data.tender.id);
    assert.ok(seen && seen.issuer.verified === true && seen.issuer.country === 'AE' && seen.issuer.name.includes('ذ.م.م'));
    // عملة العرض: KWD مقبولة، وغير المعروفة تعود لعملة دولة الجهة
    const ok = await call('vc', 'POST', '/api/procurement/tenders/' + pub.data.tender.id + '/submit', { body: bidBody(pub.data.tender, 1000, 'KWD') });
    assert.strictEqual(ok.status, 201);
    assert.strictEqual(getDB().prepare('SELECT financial_currency c FROM bid_submissions WHERE id=?').get(ok.data.submissionId).c, 'KWD');
    const bidCurrencies = require('../src/lib/org').BID_CURRENCIES;
    assert.ok(bidCurrencies.includes('GBP') && bidCurrencies.includes('EUR'), 'GBP and EUR must be accepted bid currencies');
    // سحب التوثيق: يختفي العطاء ويُمنع التقديم
    assert.strictEqual((await call('vadm', 'POST', '/api/verification/admin/' + row.id + '/revoke', { body: { note: 'شكوى موثّقة' } })).status, 200);
    assert.ok(!(await call('vc', 'GET', '/api/procurement/open-tenders')).data.tenders.some((t) => t.id === pub.data.tender.id));
    await call('vc2', 'POST', '/api/auth/register', { body: { name: 'مقاول2', email: 'vc2' + uniq() + '@t.com', password: 'Password123' } });
    assert.strictEqual((await call('vc2', 'POST', '/api/procurement/tenders/' + pub.data.tender.id + '/submit', { body: bidBody(pub.data.tender) })).status, 409);
  } finally { cfg.REQUIRE_ORG_VERIFICATION = false; }
});

test('67 — دول الخليج: فواتير بالعملات المربوطة، والدينار الكويتي بالدولار فقط', async () => {
  await call('gcc', 'POST', '/api/auth/register', { body: { name: 'مقاول خليجي', email: 'g' + uniq() + '@t.com', password: 'Password123', role: 'contractor' } });
  const amt = async (cur) => (await call('gcc', 'POST', '/api/billing/invoices', { body: { planKey: 'starter', billingCycle: 'monthly', currency: cur } }));
  assert.strictEqual((await amt('USD')).data.invoice.amount, 39);
  assert.strictEqual((await amt('SAR')).data.invoice.amount, 146.25);
  assert.strictEqual((await amt('AED')).data.invoice.amount, 143.23);
  assert.strictEqual((await amt('QAR')).data.invoice.amount, 141.96);
  assert.strictEqual((await amt('BHD')).data.invoice.amount, 14.664);
  assert.strictEqual((await amt('OMR')).data.invoice.amount, 14.996);
  assert.strictEqual((await amt('JOD')).data.invoice.amount, 27.65);
  assert.strictEqual((await amt('KWD')).status, 422);
});

test('68 — توقيت إغلاق العطاء حسب دولة الجهة (الإمارات +4، السعودية +3)', async () => {
  const org = require('../src/lib/org');
  assert.strictEqual(org.tzOf('AE'), '+04:00');
  assert.strictEqual(org.tzOf('OM'), '+04:00');
  assert.strictEqual(org.tzOf('SA'), '+03:00');
  assert.strictEqual(org.tzOf('XX'), '+03:00');
  assert.deepStrictEqual(Object.keys((await call('anon3', 'GET', '/api/verification/meta')).data.countries.reduce((o, c) => ({ ...o, [c.code]: 1 }), {})), ['JO', 'SA', 'AE', 'KW', 'QA', 'BH', 'OM']);
});

test('69 — نص العطاء بالعربية والإنجليزية: الاسم والملاحظات وعناوين المتطلبات', async () => {
  await call('bl', 'POST', '/api/auth/register', { body: { name: 'جهة ثنائية', email: 'bl' + uniq() + '@t.com', password: 'Password123', role: 'buyer' } });
  const mk = await call('bl', 'POST', '/api/procurement/tenders', { body: {
    name: 'إنشاء مبنى الإدارة', nameEn: 'Administration building construction', notes: 'ملاحظات', notesEn: 'Site visit is mandatory', reference: 'BL-' + uniq(),
    requirements: [{ title: 'الخبرة السابقة', titleEn: 'Previous experience', description: 'وصف', descriptionEn: 'Describe similar projects', weight: 60, mandatory: true }, { title: 'المنهجية', weight: 40 }] } });
  assert.strictEqual(mk.status, 201, JSON.stringify(mk.data));
  const t = mk.data.tender;
  assert.strictEqual(t.nameEn, 'Administration building construction');
  assert.strictEqual(t.notesEn, 'Site visit is mandatory');
  assert.strictEqual(t.requirements[0].titleEn, 'Previous experience');
  assert.strictEqual(t.requirements[0].descriptionEn, 'Describe similar projects');
  assert.strictEqual(t.requirements[1].titleEn, null, 'الإنجليزية اختيارية');
  await call('blc', 'POST', '/api/auth/register', { body: { name: 'مقاول', email: 'blc' + uniq() + '@t.com', password: 'Password123' } });
  const list = await call('blc', 'GET', '/api/procurement/open-tenders');
  assert.strictEqual(list.data.tenders.find((x) => x.id === t.id).nameEn, 'Administration building construction');
  const one = await call('blc', 'GET', '/api/procurement/tenders/' + t.id);
  assert.strictEqual(one.data.tender.requirements[0].titleEn, 'Previous experience');
  // الحقول القديمة بلا إنجليزي تبقى صالحة
  const old = await mkTender('bl', 7);
  assert.strictEqual(old.status, 201);
  assert.strictEqual(old.data.tender.nameEn, null);
});

/* ==========================================================
   الجهة والأدوار + دورة الطلبات (مالك ← مشاريع ← مشتريات ← مقاول)
   ========================================================== */
let teamSeq = 0;
async function newBuyer(name, plan, country) {
  const email = name + (++teamSeq) + uniq() + '@t.com';
  const r = await call(name + teamSeq, 'POST', '/api/auth/register', { body: { name: 'عضو ' + name, email, password: 'Password123', role: 'buyer', ...(country ? { country } : {}) } });
  assert.strictEqual(r.status, 201, JSON.stringify(r.data));
  const who = name + teamSeq;
  // Buyer plans are permanently free; the legacy plan argument is retained only for fixture compatibility.
  return who;
}
async function joinTeam(mgr, role, label) {
  const inv = await call(mgr, 'POST', '/api/org/invites', { body: { role, label } });
  assert.strictEqual(inv.status, 201, JSON.stringify(inv.data));
  const who = await newBuyer(label);
  const j = await call(who, 'POST', '/api/org/join', { body: { code: inv.data.code } });
  assert.strictEqual(j.status, 200, JSON.stringify(j.data));
  return { who, code: inv.data.code };
}
const reqBody = (over = {}) => ({ title: 'إنشاء مبنى إداري', titleEn: 'Administrative building', description: 'مبنى من ثلاثة طوابق', location: 'عمّان', country: 'JO', serviceType: 'works', budget: 500000, currency: 'JOD', neededBy: '2027-06-30', ...over });
function docForm(kind, name = 'spec.pdf') {
  const fd = new FormData();
  fd.append('kind', kind);
  fd.append('files', new Blob(['%PDF-1.4 ' + kind], { type: 'application/pdf' }), name);
  return fd;
}
const tenderBody = (over = {}) => ({ closing: '2030-01-01', requirements: reqs4(), ...over });

test('70 — جهة جديدة: تحفظ دولة الحساب على الجهة وتُدار عضويتها', async () => {
  const free = await newBuyer('free', undefined, 'AE');
  const org = await call(free, 'GET', '/api/org');
  assert.strictEqual(org.data.myRole, 'manager');
  const userId = (await call(free, 'GET', '/api/auth/me')).data.user.id;
  const orgId = getDB().prepare('SELECT org_id FROM org_members WHERE user_id=?').get(userId).org_id;
  assert.strictEqual(getDB().prepare('SELECT country FROM organizations WHERE id=?').get(orgId).country, 'AE');
  assert.strictEqual(org.data.seats.max, null, 'عدد أعضاء الجهة غير محدود ضمن بوابة المشتريات المجانية');
  const first = await joinTeam(free, 'requester', 'first-free-member');
  assert.strictEqual(first.who !== free, true);
  const afterJoin = await call(free, 'GET', '/api/org');
  assert.strictEqual(afterJoin.data.members.length, 2);
  const pro = await newBuyer('pro', 'proc_basic');
  assert.strictEqual((await call(pro, 'GET', '/api/org')).data.seats.max, null);
  await joinTeam(pro, 'requester', 'r');
  await joinTeam(pro, 'projects', 'p');
  const fourth = await call(pro, 'POST', '/api/org/invites', { body: { role: 'procurement' } });
  assert.strictEqual(fourth.status, 201, 'لا يوجد حد مقاعد مرتبط بباقة مدفوعة للمشتريات');
});

test('71 — الانضمام برمز: صحيح مرة واحدة، والأدوار تُدار من المدير فقط', async () => {
  const mgr = await newBuyer('mgr', 'proc_pro');
  const inv = await call(mgr, 'POST', '/api/org/invites', { body: { role: 'projects', label: 'مهندس' } });
  const a = await newBuyer('a');
  assert.strictEqual((await call(a, 'POST', '/api/org/join', { body: { code: 'AAAAA-BBBBB' } })).status, 404, 'رمز خاطئ');
  assert.strictEqual((await call(a, 'POST', '/api/org/join', { body: { code: inv.data.code } })).status, 200);
  const b = await newBuyer('b');
  assert.strictEqual((await call(b, 'POST', '/api/org/join', { body: { code: inv.data.code } })).status, 404, 'الرمز لا يُستعمل مرتين');
  const org = await call(mgr, 'GET', '/api/org');
  assert.deepStrictEqual(org.data.members.map((m) => m.role).sort(), ['manager', 'projects']);
  assert.ok(org.data.members.every((m) => m.email), 'المدير يرى البريد');
  const view = await call(a, 'GET', '/api/org');
  assert.strictEqual(view.data.myRole, 'projects');
  assert.ok(view.data.members.every((m) => m.email === undefined), 'العضو العادي لا يرى البريد');
  assert.strictEqual((await call(a, 'POST', '/api/org/invites', { body: { role: 'requester' } })).status, 403);
  const me = await call(a, 'GET', '/api/auth/me');
  assert.strictEqual(me.data.plan.plan.key, 'free', 'كل أعضاء الجهة يستخدمون الخدمات الأساسية المجانية');
  const memberId = org.data.members.find((m) => m.role === 'projects').id;
  const owner = org.data.members.find((m) => m.isOwner).id;
  assert.strictEqual((await call(mgr, 'PATCH', '/api/org/members/' + owner, { body: { role: 'projects' } })).status, 409, 'صاحب الاشتراك يبقى مديراً');
  assert.strictEqual((await call(mgr, 'PATCH', '/api/org/members/' + memberId, { body: { role: 'procurement' } })).status, 200);
  assert.strictEqual((await call(a, 'GET', '/api/org')).data.myRole, 'procurement');
  assert.strictEqual((await call(mgr, 'DELETE', '/api/org/members/' + memberId)).status, 200);

  // Organization managers cannot alter members or revoke invitations belonging to another tenant.
  const foreignManager = await newBuyer('foreign-manager', 'proc_pro');
  const foreignMemberSession = (await joinTeam(foreignManager, 'requester', 'foreign-member')).who;
  const foreignMemberId = (await call(foreignMemberSession, 'GET', '/api/auth/me')).data.user.id;
  const foreignInvite = await call(foreignManager, 'POST', '/api/org/invites', { body: { role: 'finance' } });
  assert.strictEqual((await call(mgr, 'PATCH', '/api/org/members/' + foreignMemberId, { body: { role: 'finance' } })).status, 404);
  assert.strictEqual((await call(mgr, 'DELETE', '/api/org/members/' + foreignMemberId, {})).status, 404);
  assert.strictEqual((await call(mgr, 'DELETE', '/api/org/invites/' + foreignInvite.data.invite.id)).status, 404);
  assert.strictEqual((await call(foreignManager, 'GET', '/api/org')).data.members.some((m) => m.id === foreignMemberId), true);
});

test('72 — دورة كاملة: طلب ← مشاريع ← جاهز ← مشتريات تنشر ← المقاول يرى الوثائق وFIDIC', async () => {
  const mgr = await newBuyer('mg', 'proc_pro');
  const R = (await joinTeam(mgr, 'requester', 'rq')).who, P = (await joinTeam(mgr, 'projects', 'pj')).who, C = (await joinTeam(mgr, 'procurement', 'pc')).who;
  const made = await call(R, 'POST', '/api/requests', { body: reqBody() });
  assert.strictEqual(made.status, 201, JSON.stringify(made.data));
  const id = made.data.request.id;
  assert.strictEqual(made.data.request.status, 'draft');
  assert.strictEqual((await call(P, 'GET', '/api/requests')).data.requests.length, 0, 'المسودة لا تظهر للمشاريع');
  assert.strictEqual((await call(P, 'GET', '/api/requests/' + id)).status, 404);
  assert.strictEqual((await call(R, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'take' } })).status, 403);
  assert.strictEqual((await call(R, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'submit' } })).data.request.status, 'submitted');
  assert.strictEqual((await call(P, 'GET', '/api/requests')).data.requests.length, 1);
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'take' } })).data.request.status, 'in_study');
  // لا تجهيز بلا وثائق أو بلا FIDIC
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'ready' } })).status, 422);
  assert.strictEqual((await call(R, 'POST', '/api/requests/' + id + '/docs', { form: docForm('specifications') })).status, 403, 'الطالب لا يرفع مواصفات');
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/docs', { form: docForm('specifications', 'spec.pdf') })).status, 201);
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/docs', { form: docForm('drawings', 'plan.pdf') })).status, 201);
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/docs', { form: docForm('internal', 'cost-notes.pdf') })).status, 201);
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'ready' } })).status, 422, 'FIDIC مطلوب');
  const fid = await call(P, 'PATCH', '/api/requests/' + id, { body: { fidicBook: 'red', fidicEdition: '2017', particularNotes: 'الشروط الخاصة مرفقة' } });
  assert.strictEqual(fid.status, 200, JSON.stringify(fid.data));
  assert.strictEqual((await call(P, 'PATCH', '/api/requests/' + id, { body: { fidicBook: 'purple' } })).status, 422);
  await call(P, 'PATCH', '/api/requests/' + id, { body: { fidicBook: 'red', fidicEdition: '' } });
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'ready' } })).status, 422, 'إصدار FIDIC مطلوب');
  await call(P, 'PATCH', '/api/requests/' + id, { body: { fidicBook: 'red', fidicEdition: '2017' } });
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'ready' } })).status, 422, 'جدول الكميات مطلوب لأعمال الإنشاء');
  await call(P, 'POST', '/api/requests/' + id + '/docs', { form: docForm('boq', 'boq.pdf') });
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'ready' } })).data.request.status, 'ready');
  // المشتريات ترى الجاهز فقط وتنشر؛ الطالب لا ينشر
  assert.strictEqual((await call(C, 'GET', '/api/requests')).data.requests.length, 1);
  assert.strictEqual((await call(R, 'POST', '/api/requests/' + id + '/tender', { body: tenderBody() })).status, 403);
  assert.strictEqual((await call(C, 'POST', '/api/requests/' + id + '/tender', { body: { closing: '2030-01-01' } })).status, 422, 'متطلبات التقييم مطلوبة');
  const pub = await call(C, 'POST', '/api/requests/' + id + '/tender', { body: tenderBody() });
  assert.strictEqual(pub.status, 201, JSON.stringify(pub.data));
  assert.strictEqual(pub.data.request.status, 'published');
  assert.strictEqual((await call(C, 'POST', '/api/requests/' + id + '/tender', { body: tenderBody() })).status, 409, 'لا نشر مرتين');
  // المقاول يرى العطاء مع FIDIC والوثائق العامة فقط
  const con = 'qcon-wf' + uniq();
  await call(con, 'POST', '/api/auth/register', { body: { name: 'مقاول', email: con + '@t.com', password: 'Password123' } });
  const one = await call(con, 'GET', '/api/procurement/tenders/' + pub.data.tenderId);
  assert.strictEqual(one.data.tender.fidic.book, 'red');
  assert.strictEqual(one.data.tender.fidic.edition, '2017');
  assert.strictEqual(one.data.tender.fidic.url, 'https://fidic.org');
  assert.strictEqual(one.data.tender.documentsCount, 3);
  assert.strictEqual(one.data.tender.name, 'إنشاء مبنى إداري', 'الاسم يؤخذ من الطلب');
  assert.strictEqual(one.data.tender.nameEn, 'Administrative building');
  const docs = await call(con, 'GET', '/api/procurement/tenders/' + pub.data.tenderId + '/documents');
  assert.deepStrictEqual(docs.data.documents.map((d) => d.kind).sort(), ['boq', 'drawings', 'specifications']);
  const dl = await fetch(base + '/api/procurement/tenders/' + pub.data.tenderId + '/documents/' + docs.data.documents[0].id, { headers: cookieFor(con) });
  assert.strictEqual(dl.status, 200);
  assert.ok(/attachment/.test(dl.headers.get('content-disposition')));

  // A different organization cannot list, inspect, or download this tender's files.
  const isolated = await newBuyer('isolated', 'proc_pro');
  const isolatedProcurement = (await joinTeam(isolated, 'procurement', 'isolated-proc')).who;
  assert.strictEqual((await call(isolatedProcurement, 'GET', '/api/requests/' + id)).status, 404);
  assert.strictEqual((await call(isolatedProcurement, 'GET', '/api/requests/' + id + '/docs/' + docs.data.documents[0].id)).status, 404);
  assert.strictEqual((await call(isolatedProcurement, 'GET', '/api/procurement/tenders/' + pub.data.tenderId)).status, 404);
  assert.strictEqual((await fetch(base + '/api/procurement/tenders/' + pub.data.tenderId + '/documents/' + docs.data.documents[0].id, { headers: cookieFor(isolatedProcurement) })).status, 404);
  // الوثيقة الداخلية لا تُسرَّب
  const internalId = (await call(P, 'GET', '/api/requests/' + id)).data.request.docs.find((d) => d.kind === 'internal').id;
  assert.strictEqual((await fetch(base + '/api/procurement/tenders/' + pub.data.tenderId + '/documents/' + internalId, { headers: cookieFor(con) })).status, 404);
  // المقاول لا يدخل مسارات الجهة
  assert.strictEqual((await call(con, 'GET', '/api/requests')).status, 403);
  // تظهر العطاءات لأعضاء المشتريات والمدير لا الطالب
  assert.strictEqual((await call(C, 'GET', '/api/procurement/tenders')).data.tenders.length, 1);
  assert.strictEqual((await call(mgr, 'GET', '/api/procurement/tenders')).data.tenders.length, 1);
  assert.strictEqual((await call(R, 'GET', '/api/procurement/tenders')).status, 403);
  // سجل الأحداث
  const ev = (await call(mgr, 'GET', '/api/requests/' + id)).data.request.events.map((e) => e.action);
  assert.deepStrictEqual(ev.filter((a) => ['create', 'submit', 'take', 'ready', 'publish'].includes(a)), ['create', 'submit', 'take', 'ready', 'publish']);
});

test('73 — الاعتماد الاختياري، الإعادة من المشتريات، وعزل الطلبات بين الأعضاء', async () => {
  const mgr = await newBuyer('mgr2', 'proc_pro');
  const R = (await joinTeam(mgr, 'requester', 'rr')).who, R2 = (await joinTeam(mgr, 'requester', 'r2')).who, P = (await joinTeam(mgr, 'projects', 'pp')).who, C = (await joinTeam(mgr, 'procurement', 'cc')).who;
  assert.strictEqual((await call(P, 'PATCH', '/api/org', { body: { requireApproval: true } })).status, 403);
  assert.strictEqual((await call(mgr, 'PATCH', '/api/org', { body: { requireApproval: true } })).status, 200);
  const id = (await call(R, 'POST', '/api/requests', { body: reqBody() })).data.request.id;
  assert.strictEqual((await call(R2, 'GET', '/api/requests/' + id)).status, 404, 'طالب آخر لا يرى الطلب');
  assert.strictEqual((await call(R2, 'GET', '/api/requests')).data.requests.length, 0);
  await call(R, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'submit' } });
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'return' } })).status, 422, 'ملاحظة الإعادة إلزامية');
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'return', note: 'أرفق مخطط الموقع' } })).data.request.status, 'returned');
  assert.strictEqual((await call(R, 'GET', '/api/requests/' + id)).data.request.reviewNote, 'أرفق مخطط الموقع');
  assert.strictEqual((await call(R, 'PATCH', '/api/requests/' + id, { body: reqBody({ title: 'إنشاء مبنى إداري — معدّل' }) })).status, 200);
  await call(R, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'submit' } });
  await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'take' } });
  await call(P, 'POST', '/api/requests/' + id + '/docs', { form: docForm('boq', 'boq.pdf') });
  await call(P, 'POST', '/api/requests/' + id + '/docs', { form: docForm('specifications', 'spec.pdf') });
  await call(P, 'POST', '/api/requests/' + id + '/docs', { form: docForm('drawings', 'drawings.pdf') });
  await call(P, 'PATCH', '/api/requests/' + id, { body: { fidicBook: 'yellow', fidicEdition: '1999' } });
  const aw = await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'ready' } });
  assert.strictEqual(aw.data.request.status, 'awaiting_approval');
  assert.strictEqual((await call(C, 'GET', '/api/requests')).data.requests.length, 0, 'المشتريات لا ترى قبل الاعتماد');
  assert.strictEqual((await call(P, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'approve' } })).status, 403);
  assert.strictEqual((await call(R2, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'approve' } })).status, 404);
  assert.strictEqual((await call(R, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'approve' } })).data.request.status, 'ready');
  const back = await call(C, 'POST', '/api/requests/' + id + '/transition', { body: { action: 'send_back', note: 'نحتاج مواصفات الكهرباء' } });
  assert.strictEqual(back.data.request.status, 'in_study');
  assert.strictEqual(back.data.request.reviewNote, 'نحتاج مواصفات الكهرباء');
  assert.strictEqual((await call(C, 'GET', '/api/requests')).data.requests.length, 0);
});

test('74 — توثيق الجهة يخص الجهة كلها، وطلبه لمديرها فقط', async () => {
  cfg.REQUIRE_ORG_VERIFICATION = true;
  try {
    const mgr = await newBuyer('mgv', 'proc_pro');
    const C = (await joinTeam(mgr, 'procurement', 'pcv')).who;
    const blocked = await mkTender(C, 1);
    assert.strictEqual(blocked.status, 403);
    assert.strictEqual(blocked.data.error.code, 'ORG_NOT_VERIFIED');
    assert.strictEqual((await call(C, 'POST', '/api/verification', { form: verForm() })).status, 403, 'العضو لا يقدّم طلب التوثيق');
    assert.strictEqual((await call(mgr, 'POST', '/api/verification', { form: verForm({ orgName: 'الشركة المتحدة', country: 'SA' }) })).status, 201);
    await makeAdmin('vadm2');
    const row = (await call('vadm2', 'GET', '/api/verification/admin?status=pending')).data.verifications.find((v) => v.orgName === 'الشركة المتحدة');
    assert.ok(row);
    assert.strictEqual((await call('vadm2', 'POST', '/api/verification/admin/' + row.id + '/approve', { body: {} })).status, 200);
    const ok = await mkTender(C, 2);
    assert.strictEqual(ok.status, 201, JSON.stringify(ok.data));
    assert.strictEqual(ok.data.tender.country, 'SA', 'دولة الجهة الموثّقة');
    assert.strictEqual((await call(C, 'GET', '/api/verification')).data.verification.effective, 'verified', 'العضو يرى حالة التوثيق');
  } finally { cfg.REQUIRE_ORG_VERIFICATION = false; }
});


test('78 — الانضمام لا ينقل عطاءات الحساب القديمة إلى مؤسسة أخرى', async () => {
  const target = await newBuyer('join-target', 'proc_pro');
  const invite = await call(target, 'POST', '/api/org/invites', { body: { role: 'requester' } });
  const applicant = await newBuyer('join-with-tender', 'proc_pro');
  // Ensure the standalone buyer's personal organization exists before the first tender is created.
  assert.strictEqual((await call(applicant, 'GET', '/api/org')).status, 200);
  const created = await call(applicant, 'POST', '/api/tenders', {
    body: { name: 'عطاء سابق مستقل', authority: 'جهة اختبار', closing: '2030-01-01', notes: 'لا يجوز نقله تلقائياً' }
  });
  assert.strictEqual(created.status, 201, JSON.stringify(created.data));
  assert.strictEqual((await call(applicant, 'GET', '/api/org')).status, 200);
  const applicantId = (await call(applicant, 'GET', '/api/auth/me')).data.user.id;
  const before = getDB().prepare('SELECT org_id,user_id FROM tenders WHERE id=?').get(created.data.tender.id);
  const ownOrg = getDB().prepare('SELECT org_id FROM org_members WHERE user_id=?').get(applicantId);
  assert.ok(ownOrg && before.org_id === ownOrg.org_id);
  const joined = await call(applicant, 'POST', '/api/org/join', { body: { code: invite.data.code } });
  assert.strictEqual(joined.status, 409);
  const after = getDB().prepare('SELECT org_id,user_id FROM tenders WHERE id=?').get(created.data.tender.id);
  const membership = getDB().prepare('SELECT org_id FROM org_members WHERE user_id=?').get((await call(applicant, 'GET', '/api/auth/me')).data.user.id);
  assert.strictEqual(after.org_id, before.org_id);
  assert.strictEqual(membership.org_id, ownOrg.org_id);
});

test('75 — الانضمام لا يُسمح به لمدير جهة فيها أعضاء أو طلبات', async () => {
  const other = await newBuyer('o', 'proc_pro');
  const inv = await call(other, 'POST', '/api/org/invites', { body: { role: 'requester' } });
  const busy = await newBuyer('busy', 'proc_pro');
  await call(busy, 'POST', '/api/requests', { body: reqBody() });
  assert.strictEqual((await call(busy, 'POST', '/api/org/join', { body: { code: inv.data.code } })).status, 409);
});


/* ==========================================================
   Project finance: award → PO → invoice → approval → payments
   ========================================================== */
test('76 — دورة الترسية وأمر الشراء والفاتورة والمالية والدفعات', async () => {
  const manager = await newBuyer('finmgr', 'proc_pro');
  const procurement = (await joinTeam(manager, 'procurement', 'finproc')).who;
  const requester = (await joinTeam(manager, 'requester', 'finreq')).who;
  const finance = (await joinTeam(manager, 'finance', 'finrole')).who;
  const projects = (await joinTeam(manager, 'projects', 'finprojects')).who;

  // Projects staff should not browse financial records merely by being in the same organization.
  assert.strictEqual((await call(projects, 'GET', '/api/project-finance/awards')).status, 403);
  assert.strictEqual((await call(projects, 'GET', '/api/project-finance/purchase-orders')).status, 403);
  assert.strictEqual((await call(projects, 'GET', '/api/project-finance/invoices')).status, 403);

  const tender = await publish(procurement);
  const contractor = 'fincon' + uniq();
  const contractorEmail = contractor + '@t.com';
  await call(contractor, 'POST', '/api/auth/register', {
    body: { name: 'مقاول الدورة المالية', email: contractorEmail, password: 'Password123' }
  });
  const submitted = await call(contractor, 'POST', '/api/procurement/tenders/' + tender.id + '/submit', {
    body: bidBody(tender, 300)
  });
  assert.strictEqual(submitted.status, 201, JSON.stringify(submitted.data));
  const receipt = await call(contractor, 'GET', '/api/procurement/submissions/' + submitted.data.submissionId + '/receipt');
  assert.strictEqual(receipt.status, 200, JSON.stringify(receipt.data));
  assert.ok(receipt.data.receipt.reference.startsWith('MMC-'));
  assert.strictEqual(receipt.data.receipt.documents.length, 2);
  const bidDocs = getDB().prepare('SELECT id,doc_class FROM bid_submission_docs WHERE submission_id=? ORDER BY doc_class').all(submitted.data.submissionId);
  const technicalDoc = bidDocs.find((d) => d.doc_class === 'technical');
  const financialDoc = bidDocs.find((d) => d.doc_class === 'financial');
  assert.ok(technicalDoc && financialDoc, 'يجب حفظ ملفات العرضين منفصلة');
  assert.strictEqual((await call(procurement, 'GET', '/api/procurement/submissions/' + submitted.data.submissionId + '/documents/' + technicalDoc.id)).status, 200);
  assert.strictEqual((await call(procurement, 'GET', '/api/procurement/submissions/' + submitted.data.submissionId + '/documents/' + financialDoc.id)).status, 403,
    'يجب منع المشتريات من تنزيل المالي قبل الفتح الرسمي');
  assert.strictEqual((await call(projects, 'GET', '/api/procurement/submissions/' + submitted.data.submissionId + '/documents/' + financialDoc.id)).status, 404,
    'موظف المشاريع لا يملك صلاحية الوصول إلى عروض المقاولين');

  // لا ترسية قبل التقييم الفني وفتح العرض المالي.
  const premature = await call(manager, 'POST', '/api/project-finance/awards', {
    body: { tenderId: tender.id, submissionId: submitted.data.submissionId, awardedAmount: 200, currency: 'JOD', awardReference: 'AWD-FIN-01' }
  });
  assert.strictEqual(premature.status, 422);

  const earlyOpen = await call(procurement, 'POST', '/api/procurement/submissions/' + submitted.data.submissionId + '/open-financial', { body: {} });
  assert.strictEqual(earlyOpen.status, 409, 'لا يجوز فتح المالي قبل التقييم الفني الرسمي');
  const evaluated = await call(procurement, 'POST', '/api/procurement/submissions/' + submitted.data.submissionId + '/evaluate', {
    body: { scores: tender.requirements.map((q) => ({ requirementId: q.id, score: 100 })) }
  });
  assert.strictEqual(evaluated.status, 200, JSON.stringify(evaluated.data));
  assert.strictEqual(evaluated.data.passed, true);
  assert.strictEqual(evaluated.data.financialOpened, false, 'التقييم الفني لا يفتح المالي تلقائياً');
  const financialOpen = await call(procurement, 'POST', '/api/procurement/submissions/' + submitted.data.submissionId + '/open-financial', { body: {} });
  assert.strictEqual(financialOpen.status, 200, JSON.stringify(financialOpen.data));
  assert.strictEqual(financialOpen.data.financialOpened, true);
  assert.strictEqual((await call(procurement, 'GET', '/api/procurement/submissions/' + submitted.data.submissionId + '/documents/' + financialDoc.id)).status, 200,
    'يسمح للمشتريات بتنزيل المالي بعد الفتح الرسمي');
  assert.strictEqual((await call(procurement, 'GET', '/api/procurement/submissions/' + submitted.data.submissionId + '/receipt')).status, 403,
    'الإيصال الخاص بالمقاول لا يُكشف لحساب المشتريات');

  const award = await call(manager, 'POST', '/api/project-finance/awards', {
    body: { tenderId: tender.id, submissionId: submitted.data.submissionId, awardedAmount: 300, currency: 'JOD', awardReference: 'AWD-FIN-01' }
  });
  assert.strictEqual(award.status, 201, JSON.stringify(award.data));

  // العملة المخالفة للترسية تُرفض، ثم يُنشأ أمر شراء صحيح.
  const wrongCurrency = await call(manager, 'POST', '/api/project-finance/awards/' + award.data.award.id + '/purchase-orders', {
    body: { poNumber: 'PO-FIN-BAD', currency: 'SAR', items: [{ description: 'أعمال مدنية', quantity: 1, unitPrice: 100 }] }
  });
  assert.strictEqual(wrongCurrency.status, 422);

  const po = await call(procurement, 'POST', '/api/project-finance/awards/' + award.data.award.id + '/purchase-orders', {
    body: { poNumber: 'PO-FIN-01', currency: 'JOD', items: [{ description: 'أعمال مدنية', quantity: 2, unitPrice: 100, unit: 'LS' }] }
  });
  assert.strictEqual(po.status, 201, JSON.stringify(po.data));
  const duplicateSpend = await call(manager, 'POST', '/api/project-finance/awards/' + award.data.award.id + '/purchase-orders', {
    body: { poNumber: 'PO-FIN-02', currency: 'JOD', items: [{ description: 'أعمال إضافية', quantity: 1, unitPrice: 101 }] }
  });
  assert.strictEqual(duplicateSpend.status, 422, 'لا يجوز أن يتجاوز مجموع أوامر الشراء قيمة الترسية');

  // Concurrent PO creation must serialize against the award ceiling.
  const concurrentPO = await Promise.all([1, 2].map((n) => call(procurement, 'POST', '/api/project-finance/awards/' + award.data.award.id + '/purchase-orders', {
    body: { poNumber: 'PO-RACE-' + n, currency: 'JOD', items: [{ description: 'أعمال إضافية متزامنة', quantity: 1, unitPrice: 60 }] }
  })));
  assert.deepStrictEqual(concurrentPO.map((x) => x.status).sort(), [201, 422], 'يجب قبول أمر واحد فقط عند تزاحم تجاوز قيمة الترسية');

  assert.strictEqual((await call(manager, 'POST', '/api/project-finance/purchase-orders/' + po.data.purchaseOrder.id + '/approve', { body: {} })).status, 200);
  assert.strictEqual((await call(procurement, 'POST', '/api/project-finance/purchase-orders/' + po.data.purchaseOrder.id + '/issue', { body: {} })).status, 200);

  // تجاوز قيمة أمر الشراء مرفوض.
  const tooLarge = await call(contractor, 'POST', '/api/project-finance/purchase-orders/' + po.data.purchaseOrder.id + '/invoices', {
    body: { invoiceNumber: 'INV-FIN-OVER', invoiceType: 'progress', items: [{ description: 'أعمال', quantity: 1, unitPrice: 250 }] }
  });
  assert.strictEqual(tooLarge.status, 409);

  const invoice = await call(contractor, 'POST', '/api/project-finance/purchase-orders/' + po.data.purchaseOrder.id + '/invoices', {
    body: { invoiceNumber: 'INV-FIN-01', invoiceType: 'progress', note: 'مستخلص مرحلي', items: [{ description: 'أعمال مدنية منفذة', quantity: 1, unitPrice: 150 }] }
  });
  assert.strictEqual(invoice.status, 201, JSON.stringify(invoice.data));
  const invoiceId = invoice.data.invoice.id;
  const invoiceFiles = await call(contractor, 'POST', '/api/project-finance/invoices/' + invoiceId + '/documents', {
    form: makeForm([{ name: 'invoice-proof.pdf', content: '%PDF-1.4 proof' }])
  });
  assert.strictEqual(invoiceFiles.status, 201, JSON.stringify(invoiceFiles.data));
  const invoiceDocumentId = invoiceFiles.data.documents[0].id;

  // Concurrent invoice submissions must not exceed the issued PO total.
  const concurrentInvoices = await Promise.all([1, 2].map((n) => call(contractor, 'POST', '/api/project-finance/purchase-orders/' + po.data.purchaseOrder.id + '/invoices', {
    body: { invoiceNumber: 'INV-RACE-' + n, invoiceType: 'progress', items: [{ description: 'مستخلص متزامن', quantity: 1, unitPrice: 30 }] }
  })));
  assert.deepStrictEqual(concurrentInvoices.map((x) => x.status).sort(), [201, 409], 'يجب قبول فاتورة واحدة فقط عند تزاحم تجاوز أمر الشراء');

  // Returned invoices must be safely editable and resubmittable.
  const returned = await call(procurement, 'POST', '/api/project-finance/invoices/' + invoiceId + '/procurement-review', {
    body: { decision: 'returned', note: 'يرجى إرفاق كشف الكميات المصحح' }
  });
  assert.strictEqual(returned.status, 200, JSON.stringify(returned.data));
  assert.strictEqual(returned.data.status, 'returned');
  const resubmitted = await call(contractor, 'POST', '/api/project-finance/invoices/' + invoiceId + '/resubmit', {
    body: { invoiceNumber: 'INV-FIN-01-R1', invoiceType: 'progress', note: 'تم التصحيح', items: [{ description: 'أعمال مدنية منفذة - مصححة', quantity: 1, unitPrice: 150 }] }
  });
  assert.strictEqual(resubmitted.status, 200, JSON.stringify(resubmitted.data));
  assert.strictEqual(resubmitted.data.status, 'submitted');
  assert.strictEqual(resubmitted.data.invoice.gross_amount, 150);

  // Cross-organization and unrelated-contractor reads must not expose this real invoice.
  const otherManager = await newBuyer('finother', 'proc_pro');
  const otherFinance = (await joinTeam(otherManager, 'finance', 'finother-role')).who;

  // Tenant isolation: a second organization's manager/finance users cannot
  // discover, read, evaluate, award, or transact against this organization's tender.
  const otherProcurement = (await joinTeam(otherManager, 'procurement', 'finother-procurement')).who;
  const originalInvite = await call(manager, 'POST', '/api/org/invites', { body: { role: 'requester', label: 'private-tenant-invite' } });
  assert.strictEqual(originalInvite.status, 201, JSON.stringify(originalInvite.data));
  const otherOrgView = await call(otherManager, 'GET', '/api/org');
  const originalOrgView = await call(manager, 'GET', '/api/org');
  assert.notStrictEqual(otherOrgView.data.org.id, originalOrgView.data.org.id, 'لكل مؤسسة معرّف مستقل');
  assert.ok(!otherOrgView.data.members.some((member) => member.id === manager), 'لا تظهر عضوية المؤسسة الأولى في إدارة المؤسسة الثانية');
  assert.ok(originalOrgView.data.invites.some((invite) => invite.id === originalInvite.data.invite.id), 'المدير يرى دعوة مؤسسته');
  assert.ok(!otherOrgView.data.invites.some((invite) => invite.id === originalInvite.data.invite.id), 'لا تظهر دعوات المؤسسة الأولى في المؤسسة الثانية');
  const otherTenderList = await call(otherProcurement, 'GET', '/api/procurement/tenders');
  assert.strictEqual(otherTenderList.status, 200);
  assert.ok(!otherTenderList.data.tenders.some((t) => t.id === tender.id), 'العطاء لا يظهر في قائمة مشتريات جهة أخرى');
  assert.strictEqual((await call(otherProcurement, 'GET', '/api/procurement/tenders/' + tender.id)).status, 404);
  assert.strictEqual((await call(otherProcurement, 'GET', '/api/procurement/tenders/' + tender.id + '/evaluations')).status, 404);
  assert.strictEqual((await call(otherProcurement, 'POST', '/api/submissions/' + submitted.data.submissionId + '/evaluate', {
    body: { scores: [] }
  })).status, 404, 'لا يمكن تقييم عرض تابع لعطاء جهة أخرى');
  assert.strictEqual((await call(otherProcurement, 'GET', '/api/procurement/tenders/' + tender.id + '/documents')).status, 404);
  assert.strictEqual((await call(otherManager, 'POST', '/api/project-finance/awards', {
    body: { tenderId: tender.id, submissionId: submitted.data.submissionId, awardedAmount: 300, currency: 'JOD' }
  })).status, 404);
  assert.strictEqual((await call(otherFinance, 'GET', '/api/project-finance/awards')).data.awards.length, 0);
  assert.strictEqual((await call(otherFinance, 'GET', '/api/project-finance/purchase-orders')).data.purchaseOrders.length, 0);
  assert.strictEqual((await call(otherFinance, 'GET', '/api/project-finance/invoices')).data.invoices.length, 0);
  assert.strictEqual((await call(otherFinance, 'GET', '/api/requests')).data.requests.length, 0);
  const outsider = 'finoutsider' + uniq();
  await call(outsider, 'POST', '/api/auth/register', {
    body: { name: 'مقاول غير مرتبط', email: outsider + '@t.com', password: 'Password123' }
  });
  assert.strictEqual((await call(outsider, 'GET', '/api/project-finance/invoices/' + invoiceId)).status, 404);
  assert.strictEqual((await call(otherFinance, 'GET', '/api/project-finance/invoices/' + invoiceId)).status, 404);
  assert.strictEqual((await call(otherFinance, 'GET', '/api/project-finance/invoices/' + invoiceId + '/documents')).status, 404);
  assert.strictEqual((await fetch(base + '/api/project-finance/invoice-documents/' + invoiceDocumentId + '/download', { headers: cookieFor(otherFinance) })).status, 404);
  assert.strictEqual((await fetch(base + '/api/project-finance/invoice-documents/' + invoiceDocumentId + '/download', { headers: cookieFor(outsider) })).status, 404);
  assert.strictEqual((await call(otherFinance, 'POST', '/api/project-finance/invoices/' + invoiceId + '/finance-approval', { body: {} })).status, 404);

  assert.strictEqual((await call(procurement, 'POST', '/api/project-finance/invoices/' + invoiceId + '/procurement-review', {
    body: { decision: 'accepted', note: 'مطابقة لأمر الشراء' }
  })).data.status, 'owner_confirmation');
  assert.strictEqual((await call(requester, 'POST', '/api/project-finance/invoices/' + invoiceId + '/owner-confirmation', {
    body: { decision: 'confirmed', note: 'تم استلام الأعمال' }
  })).data.status, 'finance_queue');
  assert.strictEqual((await call(requester, 'POST', '/api/project-finance/invoices/' + invoiceId + '/forward-to-finance', { body: {} })).data.status, 'finance_review');
  assert.strictEqual((await call(procurement, 'POST', '/api/project-finance/invoices/' + invoiceId + '/finance-approval', { body: {} })).status, 403);
  assert.strictEqual((await call(finance, 'POST', '/api/project-finance/invoices/' + invoiceId + '/finance-approval', { body: {} })).data.status, 'approved_for_payment');

  const partial = await call(finance, 'POST', '/api/project-finance/invoices/' + invoiceId + '/payments', {
    body: { amount: 50, paymentReference: 'PAY-FIN-01', paymentDate: '2026-11-03' }
  });
  assert.strictEqual(partial.status, 201, JSON.stringify(partial.data));
  assert.strictEqual((await call(finance, 'GET', '/api/project-finance/invoices/' + invoiceId)).data.invoice.status, 'part_paid');

  const overpayment = await call(finance, 'POST', '/api/project-finance/invoices/' + invoiceId + '/payments', {
    body: { amount: 101, paymentReference: 'PAY-FIN-OVER', paymentDate: '2026-11-03' }
  });
  assert.strictEqual(overpayment.status, 409);

  const concurrentPayments = await Promise.all([1, 2].map((n) => call(finance, 'POST', '/api/project-finance/invoices/' + invoiceId + '/payments', {
    body: { amount: 100, paymentReference: 'PAY-RACE-' + n, paymentDate: '2026-11-03' }
  })));
  assert.deepStrictEqual(concurrentPayments.map((x) => x.status).sort(), [201, 409], 'يجب قبول دفعة واحدة فقط حتى لا يتجاوز مجموع الدفعات قيمة الفاتورة');
  const finalState = await call(finance, 'GET', '/api/project-finance/invoices/' + invoiceId);
  assert.strictEqual(finalState.data.invoice.status, 'paid');
  assert.strictEqual(finalState.data.paid, 150);
  assert.strictEqual(finalState.data.remaining, 0);

  // بيانات دورة المشروع لا تدخل في فواتير اشتراكات MMC.
  const billing = await call(manager, 'GET', '/api/billing/invoices');
  assert.strictEqual(billing.status, 200);
  assert.ok(!billing.data.invoices.some((x) => x.id === invoiceId));
});

test('77 — دور المالية محصور بجهته ولا يستطيع مقاول آخر قراءة فاتورة الغير', async () => {
  const manager = await newBuyer('finiso', 'proc_pro');
  const finance = (await joinTeam(manager, 'finance', 'finiso-role')).who;
  const outsider = 'finout' + uniq();
  await call(outsider, 'POST', '/api/auth/register', {
    body: { name: 'مقاول خارجي', email: outsider + '@t.com', password: 'Password123' }
  });
  assert.strictEqual((await call(finance, 'GET', '/api/project-finance/invoices')).status, 200);
  assert.strictEqual((await call(outsider, 'GET', '/api/project-finance/invoices')).status, 200);
  const denied = await call(outsider, 'POST', '/api/project-finance/invoices/fake-id/finance-approval', { body: {} });
  assert.strictEqual(denied.status, 403);
});


test('79 — رمز الدعوة أحادي الاستخدام ولا يقبل عضواً ثانياً', async () => {
  const manager = await newBuyer('single-invite-owner', 'proc_pro');
  const invitation = await call(manager, 'POST', '/api/org/invites', { body: { role: 'requester' } });
  assert.strictEqual(invitation.status, 201);
  const first = await newBuyer('single-invite-first', 'proc_pro');
  const second = await newBuyer('single-invite-second', 'proc_pro');
  const firstJoin = await call(first, 'POST', '/api/org/join', { body: { code: invitation.data.code } });
  assert.strictEqual(firstJoin.status, 200, JSON.stringify(firstJoin.data));
  const secondJoin = await call(second, 'POST', '/api/org/join', { body: { code: invitation.data.code } });
  assert.ok([404, 409].includes(secondJoin.status), JSON.stringify(secondJoin.data));
  const targetOrg = (await call(manager, 'GET', '/api/org')).data.org.id;
  const members = getDB().prepare('SELECT COUNT(*) n FROM org_members WHERE org_id=?').get(targetOrg).n;
  assert.strictEqual(members, 2, 'المدير والعضو الأول فقط');
});

/* ==========================================================
   لجنة التقييم + دور الاستشاري + طابور البريد
   ========================================================== */
test('90 — لجنة التقييم: تقييم مستقل مجهول الهوية، فروق، اعتماد بالمتوسط، وطابور بريد', async () => {
  const buyer = await newBuyer('cmtb', 'proc_pro');
  const t = await publish(buyer, undefined);
  const mk = async (who, role, plan) => {
    const email = who + uniq() + '@t.com';
    const r = await call(who, 'POST', '/api/auth/register', { body: { name: who, email, password: 'Password123', role } });
    assert.strictEqual(r.status, 201, JSON.stringify(r.data));
    if (plan) grantPlan(email, plan);
    return email;
  };
  await mk('cmtA', 'contractor', 'ent'); await mk('cmtB', 'contractor', 'ent');
  const c1 = await mk('cmtc1', 'consultant'); const c2 = await mk('cmtc2', 'consultant');
  assert.strictEqual((await call('cmtA', 'POST', '/api/procurement/tenders/' + t.id + '/submit', { body: bidBody(t, 900) })).status, 201);
  assert.strictEqual((await call('cmtB', 'POST', '/api/procurement/tenders/' + t.id + '/submit', { body: bidBody(t, 1100) })).status, 201);

  // المقاول لا يصل لمساحة المقيّم، ولا يُضاف للجنة، ولا يُضاف حساب غير مسجّل
  assert.strictEqual((await call('cmtA', 'GET', '/api/committee/tenders/' + t.id + '/work')).status, 404);
  assert.strictEqual((await call(buyer, 'POST', '/api/committee/tenders/' + t.id + '/members', { body: { email: 'nobody' + uniq() + '@t.com' } })).status, 404);
  const cEmail = getDB().prepare("SELECT email FROM users WHERE name='cmtA'").get().email;
  assert.strictEqual((await call(buyer, 'POST', '/api/committee/tenders/' + t.id + '/members', { body: { email: cEmail } })).status, 422);
  // استشاري غير مكلّف لا يرى شيئاً
  assert.strictEqual((await call('cmtc1', 'GET', '/api/committee/tenders/' + t.id + '/work')).status, 404);

  assert.strictEqual((await call(buyer, 'POST', '/api/committee/tenders/' + t.id + '/members', { body: { email: c1 } })).status, 201);
  // عضو واحد لا يكفي للاعتماد
  assert.strictEqual((await call(buyer, 'POST', '/api/committee/tenders/' + t.id + '/finalize')).status, 409);
  assert.strictEqual((await call(buyer, 'POST', '/api/committee/tenders/' + t.id + '/members', { body: { email: c2 } })).status, 201);
  assert.strictEqual((await call(buyer, 'POST', '/api/committee/tenders/' + t.id + '/finalize')).status, 409); // التقييم غير مكتمل

  // الاستشاري يرى عروضاً مجهولة بلا أسعار ولا أسماء
  const w = await call('cmtc1', 'GET', '/api/committee/tenders/' + t.id + '/work');
  assert.strictEqual(w.status, 200);
  const raw = JSON.stringify(w.data);
  assert.deepStrictEqual(w.data.bidders.map((b) => b.label), ['A', 'B']);
  assert.ok(!/cmtA|cmtB|financial|900|1100/.test(raw.replace(/submissionId":"[^"]*"/g, '')), 'لا أسماء ولا أسعار');

  // درجات: المقيّم الأول 100 للجميع، الثاني 60 للعارض A و100 للعارض B
  const [sa, sb] = w.data.bidders.map((b) => b.submissionId);
  const rq = w.data.requirements.map((r) => r.id);
  const scores = (v) => [].concat(...[[sa, v.A], [sb, v.B]].map(([s, x]) => rq.map((r) => ({ submissionId: s, requirementId: r, score: x }))));
  assert.strictEqual((await call('cmtc1', 'POST', '/api/committee/tenders/' + t.id + '/scores', { body: { scores: scores({ A: 100, B: 100 }) } })).status, 200);
  assert.strictEqual((await call('cmtc2', 'POST', '/api/committee/tenders/' + t.id + '/scores', { body: { scores: scores({ A: 60, B: 100 }) } })).status, 200);
  assert.strictEqual((await call('cmtc1', 'POST', '/api/committee/tenders/' + t.id + '/scores', { body: { scores: [{ submissionId: sa, requirementId: rq[0], score: 101 }] } })).status, 422);
  // المقيّم لا يرى درجات زميله، والاستشاري لا يصل لواجهة صاحب العطاء
  assert.strictEqual((await call('cmtc1', 'GET', '/api/committee/tenders/' + t.id)).status, 404);
  const mine = (await call('cmtc2', 'GET', '/api/committee/tenders/' + t.id + '/work')).data.bidders[0].responses[0].myScore;
  assert.strictEqual(mine, 60);

  // صاحب العطاء يرى المصفوفة والفروق
  const m = await call(buyer, 'GET', '/api/committee/tenders/' + t.id);
  assert.strictEqual(m.status, 200);
  assert.strictEqual(m.data.bidders[0].committeeAverage, 80);
  assert.ok(m.data.bidders[0].divergentRequirements.length >= 1);

  // الاعتماد: A متوسط 80 → 48 نقطة < 50 (غير مؤهل)، B → 60 (مؤهل)
  const fin = await call(buyer, 'POST', '/api/committee/tenders/' + t.id + '/finalize');
  assert.strictEqual(fin.status, 200, JSON.stringify(fin.data));
  const subs = getDB().prepare('SELECT id,technical_points,technical_passed,financial_unlocked,status FROM bid_submissions WHERE tender_id=?').all(t.id);
  const A = subs.find((x) => x.id === sa), B = subs.find((x) => x.id === sb);
  assert.ok(Math.abs(A.technical_points - 48) < 1e-6 && !A.technical_passed);
  assert.ok(Math.abs(B.technical_points - 60) < 1e-6 && B.technical_passed);
  assert.ok(subs.every((x) => x.status === 'evaluated' && !x.financial_unlocked), 'الفتح المالي يبقى منفصلاً');
  assert.strictEqual((await call('cmtc1', 'POST', '/api/committee/tenders/' + t.id + '/scores', { body: { scores: scores({ A: 1, B: 1 }) } })).status, 409);

  // طابور البريد: مع ناقل JSON الاختباري تُسجَّل الرسائل sent؛ وبدونه تبقى skipped.
  const out = getDB().prepare("SELECT subject,status FROM email_outbox WHERE to_email IN (?,?)").all(c1, c2);
  assert.ok(out.length >= 2 && out.every((o) => ['pending', 'sent', 'skipped', 'failed'].includes(o.status)));
  assert.ok(out.some((o) => /تكليف/.test(o.subject)));
});

/* ==========================================================
   الفوترة الوطنية (JoFotara) — خادم وهمي يعترض الإرسال
   ========================================================== */
test('91 — الفوترة الوطنية: بناء XML وإرساله، ICV متسلسل، الرفض لا يعطّل الاعتماد، وإعادة الإرسال', async () => {
  const config = require('../src/config');
  const J = require('../src/lib/jofotara');
  const saved = config.EINVOICE;
  config.EINVOICE = { ...saved, enabled: true, url: 'https://jofotara.test/core/invoices/', clientId: 'cid-1', secretKey: 'sec-1', incomeSource: '555', sellerTin: '123456789', sellerName: 'MMC Test & Co', vatRate: 16, pricesIncludeTax: true, typeName: '012' };
  const realFetch = global.fetch, sent = [];
  let nextStatus = 200;
  global.fetch = async (url, opts) => {
    if (String(url).startsWith('https://jofotara.test/')) {
      sent.push({ url: String(url), headers: opts.headers, body: JSON.parse(opts.body) });
      return new Response(JSON.stringify(nextStatus === 200 ? { EINV_NUM: 'E-1', EINV_QR: 'QRDATA' } : { error: 'invalid field' }), { status: nextStatus, headers: { 'content-type': 'application/json' } });
    }
    return realFetch(url, opts);
  };
  try {
    await makeAdmin('eadm');
    const mkInvoice = async (who, company, tin) => {
      const email = who + uniq() + '@t.com';
      await call(who, 'POST', '/api/auth/register', { body: { name: who, email, password: 'Password123', role: 'contractor', company } });
      const inv = await call(who, 'POST', '/api/billing/invoices', { body: { planKey: 'starter', billingCycle: 'monthly', currency: 'USD', buyerTaxNumber: tin } });
      assert.strictEqual(inv.status, 201, JSON.stringify(inv.data));
      const fd = new FormData();
      fd.append('receipt', new Blob(['%PDF-1.4 r'], { type: 'application/pdf' }), 'r.pdf'); fd.append('transferReference', 'REF-' + uniq()); fd.append('transferDate', '2026-11-05');
      assert.strictEqual((await call(who, 'POST', '/api/billing/invoices/' + inv.data.invoice.id + '/receipt', { form: fd })).status, 201);
      return inv.data.invoice;
    };
    const waitFor = async (id, status) => { for (let i = 0; i < 40; i++) { const r = getDB().prepare('SELECT * FROM einvoice_submissions WHERE invoice_id=?').get(id); if (r && r.status === status) return r; await new Promise((x) => setTimeout(x, 50)); } return getDB().prepare('SELECT * FROM einvoice_submissions WHERE invoice_id=?').get(id); };

    // رقم ضريبي غير صالح يُرفض عند إنشاء الفاتورة
    await call('ebad', 'POST', '/api/auth/register', { body: { name: 'مقاول تجريبي', email: 'eb' + uniq() + '@t.com', password: 'Password123', role: 'contractor' } });
    assert.strictEqual((await call('ebad', 'POST', '/api/billing/invoices', { body: { planKey: 'starter', currency: 'USD', buyerTaxNumber: '12' } })).status, 422);

    // 1) اعتماد → إرسال ناجح
    const i1 = await mkInvoice('einv1', 'شركة أ & ب <م>', '987654321');
    assert.strictEqual((await call('eadm', 'POST', '/api/billing/admin/invoices/' + i1.id + '/approve', { body: {} })).status, 200);
    const s1 = await waitFor(i1.id, 'accepted');
    assert.strictEqual(s1.status, 'accepted'); assert.strictEqual(s1.icv, 1); assert.strictEqual(s1.einv_number, 'E-1');
    assert.strictEqual(sent[0].headers['Client-Id'], 'cid-1'); assert.strictEqual(sent[0].headers['Secret-Key'], 'sec-1');
    const xml = Buffer.from(sent[0].body.invoice, 'base64').toString('utf8');
    assert.ok(xml.includes('<cbc:CompanyID>123456789</cbc:CompanyID>') && xml.includes('MMC Test &amp; Co'));
    assert.ok(xml.includes('شركة أ &amp; ب &lt;م&gt;') && xml.includes('schemeID="TN">987654321<'));
    assert.ok(xml.includes('name="012">388<') && xml.includes('<cbc:ID>555</cbc:ID>') && xml.includes('<cbc:UUID>1</cbc:UUID>'));
    const a = J.amounts({ currency: 'USD', amount: i1.amount });
    assert.ok(Math.abs(a.net + a.tax - a.total) < 1e-9);
    assert.ok(xml.includes('currencyID="JOD">' + a.total.toFixed(3) + '<'));
    assert.ok(a.tax > 0 && Math.abs(a.tax / a.net - 0.16) < 0.001, 'ضريبة 16% مفصولة عن السعر الشامل');

    // 2) رفض المنصة (400) لا يمنع تفعيل الباقة، ويحفظ الرد
    nextStatus = 400;
    const i2 = await mkInvoice('einv2', 'شركة ب', '');
    assert.strictEqual((await call('eadm', 'POST', '/api/billing/admin/invoices/' + i2.id + '/approve', { body: {} })).status, 200);
    const s2 = await waitFor(i2.id, 'rejected');
    assert.strictEqual(s2.status, 'rejected'); assert.strictEqual(s2.icv, 2); assert.ok(/invalid field/.test(s2.error));
    assert.strictEqual(getDB().prepare('SELECT status FROM invoices WHERE id=?').get(i2.id).status, 'paid');
    const list = await call('eadm', 'GET', '/api/billing/admin/invoices?status=paid');
    assert.strictEqual(list.data.invoices.find((x) => x.id === i2.id).einvoice.status, 'rejected');

    // 3) إعادة الإرسال تحتفظ بنفس UUID وICV
    nextStatus = 200;
    const re = await call('eadm', 'POST', '/api/billing/admin/invoices/' + i2.id + '/einvoice/retry', { body: {} });
    assert.strictEqual(re.status, 200); assert.strictEqual(re.data.ok, true);
    const s2b = getDB().prepare('SELECT * FROM einvoice_submissions WHERE invoice_id=?').get(i2.id);
    assert.strictEqual(s2b.uuid, s2.uuid); assert.strictEqual(s2b.icv, 2); assert.strictEqual(s2b.status, 'accepted');

    // 4) معاينة XML للمدير فقط
    assert.strictEqual((await call('einv1', 'GET', '/api/billing/admin/invoices/' + i1.id + '/einvoice-xml')).status, 403);
    assert.strictEqual((await call('eadm', 'GET', '/api/billing/admin/invoices/' + i1.id + '/einvoice-xml')).status, 200);

    // 5) إعدادات ناقصة: لا إرسال، وخطأ واضح، والاعتماد يعمل
    config.EINVOICE = { ...config.EINVOICE, clientId: '' };
    const before = sent.length;
    const i3 = await mkInvoice('einv3', 'شركة ج', '');
    assert.strictEqual((await call('eadm', 'POST', '/api/billing/admin/invoices/' + i3.id + '/approve', { body: {} })).status, 200);
    const s3 = await waitFor(i3.id, 'error');
    assert.ok(/JOFOTARA_CLIENT_ID/.test(s3.error)); assert.strictEqual(sent.length, before);
  } finally { global.fetch = realFetch; config.EINVOICE = saved; }
});

test('92 — العطاءات الخارجية: للمقاول والمدير فقط، وتُحجب عن المشتري والاستشاري والزائر', async () => {
  getDB().prepare("INSERT OR IGNORE INTO tender_opportunities (id,source_key,external_id,title,authority,country,tender_number,closing_at,source_url,status,language) VALUES ('opp_gate','apc','gate-1','اختبار الحجب','APC','JO','G-1','2099-01-01','https://arabpotash.com/x','open','ar')").run();
  const mk = async (who, role) => { const e = who + uniq() + '@t.com'; const requestedRole = role === 'admin' ? 'buyer' : role; const r = await call(who, 'POST', '/api/auth/register', { body: { name: 'مستخدم ' + who, email: e, password: 'Password123', role: requestedRole } }); assert.strictEqual(r.status, 201, JSON.stringify(r.data)); if (role === 'admin') getDB().prepare("UPDATE users SET role='admin' WHERE email=?").run(e); };
  await mk('gb', 'buyer'); await mk('gc', 'contractor'); await mk('gs', 'consultant'); await mk('ga', 'admin');
  assert.strictEqual((await call('gb', 'GET', '/api/opportunities/feed')).status, 403, 'المشتري محجوب');
  assert.strictEqual((await call('gc', 'GET', '/api/opportunities/feed')).status, 200);
  assert.strictEqual((await call('gs', 'GET', '/api/opportunities/feed')).status, 403, 'الاستشاري محجوب');
  assert.strictEqual((await call('ga', 'GET', '/api/opportunities/feed')).status, 200);
  assert.strictEqual((await call('nobody', 'GET', '/api/opportunities/feed')).status, 401);
});

test('93 — سوق العطاءات: ترقيم، فتح بحسب التاريخ، نافذة الإغلاق، المفضلة والإحصاءات', async () => {
  const db = getDB(), day = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
  db.prepare("DELETE FROM tender_opportunities WHERE id LIKE 'mk_%'").run();
  const ins = db.prepare("INSERT INTO tender_opportunities (id,source_key,external_id,title,authority,country,tender_number,closing_at,source_url,status,language,imported_at) VALUES (?,?,?,?,?,?,?,?,?,?,'ar',?)");
  const now = Math.floor(Date.now() / 1000);
  ins.run('mk_1', 'apc', 'm1', 'يغلق غداً', 'APC', 'JO', 'M1', day(1), 'https://arabpotash.com/1', 'open', now - 100);
  ins.run('mk_2', 'joneps', 'm2', 'يغلق بعد 20 يوماً', 'JONEPS', 'JO', 'M2', day(20), 'https://joneps.gov.jo/2', 'open', now - 8 * 86400);
  ins.run('mk_3', 'apc', 'm3', 'حالته open لكن تاريخه مضى', 'APC', 'JO', 'M3', day(-3), 'https://arabpotash.com/3', 'open', now - 50);
  ins.run('mk_4', 'apc', 'm4', 'بلا موعد', 'APC', 'JO', 'M4', null, 'https://arabpotash.com/4', 'open', now - 10);
  const email = 'mkt' + uniq() + '@t.com';
  assert.strictEqual((await call('mkt', 'POST', '/api/auth/register', { body: { name: 'مقاول السوق', email, password: 'Password123', role: 'contractor' } })).status, 201);
  const ids = (r) => r.data.opportunities.map((o) => o.id).filter((i) => i.startsWith('mk_'));
  const open = await call('mkt', 'GET', '/api/opportunities/feed?limit=60');
  assert.deepStrictEqual(ids(open), ['mk_1', 'mk_2', 'mk_4'], 'المنتهي بالتاريخ لا يظهر ضمن المفتوحة، والترتيب بالأقرب إغلاقاً وبلا موعد آخراً');
  assert.deepStrictEqual(ids(await call('mkt', 'GET', '/api/opportunities/feed?status=closed&limit=60')).includes('mk_3'), true);
  assert.deepStrictEqual(ids(await call('mkt', 'GET', '/api/opportunities/feed?closing=7&limit=60')), ['mk_1']);
  assert.deepStrictEqual(ids(await call('mkt', 'GET', '/api/opportunities/feed?sort=new&limit=60')), ['mk_4', 'mk_1', 'mk_2']);
  const p1 = await call('mkt', 'GET', '/api/opportunities/feed?limit=1&offset=0'); const p2 = await call('mkt', 'GET', '/api/opportunities/feed?limit=1&offset=1');
  assert.strictEqual(p1.data.count, 1); assert.ok(p1.data.total >= 3 && p1.data.hasMore); assert.notStrictEqual(p1.data.opportunities[0].id, p2.data.opportunities[0].id);
  assert.ok(open.data.stats.closingSoon >= 1 && open.data.stats.newThisWeek >= 2 && open.data.stats.open >= 3);
  // المفضلة
  assert.strictEqual((await call('mkt', 'POST', '/api/opportunities/mk_2/save')).status, 200);
  assert.strictEqual((await call('mkt', 'POST', '/api/opportunities/nope/save')).status, 404);
  const saved = await call('mkt', 'GET', '/api/opportunities/feed?saved=1&limit=60');
  assert.deepStrictEqual(ids(saved), ['mk_2']); assert.strictEqual(saved.data.opportunities[0].saved, true); assert.strictEqual(saved.data.stats.saved, 1);
  assert.strictEqual((await call('mkt', 'DELETE', '/api/opportunities/mk_2/save')).status, 200);
  assert.strictEqual((await call('mkt', 'GET', '/api/opportunities/feed?saved=1&limit=60')).data.total, 0);
  // المشتري لا يصل للمفضلة أيضاً
  await call('mkb', 'POST', '/api/auth/register', { body: { name: 'مشتري السوق', email: 'mkb' + uniq() + '@t.com', password: 'Password123', role: 'buyer' } });
  assert.strictEqual((await call('mkb', 'POST', '/api/opportunities/mk_1/save')).status, 403);
});


test('94 — دليل العطاءات يرشّح حسب المصدر مع بقاء الوصول مقتصراً على المقاول أو المسؤول', async () => {
  const db = getDB(), token = 'source-filter-' + uniq(), user = 'source-filter-admin';
  await makeAdmin(user);
  const insert = db.prepare(`INSERT INTO tender_opportunities
    (id,source_key,external_id,title,authority,country,sector,tender_number,summary,closing_at,source_url,status,language)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  insert.run('filter-jpmc-' + token, 'jpmc', 'filter-jpmc-' + token, token, 'JPMC', 'JO', 'أعمال', token, 'test', '2099-12-31', 'https://www.jpmc.com.jo/ar/tender', 'open', 'ar');
  insert.run('filter-ungm-' + token, 'ungm', 'filter-ungm-' + token, token, 'UNGM', 'JO', 'أعمال', token, 'test', '2099-12-31', 'https://www.ungm.org/Public/Notice', 'open', 'en');
  try {
    const filtered = await call(user, 'GET', '/api/opportunities?source=jpmc&country=JO&status=open&q=' + token);
    assert.strictEqual(filtered.status, 200, JSON.stringify(filtered.data));
    assert.strictEqual(filtered.data.count, 1);
    assert.strictEqual(filtered.data.opportunities[0].sourceKey, 'jpmc');
  } finally {
    db.prepare("DELETE FROM tender_opportunities WHERE external_id IN (?,?)").run('filter-jpmc-' + token, 'filter-ungm-' + token);
  }
});

test('95 — استيراد عطاءات أمانة عمّان وFAO متاح للمسؤول ويحدّث السجلات دون تكرار', async () => {
  const db = getDB(), admin = 'curated-import-admin';
  const denied = await call('anon-curated-import', 'POST', '/api/opportunities/admin/import/amman-curated', { body: {} });
  assert.strictEqual(denied.status, 401);
  await makeAdmin(admin);
  db.prepare("DELETE FROM tender_opportunities WHERE source_key='amman' OR (source_key='ungm' AND external_id='318902')").run();
  const first = await call(admin, 'POST', '/api/opportunities/admin/import/amman-curated', { body: {} });
  assert.strictEqual(first.status, 200, JSON.stringify(first.data));
  assert.deepStrictEqual([first.data.added, first.data.updated, first.data.received, first.data.snapshotOnly], [14, 0, 14, true]);
  const second = await call(admin, 'POST', '/api/opportunities/admin/import/amman-curated', { body: {} });
  assert.strictEqual(second.status, 200, JSON.stringify(second.data));
  assert.deepStrictEqual([second.data.added, second.data.updated], [0, 14]);
  assert.strictEqual(db.prepare("SELECT COUNT(*) n FROM tender_opportunities WHERE source_key='amman'").get().n, 14);
  const ungm = await call(admin, 'POST', '/api/opportunities/admin/import/ungm-jordan-curated', { body: {} });
  assert.strictEqual(ungm.status, 200, JSON.stringify(ungm.data));
  assert.deepStrictEqual([ungm.data.added, ungm.data.received, ungm.data.snapshotOnly], [1, 1, true]);
});


test('96 — وثائق العطاء العامة تُنزّل عبر MMC وتُخزّن بعد أول طلب مع حماية الدخول', async () => {
  const db=getDB(), token='doc-download-'+uniq(), opportunityId='doc-opp-'+token, documentId='doc-file-'+token;
  const documentUrl='https://arabpotash.com/public/'+token+'.pdf', apiPath='/api/opportunities/'+opportunityId+'/documents/'+documentId+'/download';
  const bytes=Buffer.from('%PDF-1.7\nMMC tender document\n');
  db.prepare(`INSERT INTO tender_opportunities (id,source_key,external_id,title,authority,country,source_url,status,language)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(opportunityId,'apc',token,'Public APC tender','Arab Potash','JO','https://arabpotash.com/EN/Modules/Tenders','open','en');
  db.prepare(`INSERT INTO tender_opportunity_public_documents (id,opportunity_id,label,document_url,availability)
    VALUES (?,?,?,?,?)`).run(documentId,opportunityId,'كراسة العطاء',documentUrl,'public-source-link');
  const denied=await call('anon-doc-download','GET',apiPath);
  assert.strictEqual(denied.status,401);
  const contractor='doc-contractor-'+uniq();
  await call(contractor,'POST','/api/auth/register',{body:{name:'مقاول تنزيل',email:contractor+'@t.com',password:'Password123'}});
  const originalFetch=global.fetch;let upstreamRequests=0;
  global.fetch=async(url,options)=>{
    if(String(url)===documentUrl){upstreamRequests++;return new Response(bytes,{status:200,headers:{'content-type':'application/pdf','content-length':String(bytes.length)}});}
    return originalFetch(url,options);
  };
  try {
    const preflight=await fetch(base+apiPath,{method:'HEAD',headers:cookieFor(contractor),redirect:'manual'});
    assert.strictEqual(preflight.status,200);
    assert.strictEqual(preflight.headers.get('x-mmc-document-cache'),'stored');
    assert.match(preflight.headers.get('content-disposition')||'',/attachment/);
    assert.strictEqual((await preflight.arrayBuffer()).byteLength,0,'HEAD checks/caches the document without delivering the body');
    const first=await fetch(base+apiPath,{headers:cookieFor(contractor),redirect:'manual'});
    assert.strictEqual(first.status,200);
    assert.strictEqual(first.headers.get('x-mmc-document-cache'),'hit');
    assert.deepStrictEqual(Buffer.from(await first.arrayBuffer()),bytes);
    const stored=db.prepare('SELECT storage_key,storage_driver,content_type,file_size,checksum_sha256,downloaded_at FROM tender_opportunity_public_documents WHERE id=?').get(documentId);
    assert.ok(stored.storage_key.startsWith('public-tenders/apc/'+documentId));
    assert.ok(stored.storage_driver);
    assert.strictEqual(stored.content_type,'application/pdf');
    assert.strictEqual(stored.file_size,bytes.length);
    assert.ok(stored.checksum_sha256&&stored.downloaded_at);
    const second=await fetch(base+apiPath,{headers:cookieFor(contractor),redirect:'manual'});
    assert.strictEqual(second.status,200);
    assert.strictEqual(second.headers.get('x-mmc-document-cache'),'hit');
    assert.deepStrictEqual(Buffer.from(await second.arrayBuffer()),bytes);
    assert.strictEqual(upstreamRequests,1,'the cached MMC copy should prevent a second source fetch');
  } finally {
    global.fetch=originalFetch;
    db.prepare('DELETE FROM tender_opportunities WHERE id=?').run(opportunityId);
  }
});

test('97 — تفاصيل العطاء تعيد رابط تنزيل داخلياً للوثيقة الرسمية', async () => {
  const db=getDB(),token='doc-details-'+uniq(),opportunityId='detail-opp-'+token,documentId='detail-file-'+token,user='detail-contractor-'+uniq();
  await call(user,'POST','/api/auth/register',{body:{name:'مقاول تفاصيل',email:user+'@t.com',password:'Password123'}});
  db.prepare(`INSERT INTO tender_opportunities (id,source_key,external_id,title,authority,country,source_url,status,language)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(opportunityId,'apc',token,'APC notice','Arab Potash','JO','https://arabpotash.com/EN/Modules/Tenders','open','en');
  db.prepare(`INSERT INTO tender_opportunity_public_documents (id,opportunity_id,label,document_url,availability)
    VALUES (?,?,?,?,?)`).run(documentId,opportunityId,'Tender PDF','https://arabpotash.com/docs/'+token+'.pdf','public-source-link');
  try {
    const result=await call(user,'GET','/api/opportunities/'+opportunityId);
    assert.strictEqual(result.status,200,JSON.stringify(result.data));
    assert.strictEqual(result.data.opportunity.id,opportunityId);
    assert.strictEqual(result.data.documents.length,1);
    assert.strictEqual(result.data.documents[0].downloadUrl,'/api/opportunities/'+opportunityId+'/documents/'+documentId+'/download');
  } finally { db.prepare('DELETE FROM tender_opportunities WHERE id=?').run(opportunityId); }
});
