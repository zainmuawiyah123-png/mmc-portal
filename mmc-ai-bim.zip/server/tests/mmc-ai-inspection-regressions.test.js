'use strict';
/* Regression tests for defects found during the inspection pass.
   Each test pins a bug that was actually reproduced before the fix. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');

test('date validation accepts a real ISO date (schedule route)', () => {
  // Bug: the regex was written /^\\d{4}-\\d{2}-\\d{2}$/ inside a regex literal,
  // which matches a literal backslash and rejected every valid date.
  const src = fs.readFileSync(path.join(ROOT, 'src/routes/mmc-ai-schedule.js'), 'utf8');
  assert.ok(!src.includes('\\\\d{4}'), 'schedule route must not contain a double-escaped \\d');
  assert.ok(/\/\^\\d\{4\}-\\d\{2\}-\\d\{2\}\$\//.test(src), 'schedule route must use a single-escaped date regex');
});

test('date validation accepts a real ISO date (correspondence route)', () => {
  const src = fs.readFileSync(path.join(ROOT, 'src/routes/mmc-ai-correspondence.js'), 'utf8');
  assert.ok(!src.includes('\\\\d{4}'), 'correspondence route must not contain a double-escaped \\d');
});

test('SQL string literals use single quotes, not double quotes', () => {
  // Bug: COALESCE(communication_date,"") made SQLite treat "" as an identifier,
  // so the correspondence list endpoint returned HTTP 500.
  const files = ['src/routes/mmc-ai-correspondence.js', 'src/routes/mmc-ai-contract-management.js'];
  for (const f of files) {
    const src = fs.readFileSync(path.join(ROOT, f), 'utf8');
    const bad = /(COALESCE|IFNULL|NULLIF)\([^)]*"/.exec(src);
    assert.equal(bad, null, `${f} must not use double quotes inside ${bad && bad[1]}`);
  }
});

test('correspondence module loads and exposes a router', () => {
  const mod = require(path.join(ROOT, 'src/routes/mmc-ai-correspondence.js'));
  assert.ok(mod, 'module must export something');
});

test('contract-management module loads and exposes a router', () => {
  const mod = require(path.join(ROOT, 'src/routes/mmc-ai-contract-management.js'));
  assert.ok(mod, 'module must export something');
});

test('spatial-extract test imports every function it exercises', () => {
  // Bug: the test called rotateBboxToSvgFrame / parseSvgPageFrame without
  // importing them, so 4 assertions failed with "not a function".
  const src = fs.readFileSync(path.join(ROOT, 'tests/mmc-ai-pdf-text-spatial-extract.test.js'), 'utf8');
  for (const fn of ['rotateBboxToSvgFrame', 'parseSvgPageFrame']) {
    assert.ok(src.includes(fn), `test must reference ${fn}`);
  }
  const mod = require(path.join(ROOT, 'src/lib/mmc-ai/pdf-text-spatial-extract.js'));
  assert.equal(typeof mod.rotateBboxToSvgFrame, 'function');
  assert.equal(typeof mod.parseSvgPageFrame, 'function');
});

test('consultant page loads api.js before its inline script', () => {
  // Bug: the inline script called API.me() before api.js was loaded, throwing
  // "API is not defined" and leaving the page blank.
  const html = fs.readFileSync(
    path.resolve(ROOT, '..', 'webpages/technical-proposal-kit_v5/consultant/index.html'), 'utf8');
  const apiIdx = html.indexOf('assets/api.js');
  const inlineIdx = html.indexOf('<script>(function(){');
  assert.ok(apiIdx > -1, 'consultant page must load api.js');
  assert.ok(inlineIdx > -1, 'consultant page must have its inline script');
  assert.ok(apiIdx < inlineIdx, 'api.js must be loaded before the inline script runs');
});

test('takeoff page exposes a real upload control and register', () => {
  const html = fs.readFileSync(
    path.resolve(ROOT, '..', 'webpages/technical-proposal-kit_v5/mmc-ai/index.html'), 'utf8');
  for (const id of ['tkFile', 'tkRows', 'tkApprove', 'tkToBoq', 'tkStatus']) {
    assert.ok(html.includes(`id="${id}"`), `takeoff UI must contain #${id}`);
  }
  assert.ok(html.includes('/takeoff/dxf'), 'takeoff UI must call the DXF takeoff endpoint');
});

test('standalone demo loads the bundle and demo backend', () => {
  const html = fs.readFileSync(
    path.resolve(ROOT, '..', 'webpages/technical-proposal-kit_v5/mmc-ai/index.html'), 'utf8');
  // The page must reference the bundle by a RELATIVE path: the files sit next
  // to the page, so an absolute '/mmc-ai-bundle.js' 404s on the preview server
  // and standalone demo mode never loads.
  assert.ok(html.includes("s.src = 'mmc-ai-bundle.js'"), 'page must load the bundle by a relative path');
  assert.ok(html.includes("d.src = 'mmc-ai-demo-backend.js'"), 'page must load the demo backend by a relative path');
  assert.ok(!html.includes("'/mmc-ai-bundle.js'"), 'page must not use an absolute bundle path');
  for (const f of ['mmc-ai-bundle.js', 'mmc-ai-demo-backend.js']) {
    assert.ok(fs.existsSync(path.resolve(ROOT, '..', 'webpages/technical-proposal-kit_v5/mmc-ai', f)),
      `${f} must be present next to the page`);
  }
});

test('no source file contains double-encoded Arabic (mojibake)', () => {
  // Bug: 31 files carried cp850-mangled Arabic, so console output and some
  // UI strings rendered as garbage.
  const dirs = [path.join(ROOT, 'src')];
  const offenders = [];
  const walk = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (e.name !== 'node_modules') walk(p); continue; }
      if (!p.endsWith('.js')) continue;
      const t = fs.readFileSync(p, 'utf8');
      // Real mojibake shows up as runs of Latin-1 supplement characters that
      // decode back to Arabic. Isolated math symbols (×, Σ, −, ²) are fine.
      const runs = t.match(/[\u00a0-\u00ff]{2,}/g) || [];
      const mangled = runs.filter((r) => {
        try { return /[\u0600-\u06ff]/.test(Buffer.from(r, 'latin1').toString('utf8')); }
        catch (_) { return false; }
      });
      if (mangled.length) offenders.push(path.relative(ROOT, p));
    }
  };
  dirs.forEach(walk);
  assert.deepEqual(offenders, [], 'files with mojibake: ' + offenders.join(', '));
});
