'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { writeIfc, ifcGuid, stepString, stepReal } = require('../src/lib/mmc-ai/ifc-writer');
const { parseIfc } = require('../src/lib/mmc-ai/ifc-inspector');

function element(over) {
  return Object.assign({
    id: 'bime_0001', category: 'columns', kind: 'column', ifcType: 'IfcColumn',
    discipline: 'structural', label: { ar: 'عمود', en: 'Column' }, name: 'Column 1',
    storey: 'Level 0',
    footprint: { minX: 0, minY: 0, maxX: 0.3, maxY: 0.3, width: 0.3, depth: 0.3 },
    centroid: { x: 0.15, y: 0.15 }, baseM: 0, heightM: 3, topM: 3, volumeM3: 0.27,
    geometryBasis: 'closed_polyline_rectangle', heightSource: 'project_input',
    source: { takeoffItemId: 't1', layer: 'S-COLS', entityIndex: 0, formula: '0.3×0.3×3', quantity: 0.09, unit: 'm2' }
  }, over);
}

test('stepString doubles single quotes', () => {
  assert.equal(stepString("O'Brien"), "'O''Brien'");
});

test('stepReal always carries a decimal point', () => {
  assert.equal(stepReal(3), '3.0');
  assert.equal(stepReal(0.3), '0.3');
  assert.throws(() => stepReal(NaN), /non-finite/);
});

test('ifcGuid is 22 characters and deterministic', () => {
  const a = ifcGuid('element:bime_0001:columns');
  assert.equal(a.length, 22);
  assert.equal(a, ifcGuid('element:bime_0001:columns'));
  assert.notEqual(a, ifcGuid('element:bime_0002:columns'));
});

test('writes a valid IFC4 envelope the project inspector accepts', () => {
  const ifc = writeIfc({ elements: [element()], projectName: 'Test', storeyName: 'Level 0' });
  assert.match(ifc, /^ISO-10303-21;/);
  assert.match(ifc, /END-ISO-10303-21;\s*$/);
  assert.match(ifc, /FILE_SCHEMA\(\('IFC4'\)\)/);
  const report = parseIfc(ifc);
  assert.equal(report.schema, 'IFC4');
  assert.equal(report.lengthUnit, 'm');
  assert.ok(report.records > 20);
});

test('declares the full spatial structure', () => {
  const ifc = writeIfc({ elements: [element()], projectName: 'Test' });
  for (const entity of ['IFCPROJECT', 'IFCSITE', 'IFCBUILDING', 'IFCBUILDINGSTOREY', 'IFCRELAGGREGATES']) {
    assert.ok(ifc.includes(entity + '('), 'missing ' + entity);
  }
});

test('declares SI units', () => {
  const ifc = writeIfc({ elements: [element()] });
  assert.ok(ifc.includes('.LENGTHUNIT.,$,.METRE.'));
  assert.ok(ifc.includes('.AREAUNIT.,$,.SQUARE_METRE.'));
  assert.ok(ifc.includes('.VOLUMEUNIT.,$,.CUBIC_METRE.'));
});

test('emits one product per element with extruded solid geometry', () => {
  const ifc = writeIfc({ elements: [element(), element({ id: 'bime_0002', ifcType: 'IfcBeam', category: 'beams' })] });
  const report = parseIfc(ifc);
  assert.equal(report.buildingElementCount, 2);
  assert.equal((ifc.match(/IFCEXTRUDEDAREASOLID\(/g) || []).length, 2);
  assert.equal((ifc.match(/IFCRECTANGLEPROFILEDEF\(/g) || []).length, 2);
});

test('places every element in the storey via containment', () => {
  const ifc = writeIfc({ elements: [element()] });
  assert.ok(ifc.includes('IFCRELCONTAINEDINSPATIALSTRUCTURE('));
});

test('carries provenance in a property set', () => {
  const ifc = writeIfc({ elements: [element()] });
  assert.ok(ifc.includes('IFCPROPERTYSET('));
  assert.ok(ifc.includes("'MMC_Provenance'"));
  assert.ok(ifc.includes("'SourceTakeoffItemId'"));
  assert.ok(ifc.includes("'t1'"));
  assert.ok(ifc.includes("'S-COLS'"));
  assert.ok(ifc.includes('IFCRELDEFINESBYPROPERTIES('));
});

test('skips degenerate geometry instead of writing a zero-size solid', () => {
  const ifc = writeIfc({ elements: [element({ heightM: 0 })] });
  assert.equal((ifc.match(/IFCEXTRUDEDAREASOLID\(/g) || []).length, 0);
  assert.equal(parseIfc(ifc).buildingElementCount, 0);
});

test('is deterministic: the same elements produce the same file', () => {
  const a = writeIfc({ elements: [element()], projectName: 'X' }, { timestamp: '2026-01-01T00:00:00' });
  const b = writeIfc({ elements: [element()], projectName: 'X' }, { timestamp: '2026-01-01T00:00:00' });
  assert.equal(a, b);
});

test('writes the correct IFC entity for each discipline', () => {
  const cases = [
    ['IfcFooting', 'foundations'], ['IfcSlab', 'slabs'], ['IfcWall', 'walls'],
    ['IfcDoor', 'doors'], ['IfcWindow', 'glazing'], ['IfcPipeSegment', 'pipes'],
    ['IfcDuctSegment', 'ducts'], ['IfcLightFixture', 'lighting'], ['IfcOutlet', 'power_devices'],
    ['IfcPump', 'pumps'], ['IfcFireSuppressionTerminal', 'sprinklers'], ['IfcRoof', 'roof']
  ];
  for (const [ifcType, category] of cases) {
    const ifc = writeIfc({ elements: [element({ ifcType, category })] });
    assert.ok(ifc.includes(ifcType.toUpperCase() + '('), 'missing ' + ifcType + ' for ' + category);
  }
});

test('an unknown IFC type falls back to a proxy rather than crashing', () => {
  const ifc = writeIfc({ elements: [element({ ifcType: 'IfcMadeUpThing' })] });
  assert.ok(ifc.includes('IFCBUILDINGELEMENTPROXY('));
});

test('an empty element list still produces a valid file with the spatial structure', () => {
  const ifc = writeIfc({ elements: [] });
  const report = parseIfc(ifc);
  assert.equal(report.schema, 'IFC4');
  assert.equal(report.buildingElementCount, 0);
  assert.ok(ifc.includes('IFCPROJECT('));
});
