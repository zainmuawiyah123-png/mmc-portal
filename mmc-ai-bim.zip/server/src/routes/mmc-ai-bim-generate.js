'use strict';

/**
 * MMC AI — BIM generation API.
 *
 * Generates a BIM model (IFC + GLB) from a reviewed takeoff run, stores both
 * files, persists the element list with its provenance, and exposes the
 * two-way link between BIM elements and BOQ items.
 *
 * Every element carries the takeoff item it came from, so the UI can jump from
 * a BOQ line to the matching element in the 3D model and back.
 */
const express = require('express');
const crypto = require('node:crypto');
const { getDB, uid } = require('../db');
const { E, wrap } = require('../lib/errors');
const A = require('../lib/auth');
const storage = require('../lib/storage');
const { buildBimElements } = require('../lib/mmc-ai/bim-element-model');
const { writeIfc } = require('../lib/mmc-ai/ifc-writer');
const { writeGlb } = require('../lib/mmc-ai/glb-writer');
const { buildLinkIndex } = require('../lib/mmc-ai/bim-link');

const router = express.Router();
router.use(A.requireMmcAiAuth);

const EDIT_ROLES = ['owner', 'project_manager', 'engineer', 'quantity_surveyor'];
const MAX_INPUT_KEYS = 60;

function member(projectId, userId) {
  return getDB().prepare(
    'SELECT m.role,p.status,p.name,p.currency FROM ai_project_members m JOIN ai_projects p ON p.id=m.project_id WHERE m.project_id=? AND m.user_id=?'
  ).get(projectId, userId) || null;
}
function requireMember(req) {
  const m = member(req.params.projectId, req.user.id);
  if (!m || m.status !== 'active') throw E.notFound('المشروع غير موجود.');
  return m;
}
function requireEditor(req) {
  const m = requireMember(req);
  if (!EDIT_ROLES.includes(m.role)) throw E.forbidden('لا تملك صلاحية توليد نموذج BIM.');
  return m;
}

/** Loads a takeoff run's items in the shape the element model expects. */
function loadRunRows(db, runId) {
  const rows = db.prepare(
    'SELECT id,entity_index,entity_type,layer_name,quantity,unit,detail_json,review_status FROM ai_takeoff_items WHERE run_id=? ORDER BY entity_index'
  ).all(runId);
  return rows.map((r) => {
    let detail = {};
    try { detail = JSON.parse(r.detail_json || '{}'); } catch (_) { detail = {}; }
    return {
      id: r.id,
      entity_index: r.entity_index,
      entity_type: r.entity_type,
      layer_name: r.layer_name,
      quantity: r.quantity,
      unit: r.unit,
      review_status: r.review_status,
      category: detail.disciplineCategory || detail.category || null,
      discipline: detail.discipline || null,
      geometry: detail.geometry || null,
      closed: detail.closed === true,
      radius_m: detail.radius_m ?? null,
      detail
    };
  });
}

/**
 * Sanitises the engineer's dimension inputs: a flat map of
 * category → { heightM, baseM, widthM, ... } with numeric values only.
 */
function sanitiseInputs(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const out = {};
  let keys = 0;
  for (const [category, bucket] of Object.entries(raw)) {
    if (keys >= MAX_INPUT_KEYS) break;
    if (!bucket || typeof bucket !== 'object' || Array.isArray(bucket)) continue;
    const clean = {};
    for (const [k, v] of Object.entries(bucket)) {
      if (!/^[a-zA-Z]{2,20}$/.test(k)) continue;
      const n = Number(v);
      if (!Number.isFinite(n) || n < 0 || n > 1e6) continue;
      clean[k] = n;
    }
    if (Object.keys(clean).length) { out[String(category).slice(0, 60)] = clean; keys++; }
  }
  return out;
}

function modelView(row) {
  return {
    id: row.id,
    project_id: row.project_id,
    takeoff_run_id: row.takeoff_run_id,
    name: row.name,
    storey_name: row.storey_name,
    element_count: row.element_count,
    unresolved_count: row.unresolved_count,
    summary: JSON.parse(row.summary_json || '{}'),
    inputs: JSON.parse(row.inputs_json || '{}'),
    has_ifc: !!row.ifc_storage_key,
    has_glb: !!row.glb_storage_key,
    ifc_size_bytes: row.ifc_size_bytes,
    glb_size_bytes: row.glb_size_bytes,
    status: row.status,
    created_at: row.created_at
  };
}

function elementView(row) {
  return {
    id: row.id,
    element_code: row.element_code,
    category: row.category,
    kind: row.kind,
    ifc_type: row.ifc_type,
    discipline: row.discipline,
    name: row.name,
    storey: row.storey,
    footprint: JSON.parse(row.footprint_json || '{}'),
    centroid: JSON.parse(row.centroid_json || '{}'),
    base_m: row.base_m,
    height_m: row.height_m,
    top_m: row.top_m,
    volume_m3: row.volume_m3,
    geometry_basis: row.geometry_basis,
    height_source: row.height_source,
    source_takeoff_item_id: row.source_takeoff_item_id,
    source: JSON.parse(row.source_json || '{}')
  };
}

/** POST /projects/:projectId/takeoff/runs/:runId/bim — generate a model. */
router.post('/projects/:projectId/takeoff/runs/:runId/bim', wrap(async (req, res) => {
  const m = requireEditor(req);
  const db = getDB();
  const run = db.prepare('SELECT * FROM ai_takeoff_runs WHERE id=? AND project_id=?').get(req.params.runId, req.params.projectId);
  if (!run) throw E.notFound('نتيجة الحصر غير موجودة.');

  const rows = loadRunRows(db, run.id);
  if (!rows.length) throw E.validation('لا توجد بنود في نتيجة الحصر لتوليد نموذج منها.');

  const inputs = sanitiseInputs(req.body && req.body.inputs);
  const storeyName = String((req.body && req.body.storeyName) || 'Level 0').trim().slice(0, 80) || 'Level 0';
  const modelName = String((req.body && req.body.name) || (m.name + ' — BIM')).trim().slice(0, 160) || 'BIM Model';

  const model = buildBimElements({ items: rows }, { inputs, projectName: m.name, storeyName });
  if (!model.elements.length) {
    throw E.validation('لم يُنتج أي عنصر ثلاثي الأبعاد. زوّد النظام بأبعاد العناصر (الارتفاع والسماكة) ثم أعد المحاولة. الأسباب: ' +
      model.unresolved.slice(0, 6).map((u) => u.category + ' (' + u.reason + ')').join('، '));
  }

  const ifcText = writeIfc({ ...model, projectName: m.name, storeyName });
  const ifcBuffer = Buffer.from(ifcText, 'utf8');
  const glbBuffer = writeGlb({ ...model });

  const modelId = uid('aibimg_');
  const baseKey = ['mmc-ai', 'projects', req.params.projectId, 'bim-generated', modelId].join('/');
  const ifcKey = baseKey + '/model.ifc';
  const glbKey = baseKey + '/model.glb';
  const store = storage.getStorage();

  await store.put(ifcKey, ifcBuffer, { mime: 'application/x-step', originalName: 'model.ifc' });
  try {
    await store.put(glbKey, glbBuffer, { mime: 'model/gltf-binary', originalName: 'model.glb' });
  } catch (err) {
    await store.delete(ifcKey).catch(() => {});
    throw err;
  }

  const ifcSha = crypto.createHash('sha256').update(ifcBuffer).digest('hex');
  const glbSha = crypto.createHash('sha256').update(glbBuffer).digest('hex');

  try {
    db.transaction(() => {
      db.prepare(`INSERT INTO ai_bim_generated_models
        (id,project_id,takeoff_run_id,created_by,name,storey_name,element_count,unresolved_count,summary_json,inputs_json,
         ifc_storage_key,ifc_size_bytes,ifc_sha256,glb_storage_key,glb_size_bytes,glb_sha256,status)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'ready')`).run(
        modelId, req.params.projectId, run.id, req.user.id, modelName, storeyName,
        model.elements.length, model.unresolved.length,
        JSON.stringify({ ...model.summary, unresolved: model.unresolved, limitations: model.limitations }),
        JSON.stringify(inputs),
        ifcKey, ifcBuffer.length, ifcSha, glbKey, glbBuffer.length, glbSha
      );
      const add = db.prepare(`INSERT INTO ai_bim_elements
        (id,model_id,element_code,category,kind,ifc_type,discipline,name,storey,footprint_json,centroid_json,
         base_m,height_m,top_m,volume_m3,geometry_basis,height_source,source_takeoff_item_id,source_json)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
      for (const el of model.elements) {
        add.run(uid('aibime_'), modelId, el.id, el.category, el.kind, el.ifcType, el.discipline, el.name, el.storey,
          JSON.stringify(el.footprint), JSON.stringify(el.centroid), el.baseM, el.heightM, el.topM, el.volumeM3,
          el.geometryBasis || null, el.heightSource || null,
          el.source.takeoffItemId || null, JSON.stringify(el.source));
      }
      db.prepare(`INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json)
        VALUES(?,?,?,?,?,?,?)`).run(uid('aial_'), req.params.projectId, req.user.id, 'bim_model_generated', 'bim_generated_model', modelId,
        JSON.stringify({ takeoffRunId: run.id, elements: model.elements.length, unresolved: model.unresolved.length, ifcBytes: ifcBuffer.length, glbBytes: glbBuffer.length }));
    })();
  } catch (err) {
    await store.delete(ifcKey).catch(() => {});
    await store.delete(glbKey).catch(() => {});
    throw err;
  }

  console.info('[mmc-ai][bim-generate][completed]', JSON.stringify({
    projectId: req.params.projectId, runId: run.id, modelId,
    elements: model.elements.length, unresolved: model.unresolved.length,
    ifcBytes: ifcBuffer.length, glbBytes: glbBuffer.length
  }));

  const saved = db.prepare('SELECT * FROM ai_bim_generated_models WHERE id=?').get(modelId);
  res.status(201).json({
    model: modelView(saved),
    elements: model.elements.map((el) => ({
      element_code: el.id, category: el.category, kind: el.kind, discipline: el.discipline,
      name: el.name, volume_m3: el.volumeM3, base_m: el.baseM, top_m: el.topM,
      source_takeoff_item_id: el.source.takeoffItemId
    })),
    unresolved: model.unresolved,
    limitations: model.limitations,
    notice: 'النموذج مُشتق من قياسات المخطط ويحتاج مراجعة مهندس قبل الاستخدام التعاقدي.'
  });
}));

/** GET /projects/:projectId/bim/generated — list generated models. */
router.get('/projects/:projectId/bim/generated', wrap(async (req, res) => {
  requireMember(req);
  const rows = getDB().prepare(
    'SELECT * FROM ai_bim_generated_models WHERE project_id=? ORDER BY created_at DESC'
  ).all(req.params.projectId);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ models: rows.map(modelView) });
}));

/** GET /projects/:projectId/bim/generated/:modelId — model + elements + BOQ links. */
router.get('/projects/:projectId/bim/generated/:modelId', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_generated_models WHERE id=? AND project_id=?').get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');

  const elements = db.prepare('SELECT * FROM ai_bim_elements WHERE model_id=? ORDER BY element_code').all(row.id).map(elementView);
  const boqItems = db.prepare('SELECT id,item_code,description,unit,quantity,rate,source_takeoff_item_id FROM ai_boq_items WHERE project_id=?').all(req.params.projectId);
  const links = buildLinkIndex(elements.map((e) => ({ id: e.element_code, source: { takeoffItemId: e.source_takeoff_item_id } })), boqItems);

  res.setHeader('Cache-Control', 'no-store');
  res.json({ model: modelView(row), elements, links, boqItems });
}));

/** GET /projects/:projectId/bim/generated/:modelId/download?format=ifc|glb */
router.get('/projects/:projectId/bim/generated/:modelId/download', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_generated_models WHERE id=? AND project_id=?').get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');

  const format = String(req.query.format || 'ifc').toLowerCase();
  if (!['ifc', 'glb'].includes(format)) throw E.validation('صيغة التنزيل يجب أن تكون ifc أو glb.');
  const key = format === 'ifc' ? row.ifc_storage_key : row.glb_storage_key;
  const size = format === 'ifc' ? row.ifc_size_bytes : row.glb_size_bytes;
  const sha = format === 'ifc' ? row.ifc_sha256 : row.glb_sha256;
  if (!key) throw E.notFound('ملف النموذج بهذه الصيغة غير متوفر.');

  const store = storage.getStorage();
  if (!(await store.exists(key))) throw E.notFound('ملف النموذج غير موجود في التخزين.');

  db.prepare(`INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json)
    VALUES(?,?,?,?,?,?,?)`).run(uid('aial_'), row.project_id, req.user.id, 'bim_model_downloaded', 'bim_generated_model', row.id,
    JSON.stringify({ format, sha256: sha }));

  const safeName = String(row.name || 'model').replace(/[^\w\u0600-\u06FF.-]+/g, '_').slice(0, 80);
  res.setHeader('Content-Type', format === 'ifc' ? 'application/x-step' : 'model/gltf-binary');
  if (size) res.setHeader('Content-Length', String(size));
  res.setHeader('Content-Disposition', (req.query.inline === '1' ? 'inline' : 'attachment') + '; filename="' + safeName + '.' + format + '"');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'private, no-store');
  if (store.DRIVER === 's3') {
    const result = await store.stream(key);
    result.body.pipe(res);
  } else {
    store.stream(key).pipe(res);
  }
}));

/** GET /projects/:projectId/bim/generated/:modelId/by-boq/:boqItemId — element ids for a BOQ line. */
router.get('/projects/:projectId/bim/generated/:modelId/by-boq/:boqItemId', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT id,takeoff_run_id FROM ai_bim_generated_models WHERE id=? AND project_id=?').get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');
  const boq = db.prepare(
    'SELECT id,source_takeoff_item_id,source_takeoff_run_id,source_proposal_key FROM ai_boq_items WHERE id=? AND project_id=?'
  ).get(req.params.boqItemId, req.params.projectId);
  if (!boq) throw E.notFound('بند جدول الكميات غير موجود.');

  // Two link paths, because BOQ items reach the table two ways:
  //  1. A manually created item carries source_takeoff_item_id → exact element.
  //  2. An item rolled up from a takeoff proposal carries
  //     source_takeoff_run_id + source_proposal_key ("category:key") → every
  //     element of that category in the same run.
  let elements = [];
  let basis = null;
  if (boq.source_takeoff_item_id) {
    elements = db.prepare('SELECT element_code FROM ai_bim_elements WHERE model_id=? AND source_takeoff_item_id=?').all(row.id, boq.source_takeoff_item_id);
    basis = 'takeoff_item';
  } else if (boq.source_takeoff_run_id && boq.source_takeoff_run_id === row.takeoff_run_id && boq.source_proposal_key) {
    const category = String(boq.source_proposal_key).split(':')[0];
    elements = db.prepare('SELECT element_code FROM ai_bim_elements WHERE model_id=? AND category=?').all(row.id, category);
    basis = 'proposal_category';
  }

  res.setHeader('Cache-Control', 'no-store');
  res.json({
    boqItemId: boq.id,
    takeoffItemId: boq.source_takeoff_item_id || null,
    basis,
    elementCodes: elements.map((e) => e.element_code)
  });
}));

module.exports = router;
