'use strict';
/** Project BOQ and estimate workspace. No tender/procurement tables are modified. */
const express=require('express');
const multer=require('multer');
const path=require('node:path');
const {parseBoqFile}=require('../lib/mmc-ai/boq-import');
const {getDB,uid}=require('../db');
const {E,wrap}=require('../lib/errors');
const A=require('../lib/auth');
const router=express.Router();
const importUpload=multer({storage:multer.memoryStorage(),limits:{fileSize:10*1024*1024,files:1,fields:0},fileFilter(req,file,cb){
 const ext=path.extname(file.originalname||'').toLowerCase();
 if(!['.xlsx','.csv'].includes(ext)) return cb(E.validation('يدعم استيراد BOQ ملفات XLSX وCSV فقط.'));
 cb(null,true);
}});
const publicRouter=express.Router();
router.use(A.requireMmcAiAuth);
const EDIT=new Set(['owner','project_manager','engineer','quantity_surveyor']);
function member(projectId,userId){return getDB().prepare(`SELECT m.role,p.status FROM ai_project_members m JOIN ai_projects p ON p.id=m.project_id WHERE m.project_id=? AND m.user_id=?`).get(projectId,userId)||null;}
function access(req,edit=false){const m=member(req.params.projectId,req.user.id);if(!m||m.status!=='active')throw E.notFound('المشروع غير موجود.');if(edit&&!EDIT.has(m.role))throw E.forbidden('لا تملك صلاحية تعديل جدول الكميات.');return m;}
function audit(db,req,action,itemId,detail){db.prepare(`INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)`).run(uid('aial_'),req.params.projectId,req.user.id,action,'boq_item',itemId,JSON.stringify(detail||{}));}
function clean(v,max){return String(v==null?'':v).trim().slice(0,max);}
function number(v,label){const n=Number(v);if(!Number.isFinite(n)||n<0||n>1e12)throw E.validation(label+' يجب أن يكون رقماً موجباً صالحاً.');return n;}
function itemView(x){const rateMissing=Boolean(x.rate_missing)||x.rate===null||x.rate===undefined;let sourceDetail={};try{sourceDetail=JSON.parse(x.source_detail_json||'{}');}catch{}return {...x,rate:rateMissing?null:Number(x.rate),rateMissing,line_total:rateMissing?null:Number((x.quantity*x.rate).toFixed(3)),validationIssues:JSON.parse(x.validation_json||'[]'),sourceDetail};}
function nullableRate(value,label='سعر الوحدة'){if(value===null||value===undefined||String(value).trim()==='')return null;return number(value,label);}
router.post('/projects/:projectId/boq/import',importUpload.single('file'),wrap(async(req,res)=>{
 access(req,true);
 if(!req.file) throw E.validation('اختر ملف Excel أو CSV أولاً.');
 let parsed;
 try{parsed=parseBoqFile({buffer:req.file.buffer,filename:req.file.originalname});}
 catch(err){throw E.validation(err.message||'تعذر قراءة ملف BOQ.');}
 if(!parsed.items.length) return res.status(422).json({error:'لا توجد بنود صالحة للاستيراد.',summary:parsed.summary,errors:parsed.errors});
 const db=getDB(),created=[];
 const insert=db.prepare(`INSERT INTO ai_boq_items(id,project_id,item_code,description,unit,quantity,rate,created_by,source_sheet,source_row,source_amount,rate_missing,validation_json,section_label) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
 const tx=db.transaction(()=>{
  for(const item of parsed.items){
   const id=uid('aiboq_');
   // Preserve a missing source rate as SQL NULL; an explicitly quoted zero remains 0.
   insert.run(id,req.params.projectId,item.itemCode,item.description,item.unit,item.quantity,item.rate,req.user.id,item.sourceSheet||null,item.rowNumber||null,item.sourceAmount??null,item.rate===null?1:0,JSON.stringify(item.validationIssues||[]),item.sectionLabel||null);
   created.push({id,...item,rate:item.rate,rateMissing:item.rate===null});
  }
  db.prepare(`INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)`)
   .run(uid('aial_'),req.params.projectId,req.user.id,'boq_items_imported','boq_import',null,JSON.stringify({filename:req.file.originalname,format:parsed.sourceFormat,imported:created.length,errorRows:parsed.errors.length,duplicateRows:parsed.duplicates.length,missingRates:created.filter(x=>x.rateMissing).length,sourceSheets:parsed.sourceSheets,warningRows:parsed.warnings?.length||0}));
 });
 tx();
 res.status(201).json({items:created,summary:{...parsed.summary,imported:created.length,missingRates:created.filter(x=>x.rateMissing).length},errors:parsed.errors,duplicates:parsed.duplicates,warnings:parsed.warnings||[],sourceSheets:parsed.sourceSheets||[],notice:'تم استيراد البنود الصالحة فقط. الصفوف غير الصالحة معروضة في الأخطاء ولم تُسقط بصمت. الأسعار غير الموجودة محفوظة كقيم NULL، والأسعار الصفرية الصريحة محفوظة كصفر.'});
}));
router.get('/projects/:projectId/boq',wrap(async(req,res)=>{
 access(req);
  const db=getDB();
  const rows=db.prepare(`SELECT * FROM ai_boq_items WHERE project_id=? ORDER BY created_at,CASE WHEN source_row IS NULL THEN 1 ELSE 0 END,source_sheet,source_row,id`).all(req.params.projectId).map(itemView);
  // Resolve provenance only through the same project's run and document.
  const source=db.prepare(`SELECT i.id AS item_id,i.entity_index,i.entity_type,i.layer_name,i.quantity AS source_quantity,i.unit AS source_unit,i.detail_json,
    r.id AS run_id,r.status AS run_status,r.engine,r.document_id,r.created_at AS run_created_at,
    d.original_name AS document_name,d.file_ext
    FROM ai_takeoff_items i JOIN ai_takeoff_runs r ON r.id=i.run_id
    JOIN ai_documents d ON d.id=r.document_id
    WHERE i.id=? AND r.project_id=? AND d.project_id=?`);
  for(const row of rows){
   if(!row.source_takeoff_item_id)continue;
   const src=source.get(row.source_takeoff_item_id,req.params.projectId,req.params.projectId);
   if(!src)continue;
   let detail={};try{detail=JSON.parse(src.detail_json||'{}');}catch(_){}
   row.sourceReference={
    takeoffItemId:src.item_id,entityIndex:src.entity_index,entityType:src.entity_type,nativeCadLayer:src.layer_name,
    quantity:Number(src.source_quantity),unit:src.source_unit,runId:src.run_id,runStatus:src.run_status,
    engine:src.engine,documentId:src.document_id,documentName:src.document_name,fileExtension:src.file_ext,
    runCreatedAt:src.run_created_at,
    measurement:{method:detail.method||detail.measurementMethod||detail.measurement_method||null,
     ruleId:detail.ruleId||detail.rule_id||null,ruleVersion:detail.ruleVersion||detail.rule_version||null,
     formula:detail.formula||null,inputs:detail.inputs||null,geometry:detail.geometry||null}
   };
  }
 const total=Number(rows.reduce((s,x)=>s+x.line_total,0).toFixed(3));
 res.setHeader('Cache-Control','no-store');
 res.json({items:rows,summary:{itemCount:rows.length,total,missingRates:rows.filter(x=>x.rate_missing).length}});
}));
router.post('/projects/:projectId/boq/from-takeoff',wrap(async(req,res)=>{
 access(req,true);
 const runId=clean(req.body?.runId,100),category=clean(req.body?.category,80),proposalKey=clean(req.body?.proposalKey,100);
 if(!runId||!category||!proposalKey)throw E.validation('معرّف الحصر والتخصص ومفتاح الكمية المقترحة مطلوبة.');
 const db=getDB();
 const run=db.prepare('SELECT id,status,summary_json FROM ai_takeoff_runs WHERE id=? AND project_id=?').get(runId,req.params.projectId);
 if(!run)throw E.notFound('نتيجة الحصر غير موجودة في هذا المشروع.');
 if(run.status!=='approved')throw E.conflict('يجب اعتماد نتيجة الحصر من المراجع قبل ترحيل أي كمية إلى BOQ.');
 let summary;
 try{summary=JSON.parse(run.summary_json||'{}');}catch{throw E.validation('ملخص الحصر غير صالح.');}
 const categoryResult=(summary.quantityProposals?.results||[]).find(x=>x.category===category);
 if(!categoryResult||categoryResult.status!=='proposed')throw E.conflict('هذه الفئة غير مكتملة ولا تحتوي على كمية قابلة للترحيل.');
 const proposal=(categoryResult.proposed||[]).find(x=>x.key===proposalKey);
 if(!proposal||!Number.isFinite(Number(proposal.value))||Number(proposal.value)<0||!proposal.unit)throw E.validation('مفتاح الكمية غير موجود أو لا يحتوي على كمية ووحدة صالحتين.');
 const duplicate=db.prepare('SELECT * FROM ai_boq_items WHERE project_id=? AND source_takeoff_run_id=? AND source_proposal_key=?').get(req.params.projectId,runId,category+':'+proposalKey);
 if(duplicate)throw E.conflict('تم ترحيل هذه الكمية إلى BOQ مسبقاً.');
 const disciplineName=categoryResult.name?.en||categoryResult.discipline||category;
 const label=proposal.label?.en||proposal.label?.ar||proposalKey;
 const description=clean(disciplineName+' - '+label,1000);
 const sourceDetail={category,discipline:categoryResult.discipline,proposal,ruleId:categoryResult.ruleId,formula:categoryResult.formula,method:categoryResult.method,sourceLayers:categoryResult.sourceLayers||[],sourceEntityCount:categoryResult.sourceEntityCount,assumptions:categoryResult.assumptions||[],limitations:categoryResult.limitations||[],reviewState:'approved_run_proposal'};
 const id=uid('aiboq_');
 db.prepare(`INSERT INTO ai_boq_items(id,project_id,item_code,description,unit,quantity,rate,rate_missing,source_takeoff_run_id,source_proposal_key,source_detail_json,created_by)
 VALUES(?,?,?,?,?,?,NULL,1,?,?,?,?)`).run(id,req.params.projectId,null,description,proposal.unit,Number(proposal.value),runId,category+':'+proposalKey,JSON.stringify(sourceDetail),req.user.id);
 audit(db,req,'boq_item_created_from_takeoff',id,{runId,category,proposalKey,quantity:Number(proposal.value),unit:proposal.unit});
 const row=db.prepare('SELECT * FROM ai_boq_items WHERE id=?').get(id);
 res.status(201).json({item:itemView(row),source:{runId,category,proposalKey,detail:sourceDetail},notice:'تم إنشاء بند BOQ بسعر وحدة غير محدد. راجع الوصف والكمية وأدخل السعر بعد مراجعة المهندس.'});
}));
router.post('/projects/:projectId/boq',wrap(async(req,res)=>{
 access(req,true);
 const description=clean(req.body?.description,1000),unit=clean(req.body?.unit,24);
 if(description.length<3||!unit)throw E.validation('وصف البند ووحدته مطلوبان.');
 const quantity=number(req.body?.quantity,'الكمية'),rate=nullableRate(req.body?.rate);
 const code=clean(req.body?.itemCode,80)||null,sourceId=clean(req.body?.sourceTakeoffItemId,100)||null;
 const db=getDB(),id=uid('aiboq_');
 if(sourceId){
  const src=db.prepare(`SELECT i.id,i.quantity,i.unit,i.entity_type,i.layer_name,r.project_id,r.status FROM ai_takeoff_items i JOIN ai_takeoff_runs r ON r.id=i.run_id WHERE i.id=? AND r.project_id=?`).get(sourceId,req.params.projectId);
  if(!src)throw E.notFound('عنصر الحصر المصدر غير موجود في هذا المشروع.');
  if(src.status!=='approved')throw E.conflict('لا يمكن ربط بند BOQ بنتيجة حصر قبل اعتمادها من المراجع.');
  if(Math.abs(Number(src.quantity)-quantity)>Math.max(1e-9,Math.abs(Number(src.quantity))*1e-9)||src.unit!==unit)throw E.validation('كمية ووحدة بند BOQ المرتبط يجب أن تطابقا نتيجة الحصر المعتمدة.');
 }
 db.prepare(`INSERT INTO ai_boq_items(id,project_id,item_code,description,unit,quantity,rate,source_takeoff_item_id,created_by) VALUES(?,?,?,?,?,?,?,?,?)`).run(id,req.params.projectId,code,description,unit,quantity,rate,sourceId,req.user.id);
 audit(db,req,'boq_item_created',id,{quantity,rate,sourceId});
 const row=db.prepare('SELECT * FROM ai_boq_items WHERE id=?').get(id);
 res.status(201).json({item:itemView(row)});
}));
router.patch('/projects/:projectId/boq/:itemId',wrap(async(req,res)=>{
 access(req,true);
 const db=getDB(),old=db.prepare('SELECT * FROM ai_boq_items WHERE id=? AND project_id=?').get(req.params.itemId,req.params.projectId);
 if(!old)throw E.notFound('بند BOQ غير موجود.');
 const description=req.body?.description===undefined?old.description:clean(req.body.description,1000);
 const unit=req.body?.unit===undefined?old.unit:clean(req.body.unit,24);
 if(description.length<3||!unit)throw E.validation('وصف البند ووحدته مطلوبان.');
 const quantity=req.body?.quantity===undefined?old.quantity:number(req.body.quantity,'الكمية');
 const rate=req.body?.rate===undefined?old.rate:nullableRate(req.body.rate);
 if(old.source_takeoff_item_id){
  const src=db.prepare(`SELECT i.quantity,i.unit,r.status FROM ai_takeoff_items i JOIN ai_takeoff_runs r ON r.id=i.run_id WHERE i.id=? AND r.project_id=?`).get(old.source_takeoff_item_id,req.params.projectId);
  if(!src||src.status!=='approved')throw E.conflict('مصدر الحصر المرتبط غير متاح أو لم يعد معتمداً.');
  if(Math.abs(quantity-Number(src.quantity))>Math.max(1e-9,Math.abs(Number(src.quantity))*1e-9)||unit!==src.unit)throw E.validation('لا يمكن تغيير كمية أو وحدة بند مرتبط بحصر معتمد؛ أنشئ بنداً مستقلاً للتعديل.');
 }
 const code=req.body?.itemCode===undefined?old.item_code:(clean(req.body.itemCode,80)||null);
 db.prepare('UPDATE ai_boq_items SET item_code=?,description=?,unit=?,quantity=?,rate=?,rate_missing=?,updated_at=unixepoch() WHERE id=? AND project_id=?').run(code,description,unit,quantity,rate,(rate===null?1:0),old.id,req.params.projectId);
 audit(db,req,'boq_item_updated',old.id,{quantity,rate});
 res.json({item:itemView(db.prepare('SELECT * FROM ai_boq_items WHERE id=?').get(old.id))});
}));
router.delete('/projects/:projectId/boq/:itemId',wrap(async(req,res)=>{
 access(req,true);
 const db=getDB(),old=db.prepare('SELECT id FROM ai_boq_items WHERE id=? AND project_id=?').get(req.params.itemId,req.params.projectId);
 if(!old)throw E.notFound('بند BOQ غير موجود.');
 db.prepare('DELETE FROM ai_boq_items WHERE id=? AND project_id=?').run(old.id,req.params.projectId);
 audit(db,req,'boq_item_deleted',old.id,{});
 res.json({ok:true,id:old.id});
}));


// Spreadsheet import: CSV and XLSX (first non-empty worksheet). Upload is parsed in memory only.
const zlib=require('node:zlib');
function xmlText(s){return String(s||'').replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n))).replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16)));}
function unzipEntries(buf){
 const out={};let eocd=-1;
 for(let i=buf.length-22;i>=Math.max(0,buf.length-65558);i--){if(buf.readUInt32LE(i)===0x06054b50){eocd=i;break;}}
 if(eocd<0)throw E.validation('ملف XLSX غير صالح أو تالف.');
 const count=buf.readUInt16LE(eocd+10),start=buf.readUInt32LE(eocd+16);let p=start;
 for(let i=0;i<count;i++){
  if(buf.readUInt32LE(p)!==0x02014b50)throw E.validation('بنية ملف XLSX غير مدعومة.');
  const method=buf.readUInt16LE(p+10),compressed=buf.readUInt32LE(p+20),nameLen=buf.readUInt16LE(p+28),extraLen=buf.readUInt16LE(p+30),commentLen=buf.readUInt16LE(p+32),local=buf.readUInt32LE(p+42);
  const name=buf.toString('utf8',p+46,p+46+nameLen);const lhName=buf.readUInt16LE(local+26),lhExtra=buf.readUInt16LE(local+28),dataStart=local+30+lhName+lhExtra;
  const raw=buf.subarray(dataStart,dataStart+compressed);
  if(!name.endsWith('/')){if(method===0)out[name]=raw;else if(method===8)out[name]=zlib.inflateRawSync(raw);else throw E.validation('طريقة ضغط XLSX غير مدعومة.');}
  p+=46+nameLen+extraLen+commentLen;
 }
 return out;
}
function parseXlsx(buf){
 const files=unzipEntries(buf),get=n=>files[n]?.toString('utf8')||'';
 const shared=[...get('xl/sharedStrings.xml').matchAll(/<si\b[^>]*>([\s\S]*?)<\/si>/g)].map(m=>[...m[1].matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map(x=>xmlText(x[1])).join(''));
 const wb=get('xl/workbook.xml'),rels=get('xl/_rels/workbook.xml.rels');
 const relation={};for(const m of rels.matchAll(/<Relationship\b([^>]*)\/?>/g)){const a=m[1],id=(a.match(/\bId="([^"]+)"/)||[])[1],target=(a.match(/\bTarget="([^"]+)"/)||[])[1];if(id&&target)relation[id]=target.startsWith('/')?target.slice(1):'xl/'+target.replace(/^\.\//,'');}
 const sheets=[...wb.matchAll(/<sheet\b([^>]*)\/?>/g)].map(m=>({name:(m[1].match(/\bname="([^"]+)"/)||[])[1],rid:(m[1].match(/r:id="([^"]+)"/)||[])[1]}));
 const aliases={
  description:['description','itemdescription','descriptionofitem','workdescription','descriptionofwork','shortdescription','itemdetails','workitem','scope','item','نوعالعمل','نوعالاعمال','نوعالاعمال','نوعالعملالرئيسي','الوصف','وصف','وصفالبند','وصفالاعمال','وصفالعمل','بيان','بيانالاعمال','بيانالعمل','البيان','تفاصيلالبند','تفاصيلالاعمال','اسمالبند','البند','الاعمال'],
  unit:['unit','uom','unitofmeasure','unitofmeasurement','measurementunit','الوحده','الوحدة','وحده','وحدة','وحدهالقياس','وحدةالقياس'],
  quantity:['quantity','qty','quantities','totalquantity','qtym3','qtym2','qtynos','quantitym3','quantitym2','الكميه','الكمية','كميه','كمية','كميهالبند','كميةالبند','العدد','اجماليالكميه','اجماليالكمية','المقدار']
 };
 let best=null,bestScore=0;
 for(const sh of sheets){
  const path=relation[sh.rid];if(!path||!files[path])continue;
  const xml=files[path].toString('utf8'),rows=[];
  for(const rm of xml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)){
   const cells=[];
   for(const cm of rm[1].matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g)){
    const attrs=cm[1],body=cm[2],ref=(attrs.match(/\br="([A-Z]+)\d+"/)||[])[1]||'',type=(attrs.match(/\bt="([^"]+)"/)||[])[1],idx=ref.split('').reduce((n,ch)=>n*26+ch.charCodeAt(0)-64,0)-1;
    let val='';const v=(body.match(/<v>([\s\S]*?)<\/v>/)||[])[1];
    if(type==='s')val=shared[Number(v)]??'';
    else if(type==='inlineStr')val=[...body.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map(x=>xmlText(x[1])).join('');
    else val=v==null?'':xmlText(v);
    cells[idx]=val;
   }
   rows.push(cells);
  }
  if(!rows.some(row=>row.some(v=>String(v??'').trim())))continue;
  let score=0;
  for(const row of rows.slice(0,20)){
   const keys=row.map(headerKey);
   const rowScore=Object.values(aliases).filter(opts=>keys.some(k=>opts.some(a=>headerKey(a)===k))).length;
   score=Math.max(score,rowScore);
  }
  if(!best||score>bestScore){best={sheet:sh.name||'Sheet',rows};bestScore=score;}
  if(score===3)return best;
 }
 if(best)return best;
 throw E.validation('لم يتم العثور على ورقة تحتوي بيانات في ملف XLSX.');
}
function parseCsv(text){
 const first=(text.split(/\r?\n/,1)[0]||''),delim=[',',';','\t'].sort((a,b)=>first.split(b).length-first.split(a).length)[0],rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){const ch=text[i];if(ch==='"'&&quoted&&text[i+1]==='"'){cell+='"';i++;}else if(ch==='"')quoted=!quoted;else if(ch===delim&&!quoted){row.push(cell);cell='';}else if((ch==='\n'||ch==='\r')&&!quoted){if(ch==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(v=>v.trim()))rows.push(row);row=[];cell='';}else cell+=ch;}
 row.push(cell);if(row.some(v=>v.trim()))rows.push(row);return rows;
}
function headerKey(v){
 return String(v||'').normalize('NFKC').toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[^\p{L}\p{N}]/gu,'');
}
function parseBoqNumber(value){
 const digits={'٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9','۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9'};
 const normalized=String(value??'').replace(/[٠-٩۰-۹]/g,ch=>digits[ch]).replace(/[٬،]/g,'').replace(/٫/g,'.').replace(/\s/g,'');
 return normalized===''?NaN:Number(normalized.replace(/,/g,''));
}
function inferDiscipline(description){
 const d=String(description||'').toLowerCase();
 // Classify by the principal deliverable before incidental material references.
 // Order matters: a marble-look MDF cabinet is joinery, not stone; an upholstered sofa is furniture, not painting.
 if(/demolition|dismantling|removal|remove |take down|ceiling removal|هدم|ازاله|إزالة|فك |تفكيك|قص الاسوار|قص الأسوار/.test(d))return 'Demolition & Removal';
 if(/window|windows|glazing|window frame|نوافذ|شبابيك|شباك|اطار الشباك|إطار الشباك|ستائر رول|ستارة رول|ستائر زيبرا|زيبرا/.test(d))return 'Windows & Glazing';
 if(/furniture|sofa|chair|chairs|table|tables|upholster|curtain|roller blind|zebra blind|اثاث|أثاث|كنب|كرسي|كراسي|طاولة|طاولات|ستائر|ستاره|ستارة/.test(d))return 'Furniture & Fixtures';
 if(/cabinet|counter|reception desk|wardrobe|shelves|shelf|خزانة|خزانه|كاونتر|كونتر|رفوف|رف خشبي|خزائن|نجارة|نجاره|m\.?d\.?f|hdf|melamine|ميلامين|فورمايكا|خشب|خشبية|خشبيه/.test(d))return 'Joinery & Cabinetry';
 if(/insulation|insulated panel|foam concrete|polystyrene|thermal|acoustic|عازل حراري|عزل حراري|ألواح عازلة|الواح عازله|فلين|بولسترين|بوليسترين|خرسانة رغوية|خرسانه رغويه/.test(d))return 'Insulation & Wall Systems';
 if(/door|doors|door frame|ابواب|أبواب|باب|حلوق الابواب|حلق باب/.test(d))return 'Doors & Joinery';
 if(/marble|granite|basalt|stone cladding|natural stone|رخام|بازلت|حجر طبيعي|كسوة حجرية|تلبيس حجر/.test(d))return 'Stone & Marble';
 if(/tile|tiling|porcelain|ceramic|flooring|floor finish|ارضيات|أرضيات|بلاط|بورسلان|تبليط|بلاط ارضيات|بلاط أرضيات/.test(d))return 'Flooring & Tiling';
 if(/gypsum|gypsum board|false ceiling|suspended ceiling|drywall|جبس|جبص|جبصم|جبسم|اسقف مستعارة|أسقف مستعارة|سقف مستعار|بانوه|زنانير/.test(d))return 'Gypsum & Ceilings';
 if(/paint|painting|vinyl silk|emulsion|decorative coating|دهان|طلاء|صبغ|معجونة|معجون|دهانات/.test(d))return 'Painting & Finishes';
 if(/geotextile|geosynthetic|hdpe|geomembrane|جيوتكستايل|جيوتكستيل|غشاء بولي|بطانة الحوض|بطانه الحوض|اغشية|أغشية/.test(d))return 'Geosynthetics & Pond Lining';
 if(/riprap|rock armour|stone pitching|دبش|تدبيش|حماية حجرية|حمايه حجريه/.test(d))return 'Riprap & Slope Protection';
 if(/waterproof|water proof|bitumen|damp proof|عزل مائي|مائي|بيتومين|لفائف عزل|دهان عازل/.test(d))return 'Waterproofing';
 if(/landscap|planting|shrubs|flowers|seedlings|garden|irrigation|شجيرات|ازهار|أزهار|اشتال|أشتال|زراعة|زراعه|تربة زراعية|تربه زراعيه|حصى سيل/.test(d))return 'Landscaping';
 if(/signage|sign board|illuminated sign|led sign|ارمة|أرمة|لوحة مضيئة|لوحه مضيئه|يافطة/.test(d))return 'Signage';
 if(/road|pavement|asphalt|roadwork|طريق|طرق|اسفلت|أسفلت|تعبيد/.test(d))return 'Roadworks';
 if(/waste|debris|rubbish|disposal|cart away|مخلفات|نفايات|انقاض|أنقاض|ترحيل/.test(d))return 'Waste Removal';
 if(/inspection|testing|laboratory|third.party|فحص|اختبار|مختبر|ضبط الجودة|ضبط الجوده/.test(d))return 'QA/QC & Testing';
 if(/manpower|labou?r|workforce|عمالة|عماله|عمال|ايدي عامله|أيدي عاملة/.test(d))return 'Manpower';
 if(/equipment|mobilization|mobilisation|excavator|loader|dump truck|crane|معدات|آليات|اليات|حفار|جرافة|جرافه|قلاب/.test(d))return 'Plant & Equipment';
 if(/excavat|backfill|earthwork|earth work|soil|filling|bulk excavation|حفر|ردم|تراب|تسوية|تسويه/.test(d))return 'Earthworks';
 if(/formwork|shuttering|shutter|soffit|form work|نجاره|قوالب/.test(d))return 'Formwork';
 if(/plaster|rendering|render coat|لياسه|قصاره|محاره|قصارة|محارة/.test(d))return 'Plastering';
 if(/masonry|blockwork|brickwork|block wall|brick wall|مباني|طوب|بلوك|بناء جدران|بناء بلوك/.test(d))return 'Masonry';
 if(/railing|balustrade|handrail|metalwork|steelwork|canopy|درابزين|اعمال معدنية|أعمال معدنية/.test(d))return 'Metalwork';
 if(/roof covering|roofing|roof membrane|تسقيف/.test(d))return 'Roofing';
 if(/concrete|\bpcc\b|\brcc\b|footing|column|beam|\bslab\b|stair|blinding|خرسانه|خرسانة|قواعد|اعمده|أعمدة|كمرات|بلاطه|بلاطة/.test(d))return 'Concrete & Structural';
 return null;
}
function normalizeSpreadsheet(rows){
 if(!rows.length)throw E.validation('الملف لا يحتوي صفوفاً.');
 const aliases={
  code:['itemno','itemnumber','itemcode','code','الرقم','رقم','رقمالبند','رقمالفقرة','الكود','رقمالعنصر'],
  description:['description','itemdescription','descriptionofitem','workdescription','descriptionofwork','shortdescription','itemdetails','workitem','scope','item','نوعالعمل','نوعالاعمال','الوصف','وصفالبند','وصفالاعمال','وصفالعمل','بيان','بيانالاعمال','البيان','تفاصيلالبند','اسم البند','اسمالبند','البند'],
  unit:['unit','uom','unitofmeasure','unitofmeasurement','measurementunit','الوحده','الوحدة','وحدهالقياس','وحدةالقياس'],
  quantity:['quantity','qty','quantities','totalquantity','qtym3','qtym2','qtynos','quantitym3','quantitym2','الكميه','الكمية','كميه','كميهالبند','كميةالبند','العدد'],
  rate:['rate','unitrate','price','unitprice','دينار','د.ا','سعرالوحده','سعرالوحدة','سعرالافراد','سعرالإفراد','سعرالافرادي','السعرالافرادي','السعر','سعر'],
  discipline:['discipline','trade','section','التخصص','القسم','البندالرئيسي']
 };
 // Header rows are not always the first row: BOQs often start with a project title or blank lines.
 let headerIndex=-1,headers=[],idx={};
 const scan=Math.min(rows.length,20);
 for(let r=0;r<scan;r++){
  // Many Arabic tender BOQs split the column labels over two adjacent header rows.
  // Merge labels by column from the current row and the two rows immediately above it.
  const width=Math.max(0,...rows.slice(Math.max(0,r-2),r+1).map(x=>x.length));
  const candidate=Array.from({length:width},(_,col)=>{
   for(let rr=r;rr>=Math.max(0,r-2);rr--){
    const key=headerKey(rows[rr]?.[col]??'');
    if(key&&Object.values(aliases).some(opts=>opts.some(a=>headerKey(a)===key)))return key;
   }
   for(let rr=r;rr>=Math.max(0,r-2);rr--){const v=String(rows[rr]?.[col]??'').trim();if(v)return headerKey(v);}
   return '';
  }),found={};
  for(const [key,opts] of Object.entries(aliases))found[key]=candidate.findIndex(h=>opts.some(a=>headerKey(a)===h));
  const score=['description','unit','quantity'].filter(k=>found[k]>=0).length;
  if(score>['description','unit','quantity'].filter(k=>idx[k]>=0).length){headerIndex=r;headers=candidate;idx=found;}
  if(score===3)break;
 }
 if(headerIndex<0||['description','unit','quantity'].some(k=>idx[k]<0))
  throw E.validation('لم أتعرف على أعمدة الوصف والوحدة والكمية. استخدم Description, Unit, Quantity أو: وصف البند، الوحدة، الكمية. تأكد أن عناوين الأعمدة موجودة في أول 20 صفاً.');
 const items=[],errors=[];let ignoredRows=0;
 for(let i=headerIndex+1;i<rows.length;i++){const row=rows[i]||[],get=k=>idx[k]>=0?String(row[idx[k]]??'').trim():'';if(!row.some(v=>String(v??'').trim()))continue;
  const description=get('description'),unit=get('unit'),quantityRaw=get('quantity'),q=parseBoqNumber(quantityRaw),rateRaw=get('rate'),rate=rateRaw===''?0:parseBoqNumber(rateRaw);
  // Ignore section labels, notes and wrapped continuation rows. A numbered BOQ item
  // (for example A\\1 or C/4) remains a validation error if its measurement data is missing.
  const code=get('code'),looksLikeItemCode=/^[A-Z]{1,3}\s*[\\/]\s*\d{1,4}[A-Z]?$/i.test(code)||/^\d+(?:[.\/-]\d+)*$/.test(code)
  if(!unit&&!quantityRaw&&rateRaw===''&&!looksLikeItemCode){ignoredRows++;continue;}
  const err=[];if(description.length<3)err.push('وصف البند مفقود أو قصير');if(!unit)err.push('الوحدة مفقودة');if(!get('quantity')||!Number.isFinite(q)||q<0)err.push('الكمية غير صالحة');if(rateRaw!==''&&(!Number.isFinite(rate)||rate<0))err.push('سعر الوحدة غير صالح');
  if(err.length)errors.push({row:i+1,errors:err});
  else items.push({itemCode:get('code')||null,description,unit,quantity:q,rate,discipline:get('discipline')||inferDiscipline(description),sourceRow:i+1});
 }
 if(!items.length)throw E.validation('لم يتم استخراج أي بنود صالحة من الملف.');
 if(items.length>3000)throw E.validation('الملف يتجاوز الحد المسموح وهو 3,000 بند لكل عملية استيراد.');
 return {items,errors,ignoredRows,headers:rows[headerIndex].map(x=>String(x||'')),headerRow:headerIndex+1,totalRows:rows.length-headerIndex-1};
}
function readBoqUpload(file){
 const name=String(file.originalname||'').toLowerCase(),mime=String(file.mimetype||'');
 if(name.endsWith('.csv')||mime.includes('csv'))return {sheet:'CSV',...normalizeSpreadsheet(parseCsv(file.buffer.toString('utf8').replace(/^\uFEFF/,'')))};
 if(name.endsWith('.xlsx')||mime.includes('spreadsheetml')){const parsed=parseXlsx(file.buffer);return {sheet:parsed.sheet,...normalizeSpreadsheet(parsed.rows)};}
 throw E.validation('الصيغ المدعومة حالياً: XLSX وCSV فقط.');
}
router.post('/projects/:projectId/boq/import-preview',importUpload.single('file'),wrap(async(req,res)=>{
 access(req,true);if(!req.file)throw E.validation('اختر ملف Excel أو CSV أولاً.');
 const parsed=readBoqUpload(req.file);
 res.setHeader('Cache-Control','no-store');
 res.json({filename:req.file.originalname,sheet:parsed.sheet,headers:parsed.headers,totalRows:parsed.totalRows,validCount:parsed.items.length,errorCount:parsed.errors.length,ignoredRows:parsed.ignoredRows,errors:parsed.errors,items:parsed.items,pricedCount:parsed.items.filter(x=>x.rate>0).length,unpricedCount:parsed.items.filter(x=>x.rate===0).length});
}));
router.post('/projects/:projectId/boq/import',wrap(async(req,res)=>{
 access(req,true);const items=req.body?.items;
 if(!Array.isArray(items)||!items.length||items.length>3000)throw E.validation('قائمة الاستيراد غير صالحة أو تتجاوز 3,000 بند في العملية الواحدة.');
 const seen=new Set(),cleaned=items.map((x,i)=>{
  const description=clean(x.description,1000),unit=clean(x.unit,24),quantity=number(x.quantity,'الكمية'),rate=number(x.rate??0,'سعر الوحدة'),itemCode=clean(x.itemCode,80)||null;
  if(description.length<3||!unit)throw E.validation('يوجد بند بلا وصف أو وحدة في الصف '+(x.sourceRow||i+1)+'.');
  const key=itemCode?itemCode.toLowerCase():null;if(key&&seen.has(key))throw E.validation('رقم البند مكرر داخل الملف: '+itemCode);if(key)seen.add(key);
  return {description,unit,quantity,rate,itemCode,sourceRow:Number(x.sourceRow)||i+1,discipline:clean(x.discipline,80)||null};
 });
 const db=getDB(),insert=db.prepare('INSERT INTO ai_boq_items(id,project_id,item_code,discipline,description,unit,quantity,rate,source_takeoff_item_id,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)');
 const auditInsert=db.prepare('INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)');
 const transaction=db.transaction(()=>{for(const x of cleaned){const id=uid('aiboq_');insert.run(id,req.params.projectId,x.itemCode,x.discipline,x.description,x.unit,x.quantity,x.rate,null,req.user.id);auditInsert.run(uid('aial_'),req.params.projectId,req.user.id,'boq_item_imported','boq_item',id,JSON.stringify({sourceRow:x.sourceRow,discipline:x.discipline,rateProvided:x.rate>0}));}});
 transaction();
 const total=Number(cleaned.reduce((s,x)=>s+x.quantity*x.rate,0).toFixed(3));
 res.status(201).json({ok:true,imported:cleaned.length,priced:cleaned.filter(x=>x.rate>0).length,unpriced:cleaned.filter(x=>x.rate===0).length,total});
}));

// Public, isolated BOQ sandbox: parses a spreadsheet in memory without login or project access.
// Nothing is persisted; this endpoint cannot read or modify private project records.
publicRouter.post('/public-boq-preview',importUpload.single('file'),wrap(async(req,res)=>{
 if(!req.file)throw E.validation('اختر ملف XLSX أو CSV أولاً.');
 const parsed=readBoqUpload(req.file);
 const priced=parsed.items.filter(x=>x.rate>0),unpriced=parsed.items.filter(x=>x.rate===0);
 const knownTotal=Number(parsed.items.reduce((s,x)=>s+x.quantity*x.rate,0).toFixed(3));
 const disciplines=Object.entries(parsed.items.reduce((a,x)=>{const k=x.discipline||'غير مصنف';a[k]=(a[k]||0)+1;return a;},{})).map(([discipline,count])=>({discipline,count}));
 res.setHeader('Cache-Control','no-store');
 res.json({mode:'public_preview_only',persisted:false,filename:req.file.originalname,sheet:parsed.sheet,totalRows:parsed.totalRows,items:parsed.items,errors:parsed.errors,summary:{itemCount:parsed.items.length,pricedCount:priced.length,unpricedCount:unpriced.length,knownPricedTotal:knownTotal,ignoredRows:parsed.ignoredRows,disciplineBreakdown:disciplines},scheduleCandidates:parsed.items.map((x,i)=>({sequence:i+1,code:x.itemCode,activity:x.description,discipline:x.discipline||null,quantity:x.quantity,unit:x.unit,durationDays:null,status:'requires_productivity_resources_and_logic'})),riskSignals:[...(unpriced.length?[{type:'missing_unit_rates',count:unpriced.length,severity:'commercial_input_required'}]:[]),...(parsed.items.some(x=>!x.discipline)?[{type:'unclassified_discipline',count:parsed.items.filter(x=>!x.discipline).length,severity:'classification_required'}]:[]),...(parsed.errors.length?[{type:'invalid_rows',count:parsed.errors.length,severity:'data_quality'}]:[])]});
}));


module.exports={router,publicRouter,_test:{inferDiscipline,parseBoqNumber}};
