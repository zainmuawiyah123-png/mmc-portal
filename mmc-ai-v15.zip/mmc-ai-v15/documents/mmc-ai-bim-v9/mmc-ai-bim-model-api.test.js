'use strict';
/**
 * BIM model API test: build -> measure -> export IFC -> import IFC -> approve,
 * exercised through the real HTTP routes with real authentication.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mmc-ai-bim-api-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json';
process.env.DB_PATH = path.join(TMP, 'test.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false';
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'mmc-ai-bim-api-test-secret';
process.env.BCRYPT_ROUNDS = '4';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { closeDB } = require('../src/db');

let server, base;
const jar = {};

async function call(user, method, url, body) {
  const headers = { ...(jar[user] ? { Cookie: jar[user] } : {}) };
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) jar[user] = first;
  }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data, headers: r.headers };
}

const uniq = () => Math.random().toString(36).slice(2, 10);

async function register(key) {
  const email = key + uniq() + '@test.local';
  const r = await call(key, 'POST', '/api/auth/register', { name: key, email, password: 'Password123', company: key });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const db = require('../src/db').getDB();
  const user = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now, user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);
  const login = await call(key, 'POST', '/api/auth/login', { email, password: 'Password123' });
  assert.equal(login.status, 200, JSON.stringify(login.data));
  return user.id;
}

function sampleModel() {
  return {
    name: 'API test building',
    storeys: [
      { id: 'GF', name: 'Ground Floor', elevation: 0 },
      { id: 'FF', name: 'First Floor', elevation: 3.2 }
    ],
    elements: [
      { id: 'F1', type: 'footing', storeyId: 'GF', origin: { x: 0, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6, properties: { concreteGrade: 'C30/37' } },
      { id: 'F2', type: 'footing', storeyId: 'GF', origin: { x: 5, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'C1', type: 'column', storeyId: 'GF', origin: { x: 0, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'C2', type: 'column', storeyId: 'GF', origin: { x: 5, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'S1', type: 'slab', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0 }, length: 5, width: 4, height: 0.25 },
      { id: 'W1', type: 'wall', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0.25 }, length: 5, width: 0.2, height: 3.2, properties: { wallType: 'external' } },
      { id: 'O1', type: 'opening', storeyId: 'GF', hostId: 'W1', origin: { x: 1.5, y: 0, z: 1.15 }, length: 1.2, width: 0.2, height: 1.5, sillHeight: 0.9 },
      { id: 'B1', type: 'beam', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 3.2 }, length: 5, width: 0.3, height: 0.5 }
    ]
  };
}

test.before(async () => {
  migrate();
  const app = createApp();
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = 'http://127.0.0.1:' + server.address().port;
});

test.after(async () => {
  if (server) await new Promise((r) => server.close(r));
  closeDB();
  fs.rmSync(TMP, { recursive: true, force: true });
});

test('builds a model through the API and measures quantities from its geometry', async () => {
  const owner = await register('owner');
  const proj = await call('owner', 'POST', '/api/mmc-ai/projects', { name: 'BIM API project' });
  assert.equal(proj.status, 201, JSON.stringify(proj.data));
  const projectId = proj.data.project.project_id;

  const built = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, {
    model: sampleModel(), revision: 'A'
  });
  assert.equal(built.status, 201, JSON.stringify(built.data));
  const model = built.data.model;
  assert.equal(model.elementCount, 8);
  assert.equal(model.source, 'built');
  assert.equal(model.status, 'needs_review');
  assert.equal(model.storeyCount, 2);
  assert.equal(model.countsByType.wall, 1);
  assert.equal(model.countsByType.opening, 1);
  assert.ok(model.bbox.size.x > 0);

  const byRule = Object.fromEntries(built.data.quantities.map((q) => [q.ruleId, q]));
  // Wall net area: 5 x 3.2 - (1.2 x 1.5) = 16 - 1.8 = 14.2
  assert.equal(byRule['Q-WALL-NET-AREA'].quantity, 14.2);
  assert.equal(byRule['Q-WALL-NET-AREA'].unit, 'm2');
  // Column volume: 2 x (0.4 x 0.4 x 3.2) = 1.024
  assert.equal(byRule['Q-COLUMN-VOLUME'].quantity, 1.024);
  assert.equal(byRule['Q-COLUMN-COUNT'].quantity, 2);
  // Footing volume: 2 x (1.5 x 1.5 x 0.6) = 2.7
  assert.equal(byRule['Q-FOOTING-VOLUME'].quantity, 2.7);
  // Slab: area 20, volume 5
  assert.equal(byRule['Q-SLAB-AREA'].quantity, 20);
  assert.equal(byRule['Q-SLAB-VOLUME'].quantity, 5);
  // Beam volume: 5 x 0.3 x 0.5 = 0.75
  assert.equal(byRule['Q-BEAM-VOLUME'].quantity, 0.75);
  assert.equal(byRule['Q-OPENING-COUNT'].quantity, 1);
  assert.equal(byRule['Q-OPENING-AREA'].quantity, 1.8);

  // Every quantity is proposed, never approved, and carries its evidence.
  for (const q of built.data.quantities) {
    assert.equal(q.reviewState, 'measured_ready_for_review');
    assert.equal(q.measurementBasis, 'bim_model_geometry');
    assert.ok(q.elementIds.length > 0);
    assert.ok(q.formula.length > 0);
    assert.ok(q.descriptionAr);
  }
  assert.equal(built.data.totalsByUnit.m2, 14.2 + 20 + 1.8);
  // m3: wall net 2.84 + column 1.024 + footing 2.7 + slab 5 + beam 0.75
  assert.equal(built.data.totalsByUnit.m3, 12.314);

  // The model is retrievable with its elements and quantities.
  const detail = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${model.id}`);
  assert.equal(detail.status, 200);
  assert.equal(detail.data.elements.length, 8);
  assert.equal(detail.data.quantities.length, built.data.quantities.length);
  const wall = detail.data.elements.find((e) => e.id === 'W1');
  assert.equal(wall.type, 'wall');
  assert.equal(wall.properties.wallType, 'external');
  const opening = detail.data.elements.find((e) => e.id === 'O1');
  assert.equal(opening.hostId, 'W1');

  // Listing shows the model.
  const list = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model`);
  assert.equal(list.status, 200);
  assert.equal(list.data.summary.total, 1);
  assert.equal(list.data.summary.built, 1);
});

test('exports IFC and re-imports it, preserving quantities', async () => {
  const owner = await register('owner2');
  const proj = await call('owner2', 'POST', '/api/mmc-ai/projects', { name: 'IFC round trip' });
  const projectId = proj.data.project.project_id;

  const built = await call('owner2', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  assert.equal(built.status, 201, JSON.stringify(built.data));
  const modelId = built.data.model.id;
  const before = Object.fromEntries(built.data.quantities.map((q) => [q.ruleId, q.quantity]));

  // Download the IFC export.
  const ifcRes = await fetch(base + `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/ifc`, {
    headers: { Cookie: jar.owner2 }
  });
  assert.equal(ifcRes.status, 200);
  assert.match(ifcRes.headers.get('content-type') || '', /step/);
  const ifcText = await ifcRes.text();
  assert.match(ifcText, /^ISO-10303-21;/);
  assert.match(ifcText, /FILE_SCHEMA\(\('IFC4'\)\)/);
  assert.match(ifcText, /IFCELEMENTQUANTITY/);
  assert.match(ifcText, /IFCPROPERTYSET/);
  assert.match(ifcText, /IFCRELVOIDSELEMENT/);
  assert.match(ifcText, /END-ISO-10303-21;\s*$/);

  // Re-import the exported file as a new model.
  const form = new FormData();
  form.append('file', new Blob([ifcText]), 'roundtrip.ifc');
  form.append('name', 'Reimported model');
  const impRes = await fetch(base + `/api/mmc-ai/projects/${projectId}/bim/model/import`, {
    method: 'POST', headers: { Cookie: jar.owner2 }, body: form
  });
  const imported = await impRes.json();
  assert.equal(impRes.status, 201, JSON.stringify(imported));
  assert.equal(imported.model.source, 'ifc_import');
  assert.equal(imported.model.elementCount, 8);
  assert.equal(imported.importReport.schema, 'IFC4');
  assert.equal(imported.importReport.skippedCount, 0);

  const after = Object.fromEntries(imported.quantities.map((q) => [q.ruleId, q.quantity]));
  for (const rule of ['Q-COLUMN-VOLUME', 'Q-COLUMN-COUNT', 'Q-FOOTING-VOLUME', 'Q-SLAB-AREA',
    'Q-SLAB-VOLUME', 'Q-BEAM-VOLUME', 'Q-WALL-LENGTH', 'Q-OPENING-COUNT', 'Q-OPENING-AREA']) {
    assert.ok(rule in before, 'before has ' + rule);
    assert.ok(rule in after, 'after has ' + rule);
    assert.ok(Math.abs(before[rule] - after[rule]) < 1e-6, `${rule}: ${before[rule]} != ${after[rule]}`);
  }

  // The imported model is listed as an import.
  const list = await call('owner2', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model`);
  assert.equal(list.data.summary.imported, 1);
  assert.equal(list.data.summary.built, 1);
});

test('rejects a malformed IFC import with a clear message', async () => {
  const owner = await register('owner3');
  const proj = await call('owner3', 'POST', '/api/mmc-ai/projects', { name: 'Bad IFC' });
  const projectId = proj.data.project.project_id;

  const form = new FormData();
  form.append('file', new Blob(['this is not an IFC file at all']), 'bad.ifc');
  const res = await fetch(base + `/api/mmc-ai/projects/${projectId}/bim/model/import`, {
    method: 'POST', headers: { Cookie: jar.owner3 }, body: form
  });
  const data = await res.json();
  assert.equal(res.status, 422, JSON.stringify(data));
  assert.match(JSON.stringify(data), /IFC/);

  // A non-IFC extension is refused before reading.
  const form2 = new FormData();
  form2.append('file', new Blob(['x']), 'drawing.dwg');
  const res2 = await fetch(base + `/api/mmc-ai/projects/${projectId}/bim/model/import`, {
    method: 'POST', headers: { Cookie: jar.owner3 }, body: form2
  });
  assert.equal(res2.status, 422);
});

test('rejects an invalid model specification instead of guessing', async () => {
  const owner = await register('owner4');
  const proj = await call('owner4', 'POST', '/api/mmc-ai/projects', { name: 'Bad model' });
  const projectId = proj.data.project.project_id;

  const empty = await call('owner4', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, {
    model: { name: 'empty', elements: [] }
  });
  assert.equal(empty.status, 422);

  const badType = await call('owner4', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, {
    model: { name: 'x', elements: [{ type: 'sofa', length: 1, width: 1, height: 1 }] }
  });
  assert.equal(badType.status, 422);

  const badOpening = await call('owner4', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, {
    model: {
      name: 'x',
      elements: [
        { id: 'W', type: 'wall', length: 2, width: 0.2, height: 3 },
        { id: 'O', type: 'opening', hostId: 'W', length: 5, width: 0.2, height: 1 }
      ]
    }
  });
  assert.equal(badOpening.status, 422);
});

test('approval records who approved and when, and is restricted by role', async () => {
  const owner = await register('owner5');
  const proj = await call('owner5', 'POST', '/api/mmc-ai/projects', { name: 'Approval' });
  const projectId = proj.data.project.project_id;
  const built = await call('owner5', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  const modelId = built.data.model.id;

  // A viewer cannot approve.
  const viewer = await register('viewer5');
  const db = require('../src/db').getDB();
  db.prepare('INSERT INTO ai_project_members(project_id,user_id,role) VALUES(?,?,?)').run(projectId, viewer, 'viewer');
  const denied = await call('viewer5', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/approve`, {});
  assert.equal(denied.status, 403, JSON.stringify(denied.data));

  // The owner can.
  const ok = await call('owner5', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/approve`, {});
  assert.equal(ok.status, 200, JSON.stringify(ok.data));
  assert.equal(ok.data.model.status, 'approved');
  for (const q of ok.data.quantities) {
    assert.equal(q.reviewState, 'approved');
    assert.ok(q.approvedBy, 'approver recorded');
    assert.ok(q.approvedAt > 0, 'approval time recorded');
  }
});

test('a non-member cannot read or build a model in someone else\'s project', async () => {
  const owner = await register('owner6');
  const proj = await call('owner6', 'POST', '/api/mmc-ai/projects', { name: 'Private' });
  const projectId = proj.data.project.project_id;
  const built = await call('owner6', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  const modelId = built.data.model.id;

  await register('outsider6');
  const read = await call('outsider6', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}`);
  assert.equal(read.status, 404);
  const build = await call('outsider6', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  assert.equal(build.status, 404);
  const ifc = await call('outsider6', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/ifc`);
  assert.equal(ifc.status, 404);
});

test('exposes the element vocabulary and quantity rules', async () => {
  const owner = await register('owner7');
  const proj = await call('owner7', 'POST', '/api/mmc-ai/projects', { name: 'Vocabulary' });
  const projectId = proj.data.project.project_id;
  const res = await call('owner7', 'GET', `/api/mmc-ai/projects/${projectId}/bim/element-types`);
  assert.equal(res.status, 200);
  const types = res.data.elementTypes.map((t) => t.type);
  for (const t of ['wall', 'column', 'footing', 'slab', 'beam', 'opening']) {
    assert.ok(types.includes(t), 'vocabulary has ' + t);
  }
  for (const r of res.data.quantityRules) {
    assert.ok(['m', 'm2', 'm3', 'nr'].includes(r.unit), r.id + ' unit');
    assert.ok(r.label.ar && r.label.en, r.id + ' bilingual');
  }
});

test('produces canonical BOQ records from a stored model', async () => {
  const owner = await register('owner8');
  const proj = await call('owner8', 'POST', '/api/mmc-ai/projects', { name: 'BOQ records' });
  const projectId = proj.data.project.project_id;
  const built = await call('owner8', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  const modelId = built.data.model.id;

  const res = await call('owner8', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-records`);
  assert.equal(res.status, 200);
  assert.ok(res.data.recordCount > 0);
  for (const r of res.data.records) {
    assert.equal(r.derivation.method, 'bim_element_takeoff');
    assert.ok(r.derivation.ruleId);
    assert.ok(r.derivation.formula);
    assert.ok(r.derivation.inputs.length > 0);
    assert.ok(r.sources.length > 0);
    assert.equal(r.reviewState, 'measured_ready_for_review');
  }
  // The existing BOQ compiler accepts them.
  const { compileBoq } = require('../src/lib/mmc-ai/boq-compiler');
  const boq = compileBoq(res.data.records, { includeStates: ['measured_ready_for_review'] });
  assert.equal(boq.status, 'boq_draft');
  assert.ok(boq.itemCount > 0);
});
