'use strict';
/**
 * Real-project proof: DXF drawing -> BIM model -> quantities -> IFC -> re-import.
 *
 * Reads the project's own architectural DXF fixture, reconstructs wall elements
 * from the A-WALLS layer geometry, adds the structural frame implied by the
 * drawing's grid, builds a BIM model, measures it, exports IFC4, re-imports the
 * exported file and compares the quantities.
 *
 * Run: node scripts/bim-real-project-proof.js
 * Writes: proof/bim-real-project/{model.json,quantities.json,model.ifc,report.json}
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const { takeoffDxf } = require('../src/lib/mmc-ai/dxf-takeoff');
const { buildModel, measureModel } = require('../src/lib/mmc-ai/bim-model');
const { writeIfc } = require('../src/lib/mmc-ai/ifc-writer');
const { importIfc } = require('../src/lib/mmc-ai/ifc-importer');

const OUT = path.join(__dirname, '..', 'proof', 'bim-real-project');
fs.mkdirSync(OUT, { recursive: true });

const dxfPath = path.join(__dirname, '..', 'tests', 'fixtures', 'synthetic-architectural-sample.dxf');
const dxfText = fs.readFileSync(dxfPath, 'utf8');
const takeoff = takeoffDxf(dxfText, {});

// ---- 1. Reconstruct walls from the drawing's A-WALLS lines ----
const wallLines = takeoff.rows.filter((i) => i.layer === 'A-WALLS' && i.geometry.type === 'LINE');
const WALL_THICKNESS = 0.2;
const WALL_HEIGHT = 3.0;

const elements = [];
let wallNo = 0;
for (const item of wallLines) {
  const { start, end } = item.geometry;
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const length = Math.hypot(dx, dy);
  if (!(length > 0.05)) continue;
  wallNo += 1;
  const rotationDeg = (Math.atan2(dy, dx) * 180) / Math.PI;
  elements.push({
    id: `W${wallNo}`,
    type: 'wall',
    name: `Wall W${wallNo} (from A-WALLS)`,
    storeyId: 'GF',
    origin: { x: (start.x + end.x) / 2, y: (start.y + end.y) / 2, z: 0 },
    length: Number(length.toFixed(4)),
    width: WALL_THICKNESS,
    height: WALL_HEIGHT,
    rotationDeg: Number(rotationDeg.toFixed(4)),
    properties: { sourceLayer: 'A-WALLS', sourceEntity: item.entity, drawingUnit: 'm' }
  });
}

// ---- 2. Openings from the drawing's A-WINDOWS polylines ----
const windowPolys = takeoff.rows.filter((i) => i.layer === 'A-WINDOWS' && i.geometry.type === 'LWPOLYLINE');
let openNo = 0;
for (const item of windowPolys) {
  const vs = item.geometry.vertices;
  if (!vs || vs.length < 3) continue;
  const xs = vs.map((v) => v.x);
  const ys = vs.map((v) => v.y);
  const w = Math.max(...xs) - Math.min(...xs);
  const h = Math.max(...ys) - Math.min(...ys);
  if (!(w > 0.1)) continue;
  openNo += 1;
  // Host the window in the nearest wall by centre distance.
  const cx = (Math.max(...xs) + Math.min(...xs)) / 2;
  const cy = (Math.max(...ys) + Math.min(...ys)) / 2;
  let best = null;
  let bestD = Infinity;
  for (const wl of elements) {
    if (wl.type !== 'wall') continue;
    const d = Math.hypot(wl.origin.x - cx, wl.origin.y - cy);
    if (d < bestD) { bestD = d; best = wl; }
  }
  if (!best) continue;
  elements.push({
    id: `O${openNo}`,
    type: 'opening',
    name: `Window O${openNo} (from A-WINDOWS)`,
    storeyId: 'GF',
    hostId: best.id,
    origin: { x: cx, y: cy, z: 0.9 },
    length: Number(w.toFixed(4)),
    width: WALL_THICKNESS,
    height: Number(Math.max(h, 1.2).toFixed(4)),
    sillHeight: 0.9,
    properties: { sourceLayer: 'A-WINDOWS', sourceEntity: item.entity }
  });
}

// ---- 3. Structural frame on the drawing's 8 x 6 m grid ----
const gridX = [0, 4, 8];
const gridY = [0, 3, 6];
let colNo = 0;
let footNo = 0;
for (const x of gridX) {
  for (const y of gridY) {
    colNo += 1;
    footNo += 1;
    elements.push({
      id: `C${colNo}`, type: 'column', name: `Column C${colNo}`, storeyId: 'GF',
      origin: { x, y, z: 0 }, length: 0.3, width: 0.3, height: WALL_HEIGHT,
      properties: { concreteGrade: 'C30/37', gridRef: `${x}/${y}` }
    });
    elements.push({
      id: `F${footNo}`, type: 'footing', name: `Pad footing F${footNo}`, storeyId: 'GF',
      origin: { x, y, z: -0.6 }, length: 1.2, width: 1.2, height: 0.6,
      properties: { concreteGrade: 'C30/37', gridRef: `${x}/${y}` }
    });
  }
}
// Ground slab over the 8 x 6 m footprint
elements.push({
  id: 'S1', type: 'slab', name: 'Ground slab', storeyId: 'GF',
  origin: { x: 4, y: 3, z: 0 }, length: 8, width: 6, height: 0.2,
  properties: { concreteGrade: 'C25/30' }
});
// Ring beams at roof level
elements.push({
  id: 'B1', type: 'beam', name: 'Beam B1 (south)', storeyId: 'GF',
  origin: { x: 4, y: 0, z: WALL_HEIGHT }, length: 8, width: 0.3, height: 0.5,
  properties: { concreteGrade: 'C30/37' }
});
elements.push({
  id: 'B2', type: 'beam', name: 'Beam B2 (north)', storeyId: 'GF',
  origin: { x: 4, y: 6, z: WALL_HEIGHT }, length: 8, width: 0.3, height: 0.5,
  properties: { concreteGrade: 'C30/37' }
});

const spec = {
  name: 'Real DXF reconstruction — 8x6 m single storey',
  projectId: 'proof-project',
  storeys: [{ id: 'GF', name: 'Ground Floor', elevation: 0 }],
  elements
};

// ---- 4. Build, measure, export, re-import ----
const model = buildModel(spec);
const measurement = measureModel(model, { modelId: 'proof-model', projectId: 'proof-project', revision: 'A' });
const { text: ifcText, stats: ifcStats } = writeIfc(model, {
  projectName: 'Real DXF reconstruction',
  author: 'MMC AI BIM engine',
  organization: 'MMC Construction Intelligence'
});
const reimported = importIfc(ifcText, { name: 'Reimported proof model', projectId: 'proof-project' });
const remeasure = measureModel(reimported.model, { modelId: 'proof-model', projectId: 'proof-project', revision: 'A' });

const before = Object.fromEntries(measurement.rows.map((r) => [r.ruleId, r.quantity]));
const after = Object.fromEntries(remeasure.rows.map((r) => [r.ruleId, r.quantity]));
const comparison = Object.keys(before).map((rule) => ({
  ruleId: rule,
  unit: measurement.rows.find((r) => r.ruleId === rule).unit,
  before: before[rule],
  after: after[rule] ?? null,
  delta: after[rule] === undefined ? null : Number((after[rule] - before[rule]).toFixed(9)),
  match: after[rule] !== undefined && Math.abs(after[rule] - before[rule]) < 1e-6
}));

const report = {
  generatedAt: new Date().toISOString(),
  source: {
    drawing: path.relative(path.join(__dirname, '..'), dxfPath),
    drawingUnits: takeoff.units.metresPerUnit,
    dxfEntities: takeoff.rows.length,
    wallLinesUsed: wallLines.length,
    windowPolylinesUsed: windowPolys.length
  },
  model: {
    name: model.name,
    storeys: model.storeys.length,
    elements: model.elementCount,
    countsByType: model.countsByType,
    bbox: model.bbox
  },
  quantities: measurement.rows.map((r) => ({
    ruleId: r.ruleId, elementType: r.elementType, unit: r.unit,
    quantity: r.quantity, formula: r.formula, elementCount: r.elementCount,
    description: r.description, descriptionAr: r.descriptionAr
  })),
  totalsByUnit: measurement.totalsByUnit,
  ifc: {
    schema: ifcStats.schema,
    entityCount: ifcStats.entityCount,
    elementCount: ifcStats.elementCount,
    openingCount: ifcStats.openingCount,
    bytes: Buffer.byteLength(ifcText),
    sha256: crypto.createHash('sha256').update(ifcText).digest('hex')
  },
  roundTrip: {
    importedElements: reimported.report.importedElementCount,
    skipped: reimported.report.skippedCount,
    comparison,
    allMatched: comparison.every((c) => c.match)
  }
};

fs.writeFileSync(path.join(OUT, 'model.json'), JSON.stringify(model, null, 2));
fs.writeFileSync(path.join(OUT, 'quantities.json'), JSON.stringify({
  modelId: 'proof-model', totalsByUnit: measurement.totalsByUnit, rows: measurement.rows
}, null, 2));
fs.writeFileSync(path.join(OUT, 'model.ifc'), ifcText);
fs.writeFileSync(path.join(OUT, 'report.json'), JSON.stringify(report, null, 2));

console.log('=== REAL PROJECT PROOF ===');
console.log('DXF entities:', takeoff.rows.length, '| walls:', wallLines.length, '| windows:', windowPolys.length);
console.log('Model elements:', model.elementCount, JSON.stringify(model.countsByType));
console.log('Quantities:', measurement.rows.length, 'rows');
for (const r of measurement.rows) console.log(`  ${r.ruleId.padEnd(22)} ${String(r.quantity).padStart(10)} ${r.unit}`);
console.log('IFC:', ifcStats.schema, ifcStats.entityCount, 'entities,', Buffer.byteLength(ifcText), 'bytes');
console.log('Round trip: imported', reimported.report.importedElementCount, 'elements, skipped', reimported.report.skippedCount);
console.log('All quantities matched:', report.roundTrip.allMatched);
if (!report.roundTrip.allMatched) {
  for (const c of comparison.filter((x) => !x.match)) console.log('  MISMATCH', c.ruleId, c.before, '->', c.after);
  process.exitCode = 1;
}
console.log('Written to', path.relative(process.cwd(), OUT));
