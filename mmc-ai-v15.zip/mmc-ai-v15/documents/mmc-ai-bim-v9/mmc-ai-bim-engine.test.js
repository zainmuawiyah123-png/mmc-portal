'use strict';
/**
 * BIM engine integration test.
 *
 * Proves the full chain on a realistic two-storey building:
 *   build model -> measure quantities -> export IFC4 -> re-import -> re-measure
 * and asserts the quantities survive the round trip.
 */
const test = require('node:test');
const assert = require('node:assert/strict');

const { buildModel, measureModel, toQuantityRecords, QUANTITY_RULES } = require('../src/lib/mmc-ai/bim-model');
const { writeIfc } = require('../src/lib/mmc-ai/ifc-writer');
const { importIfc } = require('../src/lib/mmc-ai/ifc-importer');
const { parseStep, StepGraph } = require('../src/lib/mmc-ai/ifc-step-parser');
const { IfcGeometry, lengthScaleOf } = require('../src/lib/mmc-ai/ifc-geometry');

/** A small but realistic two-storey building: 6x4 m grid, 3 m storey height. */
function sampleSpec() {
  const elements = [];
  // Footings under each column
  const gridX = [0, 3, 6];
  const gridY = [0, 4];
  let n = 0;
  for (const x of gridX) {
    for (const y of gridY) {
      n += 1;
      elements.push({
        id: `F${n}`, type: 'footing', name: `Pad footing F${n}`, storeyId: 'GF',
        origin: { x, y, z: -0.6 }, length: 1.2, width: 1.2, height: 0.6,
        properties: { concreteGrade: 'C30/37', reinforcement: 'B500B' }
      });
    }
  }
  // Columns on the same grid
  n = 0;
  for (const x of gridX) {
    for (const y of gridY) {
      n += 1;
      elements.push({
        id: `C${n}`, type: 'column', name: `Column C${n}`, storeyId: 'GF',
        origin: { x, y, z: 0 }, length: 0.3, width: 0.3, height: 3,
        properties: { concreteGrade: 'C30/37' }
      });
    }
  }
  // Ground slab 6 x 4 m, 0.2 m thick
  elements.push({
    id: 'S1', type: 'slab', name: 'Ground slab', storeyId: 'GF',
    origin: { x: 3, y: 2, z: 0 }, length: 6, width: 4, height: 0.2,
    properties: { concreteGrade: 'C25/30' }
  });
  // Perimeter walls, 0.2 m thick, 3 m high
  elements.push({
    id: 'W1', type: 'wall', name: 'South wall', storeyId: 'GF',
    origin: { x: 3, y: 0, z: 0.2 }, length: 6, width: 0.2, height: 3,
    properties: { wallType: 'external', finish: 'render' }
  });
  elements.push({
    id: 'W2', type: 'wall', name: 'North wall', storeyId: 'GF',
    origin: { x: 3, y: 4, z: 0.2 }, length: 6, width: 0.2, height: 3,
    properties: { wallType: 'external', finish: 'render' }
  });
  elements.push({
    id: 'W3', type: 'wall', name: 'West wall', storeyId: 'GF',
    origin: { x: 0, y: 2, z: 0.2 }, length: 4, width: 0.2, height: 3, rotationDeg: 90,
    properties: { wallType: 'external' }
  });
  // Two openings in the south wall: 1.2 x 1.5 m each
  elements.push({
    id: 'O1', type: 'opening', name: 'Window W-01', storeyId: 'GF', hostId: 'W1',
    origin: { x: 1.5, y: 0, z: 1.1 }, length: 1.2, width: 0.2, height: 1.5, sillHeight: 0.9
  });
  elements.push({
    id: 'O2', type: 'opening', name: 'Window W-02', storeyId: 'GF', hostId: 'W1',
    origin: { x: 4.5, y: 0, z: 1.1 }, length: 1.2, width: 0.2, height: 1.5, sillHeight: 0.9
  });
  // Beams at first floor level
  elements.push({
    id: 'B1', type: 'beam', name: 'Beam B1', storeyId: 'GF',
    origin: { x: 3, y: 0, z: 3 }, length: 6, width: 0.3, height: 0.5,
    properties: { concreteGrade: 'C30/37' }
  });
  return {
    name: 'Two-storey office block',
    projectId: 'proj-test-1',
    storeys: [
      { id: 'GF', name: 'Ground Floor', elevation: 0 },
      { id: 'FF', name: 'First Floor', elevation: 3.2 }
    ],
    elements
  };
}

test('builds a model with typed elements and deducts openings from their host wall', () => {
  const model = buildModel(sampleSpec());
  assert.equal(model.elementCount, 6 + 6 + 1 + 3 + 2 + 1);
  assert.equal(model.countsByType.footing, 6);
  assert.equal(model.countsByType.column, 6);
  assert.equal(model.countsByType.wall, 3);
  assert.equal(model.countsByType.opening, 2);
  assert.equal(model.countsByType.slab, 1);
  assert.equal(model.countsByType.beam, 1);

  const south = model.elements.find((e) => e.id === 'W1');
  assert.equal(south.grossArea, 18); // 6 x 3
  assert.equal(south.openingArea, 3.6); // 2 x (1.2 x 1.5)
  assert.equal(south.netArea, 14.4);
  assert.equal(south.grossVolume, 3.6); // 6 x 3 x 0.2
  assert.equal(south.netVolume, 2.88); // 3.6 - 2 x (1.2*1.5*0.2)
  assert.deepEqual(south.openings, ['O1', 'O2']);

  // Every element carries a real solid with vertices and faces.
  for (const el of model.elements) {
    assert.ok(el.solid.vertices.length >= 8, el.id + ' has vertices');
    assert.ok(el.solid.faces.length >= 6, el.id + ' has faces');
    assert.ok(el.solid.volume > 0, el.id + ' has positive volume');
  }
  assert.ok(model.bbox.size.x > 0 && model.bbox.size.y > 0 && model.bbox.size.z > 0);
});

test('measures quantities from model geometry with correct units', () => {
  const model = buildModel(sampleSpec());
  const m = measureModel(model, { modelId: 'model-1', projectId: 'proj-test-1' });

  const byRule = Object.fromEntries(m.rows.map((r) => [r.ruleId, r]));

  // Wall net area: W1 14.4 + W2 18 + W3 12 = 44.4
  assert.equal(byRule['Q-WALL-NET-AREA'].quantity, 44.4);
  assert.equal(byRule['Q-WALL-NET-AREA'].unit, 'm2');
  // Wall length: 6 + 6 + 4 = 16
  assert.equal(byRule['Q-WALL-LENGTH'].quantity, 16);
  assert.equal(byRule['Q-WALL-LENGTH'].unit, 'm');
  // Column volume: 6 x (0.3*0.3*3) = 1.62
  assert.equal(byRule['Q-COLUMN-VOLUME'].quantity, 1.62);
  assert.equal(byRule['Q-COLUMN-VOLUME'].unit, 'm3');
  assert.equal(byRule['Q-COLUMN-COUNT'].quantity, 6);
  assert.equal(byRule['Q-COLUMN-COUNT'].unit, 'nr');
  // Footing volume: 6 x (1.2*1.2*0.6) = 5.184
  assert.equal(byRule['Q-FOOTING-VOLUME'].quantity, 5.184);
  // Slab area 24, volume 4.8
  assert.equal(byRule['Q-SLAB-AREA'].quantity, 24);
  assert.equal(byRule['Q-SLAB-VOLUME'].quantity, 4.8);
  // Beam volume 6*0.3*0.5 = 0.9
  assert.equal(byRule['Q-BEAM-VOLUME'].quantity, 0.9);
  // Openings: 2 nr, 3.6 m2
  assert.equal(byRule['Q-OPENING-COUNT'].quantity, 2);
  assert.equal(byRule['Q-OPENING-AREA'].quantity, 3.6);

  // Every row is proposed, never approved.
  for (const r of m.rows) {
    assert.equal(r.reviewState, 'measured_ready_for_review');
    assert.equal(r.measurementBasis, 'bim_model_geometry');
    assert.ok(r.elementIds.length > 0);
    assert.ok(r.formula.length > 0);
  }
  assert.equal(m.unmeasurable.length, 0);
  assert.equal(m.totalsByUnit.m2, 44.4 + 24 + 3.6);
  // m3: wall net 8.88 + column 1.62 + footing 5.184 + slab 4.8 + beam 0.9
  assert.equal(m.totalsByUnit.m3, 21.384);
});

test('rejects invalid models instead of guessing geometry', () => {
  assert.throws(() => buildModel({ name: 'x', elements: [] }), /at least one element/);
  assert.throws(
    () => buildModel({ name: 'x', elements: [{ type: 'wall', length: 0, width: 0.2, height: 3 }] }),
    /length must not be zero/
  );
  assert.throws(
    () => buildModel({ name: 'x', elements: [{ type: 'sofa', length: 1, width: 1, height: 1 }] }),
    /unsupported type/
  );
  assert.throws(
    () => buildModel({
      name: 'x',
      elements: [
        { id: 'W', type: 'wall', length: 2, width: 0.2, height: 3 },
        { id: 'O', type: 'opening', hostId: 'W', length: 3, width: 0.2, height: 1 }
      ]
    }),
    /wider than its host wall/
  );
  assert.throws(
    () => buildModel({
      name: 'x',
      elements: [{ id: 'O', type: 'opening', length: 1, width: 0.2, height: 1 }]
    }),
    /requires hostId/
  );
});

test('exports valid IFC4 that its own parser can read back', () => {
  const model = buildModel(sampleSpec());
  const { text, stats } = writeIfc(model, { projectName: 'Office Block' });

  assert.match(text, /^ISO-10303-21;/);
  assert.match(text, /FILE_SCHEMA\(\('IFC4'\)\)/);
  assert.match(text, /END-ISO-10303-21;\s*$/);
  assert.equal(stats.schema, 'IFC4');
  assert.equal(stats.elementCount, model.elementCount);
  assert.equal(stats.openingCount, 2);
  assert.equal(stats.storeyCount, 2);

  // Structural entities present
  for (const t of ['IFCPROJECT', 'IFCSITE', 'IFCBUILDING', 'IFCBUILDINGSTOREY',
    'IFCWALL', 'IFCCOLUMN', 'IFCFOOTING', 'IFCSLAB', 'IFCBEAM', 'IFCOPENINGELEMENT',
    'IFCELEMENTQUANTITY', 'IFCPROPERTYSET', 'IFCRELVOIDSELEMENT',
    'IFCRELCONTAINEDINSPATIALSTRUCTURE', 'IFCEXTRUDEDAREASOLID']) {
    assert.ok(text.includes(t), 'IFC output must contain ' + t);
  }

  const parsed = parseStep(text);
  assert.equal(parsed.schema, 'IFC4');
  assert.ok(parsed.records.length > 100);
  const graph = new StepGraph(parsed);
  assert.equal(graph.byType('IFCWALL').length, 3);
  assert.equal(graph.byType('IFCCOLUMN').length, 6);
  assert.equal(graph.byType('IFCFOOTING').length, 6);
  assert.equal(graph.byType('IFCOPENINGELEMENT').length, 2);
  assert.equal(graph.byType('IFCRELVOIDSELEMENT').length, 2);
  assert.equal(lengthScaleOf(graph), 1);
});

test('round trip: export then re-import preserves element counts and quantities', () => {
  const model = buildModel(sampleSpec());
  const before = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const { text } = writeIfc(model, { projectName: 'Office Block' });

  const { model: reimported, report } = importIfc(text, { name: 'Reimported', projectId: 'p1' });
  assert.equal(report.schema, 'IFC4');
  assert.equal(report.importedElementCount, model.elementCount);
  assert.equal(report.skippedCount, 0);
  assert.equal(reimported.countsByType.wall, 3);
  assert.equal(reimported.countsByType.column, 6);
  assert.equal(reimported.countsByType.footing, 6);
  assert.equal(reimported.countsByType.slab, 1);
  assert.equal(reimported.countsByType.beam, 1);
  assert.equal(reimported.countsByType.opening, 2);

  // Openings must still be linked to their host wall after the round trip.
  const openings = reimported.elements.filter((e) => e.type === 'opening');
  assert.equal(openings.length, 2);
  const wallIds = new Set(reimported.elements.filter((e) => e.type === 'wall').map((e) => e.id));
  for (const o of openings) {
    assert.ok(o.hostId, 'opening ' + o.id + ' keeps a host');
    assert.ok(wallIds.has(o.hostId), 'opening host is a wall');
  }

  const after = measureModel(reimported, { modelId: 'm1', projectId: 'p1' });
  const beforeByRule = Object.fromEntries(before.rows.map((r) => [r.ruleId, r.quantity]));
  const afterByRule = Object.fromEntries(after.rows.map((r) => [r.ruleId, r.quantity]));

  // Geometry-derived quantities must match exactly (same solids, same units).
  for (const rule of ['Q-COLUMN-VOLUME', 'Q-COLUMN-COUNT', 'Q-FOOTING-VOLUME',
    'Q-FOOTING-COUNT', 'Q-SLAB-AREA', 'Q-SLAB-VOLUME', 'Q-BEAM-VOLUME',
    'Q-BEAM-LENGTH', 'Q-WALL-LENGTH', 'Q-OPENING-COUNT', 'Q-OPENING-AREA']) {
    assert.ok(rule in beforeByRule, 'before has ' + rule);
    assert.ok(rule in afterByRule, 'after has ' + rule);
    assert.ok(
      Math.abs(beforeByRule[rule] - afterByRule[rule]) < 1e-6,
      `${rule}: ${beforeByRule[rule]} != ${afterByRule[rule]}`
    );
  }
});

test('imports a hand-written IFC with millimetre units and scales to metres', () => {
  const ifc = `ISO-10303-21;
HEADER;
FILE_SCHEMA(('IFC4'));
ENDSEC;
DATA;
#1=IFCSIUNIT(*,.LENGTHUNIT.,.MILLI.,.METRE.);
#2=IFCCARTESIANPOINT((0.,0.,0.));
#3=IFCDIRECTION((0.,0.,1.));
#4=IFCDIRECTION((1.,0.,0.));
#5=IFCAXIS2PLACEMENT3D(#2,#3,#4);
#6=IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,#5,$);
#7=IFCGEOMETRICREPRESENTATIONSUBCONTEXT('Body','Model',*,*,*,*,#6,$,.MODEL_VIEW.,$);
#10=IFCBUILDINGSTOREY('st1',$,'Level 1',$,$,$,$,$,.ELEMENT.,0.);
#20=IFCLOCALPLACEMENT($,#5);
#21=IFCCARTESIANPOINT((0.,0.,0.));
#22=IFCAXIS2PLACEMENT3D(#21,#3,#4);
#23=IFCLOCALPLACEMENT(#20,#22);
#30=IFCCARTESIANPOINT((0.,0.));
#31=IFCAXIS2PLACEMENT2D(#30,$);
#32=IFCRECTANGLEPROFILEDEF(.AREA.,$,#31,4000.,300.);
#33=IFCEXTRUDEDAREASOLID(#32,#5,#3,3000.);
#34=IFCSHAPEREPRESENTATION(#7,'Body','SweptSolid',(#33));
#35=IFCPRODUCTDEFINITIONSHAPE($,$,(#34));
#40=IFCWALL('w1',$,'Wall in mm',$,$,#23,#35,$,.SOLIDWALL.,$);
#50=IFCRELCONTAINEDINSPATIALSTRUCTURE('r1',$,$,$,(#40),#10);
ENDSEC;
END-ISO-10303-21;`;
  const { model, report } = importIfc(ifc);
  assert.equal(report.lengthUnitScale, 0.001);
  assert.equal(model.elements.length, 1);
  const wall = model.elements[0];
  assert.equal(wall.type, 'wall');
  // 4000 mm x 300 mm x 3000 mm -> 4 m x 0.3 m x 3 m
  assert.ok(Math.abs(wall.length - 4) < 1e-6, 'length ' + wall.length);
  assert.ok(Math.abs(wall.width - 0.3) < 1e-6, 'width ' + wall.width);
  assert.ok(Math.abs(wall.height - 3) < 1e-6, 'height ' + wall.height);
  assert.ok(Math.abs(wall.measuredVolume - 3.6) < 1e-6, 'volume ' + wall.measuredVolume);

  const m = measureModel(model);
  const area = m.rows.find((r) => r.ruleId === 'Q-WALL-NET-AREA');
  assert.ok(Math.abs(area.quantity - 12) < 1e-6, 'net area ' + area.quantity);
});

test('reports unsupported geometry instead of inventing quantities', () => {
  const ifc = `ISO-10303-21;
HEADER;
FILE_SCHEMA(('IFC4'));
ENDSEC;
DATA;
#1=IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.);
#2=IFCCARTESIANPOINT((0.,0.,0.));
#3=IFCDIRECTION((0.,0.,1.));
#4=IFCDIRECTION((1.,0.,0.));
#5=IFCAXIS2PLACEMENT3D(#2,#3,#4);
#6=IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,#5,$);
#7=IFCGEOMETRICREPRESENTATIONSUBCONTEXT('Body','Model',*,*,*,*,#6,$,.MODEL_VIEW.,$);
#10=IFCBUILDINGSTOREY('st1',$,'Level 1',$,$,$,$,$,.ELEMENT.,0.);
#20=IFCLOCALPLACEMENT($,#5);
#30=IFCCARTESIANPOINT((0.,0.));
#31=IFCAXIS2PLACEMENT2D(#30,$);
#32=IFCRECTANGLEPROFILEDEF(.AREA.,$,#31,1.,1.);
#33=IFCEXTRUDEDAREASOLID(#32,#5,#3,1.);
#34=IFCSHAPEREPRESENTATION(#7,'Body','SweptSolid',(#33));
#35=IFCPRODUCTDEFINITIONSHAPE($,$,(#34));
#40=IFCWALL('w1',$,'Good wall',$,$,#20,#35,$,.SOLIDWALL.,$);
#41=IFCDOOR('d1',$,'Door',$,$,#20,$,$,1.,1.);
#42=IFCRELCONTAINEDINSPATIALSTRUCTURE('r1',$,$,$,(#40,#41),#10);
ENDSEC;
END-ISO-10303-21;`;
  const { model, report } = importIfc(ifc);
  assert.equal(model.elements.length, 1);
  assert.equal(model.elements[0].type, 'wall');
  // The door has no representation, so it is skipped rather than measured.
  assert.ok(report.skippedCount >= 0);
  const m = measureModel(model);
  assert.equal(m.rows.length, 3); // wall area, volume, length
  assert.ok(!m.rows.some((r) => r.elementType === 'door'));
});

test('converts measurements into canonical quantity records for the BOQ compiler', () => {
  const model = buildModel(sampleSpec());
  const m = measureModel(model, { modelId: 'model-1', projectId: 'proj-test-1' });
  const records = toQuantityRecords(m, { storeys: model.storeys });
  assert.equal(records.length, m.rows.length);
  for (const r of records) {
    assert.equal(r.projectId, 'proj-test-1');
    assert.equal(r.reviewState, 'measured_ready_for_review');
    assert.equal(r.derivation.method, 'bim_element_takeoff');
    assert.ok(r.derivation.ruleId);
    assert.ok(r.derivation.formula);
    assert.ok(r.derivation.inputs.length > 0);
    assert.ok(r.sources.length > 0);
    assert.ok(r.sources[0].documentId);
    assert.ok(r.sources[0].revision);
    assert.ok(r.sources[0].sheetOrPage);
  }
  // The existing BOQ compiler must accept them.
  const { compileBoq } = require('../src/lib/mmc-ai/boq-compiler');
  const boq = compileBoq(records, { includeStates: ['measured_ready_for_review'] });
  assert.equal(boq.status, 'boq_draft');
  assert.ok(boq.itemCount > 0);
  for (const item of boq.items) {
    assert.equal(item.approvalState, 'draft_requires_review');
    assert.ok(['m', 'm2', 'm3', 'nr'].includes(item.unit));
  }
});

test('every quantity rule declares a supported unit and a formula', () => {
  const allowed = new Set(['m', 'm2', 'm3', 'nr']);
  for (const rule of QUANTITY_RULES) {
    assert.ok(allowed.has(rule.unit), rule.id + ' unit ' + rule.unit);
    assert.ok(rule.formula.length > 0, rule.id + ' formula');
    assert.ok(rule.label.ar && rule.label.en, rule.id + ' bilingual label');
    assert.ok(rule.description.ar && rule.description.en, rule.id + ' bilingual description');
  }
});

test('IFC output writes REAL literals, not integers, for every numeric attribute', () => {
  // A bare integer in a REAL-typed attribute parses but makes the geometry
  // unreadable to conforming readers (ifcopenshell refuses to build the shape).
  const model = buildModel(sampleSpec());
  const { text } = writeIfc(model, { projectName: 'Real literal check' });

  const profile = text.match(/IFCRECTANGLEPROFILEDEF\([^)]*\)/g) || [];
  assert.ok(profile.length > 0, 'profiles present');
  for (const p of profile) {
    // The two profile dimensions are the last two numeric literals.
    const nums = p.match(/-?\d+(?:\.\d*)?(?:E[+-]?\d+)?/g) || [];
    const dims = nums.slice(-2);
    assert.equal(dims.length, 2, 'two profile dimensions in ' + p);
    for (const v of dims) {
      assert.ok(v.includes('.'), `profile dimension "${v}" must be a REAL literal in ${p}`);
    }
  }
  const solids = text.match(/IFCEXTRUDEDAREASOLID\([^)]*\)/g) || [];
  assert.ok(solids.length > 0, 'solids present');
  for (const s of solids) {
    const depth = s.match(/,\s*(-?\d+(?:\.\d*)?(?:E[+-]?\d+)?)\s*\)$/);
    assert.ok(depth, 'depth present in ' + s);
    assert.ok(depth[1].includes('.'), `extrusion depth "${depth[1]}" must be a REAL literal`);
  }
  // No bare-integer coordinate triples anywhere in a point or direction.
  const points = text.match(/IFCCARTESIANPOINT\(\([^)]*\)\)/g) || [];
  assert.ok(points.length > 0, 'points present');
  for (const p of points) {
    for (const c of p.match(/-?\d+(?:\.\d*)?(?:E[+-]?\d+)?/g) || []) {
      assert.ok(c.includes('.'), `coordinate "${c}" must be a REAL literal in ${p}`);
    }
  }
  const dirs = text.match(/IFCDIRECTION\(\([^)]*\)\)/g) || [];
  for (const d of dirs) {
    for (const c of d.match(/-?\d+(?:\.\d*)?(?:E[+-]?\d+)?/g) || []) {
      assert.ok(c.includes('.'), `direction "${c}" must be a REAL literal in ${d}`);
    }
  }
  // Quantity values must be REAL too.
  const qtys = text.match(/IFCQUANTITY(?:LENGTH|AREA|VOLUME)\([^)]*\)/g) || [];
  assert.ok(qtys.length > 0, 'quantities present');
  for (const q of qtys) {
    const v = q.match(/,\s*(-?\d+(?:\.\d*)?(?:E[+-]?\d+)?)\s*,\s*\$/);
    assert.ok(v, 'quantity value present in ' + q);
    assert.ok(v[1].includes('.'), `quantity value "${v[1]}" must be a REAL literal in ${q}`);
  }
});

test('an opening inherits its host wall orientation and sits on the wall centre-line', () => {
  // A rotated wall with an opening: the void must be cut along the wall, not
  // axis-aligned, or the exported geometry disagrees with the measured volume.
  const model = buildModel({
    name: 'rotated wall',
    storeys: [{ id: 'GF', name: 'GF', elevation: 0 }],
    elements: [
      { id: 'W', type: 'wall', storeyId: 'GF', origin: { x: 0, y: 0, z: 0 }, length: 6, width: 0.2, height: 3, rotationDeg: 90 },
      { id: 'O', type: 'opening', storeyId: 'GF', hostId: 'W', origin: { x: 0.05, y: 1, z: 1 }, length: 1.2, width: 0.2, height: 1.5 }
    ]
  });
  const wall = model.elements.find((e) => e.id === 'W');
  const opening = model.elements.find((e) => e.id === 'O');
  assert.equal(opening.rotationDeg, 90, 'opening inherits wall rotation');
  assert.equal(opening.width, 0.2, 'opening inherits wall thickness');
  // The opening is snapped onto the wall centre-line (x = 0), not left at 0.05.
  assert.ok(Math.abs(opening.origin.x) < 1e-9, 'opening x on centre-line, got ' + opening.origin.x);
  assert.ok(Math.abs(opening.origin.y - 1) < 1e-9, 'opening keeps its position along the wall');
  assert.ok(Math.abs(opening.offsetAlongHost - 1) < 1e-9, 'offset along host recorded');
  // Net volume deducts the opening through the wall thickness.
  assert.ok(Math.abs(wall.netVolume - (6 * 3 * 0.2 - 1.2 * 1.5 * 0.2)) < 1e-9, 'net volume ' + wall.netVolume);
});
