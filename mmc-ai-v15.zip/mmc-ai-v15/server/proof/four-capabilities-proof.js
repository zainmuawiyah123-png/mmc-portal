'use strict';
/**
 * Proof run for the four capabilities, on the project's REAL data.
 *
 * It does not use a synthetic model: it loads `proof/bim-real-project/model.json`
 * — the 27-element model reconstructed from the real DXF architectural drawing —
 * and drives the four capabilities through the real HTTP API with real auth.
 *
 * What it proves, and what it checks:
 *   1. BOQ import  — a real .xlsx built from the model's own measured quantities
 *                    is parsed with its columns detected, and each line is
 *                    matched back to the rule it came from.
 *   2. Aluminium   — the schedule is built from the model's real opening and its
 *                    numbers are recomputed independently and compared.
 *   3. Specs       — a real specification is split into clauses and linked to the
 *                    measured rules with a confidence.
 *   4. Risk        — the register is derived from the real model, quantities,
 *                    schedule and cost, and every score is re-checked.
 *
 * Output: proof/four-capabilities/report.json
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mmc-four-proof-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json';
process.env.DB_PATH = path.join(TMP, 'proof.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false';
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'mmc-four-proof-secret';
process.env.BCRYPT_ROUNDS = '4';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { closeDB, getDB } = require('../src/db');
const { buildWorkbook } = require('../src/lib/mmc-ai/xlsx-writer');
const { readXlsx } = require('../src/lib/mmc-ai/xlsx-reader');

const OUT_DIR = path.join(__dirname, 'four-capabilities');
const checks = [];
let server, base;
const jar = {};

function check(name, ok, detail) {
  checks.push({ name, ok: Boolean(ok), detail: detail === undefined ? null : detail });
  if (!ok) console.error('  ✗ ' + name + (detail ? ' — ' + JSON.stringify(detail) : ''));
  else console.log('  ✓ ' + name);
}

async function call(method, url, body) {
  const headers = { ...(jar.session ? { Cookie: jar.session } : {}) };
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) jar.session = first;
  }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data, headers: r.headers };
}

async function upload(url, filename, buffer) {
  const form = new FormData();
  form.append('file', new Blob([buffer]), filename);
  const r = await fetch(base + url, {
    method: 'POST', headers: { ...(jar.session ? { Cookie: jar.session } : {}) }, body: form, redirect: 'manual'
  });
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data, headers: r.headers };
}

const round = (n, dp = 3) => Math.round((Number(n) + Number.EPSILON) * 10 ** dp) / 10 ** dp;

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  migrate();
  const app = createApp();
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = 'http://127.0.0.1:' + server.address().port;

  /* ------------------------------ setup ------------------------------ */
  console.log('\n[setup] account, project, real model');
  const email = 'proof' + Date.now() + '@test.local';
  const reg = await call('POST', '/api/auth/register', { name: 'Proof Engineer', email, password: 'Password123', company: 'MMC' });
  if (reg.status !== 201) throw new Error('register failed: ' + JSON.stringify(reg.data));
  const db = getDB();
  const user = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now, user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);
  const login = await call('POST', '/api/auth/login', { email, password: 'Password123' });
  if (login.status !== 200) throw new Error('login failed');

  const proj = await call('POST', '/api/mmc-ai/projects', { name: 'Real DXF project — four capabilities', currency: 'OMR' });
  const projectId = proj.data.project.project_id;
  check('project created', Boolean(projectId), projectId);

  const realModel = JSON.parse(fs.readFileSync(path.join(__dirname, 'bim-real-project', 'model.json'), 'utf8'));
  const built = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: realModel });
  check('real model stored', built.status === 201, built.status);
  const modelId = built.data.model.id;
  const quantities = built.data.quantities;
  check('model has 27 elements', built.data.model.elementCount === 27, built.data.model.elementCount);
  check('model measured 13 quantity rules', quantities.length === 13, quantities.length);

  const qtyByRule = Object.fromEntries(quantities.map((q) => [q.ruleId, q]));

  /* --------------------------- 1. BOQ IMPORT -------------------------- */
  console.log('\n[1] BOQ import — a real .xlsx built from the model quantities');
  // The workbook is built from the model's OWN measured numbers, so a correct
  // import must reproduce them exactly and a correct match must find them.
  const boqRows = [
    ['1.1', 'Excavation for footings', 'm3', 7.776, 8.5],
    ['1.2', 'Plain concrete for footings', 'm3', 7.776, 45],
    ['2.1', 'Reinforced concrete columns', 'm3', 2.43, 180],
    ['2.2', 'Reinforced concrete beams', 'm3', 2.4, 195],
    ['2.3', 'Reinforced concrete slabs', 'm3', 9.6, 175],
    ['3.1', 'Blockwork walls — net face area', 'm2', 100.2, 22],
    ['3.2', 'Blockwork walls — net volume', 'm3', 20.04, 95],
    ['4.1', 'Aluminium windows', 'nr', 1, 320],
    ['4.2', 'Window glazing area', 'm2', 1.8, 40]
  ];
  const boqBuf = buildWorkbook({
    sheets: [{
      name: 'BOQ',
      title: 'BILL OF QUANTITIES — REAL DXF PROJECT',
      note: 'Reconstructed from the architectural drawing set · Rev C',
      columns: [
        { header: 'Item No', width: 10 }, { header: 'Description', width: 46 },
        { header: 'Unit', width: 10 }, { header: 'Qty', width: 12 },
        { header: 'Unit Rate', width: 12 }, { header: 'Amount', width: 14 }
      ],
      rows: boqRows.map((r) => [r[0], r[1], r[2], r[3], r[4], round(r[3] * r[4], 2)]),
      totals: ['', 'Total', '', '', '', round(boqRows.reduce((s, r) => s + r[3] * r[4], 0), 2)]
    }]
  });
  fs.writeFileSync(path.join(OUT_DIR, 'proof-boq-import.xlsx'), boqBuf);

  const imp = await upload(`/api/mmc-ai/projects/${projectId}/boq-imports`, 'real-boq.xlsx', boqBuf);
  check('BOQ file imported', imp.status === 201, imp.status);
  const importId = imp.data.import.id;
  check('9 lines read (totals row excluded)', imp.data.import.lineCount === 9, imp.data.import.lineCount);
  check('header row detected below the title block', imp.data.import.headerRow >= 3, imp.data.import.headerRow);
  const cm = imp.data.import.columnMap;
  check('columns detected by name', cm.description === 1 && cm.unit === 2 && cm.quantity === 3 && cm.rate === 4, cm);
  const firstLine = imp.data.lines[0];
  check('first line values exact', firstLine.itemCode === '1.1' && firstLine.quantity === 7.776 && firstLine.rate === 8.5, firstLine);
  check('nothing linked before matching', imp.data.lines.every((l) => l.linkState === 'unmatched'));

  const matched = await call('POST', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/match`, { modelId });
  check('matching ran', matched.status === 200, matched.status);
  const msum = matched.data.summary;
  check('every line found a candidate', msum.proposed === 9, msum);

  // Each imported line must land on the rule whose quantity it was built from.
  const expected = {
    '1.1': 'Q-FOOTING-VOLUME', '1.2': 'Q-FOOTING-VOLUME',
    '2.1': 'Q-COLUMN-VOLUME', '2.2': 'Q-BEAM-VOLUME', '2.3': 'Q-SLAB-VOLUME',
    '3.1': 'Q-WALL-NET-AREA', '3.2': 'Q-WALL-NET-VOLUME',
    '4.1': 'Q-OPENING-COUNT', '4.2': 'Q-OPENING-AREA'
  };
  let correct = 0;
  const linkDetail = [];
  for (const line of matched.data.lines) {
    const want = expected[line.itemCode];
    const got = line.match ? line.match.ruleId : null;
    const ok = want === got;
    if (ok) correct += 1;
    linkDetail.push({ itemCode: line.itemCode, expected: want, got, confidence: line.match?.confidence ?? null, ok });
  }
  check('all 9 lines matched to the rule they came from', correct === 9, linkDetail);
  check('every match carries a confidence', matched.data.lines.every((l) => l.match && l.match.confidence > 0));
  check('every match carries its signals', matched.data.lines.every((l) => l.match && typeof l.match.signals.unitMatch === 'boolean'));

  // A human decides every link, then approves.
  for (const line of matched.data.lines) {
    await call('PATCH', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/lines/${line.id}`, { state: 'confirmed' });
  }
  const approvedImport = await call('POST', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/approve`);
  check('import approved with approver and time', approvedImport.status === 200 && approvedImport.data.import.approvedBy && approvedImport.data.import.approvedAt, approvedImport.status);

  /* -------------------------- 2. ALUMINIUM --------------------------- */
  console.log('\n[2] Aluminium schedule — from the model\'s real opening');
  const alu = await call('POST', `/api/mmc-ai/projects/${projectId}/aluminium/schedules`, { modelId, name: 'Aluminium — real DXF project' });
  check('schedule built', alu.status === 201, alu.status);
  const aluId = alu.data.schedule.id;
  check('one opening taken from the model', alu.data.openings.length === 1, alu.data.openings.length);

  const op = alu.data.openings[0];
  // The real opening is 1.5 x 1.2 m.
  check('opening dimensions from the model', op.width === 1.5 && op.height === 1.2, { w: op.width, h: op.height });
  check('opening area = 1.8 m2', op.areaM2 === 1.8, op.areaM2);
  // Frame perimeter = 2*(1.5+1.2) = 5.4 m — recomputed here, not read back.
  check('frame length recomputed = 5.4 m', op.lengths.frameM === round(2 * (1.5 + 1.2)), op.lengths.frameM);
  // Glass: 2 panels, inset 50 mm -> pane 0.7 x 1.1 = 0.77, x2 = 1.54 m2.
  const paneW = (1.5 - 0.1) / 2;
  const paneH = 1.2 - 0.1;
  check('glass area recomputed = 1.54 m2', op.glassM2 === round(paneW * paneH * 2), { got: op.glassM2, want: round(paneW * paneH * 2) });

  const frameLine = alu.data.lines.find((l) => l.code === 'FR-50');
  check('frame bars = ceil(5.4/6) = 1', frameLine.bars === 1, frameLine.bars);
  check('frame cost = 5.4 x 4.5 = 24.3', frameLine.total === round(5.4 * 4.5), frameLine.total);
  const glassLine = alu.data.lines.find((l) => l.category === 'glass');
  check('glass cost = 1.54 x 12 = 18.48', glassLine.total === round(1.54 * 12), glassLine.total);
  const lineSum = round(alu.data.lines.reduce((s, l) => s + l.total, 0));
  check('schedule total equals the sum of its lines', alu.data.schedule.total === lineSum, { total: alu.data.schedule.total, sum: lineSum });

  // Editing a price must move the total by exactly that line's delta.
  const beforeTotal = alu.data.schedule.total;
  const edited = await call('PATCH', `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${aluId}`, {
    profiles: { frame: { code: 'FR-50', name: 'إطار 50 مم', barLengthM: 6, unitPrice: 9 } }
  });
  const newFrame = edited.data.lines.find((l) => l.code === 'FR-50');
  check('price edit recomputed the frame line', newFrame.total === round(5.4 * 9), newFrame.total);
  check('total moved by exactly the delta', round(edited.data.schedule.total - beforeTotal) === round(newFrame.total - frameLine.total), {
    delta: round(edited.data.schedule.total - beforeTotal), lineDelta: round(newFrame.total - frameLine.total)
  });

  const aluApproved = await call('POST', `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${aluId}/approve`);
  check('schedule approved with approver and time', aluApproved.status === 200 && aluApproved.data.schedule.approvedBy && aluApproved.data.schedule.approvedAt, aluApproved.status);

  const xlsxRes = await fetch(base + `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${aluId}/export.xlsx`, { headers: { Cookie: jar.session } });
  const xlsxBuf = Buffer.from(await xlsxRes.arrayBuffer());
  fs.writeFileSync(path.join(OUT_DIR, 'proof-aluminium.xlsx'), xlsxBuf);
  const wb = readXlsx(xlsxBuf);
  check('Excel export opens with 3 sheets', wb.sheets.length === 3, wb.sheets.map((s) => s.name));
  check('Excel carries the schedule lines', wb.sheets[0].rows.length >= 4, wb.sheets[0].rows.length);

  /* ------------------------- 3. SPECIFICATIONS ----------------------- */
  console.log('\n[3] Specifications — real clauses linked to the measured rules');
  const specText = [
    'SECTION 03 — CONCRETE',
    '',
    '3.1 Reinforced concrete columns',
    'All reinforced concrete columns shall be Grade C30 with 400 MPa reinforcement. Concrete cover shall be 40 mm minimum. Columns shall be cast in one continuous pour and vibrated.',
    '',
    '3.2 Reinforced concrete beams',
    'Reinforced concrete beams shall be Grade C30. Formwork shall remain in place for not less than 14 days. Beams shall be propped at third points during curing.',
    '',
    '3.3 Reinforced concrete slabs',
    'Suspended slabs shall be Grade C30, 200 mm thick unless noted otherwise. Slabs shall be cured for 7 days minimum.',
    '',
    'SECTION 04 — MASONRY',
    '',
    '4.1 Blockwork walls',
    'Blockwork walls shall be 200 mm hollow concrete blocks with cement mortar 1:4. Walls shall be reinforced with horizontal joint reinforcement every third course.',
    '',
    'SECTION 08 — JOINERY',
    '',
    '8.1 Aluminium windows',
    'Aluminium windows shall be thermally broken profiles with 6 mm clear glazing. All windows shall be factory assembled and tested for water tightness before delivery.'
  ].join('\n');
  fs.writeFileSync(path.join(OUT_DIR, 'proof-specification.txt'), specText, 'utf8');

  const spec = await upload(`/api/mmc-ai/projects/${projectId}/specifications`, 'specification.txt', Buffer.from(specText, 'utf8'));
  check('specification imported', spec.status === 201, spec.status);
  const specId = spec.data.document.id;
  check('5 clauses extracted', spec.data.document.clauseCount === 5, spec.data.document.clauseCount);
  check('clause codes parsed', JSON.stringify(spec.data.clauses.map((c) => c.code)) === JSON.stringify(['3.1', '3.2', '3.3', '4.1', '8.1']), spec.data.clauses.map((c) => c.code));

  const linked = await call('POST', `/api/mmc-ai/projects/${projectId}/specifications/${specId}/link`, { modelId });
  check('clauses linked', linked.status === 200, linked.status);
  check('every clause found a target', linked.data.summary.linked === 5, linked.data.summary);

  // The concrete clause must reach the concrete rule, not the masonry one.
  const colLinks = linked.data.links.filter((l) => l.targetId === 'Q-COLUMN-VOLUME');
  check('column clause linked to the column volume rule', colLinks.length > 0, colLinks.length);
  check('column link has trade agreement', colLinks.some((l) => l.signals.tradeMatch === true));
  const wallLinks = linked.data.links.filter((l) => l.targetId === 'Q-WALL-NET-AREA');
  check('masonry clause linked to the wall area rule', wallLinks.length > 0, wallLinks.length);

  // Confirm one link and read it back from the target side.
  const toConfirm = colLinks[0];
  await call('PATCH', `/api/mmc-ai/projects/${projectId}/specifications/${specId}/links/${toConfirm.id}`, { state: 'confirmed' });
  const forTarget = await call('GET', `/api/mmc-ai/projects/${projectId}/specifications/for-target?targetType=quantity_rule&targetId=Q-COLUMN-VOLUME`);
  check('confirmed spec visible on its target', forTarget.status === 200 && forTarget.data.confirmedCount >= 1, forTarget.data.confirmedCount);
  const hit = forTarget.data.links.find((l) => l.linkId === toConfirm.id);
  check('target view carries the clause text', Boolean(hit && /C30/.test(hit.clause.body)));

  // Decide the rest, then approve.
  const allLinks = (await call('GET', `/api/mmc-ai/projects/${projectId}/specifications/${specId}`)).data.links;
  for (const l of allLinks) {
    if (l.state === 'proposed') {
      await call('PATCH', `/api/mmc-ai/projects/${projectId}/specifications/${specId}/links/${l.id}`, { state: 'confirmed' });
    }
  }
  const specApproved = await call('POST', `/api/mmc-ai/projects/${projectId}/specifications/${specId}/approve`);
  check('specification approved with approver and time', specApproved.status === 200 && specApproved.data.document.approvedBy && specApproved.data.document.approvedAt, specApproved.status);

  /* ---------------------------- 4. RISK ------------------------------ */
  console.log('\n[4] Risk analysis — from the real model, schedule and cost');
  // Build a real schedule and a real cost so the analysis has something to read.
  const sched = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/schedule`, {
    name: 'Real project programme',
    dataDate: '2026-11-18',
    schedule: {
      calendar: { dataDate: '2026-11-18' },
      activities: [
        { id: 'A1', name: 'Footings', durationDays: 5, trade: 'concrete', percentComplete: 100, actualStart: '2026-10-01', actualFinish: '2026-10-06' },
        { id: 'A2', name: 'Columns', durationDays: 6, predecessors: ['A1'], trade: 'concrete', percentComplete: 60, actualStart: '2026-10-07' },
        { id: 'A3', name: 'Beams and slab', durationDays: 8, predecessors: ['A2'], trade: 'concrete', percentComplete: 20, actualStart: '2026-10-20' },
        { id: 'A4', name: 'Blockwork walls', durationDays: 7, predecessors: ['A2'], trade: 'blockwork', percentComplete: 0 },
        { id: 'A5', name: 'Aluminium windows', durationDays: 4, predecessors: ['A4'], trade: 'joinery', percentComplete: 0 }
      ]
    }
  });
  check('schedule created', sched.status === 201, sched.status);

  const rates = {
    'Q-FOOTING-VOLUME': 145, 'Q-COLUMN-VOLUME': 180, 'Q-BEAM-VOLUME': 195,
    'Q-SLAB-VOLUME': 175, 'Q-WALL-NET-AREA': 22, 'Q-WALL-NET-VOLUME': 95,
    'Q-OPENING-COUNT': 320, 'Q-OPENING-AREA': 40, 'Q-WALL-LENGTH': 12,
    'Q-COLUMN-COUNT': 25, 'Q-FOOTING-COUNT': 30, 'Q-BEAM-LENGTH': 18, 'Q-SLAB-AREA': 28
  };
  // The cost API needs the unit alongside the rate, so it is taken from the
  // measured rule itself rather than guessed.
  const rateItems = Object.entries(rates).map(([ruleId, unitRate]) => ({
    ruleId, unitRate, unit: qtyByRule[ruleId].unit
  }));
  const ratesSaved = await call('PUT', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost-items`, {
    currency: 'OMR', items: rateItems
  });
  check('unit rates registered', ratesSaved.status === 200 || ratesSaved.status === 201, ratesSaved.status);

  const cost = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost`, { currency: 'OMR' });
  check('cost built', cost.status === 201 || cost.status === 200, cost.status);
  const costTotal = cost.data.total;
  check('cost total is positive', Number(costTotal) > 0, costTotal);
  // The cost total must equal the sum of the measured quantities x their rates.
  const expectedTotal = round(quantities.reduce((s, q) => s + (rates[q.ruleId] ? q.quantity * rates[q.ruleId] : 0), 0), 2);
  check('cost total equals quantities x rates', Math.abs(Number(costTotal) - expectedTotal) < 0.02, { got: costTotal, want: expectedTotal });

  const risk = await call('POST', `/api/mmc-ai/projects/${projectId}/risk-analysis`, { modelId, asOf: '2026-11-18' });
  check('risk analysis ran', risk.status === 201, risk.status);
  const riskId = risk.data.analysis.id;
  const risks = risk.data.risks;
  check('register is not empty', risks.length > 0, risks.length);

  // Every score must be probability x impact, and every risk must carry evidence.
  const scoreOk = risks.every((r) => r.score === r.probability * r.impact);
  check('every score = probability x impact', scoreOk);
  const evidenceOk = risks.every((r) => Array.isArray(r.evidence) && r.evidence.length > 0);
  check('every risk carries its evidence', evidenceOk);
  const responseOk = risks.every((r) => r.response && r.response.length > 10);
  check('every risk has a response plan', responseOk);
  const sortedOk = risks.every((r, i) => i === 0 || risks[i - 1].score >= r.score);
  check('register sorted worst first', sortedOk);
  const allProposed = risks.every((r) => r.state === 'proposed');
  check('nothing is pre-accepted', allProposed);

  // The real project has a model, a schedule and a cost, so the "missing"
  // risks must NOT fire — that is the check that the rules read real data.
  const codes = risks.map((r) => r.code);
  check('no false "no model" risk', !codes.includes('R-MODEL-001'), codes);
  check('no false "no schedule" risk', !codes.includes('R-SCH-001'), codes);
  check('no false "no cost" risk', !codes.includes('R-COST-001'), codes);
  // The real model has one opening, so the "no openings" risk must not fire.
  check('no false "no openings" risk', !codes.includes('R-MODEL-002'), codes);
  // The real model's elements carry NO source sheet (the DXF reconstruction did
  // not record one), so the provenance risk MUST fire. This is a true positive,
  // and asserting it is what proves the rule reads the model rather than
  // always firing or never firing.
  check('provenance risk fires on a model with no source sheets', codes.includes('R-MODEL-005'), codes);
  const provRisk = risks.find((r) => r.code === 'R-MODEL-005');
  check('provenance risk cites the real count', provRisk && /27\/27/.test(provRisk.evidence.join(' ')), provRisk && provRisk.evidence);

  // Approval must be blocked while anything is still proposed.
  const blocked = await call('POST', `/api/mmc-ai/projects/${projectId}/risk-analysis/${riskId}/approve`);
  check('approval blocked while risks are proposed', blocked.status === 409, blocked.status);

  // Edit one risk and confirm the score recomputes.
  const target = risks[0];
  const editedRisk = await call('PATCH', `/api/mmc-ai/projects/${projectId}/risk-analysis/${riskId}/risks/${target.id}`, {
    probability: 5, impact: 5, response: 'خطة معدّلة: مراجعة أسبوعية مع المقاول ورفع تقرير للمالك.', owner: 'مدير المشروع'
  });
  check('edited risk recomputed to 25', editedRisk.data.risk.score === 25 && editedRisk.data.risk.level === 'critical', editedRisk.data.risk.score);

  for (const r of risks) {
    await call('PATCH', `/api/mmc-ai/projects/${projectId}/risk-analysis/${riskId}/risks/${r.id}`, { state: 'accepted' });
  }
  const riskApproved = await call('POST', `/api/mmc-ai/projects/${projectId}/risk-analysis/${riskId}/approve`);
  check('register approved with approver and time', riskApproved.status === 200 && riskApproved.data.analysis.approvedBy && riskApproved.data.analysis.approvedAt, riskApproved.status);

  /* ----------------------------- report ------------------------------ */
  const passed = checks.filter((c) => c.ok).length;
  const failed = checks.length - passed;
  const report = {
    generatedAt: new Date().toISOString(),
    source: {
      model: 'proof/bim-real-project/model.json (reconstructed from tests/fixtures/synthetic-architectural-sample.dxf)',
      elements: built.data.model.elementCount,
      quantityRules: quantities.length,
      openings: alu.data.openings.length
    },
    boqImport: {
      lines: imp.data.import.lineCount,
      headerRow: imp.data.import.headerRow,
      columnMap: cm,
      matched: msum.proposed,
      matchedCorrectly: correct,
      links: linkDetail,
      approved: approvedImport.data.import.status
    },
    aluminium: {
      openings: alu.data.openings.length,
      opening: { width: op.width, height: op.height, areaM2: op.areaM2, frameM: op.lengths.frameM, glassM2: op.glassM2 },
      lines: alu.data.lines.map((l) => ({ code: l.code, unit: l.unit, lengthM: l.lengthM, bars: l.bars, quantity: l.quantity, unitPrice: l.unitPrice, total: l.total })),
      total: alu.data.schedule.total,
      currency: alu.data.schedule.currency,
      approved: aluApproved.data.schedule.status
    },
    specifications: {
      clauses: spec.data.document.clauseCount,
      codes: spec.data.clauses.map((c) => c.code),
      linked: linked.data.summary.linked,
      links: linked.data.links.map((l) => ({ clause: l.clauseId, target: l.targetId, confidence: l.confidence, tradeMatch: l.signals.tradeMatch })),
      approved: specApproved.data.document.status
    },
    risk: {
      count: risks.length,
      summary: risk.data.analysis.summary,
      codes,
      risks: risks.map((r) => ({ code: r.code, title: r.title, probability: r.probability, impact: r.impact, score: r.score, level: r.level, source: r.source })),
      approved: riskApproved.data.analysis.status
    },
    checks: { total: checks.length, passed, failed },
    results: checks
  };
  fs.writeFileSync(path.join(OUT_DIR, 'report.json'), JSON.stringify(report, null, 2));

  console.log('\n' + passed + '/' + checks.length + ' checks passed, ' + failed + ' failed.');
  if (failed) {
    console.error('FAILED CHECKS:');
    for (const c of checks.filter((x) => !x.ok)) console.error('  - ' + c.name + ' ' + JSON.stringify(c.detail));
  }
  return failed === 0;
}

main()
  .then(async (ok) => {
    if (server) await new Promise((r) => server.close(r));
    closeDB();
    fs.rmSync(TMP, { recursive: true, force: true });
    process.exit(ok ? 0 : 1);
  })
  .catch(async (err) => {
    console.error('PROOF FAILED:', err && err.stack ? err.stack : err);
    if (server) await new Promise((r) => server.close(r));
    try { closeDB(); } catch (e) { /* ignore */ }
    fs.rmSync(TMP, { recursive: true, force: true });
    process.exit(1);
  });
