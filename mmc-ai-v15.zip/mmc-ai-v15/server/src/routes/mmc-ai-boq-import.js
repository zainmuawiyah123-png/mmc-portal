'use strict';
/**
 * BOQ import API.
 *
 * POST   /projects/:projectId/boq-imports                 — upload xlsx/csv
 * GET    /projects/:projectId/boq-imports                 — list imports
 * GET    /projects/:projectId/boq-imports/:importId       — one import with lines
 * POST   /projects/:projectId/boq-imports/:importId/match — propose links to model quantities
 * PATCH  /projects/:projectId/boq-imports/:importId/lines/:lineId — confirm/reject a link
 * POST   /projects/:projectId/boq-imports/:importId/approve — engineer approval
 * DELETE /projects/:projectId/boq-imports/:importId       — remove an import
 *
 * Nothing is written into ai_boq_items by this route. An approved import is a
 * reviewed reference; turning it into BOQ items stays an explicit, separate act.
 */
const express = require('express');
const crypto = require('node:crypto');
const multer = require('multer');
const { getDB, uid } = require('../db');
const { E, wrap } = require('../lib/errors');
const A = require('../lib/auth');
const { readBoqFile, proposeBoqLinks, FIELD_LABELS, UNIT_LABELS } = require('../lib/mmc-ai/boq-import');

const router = express.Router();
const EDIT_ROLES = new Set(['owner', 'project_manager', 'engineer', 'quantity_surveyor']);
const APPROVE_ROLES = new Set(['owner', 'project_manager', 'engineer']);
const MAX_BYTES = 20 * 1024 * 1024;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES, files: 1, fields: 4, fieldSize: 400 },
  fileFilter(req, file, cb) {
    const name = String(file.originalname || '').toLowerCase();
    if (!name.endsWith('.xlsx') && !name.endsWith('.csv')) {
      return cb(E.validation('يُدعم استيراد جداول الكميات من ملفات .xlsx و .csv فقط.'));
    }
    cb(null, true);
  }
});

router.use(A.requireAuth);

function member(projectId, userId) {
  return getDB().prepare(
    'SELECT m.role,p.status FROM ai_project_members m JOIN ai_projects p ON p.id=m.project_id WHERE m.project_id=? AND m.user_id=?'
  ).get(projectId, userId) || null;
}

function requireMember(req) {
  const m = member(req.params.projectId, req.user.id);
  if (!m || m.status !== 'active') throw E.notFound('المشروع غير موجود.');
  return m;
}

function requireEdit(req) {
  const m = requireMember(req);
  if (!EDIT_ROLES.has(m.role)) throw E.forbidden('لا تملك صلاحية استيراد جدول كميات.');
  return m;
}

function audit(db, req, action, entityId, detail) {
  db.prepare(
    'INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)'
  ).run(uid('aial_'), req.params.projectId, req.user.id, action, 'boq_import', entityId, JSON.stringify(detail || {}));
}

function importView(row) {
  return {
    id: row.id,
    projectId: row.project_id,
    originalName: row.original_name,
    fileExt: row.file_ext,
    sizeBytes: row.size_bytes,
    sha256: row.sha256,
    sheetName: row.sheet_name,
    headerRow: row.header_row,
    columnMap: JSON.parse(row.column_map_json || '{}'),
    lineCount: row.line_count,
    skippedCount: row.skipped_count,
    warnings: JSON.parse(row.warnings_json || '[]'),
    sheets: JSON.parse(row.sheets_json || '[]'),
    modelId: row.model_id,
    status: row.status,
    approvedBy: row.approved_by,
    approvedAt: row.approved_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function lineView(row) {
  return {
    id: row.id,
    rowNumber: row.row_number,
    itemCode: row.item_code,
    description: row.description,
    unit: row.unit,
    unitLabel: row.unit ? (UNIT_LABELS[row.unit] || row.unit) : null,
    unitKnown: Boolean(row.unit_known),
    unitRaw: row.unit_raw,
    quantity: row.quantity,
    rate: row.rate,
    total: row.total,
    section: row.section,
    remarks: row.remarks,
    match: row.matched_rule_id ? {
      ruleId: row.matched_rule_id,
      modelQuantity: row.matched_quantity,
      confidence: row.match_confidence,
      signals: JSON.parse(row.match_signals_json || '{}')
    } : null,
    linkState: row.link_state,
    decidedBy: row.decided_by,
    decidedAt: row.decided_at
  };
}

/** POST — upload and parse a BOQ file. */
router.post('/projects/:projectId/boq-imports', upload.single('file'), wrap(async (req, res) => {
  requireEdit(req);
  if (!req.file) throw E.validation('اختر ملف جدول كميات (.xlsx أو .csv).');

  let parsed;
  try {
    parsed = readBoqFile(req.file.buffer, req.file.originalname);
  } catch (err) {
    throw E.validation('تعذّر قراءة الملف: ' + err.message);
  }
  if (!parsed.lines.length) {
    throw E.validation(
      'لم تُقرأ أي بنود من الملف. ' + (parsed.warnings[0] || 'تحقق من صف العناوين وأسماء الأعمدة.')
    );
  }

  const db = getDB();
  const importId = uid('aiboqimp_');
  const sha = crypto.createHash('sha256').update(req.file.buffer).digest('hex');
  const ext = String(req.file.originalname).toLowerCase().endsWith('.csv') ? 'csv' : 'xlsx';
  const modelId = req.body?.modelId ? String(req.body.modelId).slice(0, 100) : null;

  db.transaction(() => {
    db.prepare(`INSERT INTO ai_boq_imports
      (id,project_id,created_by,original_name,file_ext,size_bytes,sha256,sheet_name,header_row,column_map_json,
       line_count,skipped_count,warnings_json,sheets_json,model_id,status)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'imported_requires_review')`).run(
      importId, req.params.projectId, req.user.id, String(req.file.originalname).slice(0, 200), ext,
      req.file.size, sha, parsed.primarySheet, parsed.headerRow, JSON.stringify(parsed.columnMap || {}),
      parsed.lines.length, parsed.skipped.length, JSON.stringify(parsed.warnings || []),
      JSON.stringify(parsed.sheets || []), modelId
    );
    const addLine = db.prepare(`INSERT INTO ai_boq_import_lines
      (id,import_id,project_id,row_number,item_code,description,unit,unit_known,unit_raw,quantity,rate,total,section,remarks,link_state)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'unmatched')`);
    for (const l of parsed.lines) {
      addLine.run(
        uid('aiboqline_'), importId, req.params.projectId, l.rowNumber, l.itemCode, l.description,
        l.unit, l.unitKnown ? 1 : 0, l.unitRaw, l.quantity, l.rate, l.total, l.section, l.remarks
      );
    }
    audit(db, req, 'boq_import_created', importId, {
      lines: parsed.lines.length, skipped: parsed.skipped.length, sheet: parsed.primarySheet, sha256: sha
    });
  })();

  const row = db.prepare('SELECT * FROM ai_boq_imports WHERE id=?').get(importId);
  const lines = db.prepare('SELECT * FROM ai_boq_import_lines WHERE import_id=? ORDER BY row_number').all(importId);
  res.status(201).json({
    import: importView(row),
    lines: lines.map(lineView),
    skipped: parsed.skipped,
    columnLabels: Object.fromEntries(Object.entries(parsed.columnMap || {}).map(([k, v]) => [k, { index: v, label: FIELD_LABELS[k]?.ar || k }])),
    notice: 'تم استيراد البنود للمراجعة. لم يُعتمد أي بند ولم يُنقل إلى جدول الكميات.'
  });
}));

/** GET — list imports. */
router.get('/projects/:projectId/boq-imports', wrap(async (req, res) => {
  requireMember(req);
  const rows = getDB().prepare(
    'SELECT * FROM ai_boq_imports WHERE project_id=? ORDER BY created_at DESC'
  ).all(req.params.projectId);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    imports: rows.map(importView),
    summary: {
      total: rows.length,
      approved: rows.filter((r) => r.status === 'approved').length,
      pending: rows.filter((r) => r.status === 'imported_requires_review').length,
      totalLines: rows.reduce((s, r) => s + r.line_count, 0)
    }
  });
}));

/** GET — one import with its lines. */
router.get('/projects/:projectId/boq-imports/:importId', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_boq_imports WHERE id=? AND project_id=?')
    .get(req.params.importId, req.params.projectId);
  if (!row) throw E.notFound('استيراد جدول الكميات غير موجود.');
  const lines = db.prepare('SELECT * FROM ai_boq_import_lines WHERE import_id=? ORDER BY row_number').all(row.id);
  const views = lines.map(lineView);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    import: importView(row),
    lines: views,
    summary: {
      lines: views.length,
      proposed: views.filter((l) => l.linkState === 'proposed').length,
      confirmed: views.filter((l) => l.linkState === 'confirmed').length,
      rejected: views.filter((l) => l.linkState === 'rejected').length,
      unmatched: views.filter((l) => l.linkState === 'unmatched').length,
      importedTotal: Number(views.reduce((s, l) => s + (l.total || 0), 0).toFixed(3))
    }
  });
}));

/** POST — propose links between imported lines and measured quantities. */
router.post('/projects/:projectId/boq-imports/:importId/match', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_boq_imports WHERE id=? AND project_id=?')
    .get(req.params.importId, req.params.projectId);
  if (!row) throw E.notFound('استيراد جدول الكميات غير موجود.');

  const modelId = req.body?.modelId ? String(req.body.modelId).slice(0, 100) : row.model_id;
  if (!modelId) throw E.validation('حدد نموذج BIM لمطابقة البنود بكمياته.');

  const model = db.prepare('SELECT id FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(modelId, req.params.projectId);
  if (!model) throw E.notFound('نموذج BIM غير موجود في هذا المشروع.');

  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(model.id)
    .map((q) => ({
      ruleId: q.rule_id, unit: q.unit, quantity: q.quantity,
      description: q.description, descriptionAr: q.description_ar
    }));

  const lines = db.prepare('SELECT * FROM ai_boq_import_lines WHERE import_id=? ORDER BY row_number').all(row.id)
    .map((l) => ({
      rowNumber: l.row_number, itemCode: l.item_code, description: l.description,
      unit: l.unit, quantity: l.quantity
    }));

  const proposal = proposeBoqLinks(lines, quantities);

  db.transaction(() => {
    // Reset only proposals; a human decision is never overwritten by a re-run.
    db.prepare(`UPDATE ai_boq_import_lines SET matched_rule_id=NULL,matched_quantity=NULL,match_confidence=NULL,
      match_signals_json='{}',link_state='unmatched'
      WHERE import_id=? AND link_state IN ('proposed','unmatched')`).run(row.id);

    const byRow = new Map(proposal.links.map((l) => [l.rowNumber, l]));
    const update = db.prepare(`UPDATE ai_boq_import_lines
      SET matched_rule_id=?,matched_quantity=?,match_confidence=?,match_signals_json=?,link_state='proposed'
      WHERE import_id=? AND row_number=? AND link_state IN ('proposed','unmatched')`);
    for (const [rowNumber, link] of byRow) {
      update.run(link.ruleId, link.modelQuantity, link.confidence, JSON.stringify(link.signals), row.id, rowNumber);
    }
    db.prepare('UPDATE ai_boq_imports SET model_id=?,updated_at=unixepoch() WHERE id=?').run(model.id, row.id);
    audit(db, req, 'boq_import_matched', row.id, { modelId: model.id, ...proposal.summary });
  })();

  const updated = db.prepare('SELECT * FROM ai_boq_import_lines WHERE import_id=? ORDER BY row_number').all(row.id);
  res.json({
    importId: row.id,
    modelId: model.id,
    summary: proposal.summary,
    lines: updated.map(lineView),
    unmatched: proposal.unmatched,
    notice: 'الروابط مقترحة بدرجة ثقة. راجعها وأكّدها أو ارفضها قبل الاعتماد.'
  });
}));

/** PATCH — confirm or reject one line's link. */
router.patch('/projects/:projectId/boq-imports/:importId/lines/:lineId', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const line = db.prepare('SELECT * FROM ai_boq_import_lines WHERE id=? AND import_id=? AND project_id=?')
    .get(req.params.lineId, req.params.importId, req.params.projectId);
  if (!line) throw E.notFound('بند الاستيراد غير موجود.');

  const state = String(req.body?.state || '');
  if (!['confirmed', 'rejected', 'proposed', 'unmatched'].includes(state)) {
    throw E.validation('الحالة يجب أن تكون confirmed أو rejected أو proposed أو unmatched.');
  }
  if (state === 'confirmed' && !line.matched_rule_id) {
    throw E.conflict('لا يمكن تأكيد رابط غير موجود. شغّل المطابقة أولاً أو اربط البند يدوياً.');
  }

  // A manual override of the target rule is allowed, and is recorded as such.
  let ruleId = line.matched_rule_id;
  let modelQuantity = line.matched_quantity;
  let confidence = line.match_confidence;
  let signals = JSON.parse(line.match_signals_json || '{}');
  if (req.body?.ruleId !== undefined) {
    const wanted = String(req.body.ruleId || '').slice(0, 80);
    if (!wanted) throw E.validation('رقم البند المحسوب مطلوب.');
    const importRow = db.prepare('SELECT model_id FROM ai_boq_imports WHERE id=?').get(line.import_id);
    if (!importRow || !importRow.model_id) {
      throw E.conflict('لا يوجد نموذج مرتبط بهذا الاستيراد. شغّل المطابقة أولاً.');
    }
    const q = db.prepare('SELECT rule_id,quantity,unit FROM ai_bim_quantities WHERE model_id=? AND rule_id=?')
      .get(importRow.model_id, wanted);
    if (!q) throw E.notFound('بند الكميات المحسوب غير موجود في نموذج هذا الاستيراد.');
    ruleId = q.rule_id;
    modelQuantity = q.quantity;
    confidence = 1;
    signals = { ...signals, manualOverride: true };
  }

  db.prepare(`UPDATE ai_boq_import_lines
    SET matched_rule_id=?,matched_quantity=?,match_confidence=?,match_signals_json=?,link_state=?,decided_by=?,decided_at=unixepoch()
    WHERE id=?`).run(ruleId, modelQuantity, confidence, JSON.stringify(signals), state, req.user.id, line.id);
  audit(db, req, 'boq_import_line_' + state, line.id, { ruleId, confidence });

  res.json({ line: lineView(db.prepare('SELECT * FROM ai_boq_import_lines WHERE id=?').get(line.id)) });
}));

/** POST — approve the import (engineer). */
router.post('/projects/:projectId/boq-imports/:importId/approve', wrap(async (req, res) => {
  const m = requireMember(req);
  if (!APPROVE_ROLES.has(m.role)) {
    throw E.forbidden('اعتماد جدول الكميات المستورد متاح للمالك ومدير المشروع والمهندس فقط.');
  }
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_boq_imports WHERE id=? AND project_id=?')
    .get(req.params.importId, req.params.projectId);
  if (!row) throw E.notFound('استيراد جدول الكميات غير موجود.');

  const pending = db.prepare(
    "SELECT COUNT(*) AS n FROM ai_boq_import_lines WHERE import_id=? AND link_state='proposed'"
  ).get(row.id).n;
  if (pending > 0) {
    throw E.conflict('يوجد ' + pending + ' رابطاً مقترحاً لم يُحسم. أكّده أو ارفضه قبل الاعتماد.');
  }

  const now = Math.floor(Date.now() / 1000);
  db.transaction(() => {
    db.prepare("UPDATE ai_boq_imports SET status='approved',approved_by=?,approved_at=?,updated_at=unixepoch() WHERE id=?")
      .run(req.user.id, now, row.id);
    audit(db, req, 'boq_import_approved', row.id, { approvedBy: req.user.id });
  })();

  res.json({
    import: importView(db.prepare('SELECT * FROM ai_boq_imports WHERE id=?').get(row.id)),
    notice: 'تم اعتماد جدول الكميات المستورد. سُجّل من اعتمد ومتى.'
  });
}));

/** DELETE — remove an import and its lines. */
router.delete('/projects/:projectId/boq-imports/:importId', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const row = db.prepare('SELECT id,status FROM ai_boq_imports WHERE id=? AND project_id=?')
    .get(req.params.importId, req.params.projectId);
  if (!row) throw E.notFound('استيراد جدول الكميات غير موجود.');
  if (row.status === 'approved') {
    throw E.conflict('لا يمكن حذف استيراد معتمد. ارفضه أولاً أو أنشئ استيراداً جديداً.');
  }
  db.prepare('DELETE FROM ai_boq_imports WHERE id=?').run(row.id);
  audit(db, req, 'boq_import_deleted', row.id, {});
  res.json({ ok: true, id: row.id });
}));

module.exports = router;
