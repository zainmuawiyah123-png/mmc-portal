'use strict';
/**
 * BIM model API: build, store, measure, export IFC and import IFC.
 *
 * Every model is stored with its elements and its measured quantities. Nothing
 * is approved automatically: a model starts as `needs_review` and its quantity
 * rows as `measured_ready_for_review`, and only an explicit approval action by
 * an authorised member moves them forward.
 */
const express = require('express');
const crypto = require('node:crypto');
const multer = require('multer');
const { getDB, uid } = require('../db');
const { E, wrap } = require('../lib/errors');
const A = require('../lib/auth');
const { buildModel, measureModel, toQuantityRecords, QUANTITY_RULES, TYPE_LABELS } = require('../lib/mmc-ai/bim-model');
const { buildApprovedBoqWorkbook, partitionRows, provenanceOf } = require('../lib/mmc-ai/boq-export');
const { writeIfc } = require('../lib/mmc-ai/ifc-writer');
const { importIfc } = require('../lib/mmc-ai/ifc-importer');

const router = express.Router();
const EDIT_ROLES = new Set(['owner', 'project_manager', 'engineer', 'quantity_surveyor']);
const APPROVE_ROLES = new Set(['owner', 'project_manager', 'engineer']);
const MAX_IFC_BYTES = 80 * 1024 * 1024;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_IFC_BYTES, files: 1, fields: 4, fieldSize: 400 },
  fileFilter(req, file, cb) {
    const name = String(file.originalname || '').toLowerCase();
    if (!name.endsWith('.ifc')) return cb(E.validation('يُدعم استيراد ملفات IFC النصية (.ifc) فقط.'));
    cb(null, true);
  }
});

router.use(A.requireAuth);

function member(projectId, userId) {
  return getDB().prepare(
    'SELECT m.role,p.status FROM ai_project_members m JOIN ai_projects p ON p.id=m.project_id WHERE m.project_id=? AND m.user_id=?'
  ).get(projectId, userId) || null;
}

function requireMember(req) {
  const m = member(req.params.projectId, req.user.id);
  if (!m || m.status !== 'active') throw E.notFound('المشروع غير موجود.');
  return m;
}

function requireEdit(req) {
  const m = requireMember(req);
  if (!EDIT_ROLES.has(m.role)) throw E.forbidden('لا تملك صلاحية تعديل نموذج BIM.');
  return m;
}

function audit(db, req, action, entityId, detail) {
  db.prepare(
    'INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)'
  ).run(uid('aial_'), req.params.projectId, req.user.id, action, 'bim_model_store', entityId, JSON.stringify(detail || {}));
}

function modelView(row, { includeModel = false } = {}) {
  if (!row) return null;
  const out = {
    id: row.id,
    projectId: row.project_id,
    name: row.name,
    source: row.source,
    sourceModelId: row.source_model_id,
    revision: row.revision,
    units: row.units,
    storeyCount: row.storey_count,
    elementCount: row.element_count,
    countsByType: JSON.parse(row.counts_by_type_json || '{}'),
    bbox: row.bbox_json ? JSON.parse(row.bbox_json) : null,
    status: row.status,
    hasIfc: Boolean(row.ifc_text),
    ifcSha256: row.ifc_sha256,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
  if (includeModel) out.model = JSON.parse(row.model_json);
  return out;
}

function quantityView(row) {
  return {
    id: row.id,
    modelId: row.model_id,
    ruleId: row.rule_id,
    elementType: row.element_type,
    discipline: row.discipline,
    description: row.description,
    descriptionAr: row.description_ar,
    unit: row.unit,
    quantity: row.quantity,
    formula: row.formula,
    elementCount: row.element_count,
    elementIds: JSON.parse(row.element_ids_json || '[]'),
    storeyBreakdown: JSON.parse(row.storey_breakdown_json || '{}'),
    sources: JSON.parse(row.sources_json || '[]'),
    sourceLabel: row.source_label || null,
    measurementBasis: row.measurement_basis,
    reviewState: row.review_state,
    approvedBy: row.approved_by,
    approvedAt: row.approved_at
  };
}

/** Persists a built/imported model plus its measured quantities. */
function persistModel(db, req, { model, measurement, source, sourceModelId, revision, ifcText }) {
  const modelId = uid('aibimstore_');
  const ifcSha = ifcText ? crypto.createHash('sha256').update(ifcText).digest('hex') : null;
  db.transaction(() => {
    db.prepare(`INSERT INTO ai_bim_model_store
      (id,project_id,created_by,name,source,source_model_id,revision,units,storey_count,element_count,counts_by_type_json,bbox_json,model_json,ifc_text,ifc_sha256,status)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'needs_review')`).run(
      modelId, req.params.projectId, req.user.id, model.name, source, sourceModelId || null,
      revision || 'A', model.units || 'm', model.storeys.length, model.elements.length,
      JSON.stringify(model.countsByType || {}), model.bbox ? JSON.stringify(model.bbox) : null,
      JSON.stringify(model), ifcText || null, ifcSha
    );
    const addEl = db.prepare(`INSERT INTO ai_bim_model_elements
      (id,model_id,element_id,element_type,name,storey_id,host_element_id,length_m,width_m,height_m,volume_m3,area_m2,properties_json,source_json)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const el of model.elements) {
      addEl.run(
        uid('aibimel_'), modelId, el.id, el.type, el.name || null, el.storeyId || null, el.hostId || null,
        el.length ?? null, el.width ?? null, el.height ?? null,
        el.grossVolume ?? el.solid?.volume ?? null,
        el.netArea ?? el.grossArea ?? el.solid?.footprintArea ?? null,
        JSON.stringify(el.properties || {}),
        el.source ? JSON.stringify(el.source) : null
      );
    }
    const addQ = db.prepare(`INSERT INTO ai_bim_quantities
      (id,model_id,project_id,rule_id,element_type,discipline,description,description_ar,unit,quantity,formula,element_count,element_ids_json,storey_breakdown_json,measurement_basis,review_state,sources_json,source_label,element_values_json)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'measured_ready_for_review',?,?,?)`);
    for (const r of measurement.rows) {
      addQ.run(
        uid('aibimq_'), modelId, req.params.projectId, r.ruleId, r.elementType, r.discipline,
        r.description, r.descriptionAr || null, r.unit, r.quantity, r.formula,
        r.elementCount, JSON.stringify(r.elementIds), JSON.stringify(r.storeyBreakdown),
        r.measurementBasis,
        JSON.stringify(r.sources || []), r.sourceLabel || null,
        JSON.stringify(r.elementValues || [])
      );
    }
    audit(db, req, source === 'ifc_import' ? 'bim_model_imported' : 'bim_model_built', modelId, {
      source, elements: model.elements.length, quantities: measurement.rows.length, ifcSha256: ifcSha
    });
  })();
  return modelId;
}

/** POST /projects/:projectId/bim/model — build a model from a specification. */
router.post('/projects/:projectId/bim/model', wrap(async (req, res) => {
  requireEdit(req);
  const spec = req.body?.model || req.body;
  if (!spec || typeof spec !== 'object') throw E.validation('أرسل مواصفة النموذج في الحقل model.');
  let model;
  try {
    model = buildModel({ ...spec, projectId: req.params.projectId });
  } catch (err) {
    throw E.validation('تعذّر بناء النموذج: ' + err.message);
  }
  const measurement = measureModel(model, {
    projectId: req.params.projectId,
    modelId: 'pending',
    revision: String(req.body?.revision || 'A')
  });
  const db = getDB();
  const modelId = persistModel(db, req, {
    model, measurement, source: 'built', revision: String(req.body?.revision || 'A')
  });
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=?').get(modelId);
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(modelId);
  res.status(201).json({
    model: modelView(row),
    quantities: quantities.map(quantityView),
    totalsByUnit: measurement.totalsByUnit,
    unmeasurable: measurement.unmeasurable,
    notice: 'تم بناء النموذج وحصر الكميات من هندسته. كل الكميات مقترحة وتنتظر مراجعة المهندس.'
  });
}));

/** GET /projects/:projectId/bim/model — list stored models. */
router.get('/projects/:projectId/bim/model', wrap(async (req, res) => {
  requireMember(req);
  const rows = getDB().prepare(
    'SELECT * FROM ai_bim_model_store WHERE project_id=? ORDER BY created_at DESC'
  ).all(req.params.projectId);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    models: rows.map((r) => modelView(r)),
    summary: {
      total: rows.length,
      built: rows.filter((r) => r.source === 'built').length,
      imported: rows.filter((r) => r.source === 'ifc_import').length,
      approved: rows.filter((r) => r.status === 'approved').length
    }
  });
}));

/** GET /projects/:projectId/bim/model/:modelId — one model with elements and quantities. */
router.get('/projects/:projectId/bim/model/:modelId', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');
  const elements = db.prepare(
    'SELECT * FROM ai_bim_model_elements WHERE model_id=? ORDER BY element_type,element_id'
  ).all(row.id);
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(row.id);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    model: modelView(row, { includeModel: true }),
    elements: elements.map((e) => ({
      id: e.element_id,
      type: e.element_type,
      name: e.name,
      storeyId: e.storey_id,
      hostId: e.host_element_id,
      length: e.length_m,
      width: e.width_m,
      height: e.height_m,
      volume: e.volume_m3,
      area: e.area_m2,
      properties: JSON.parse(e.properties_json || '{}'),
      source: e.source_json ? JSON.parse(e.source_json) : null
    })),
    quantities: quantities.map(quantityView),
    totalsByUnit: quantities.reduce((acc, q) => {
      acc[q.unit] = Number(((acc[q.unit] || 0) + q.quantity).toFixed(6));
      return acc;
    }, {})
  });
}));

/** GET /projects/:projectId/bim/model/:modelId/quantities — quantity rows only. */
router.get('/projects/:projectId/bim/model/:modelId/quantities', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT id FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(row.id);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    modelId: row.id,
    quantities: quantities.map(quantityView),
    totalsByUnit: quantities.reduce((acc, q) => {
      acc[q.unit] = Number(((acc[q.unit] || 0) + q.quantity).toFixed(6));
      return acc;
    }, {}),
    rules: QUANTITY_RULES.map((r) => ({ id: r.id, type: r.type, unit: r.unit, label: r.label, formula: r.formula }))
  });
}));

/** GET /projects/:projectId/bim/model/:modelId/ifc — download the IFC export. */
router.get('/projects/:projectId/bim/model/:modelId/ifc', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');
  let text = row.ifc_text;
  // An imported model keeps the original file as its cached text. That file
  // has no boolean subtraction in it, so exporting it back would not show the
  // openings that were cut. When the model carries a cut, the export is
  // regenerated from the model so the file matches what the viewer draws.
  const storedModel = JSON.parse(row.model_json);
  const hasCut = (storedModel.openingCuts?.hosts || 0) > 0;
  if (!text || hasCut) {
    const written = writeIfc(storedModel, { projectName: row.name });
    text = written.text;
    db.prepare('UPDATE ai_bim_model_store SET ifc_text=?,ifc_sha256=?,updated_at=unixepoch() WHERE id=?')
      .run(text, crypto.createHash('sha256').update(text).digest('hex'), row.id);
  }
  audit(db, req, 'bim_model_ifc_exported', row.id, { bytes: Buffer.byteLength(text) });
  const safe = String(row.name).replace(/[^A-Za-z0-9_-]+/g, '_').slice(0, 60) || 'model';
  res.setHeader('Content-Type', 'application/x-step');
  res.setHeader('Content-Disposition', `attachment; filename="${safe}.ifc"`);
  res.setHeader('Cache-Control', 'private, no-store');
  res.send(text);
}));

/** POST /projects/:projectId/bim/model/import — import an IFC file. */
router.post('/projects/:projectId/bim/model/import', upload.single('file'), wrap(async (req, res) => {
  requireEdit(req);
  if (!req.file) throw E.validation('اختر ملف IFC للاستيراد.');
  const text = req.file.buffer.toString('utf8');
  let imported;
  try {
    imported = importIfc(text, { name: String(req.body?.name || req.file.originalname || 'Imported IFC').slice(0, 200), projectId: req.params.projectId });
  } catch (err) {
    throw E.validation('تعذّر قراءة ملف IFC: ' + err.message);
  }
  if (!imported.model.elements.length) {
    throw E.validation('لم يُعثر على عناصر هندسية قابلة للقياس في ملف IFC. العناصر غير المدعومة: ' +
      (Object.keys(imported.report.unsupportedElementTypes).join(', ') || 'لا يوجد'));
  }
  const measurement = measureModel(imported.model, {
    projectId: req.params.projectId, modelId: 'pending', revision: String(req.body?.revision || 'A')
  });
  const db = getDB();
  const modelId = persistModel(db, req, {
    model: imported.model, measurement, source: 'ifc_import',
    revision: String(req.body?.revision || 'A'), ifcText: text
  });
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=?').get(modelId);
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(modelId);
  res.status(201).json({
    model: modelView(row),
    importReport: imported.report,
    quantities: quantities.map(quantityView),
    totalsByUnit: measurement.totalsByUnit,
    notice: 'تم استيراد النموذج وحصر كمياته من هندسته. راجع العناصر المتجاهلة في تقرير الاستيراد.'
  });
}));

/** POST /projects/:projectId/bim/model/:modelId/approve — engineer approval. */
router.post('/projects/:projectId/bim/model/:modelId/approve', wrap(async (req, res) => {
  const m = requireMember(req);
  if (!APPROVE_ROLES.has(m.role)) throw E.forbidden('اعتماد الكميات متاح للمالك ومدير المشروع والمهندس فقط.');
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');
  const now = Math.floor(Date.now() / 1000);
  db.transaction(() => {
    db.prepare("UPDATE ai_bim_model_store SET status='approved',updated_at=unixepoch() WHERE id=?").run(row.id);
    db.prepare("UPDATE ai_bim_quantities SET review_state='approved',approved_by=?,approved_at=? WHERE model_id=?")
      .run(req.user.id, now, row.id);
    audit(db, req, 'bim_model_approved', row.id, { approvedBy: req.user.id });
  })();
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(row.id);
  res.json({
    model: modelView(db.prepare('SELECT * FROM ai_bim_model_store WHERE id=?').get(row.id)),
    quantities: quantities.map(quantityView),
    notice: 'تم اعتماد النموذج وكمياته. سُجّل من اعتمد ومتى.'
  });
}));

/** GET /projects/:projectId/bim/model/:modelId/boq-records — canonical records for the BOQ compiler. */
router.get('/projects/:projectId/bim/model/:modelId/boq-records', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');
  const model = JSON.parse(row.model_json);
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(row.id);
  const measurement = {
    projectId: row.project_id,
    modelId: row.id,
    revision: row.revision,
    rows: quantities.map((q) => ({
      ruleId: q.rule_id,
      elementType: q.element_type,
      discipline: q.discipline,
      description: q.description,
      descriptionAr: q.description_ar,
      unit: q.unit,
      quantity: q.quantity,
      formula: q.formula,
      elementCount: q.element_count,
      elementIds: JSON.parse(q.element_ids_json || '[]'),
      storeyBreakdown: JSON.parse(q.storey_breakdown_json || '{}'),
      sources: JSON.parse(q.sources_json || '[]'),
      measurementBasis: q.measurement_basis,
      reviewState: q.review_state
    }))
  };
  const records = toQuantityRecords(measurement, { storeys: model.storeys });
  res.setHeader('Cache-Control', 'no-store');
  res.json({ modelId: row.id, recordCount: records.length, records });
}));

/**
 * GET /projects/:projectId/bim/model/:modelId/boq-export.xlsx
 *
 * Exports the approved BOQ and cost to Excel. Only approved quantity rows are
 * exported; every row carries the drawing sheet/page it came from. Rows that
 * are not approved are listed on their own sheet with the reason, so the file
 * never looks complete when it is not.
 *
 * Query: ?scope=approved_only (default) | all
 *        ?includeUnapproved=1  — also write unapproved rows into the BOQ sheet,
 *                                clearly marked, for internal review copies.
 */
router.get('/projects/:projectId/bim/model/:modelId/boq-export.xlsx', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');

  const model = JSON.parse(row.model_json);
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(row.id);
  const costRows = db.prepare('SELECT * FROM ai_bim_cost_rows WHERE model_id=? ORDER BY unit,rule_id').all(row.id);
  const project = db.prepare('SELECT name FROM ai_projects WHERE id=?').get(req.params.projectId);
  const user = db.prepare('SELECT id,name FROM users WHERE id=?').get(req.user.id);

  const includeUnapproved = String(req.query.includeUnapproved || '') === '1';
  const scope = includeUnapproved ? 'all' : 'approved_only';

  // The export engine decides what may be exported from each row's own stored
  // review_state. `includeUnapproved` only changes the scope label and the
  // note in the file — it never promotes an unapproved row to approved.
  const built = buildApprovedBoqWorkbook({
    projectName: project ? project.name : '',
    modelName: row.name,
    modelRevision: row.revision,
    currency: costRows.length ? costRows[0].currency : 'OMR',
    quantities: quantities.map((q) => ({
      ruleId: q.rule_id, elementType: q.element_type, discipline: q.discipline,
      description: q.description, descriptionAr: q.description_ar, unit: q.unit,
      quantity: q.quantity, formula: q.formula, elementCount: q.element_count,
      storeyBreakdown: JSON.parse(q.storey_breakdown_json || '{}'),
      sources: JSON.parse(q.sources_json || '[]'),
      approvedBy: q.approved_by, approvedAt: q.approved_at,
      reviewState: q.review_state
    })),
    costRows: costRows.map((c) => ({
      ruleId: c.rule_id, unitRate: c.unit_rate, total: c.total, currency: c.currency,
      actualCost: c.actual_cost, variance: c.variance, reviewState: c.review_state,
      approvedBy: c.approved_by, approvedAt: c.approved_at
    })),
    storeys: model.storeys || [],
    generatedBy: user ? { id: user.id, name: user.name } : null,
    generatedAt: Math.floor(Date.now() / 1000),
    scope
  });

  const sha256 = crypto.createHash('sha256').update(built.buffer).digest('hex');
  const safe = String(row.name).replace(/[^A-Za-z0-9_-]+/g, '_').slice(0, 50) || 'model';
  const filename = `BOQ_${safe}_${row.revision}_${new Date().toISOString().slice(0, 10)}.xlsx`;

  db.prepare(`INSERT INTO ai_bim_exports
    (id,project_id,model_id,created_by,format,scope,filename,bytes,sha256,row_count,included_json,excluded_json)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    uid('aibimexp_'), req.params.projectId, row.id, req.user.id, 'xlsx', scope, filename,
    built.buffer.length, sha256, built.stats.approvedRows,
    JSON.stringify(built.stats), JSON.stringify({ excluded: built.stats.excludedRows })
  );
  audit(db, req, 'bim_boq_exported', row.id, {
    format: 'xlsx', scope, bytes: built.buffer.length, sha256,
    approvedRows: built.stats.approvedRows, excludedRows: built.stats.excludedRows
  });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Cache-Control', 'private, no-store');
  res.setHeader('X-Export-Sha256', sha256);
  res.setHeader('X-Export-Approved-Rows', String(built.stats.approvedRows));
  res.setHeader('X-Export-Excluded-Rows', String(built.stats.excludedRows));
  res.send(built.buffer);
}));

/**
 * GET /projects/:projectId/bim/model/:modelId/boq-export/preview
 * The same data the Excel file contains, as JSON, so the UI can show what will
 * be exported before the user downloads it.
 */
router.get('/projects/:projectId/bim/model/:modelId/boq-export/preview', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(row.id);
  const costRows = db.prepare('SELECT * FROM ai_bim_cost_rows WHERE model_id=? ORDER BY unit,rule_id').all(row.id);
  const { approved, excluded } = partitionRows({
    quantities: quantities.map((q) => ({
      ruleId: q.rule_id, elementType: q.element_type, discipline: q.discipline,
      description: q.description, descriptionAr: q.description_ar, unit: q.unit,
      quantity: q.quantity, formula: q.formula, elementCount: q.element_count,
      storeyBreakdown: JSON.parse(q.storey_breakdown_json || '{}'),
      sources: JSON.parse(q.sources_json || '[]'),
      approvedBy: q.approved_by, approvedAt: q.approved_at, reviewState: q.review_state
    })),
    costRows: costRows.map((c) => ({
      ruleId: c.rule_id, unitRate: c.unit_rate, total: c.total, currency: c.currency,
      actualCost: c.actual_cost, variance: c.variance, reviewState: c.review_state,
      approvedBy: c.approved_by, approvedAt: c.approved_at
    }))
  });
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    modelId: row.id,
    modelName: row.name,
    revision: row.revision,
    approvedCount: approved.length,
    excludedCount: excluded.length,
    approved: approved.map((r) => ({
      ruleId: r.ruleId,
      description: r.descriptionAr || r.description,
      unit: r.unit,
      quantity: r.quantity,
      unitRate: r.cost ? r.cost.unitRate : null,
      total: r.cost ? r.cost.total : null,
      costApproved: Boolean(r.cost && r.cost.approved),
      provenance: provenanceOf(r),
      approvedAt: r.approvedAt
    })),
    excluded,
    exports: db.prepare('SELECT id,filename,bytes,sha256,row_count,scope,created_at FROM ai_bim_exports WHERE model_id=? ORDER BY created_at DESC, rowid DESC LIMIT 10').all(row.id)
  });
}));

/**
 * GET /projects/:projectId/bim/model/:modelId/element-context
 *
 * One payload for the 3D viewer: every element with its explicit geometry
 * (vertices + faces, so the browser can draw the real solid rather than a
 * guessed box), plus the quantity rows, cost rows and schedule activity that
 * reference it. The viewer must never invent a link: an element with no
 * quantity, no cost and no activity comes back with empty arrays and the UI
 * says so.
 */
router.get('/projects/:projectId/bim/model/:modelId/element-context', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(req.params.modelId, req.params.projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');

  const model = JSON.parse(row.model_json);
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=?').all(row.id);
  const costRows = db.prepare('SELECT * FROM ai_bim_cost_rows WHERE model_id=?').all(row.id);
  const links = db.prepare(
    `SELECT l.element_id,l.activity_id,l.state,l.confidence,a.name,a.planned_start,a.planned_finish,
            a.percent_complete,a.duration_days,a.trade
       FROM ai_bim_element_links l
       JOIN ai_bim_activities a ON a.schedule_id=l.schedule_id AND a.activity_id=l.activity_id
      WHERE l.model_id=? AND l.state<>'rejected'`
  ).all(row.id);

  const byElement = new Map();
  const bucket = (id) => {
    if (!byElement.has(id)) byElement.set(id, { quantities: [], costs: [], activities: [] });
    return byElement.get(id);
  };
  for (const q of quantities) {
    // Per-element contribution when the row recorded it; otherwise the element
    // is listed as a contributor with no value rather than being given the
    // whole row total, which would multiply the quantity by the element count.
    const values = new Map();
    for (const v of JSON.parse(q.element_values_json || '[]')) values.set(v.elementId, v.value);
    for (const id of JSON.parse(q.element_ids_json || '[]')) {
      bucket(id).quantities.push({
        ruleId: q.rule_id, description: q.description, descriptionAr: q.description_ar,
        unit: q.unit,
        quantity: values.has(id) ? values.get(id) : null,
        rowTotal: q.quantity,
        elementCount: q.element_count,
        reviewState: q.review_state,
        approvedBy: q.approved_by, approvedAt: q.approved_at
      });
    }
  }
  for (const c of costRows) {
    // element_values_json holds each element's share of the row's money, not a
    // quantity: a cost row is priced per rule, so an element's cost is a share
    // of the row and is labelled as such in the viewer.
    const values = new Map();
    for (const v of JSON.parse(c.element_values_json || '[]')) values.set(v.elementId, v.value);
    const ids = JSON.parse(c.element_ids_json || '[]');
    for (const id of ids) {
      const share = values.has(id) ? values.get(id) : null;
      bucket(id).costs.push({
        ruleId: c.rule_id, description: c.description, unit: c.unit,
        quantity: null,
        unitRate: c.unit_rate,
        total: share,
        rowTotal: c.total,
        elementCount: ids.length,
        isShare: true,
        currency: c.currency, reviewState: c.review_state
      });
    }
  }
  for (const l of links) {
    bucket(l.element_id).activities.push({
      activityId: l.activity_id, name: l.name, trade: l.trade,
      plannedStart: l.planned_start, plannedFinish: l.planned_finish,
      durationDays: l.duration_days, percentComplete: l.percent_complete,
      linkState: l.state, confidence: l.confidence
    });
  }

  const elements = (model.elements || []).map((el) => {
    const ctx = byElement.get(el.id) || { quantities: [], costs: [], activities: [] };
    return {
      id: el.id,
      type: el.type,
      name: el.name,
      storeyId: el.storeyId,
      hostId: el.hostId || null,
      rotationDeg: el.rotationDeg || 0,
      dimensions: { length: el.length, width: el.width, height: el.height },
      volume: el.grossVolume ?? el.solid?.volume ?? null,
      netArea: el.netArea ?? null,
      netVolume: el.netVolume ?? null,
      properties: el.properties || {},
      source: el.source || null,
      // Built models keep the solid under `solid`; imported models keep the
      // resolved mesh at the top level. Both are the geometry the quantities
      // were measured from, so the viewer draws exactly that.
      //
      // `displaySolid` is the same body with its openings cut out. It is what
      // the viewer draws, so a window is a real hole you can see through. The
      // measured solid above is untouched, so no quantity moves.
      vertices: el.solid?.vertices || el.vertices || [],
      faces: el.solid?.faces || el.faces || [],
      displayVertices: el.displaySolid?.vertices || null,
      displayFaces: el.displaySolid?.faces || null,
      openingCut: el.displaySolid
        ? {
          mode: el.displaySolid.mode,
          boxCount: el.displaySolid.boxCount,
          openingsApplied: el.displaySolid.openingsApplied,
          removedVolume: el.displaySolid.removedVolume
        }
        : null,
      quantities: ctx.quantities,
      costs: ctx.costs,
      activities: ctx.activities
    };
  });

  res.setHeader('Cache-Control', 'private, no-store');
  res.json({
    model: {
      id: row.id, name: row.name, units: row.units, status: row.status,
      storeys: model.storeys || [], bbox: model.bbox || null,
      elementCount: elements.length, countsByType: model.countsByType || {}
    },
    elements,
    coverage: {
      withQuantities: elements.filter((e) => e.quantities.length).length,
      withCosts: elements.filter((e) => e.costs.length).length,
      withActivities: elements.filter((e) => e.activities.length).length,
      total: elements.length
    },
    notice: 'العناصر التي لا تحمل كمية أو تكلفة أو نشاطاً تُعرض فارغة ولا يُخترع لها ربط.'
  });
}));

/** GET /projects/:projectId/bim/element-types — the supported vocabulary. */
router.get('/projects/:projectId/bim/element-types', wrap(async (req, res) => {
  requireMember(req);
  res.setHeader('Cache-Control', 'private, max-age=300');
  res.json({
    elementTypes: Object.entries(TYPE_LABELS).map(([type, label]) => ({ type, label })),
    quantityRules: QUANTITY_RULES.map((r) => ({
      id: r.id, elementType: r.type, unit: r.unit, label: r.label, formula: r.formula, description: r.description
    }))
  });
}));

module.exports = router;
