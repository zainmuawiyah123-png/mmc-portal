'use strict';
/**
 * Aluminium joinery schedule API.
 *
 * POST   /projects/:projectId/aluminium/schedules            — build from a model
 * POST   /projects/:projectId/aluminium/schedules/import     — build from an uploaded file
 * GET    /projects/:projectId/aluminium/schedules            — list
 * GET    /projects/:projectId/aluminium/schedules/:id        — one schedule with openings and lines
 * PATCH  /projects/:projectId/aluminium/schedules/:id        — edit profiles / glass / accessories / waste
 * POST   /projects/:projectId/aluminium/schedules/:id/approve — engineer approval
 * GET    /projects/:projectId/aluminium/schedules/:id/export.xlsx — Excel export
 *
 * A schedule is always created as `draft_requires_review`. Editing the profile
 * table rebuilds the lines from the stored openings, so a price change is never
 * applied to a stale total.
 */
const express = require('express');
const multer = require('multer');
const { getDB, uid } = require('../db');
const { E, wrap } = require('../lib/errors');
const A = require('../lib/auth');
const {
  buildAluminiumSchedule, openingsFromModel, openingsFromRows,
  normalizeProfiles, normalizeGlass, normalizeAccessories, DEFAULT_PROFILES, DEFAULT_GLASS, DEFAULT_ACCESSORIES
} = require('../lib/mmc-ai/aluminium-schedule');
const { readXlsx, readCsv } = require('../lib/mmc-ai/xlsx-reader');
const { buildWorkbook } = require('../lib/mmc-ai/xlsx-writer');

const router = express.Router();
// Profiles first, then glass, then accessories — the order a schedule is read in.
const LINE_ORDER = "CASE category WHEN 'profile' THEN 1 WHEN 'glass' THEN 2 ELSE 3 END, code";
const EDIT_ROLES = new Set(['owner', 'project_manager', 'engineer', 'quantity_surveyor']);
const APPROVE_ROLES = new Set(['owner', 'project_manager', 'engineer']);
const MAX_BYTES = 20 * 1024 * 1024;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES, files: 1, fields: 6, fieldSize: 2000 },
  fileFilter(req, file, cb) {
    const name = String(file.originalname || '').toLowerCase();
    if (!name.endsWith('.xlsx') && !name.endsWith('.csv')) {
      return cb(E.validation('يُدعم استيراد جدول الفتحات من ملفات .xlsx و .csv فقط.'));
    }
    cb(null, true);
  }
});

router.use(A.requireAuth);

function member(projectId, userId) {
  return getDB().prepare(
    'SELECT m.role,p.status FROM ai_project_members m JOIN ai_projects p ON p.id=m.project_id WHERE m.project_id=? AND m.user_id=?'
  ).get(projectId, userId) || null;
}
function requireMember(req) {
  const m = member(req.params.projectId, req.user.id);
  if (!m || m.status !== 'active') throw E.notFound('المشروع غير موجود.');
  return m;
}
function requireEdit(req) {
  const m = requireMember(req);
  if (!EDIT_ROLES.has(m.role)) throw E.forbidden('لا تملك صلاحية إنشاء أو تعديل جدول الألمنيوم.');
  return m;
}
function audit(db, req, action, entityId, detail) {
  db.prepare(
    'INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)'
  ).run(uid('aial_'), req.params.projectId, req.user.id, action, 'aluminium_schedule', entityId, JSON.stringify(detail || {}));
}

function scheduleView(row) {
  return {
    id: row.id,
    projectId: row.project_id,
    modelId: row.model_id,
    name: row.name,
    source: row.source,
    sourceFilename: row.source_filename,
    currency: row.currency,
    barWastePercent: row.bar_waste_percent,
    profiles: JSON.parse(row.profiles_json || '{}'),
    glass: JSON.parse(row.glass_json || '{}'),
    accessories: JSON.parse(row.accessories_json || '[]'),
    openingCount: row.opening_count,
    totalAreaM2: row.total_area_m2,
    totalGlassM2: row.total_glass_m2,
    total: row.total,
    status: row.status,
    approvedBy: row.approved_by,
    approvedAt: row.approved_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function openingView(row) {
  return {
    id: row.opening_id,
    name: row.name,
    kind: row.kind,
    storeyId: row.storey_id,
    width: row.width_m,
    height: row.height_m,
    sillHeight: row.sill_height_m,
    panels: row.panels,
    leaves: row.leaves,
    transoms: row.transoms,
    frameWidthMm: row.frame_width_mm,
    areaM2: row.area_m2,
    lengths: {
      frameM: row.frame_m, sashM: row.sash_m, mullionM: row.mullion_m,
      transomM: row.transom_m, gasketM: row.gasket_m
    },
    glassM2: row.glass_m2,
    corners: row.corners,
    source: row.source_json ? JSON.parse(row.source_json) : null
  };
}

function lineView(row) {
  return {
    id: row.id,
    category: row.category,
    code: row.code,
    name: row.name,
    unit: row.unit,
    lengthM: row.length_m,
    barLengthM: row.bar_length_m,
    bars: row.bars,
    orderedLengthM: row.ordered_length_m,
    quantity: row.quantity,
    unitPrice: row.unit_price,
    total: row.total
  };
}

/** Persists a computed schedule and its rows. */
function persistSchedule(db, req, { result, name, source, sourceFilename, modelId }) {
  const id = uid('aialu_');
  db.transaction(() => {
    db.prepare(`INSERT INTO ai_aluminium_schedules
      (id,project_id,model_id,created_by,name,source,source_filename,currency,bar_waste_percent,
       profiles_json,glass_json,accessories_json,opening_count,total_area_m2,total_glass_m2,total,status)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'draft_requires_review')`).run(
      id, req.params.projectId, modelId || null, req.user.id, name, source, sourceFilename || null,
      result.currency, result.barWastePercent, JSON.stringify(result.profiles), JSON.stringify(result.glass),
      JSON.stringify(result.accessories), result.totals.openingCount, result.totals.totalAreaM2,
      result.totals.glassM2, result.total
    );
    const addOpening = db.prepare(`INSERT INTO ai_aluminium_openings
      (id,schedule_id,project_id,opening_id,name,kind,storey_id,width_m,height_m,sill_height_m,panels,leaves,transoms,
       frame_width_mm,area_m2,frame_m,sash_m,mullion_m,transom_m,gasket_m,glass_m2,corners,source_json)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const o of result.openings) {
      addOpening.run(
        uid('aialuop_'), id, req.params.projectId, o.id, o.name, o.kind, o.storeyId,
        o.width, o.height, o.sillHeight, o.panels, o.leaves, o.transoms, o.frameWidthMm,
        o.areaM2, o.lengths.frameM, o.lengths.sashM, o.lengths.mullionM, o.lengths.transomM,
        o.lengths.gasketM, o.glassM2, o.corners, o.source ? JSON.stringify(o.source) : null
      );
    }
    const addLine = db.prepare(`INSERT INTO ai_aluminium_lines
      (id,schedule_id,project_id,category,code,name,unit,length_m,bar_length_m,bars,ordered_length_m,quantity,unit_price,total)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const l of result.lines) {
      addLine.run(
        uid('aialuln_'), id, req.params.projectId, l.category, l.code, l.name, l.unit,
        l.lengthM ?? null, l.barLengthM ?? null, l.bars ?? null, l.orderedLengthM ?? null,
        l.quantity ?? null, l.unitPrice, l.total
      );
    }
    audit(db, req, 'aluminium_schedule_created', id, {
      source, openings: result.totals.openingCount, total: result.total, currency: result.currency
    });
  })();
  return id;
}

/** POST — build from a stored BIM model. */
router.post('/projects/:projectId/aluminium/schedules', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const modelId = String(req.body?.modelId || '').slice(0, 100);
  if (!modelId) throw E.validation('حدد نموذج BIM لبناء جدول الألمنيوم من فتحاته.');
  const modelRow = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?')
    .get(modelId, req.params.projectId);
  if (!modelRow) throw E.notFound('نموذج BIM غير موجود في هذا المشروع.');

  const model = JSON.parse(modelRow.model_json);
  const openings = openingsFromModel(model);
  if (!openings.length) {
    throw E.validation('النموذج لا يحتوي أي عنصر فتحة. أضف الأبواب والنوافذ إلى النموذج أو ارفع جدول فتحات.');
  }

  let result;
  try {
    result = buildAluminiumSchedule(openings, {
      profiles: req.body?.profiles, glass: req.body?.glass, accessories: req.body?.accessories,
      currency: req.body?.currency || 'OMR', barWastePercent: req.body?.barWastePercent
    });
  } catch (err) {
    throw E.validation('تعذّر بناء جدول الألمنيوم: ' + err.message);
  }

  const id = persistSchedule(db, req, {
    result, name: String(req.body?.name || 'جدول ألمنيوم — ' + modelRow.name).slice(0, 200),
    source: 'model', modelId: modelRow.id
  });
  const row = db.prepare('SELECT * FROM ai_aluminium_schedules WHERE id=?').get(id);
  const openingRows = db.prepare('SELECT * FROM ai_aluminium_openings WHERE schedule_id=? ORDER BY opening_id').all(id);
  const lineRows = db.prepare(`SELECT * FROM ai_aluminium_lines WHERE schedule_id=? ORDER BY ${LINE_ORDER}`).all(id);
  res.status(201).json({
    schedule: scheduleView(row),
    openings: openingRows.map(openingView),
    lines: lineRows.map(lineView),
    byKind: result.byKind,
    limitations: result.limitations,
    notice: 'الجدول مسودة وتنتظر مراجعة المهندس. لم يُعتمد أي سعر.'
  });
}));

/** POST — build from an uploaded opening schedule. */
router.post('/projects/:projectId/aluminium/schedules/import', upload.single('file'), wrap(async (req, res) => {
  requireEdit(req);
  if (!req.file) throw E.validation('اختر ملف جدول الفتحات (.xlsx أو .csv).');
  const name = String(req.file.originalname || '').toLowerCase();
  let rows;
  try {
    rows = name.endsWith('.csv') ? readCsv(req.file.buffer) : readXlsx(req.file.buffer).sheets[0].rows;
  } catch (err) {
    throw E.validation('تعذّر قراءة الملف: ' + err.message);
  }
  let openings;
  try {
    openings = openingsFromRows(rows);
  } catch (err) {
    throw E.validation(err.message);
  }
  let result;
  try {
    result = buildAluminiumSchedule(openings, {
      profiles: req.body?.profiles ? JSON.parse(req.body.profiles) : undefined,
      glass: req.body?.glass ? JSON.parse(req.body.glass) : undefined,
      accessories: req.body?.accessories ? JSON.parse(req.body.accessories) : undefined,
      currency: req.body?.currency || 'OMR',
      barWastePercent: req.body?.barWastePercent
    });
  } catch (err) {
    throw E.validation('تعذّر بناء جدول الألمنيوم: ' + err.message);
  }
  const db = getDB();
  const id = persistSchedule(db, req, {
    result, name: String(req.body?.name || 'جدول ألمنيوم — ' + req.file.originalname).slice(0, 200),
    source: 'file', sourceFilename: String(req.file.originalname).slice(0, 200)
  });
  const row = db.prepare('SELECT * FROM ai_aluminium_schedules WHERE id=?').get(id);
  const openingRows = db.prepare('SELECT * FROM ai_aluminium_openings WHERE schedule_id=? ORDER BY opening_id').all(id);
  const lineRows = db.prepare(`SELECT * FROM ai_aluminium_lines WHERE schedule_id=? ORDER BY ${LINE_ORDER}`).all(id);
  res.status(201).json({
    schedule: scheduleView(row),
    openings: openingRows.map(openingView),
    lines: lineRows.map(lineView),
    byKind: result.byKind,
    limitations: result.limitations,
    notice: 'الجدول مسودة وتنتظر مراجعة المهندس.'
  });
}));

/** GET — list schedules. */
router.get('/projects/:projectId/aluminium/schedules', wrap(async (req, res) => {
  requireMember(req);
  const rows = getDB().prepare(
    'SELECT * FROM ai_aluminium_schedules WHERE project_id=? ORDER BY created_at DESC'
  ).all(req.params.projectId);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    schedules: rows.map(scheduleView),
    summary: {
      total: rows.length,
      approved: rows.filter((r) => r.status === 'approved').length,
      draft: rows.filter((r) => r.status === 'draft_requires_review').length,
      totalValue: Number(rows.reduce((s, r) => s + r.total, 0).toFixed(3))
    },
    defaults: { profiles: DEFAULT_PROFILES, glass: DEFAULT_GLASS, accessories: DEFAULT_ACCESSORIES }
  });
}));

/** GET — one schedule. */
router.get('/projects/:projectId/aluminium/schedules/:scheduleId', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_aluminium_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('جدول الألمنيوم غير موجود.');
  const openings = db.prepare('SELECT * FROM ai_aluminium_openings WHERE schedule_id=? ORDER BY opening_id').all(row.id);
  const lines = db.prepare(`SELECT * FROM ai_aluminium_lines WHERE schedule_id=? ORDER BY ${LINE_ORDER}`).all(row.id);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    schedule: scheduleView(row),
    openings: openings.map(openingView),
    lines: lines.map(lineView),
    totals: {
      openingCount: row.opening_count,
      totalAreaM2: row.total_area_m2,
      totalGlassM2: row.total_glass_m2,
      total: row.total
    }
  });
}));

/** PATCH — edit profiles / glass / accessories / waste and rebuild the lines. */
router.patch('/projects/:projectId/aluminium/schedules/:scheduleId', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_aluminium_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('جدول الألمنيوم غير موجود.');
  if (row.status === 'approved') {
    throw E.conflict('لا يمكن تعديل جدول معتمد. أنشئ جدولاً جديداً للتعديل.');
  }

  const profiles = req.body?.profiles === undefined ? JSON.parse(row.profiles_json || '{}') : normalizeProfiles(req.body.profiles);
  const glass = req.body?.glass === undefined ? JSON.parse(row.glass_json || '{}') : normalizeGlass(req.body.glass);
  const accessories = req.body?.accessories === undefined ? JSON.parse(row.accessories_json || '[]') : normalizeAccessories(req.body.accessories);
  const waste = req.body?.barWastePercent === undefined ? row.bar_waste_percent : Number(req.body.barWastePercent);
  const currency = req.body?.currency === undefined ? row.currency : String(req.body.currency).slice(0, 8);
  const name = req.body?.name === undefined ? row.name : String(req.body.name).trim().slice(0, 200);
  if (!name || name.length < 3) throw E.validation('اسم الجدول مطلوب.');

  const openingRows = db.prepare('SELECT * FROM ai_aluminium_openings WHERE schedule_id=? ORDER BY opening_id').all(row.id);
  const openings = openingRows.map((o) => ({
    id: o.opening_id, name: o.name, kind: o.kind, storeyId: o.storey_id,
    width: o.width_m, height: o.height_m, sillHeight: o.sill_height_m,
    panels: o.panels, leaves: o.leaves, transoms: o.transoms, frameWidthMm: o.frame_width_mm,
    source: o.source_json ? JSON.parse(o.source_json) : null
  }));

  let result;
  try {
    result = buildAluminiumSchedule(openings, { profiles, glass, accessories, currency, barWastePercent: waste });
  } catch (err) {
    throw E.validation('تعذّر إعادة حساب الجدول: ' + err.message);
  }

  db.transaction(() => {
    db.prepare(`UPDATE ai_aluminium_schedules SET name=?,currency=?,bar_waste_percent=?,profiles_json=?,glass_json=?,
      accessories_json=?,opening_count=?,total_area_m2=?,total_glass_m2=?,total=?,updated_at=unixepoch() WHERE id=?`).run(
      name, result.currency, result.barWastePercent, JSON.stringify(result.profiles), JSON.stringify(result.glass),
      JSON.stringify(result.accessories), result.totals.openingCount, result.totals.totalAreaM2,
      result.totals.glassM2, result.total, row.id
    );
    db.prepare('DELETE FROM ai_aluminium_lines WHERE schedule_id=?').run(row.id);
    const addLine = db.prepare(`INSERT INTO ai_aluminium_lines
      (id,schedule_id,project_id,category,code,name,unit,length_m,bar_length_m,bars,ordered_length_m,quantity,unit_price,total)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const l of result.lines) {
      addLine.run(
        uid('aialuln_'), row.id, req.params.projectId, l.category, l.code, l.name, l.unit,
        l.lengthM ?? null, l.barLengthM ?? null, l.bars ?? null, l.orderedLengthM ?? null,
        l.quantity ?? null, l.unitPrice, l.total
      );
    }
    audit(db, req, 'aluminium_schedule_updated', row.id, { total: result.total, currency: result.currency });
  })();

  const updated = db.prepare('SELECT * FROM ai_aluminium_schedules WHERE id=?').get(row.id);
  const lines = db.prepare(`SELECT * FROM ai_aluminium_lines WHERE schedule_id=? ORDER BY ${LINE_ORDER}`).all(row.id);
  res.json({
    schedule: scheduleView(updated),
    lines: lines.map(lineView),
    notice: 'أُعيد حساب الجدول بالأسعار والمقاطع الجديدة. ما زال مسودة.'
  });
}));

/** POST — approve. */
router.post('/projects/:projectId/aluminium/schedules/:scheduleId/approve', wrap(async (req, res) => {
  const m = requireMember(req);
  if (!APPROVE_ROLES.has(m.role)) {
    throw E.forbidden('اعتماد جدول الألمنيوم متاح للمالك ومدير المشروع والمهندس فقط.');
  }
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_aluminium_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('جدول الألمنيوم غير موجود.');
  const now = Math.floor(Date.now() / 1000);
  db.transaction(() => {
    db.prepare("UPDATE ai_aluminium_schedules SET status='approved',approved_by=?,approved_at=?,updated_at=unixepoch() WHERE id=?")
      .run(req.user.id, now, row.id);
    audit(db, req, 'aluminium_schedule_approved', row.id, { approvedBy: req.user.id, total: row.total });
  })();
  res.json({
    schedule: scheduleView(db.prepare('SELECT * FROM ai_aluminium_schedules WHERE id=?').get(row.id)),
    notice: 'تم اعتماد جدول الألمنيوم. سُجّل من اعتمد ومتى.'
  });
}));

/** GET — Excel export. */
router.get('/projects/:projectId/aluminium/schedules/:scheduleId/export.xlsx', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_aluminium_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('جدول الألمنيوم غير موجود.');
  const openings = db.prepare('SELECT * FROM ai_aluminium_openings WHERE schedule_id=? ORDER BY opening_id').all(row.id);
  const lines = db.prepare(`SELECT * FROM ai_aluminium_lines WHERE schedule_id=? ORDER BY ${LINE_ORDER}`).all(row.id);
  const project = db.prepare('SELECT name FROM ai_projects WHERE id=?').get(req.params.projectId);
  const approver = row.approved_by ? db.prepare('SELECT name FROM users WHERE id=?').get(row.approved_by) : null;

  const approved = row.status === 'approved';
  const sheet1 = {
    name: 'جدول الألمنيوم',
    title: 'جدول الألمنيوم — ' + row.name,
    note: 'المشروع: ' + (project?.name || '') + ' · العملة: ' + row.currency +
      ' · الحالة: ' + (approved ? 'معتمد' : 'مسودة — لم يُعتمد') +
      (approved ? ' · اعتمد بواسطة: ' + (approver?.name || row.approved_by) + ' في ' + new Date(row.approved_at * 1000).toISOString().slice(0, 10) : ''),
    columns: [
      { header: 'م', width: 6 }, { header: 'الفئة', width: 14 }, { header: 'الكود', width: 14 },
      { header: 'الوصف', width: 34 }, { header: 'الوحدة', width: 10 }, { header: 'الطول (م)', width: 12 },
      { header: 'طول القضيب (م)', width: 14 }, { header: 'عدد القضبان', width: 12 },
      { header: 'الكمية', width: 12 }, { header: 'سعر الوحدة', width: 12 }, { header: 'الإجمالي', width: 14 }
    ],
    rows: lines.map((l, i) => [
      i + 1,
      l.category === 'profile' ? 'مقطع' : l.category === 'glass' ? 'زجاج' : 'ملحق',
      l.code, l.name, l.unit,
      l.length_m ?? '', l.bar_length_m ?? '', l.bars ?? '',
      l.quantity ?? '', l.unit_price, l.total
    ]),
    totals: ['', '', '', 'الإجمالي', '', '', '', '', '', '', Number(row.total.toFixed(3))]
  };

  const sheet2 = {
    name: 'الفتحات',
    title: 'تفصيل الفتحات',
    note: 'كل فتحة بأبعادها وأطوال مقاطعها ومساحة زجاجها.',
    columns: [
      { header: 'الرمز', width: 12 }, { header: 'الاسم', width: 30 }, { header: 'النوع', width: 14 },
      { header: 'الطابق', width: 12 }, { header: 'العرض (م)', width: 12 }, { header: 'الارتفاع (م)', width: 12 },
      { header: 'المساحة (م²)', width: 12 }, { header: 'أقسام', width: 8 }, { header: 'ضلف', width: 8 },
      { header: 'إطار (م)', width: 10 }, { header: 'ساش (م)', width: 10 }, { header: 'قائم (م)', width: 10 },
      { header: 'عارضة (م)', width: 10 }, { header: 'زجاج (م²)', width: 12 }
    ],
    rows: openings.map((o) => [
      o.opening_id, o.name || '', o.kind, o.storey_id || '', o.width_m, o.height_m, o.area_m2,
      o.panels, o.leaves, o.frame_m, o.sash_m, o.mullion_m, o.transom_m, o.glass_m2
    ]),
    totals: ['', '', '', '', '', '', Number(openings.reduce((s, o) => s + o.area_m2, 0).toFixed(3)), '', '', '', '', '', '', Number(openings.reduce((s, o) => s + o.glass_m2, 0).toFixed(3))]
  };

  const sheet3 = {
    name: 'المقاطع والأسعار',
    title: 'المقاطع والأسعار المستخدمة',
    note: 'هذه هي القيم التي حُسب بها الجدول. عدّلها من الواجهة ثم أعد الحساب.',
    columns: [
      { header: 'البند', width: 18 }, { header: 'الكود', width: 14 }, { header: 'الاسم', width: 30 },
      { header: 'طول القضيب (م)', width: 14 }, { header: 'سعر الوحدة', width: 12 }
    ],
    rows: [
      ...Object.entries(JSON.parse(row.profiles_json || '{}')).map(([k, p]) => [k, p.code, p.name, p.barLengthM, p.unitPrice]),
      ['glass', JSON.parse(row.glass_json || '{}').code, JSON.parse(row.glass_json || '{}').name, '', JSON.parse(row.glass_json || '{}').unitPrice]
    ]
  };

  const buf = buildWorkbook({ sheets: [sheet1, sheet2, sheet3] });
  audit(db, req, 'aluminium_schedule_exported', row.id, { bytes: buf.length });
  const safe = String(row.name).replace(/[^A-Za-z0-9_-]+/g, '_').slice(0, 50) || 'aluminium';
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${safe}.xlsx"`);
  res.setHeader('Cache-Control', 'private, no-store');
  res.send(buf);
}));

module.exports = router;
