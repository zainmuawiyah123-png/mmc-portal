'use strict';
/**
 * Risk analysis API.
 *
 * POST   /projects/:projectId/risk-analysis                 — analyse project data
 * GET    /projects/:projectId/risk-analysis                 — list analyses
 * GET    /projects/:projectId/risk-analysis/:analysisId     — one analysis with its register
 * PATCH  /projects/:projectId/risk-analysis/:analysisId/risks/:riskId — edit a risk
 * POST   /projects/:projectId/risk-analysis/:analysisId/approve — engineer approval
 *
 * The analysis reads the project's own model, quantities, schedule, cost,
 * specifications and BOQ import. It never invents a risk without evidence, and
 * it never approves anything: the register starts `proposed`.
 */
const express = require('express');
const { getDB, uid } = require('../db');
const { E, wrap } = require('../lib/errors');
const A = require('../lib/auth');
const { analyseRisks, levelOf } = require('../lib/mmc-ai/risk-analysis');

const router = express.Router();
const EDIT_ROLES = new Set(['owner', 'project_manager', 'engineer', 'quantity_surveyor']);
const APPROVE_ROLES = new Set(['owner', 'project_manager', 'engineer']);

router.use(A.requireAuth);

function member(projectId, userId) {
  return getDB().prepare(
    'SELECT m.role,p.status FROM ai_project_members m JOIN ai_projects p ON p.id=m.project_id WHERE m.project_id=? AND m.user_id=?'
  ).get(projectId, userId) || null;
}
function requireMember(req) {
  const m = member(req.params.projectId, req.user.id);
  if (!m || m.status !== 'active') throw E.notFound('المشروع غير موجود.');
  return m;
}
function requireEdit(req) {
  const m = requireMember(req);
  if (!EDIT_ROLES.has(m.role)) throw E.forbidden('لا تملك صلاحية تحليل المخاطر أو تعديل سجلها.');
  return m;
}
function audit(db, req, action, entityId, detail) {
  db.prepare(
    'INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)'
  ).run(uid('aial_'), req.params.projectId, req.user.id, action, 'risk_analysis', entityId, JSON.stringify(detail || {}));
}

function analysisView(row) {
  return {
    id: row.id,
    projectId: row.project_id,
    modelId: row.model_id,
    asOf: row.as_of,
    riskCount: row.risk_count,
    criticalCount: row.critical_count,
    highCount: row.high_count,
    summary: JSON.parse(row.summary_json || '{}'),
    inputs: JSON.parse(row.inputs_json || '{}'),
    limitations: JSON.parse(row.limitations_json || '[]'),
    status: row.status,
    approvedBy: row.approved_by,
    approvedAt: row.approved_at,
    createdAt: row.created_at
  };
}

function riskView(row) {
  return {
    id: row.id,
    code: row.risk_code,
    title: row.title,
    category: row.category,
    description: row.description,
    probability: row.probability,
    impact: row.impact,
    score: row.score,
    level: row.level,
    levelLabel: levelOf(row.score).ar,
    response: row.response,
    owner: row.owner_name,
    evidence: JSON.parse(row.evidence_json || '[]'),
    source: row.source,
    state: row.state,
    decidedBy: row.decided_by,
    decidedAt: row.decided_at
  };
}

/** Gathers the project's real data for the analysis. */
function collectInputs(db, projectId, modelId, asOf) {
  const modelRow = modelId
    ? db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?').get(modelId, projectId)
    : db.prepare('SELECT * FROM ai_bim_model_store WHERE project_id=? ORDER BY created_at DESC LIMIT 1').get(projectId);

  const model = modelRow ? JSON.parse(modelRow.model_json) : null;
  const quantities = modelRow
    ? db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=?').all(modelRow.id).map((q) => ({
      ruleId: q.rule_id, unit: q.unit, quantity: q.quantity, reviewState: q.review_state,
      description: q.description, descriptionAr: q.description_ar, elementType: q.element_type
    }))
    : [];

  // The most recent schedule for this model, if any.
  const scheduleRow = modelRow
    ? db.prepare('SELECT * FROM ai_bim_schedules WHERE model_id=? ORDER BY created_at DESC LIMIT 1').get(modelRow.id)
    : null;
  const activities = scheduleRow
    ? db.prepare('SELECT * FROM ai_bim_activities WHERE schedule_id=? ORDER BY planned_start').all(scheduleRow.id).map((a) => ({
      name: a.name, plannedStart: a.planned_start, plannedFinish: a.planned_finish,
      percentComplete: a.percent_complete, durationDays: a.duration_days,
      status: a.percent_complete >= 100 ? 'completed' : (a.actual_start ? 'in_progress' : 'planned')
    }))
    : [];

  const costRows = modelRow
    ? db.prepare('SELECT * FROM ai_bim_cost_rows WHERE model_id=?').all(modelRow.id).map((r) => ({
      ruleId: r.rule_id, unit: r.unit, quantity: r.quantity, unitRate: r.unit_rate, total: r.total,
      description: r.description, reviewState: r.review_state
    }))
    : [];
  const costTotal = Number(costRows.reduce((s, r) => s + Number(r.total || 0), 0).toFixed(3));
  const costApproved = costRows.length > 0 && costRows.every((r) => r.reviewState === 'approved');

  const specDocs = db.prepare('SELECT * FROM ai_spec_documents WHERE project_id=?').all(projectId);
  const clauseCount = specDocs.reduce((s, d) => s + d.clause_count, 0);
  const linkedClauses = db.prepare(`SELECT COUNT(DISTINCT c.id) AS n FROM ai_spec_links l
    JOIN ai_spec_clauses c ON c.id=l.clause_id WHERE l.project_id=? AND l.state IN ('proposed','confirmed')`)
    .get(projectId).n;

  const boqImports = db.prepare('SELECT * FROM ai_boq_imports WHERE project_id=?').all(projectId);
  const importedLines = boqImports.reduce((s, i) => s + i.line_count, 0);
  const unmatchedLines = db.prepare(
    "SELECT COUNT(*) AS n FROM ai_boq_import_lines WHERE project_id=? AND link_state='unmatched'"
  ).get(projectId).n;

  return {
    model, modelId: modelRow ? modelRow.id : null, quantities,
    schedule: { activities, projectStart: scheduleRow?.project_start || null, projectFinish: scheduleRow?.project_finish || null, status: scheduleRow?.status || null },
    cost: { rows: costRows, total: costTotal, currency: costRows[0]?.currency || 'OMR', approved: costApproved },
    specs: {
      clauseCount, linkedCount: linkedClauses, unlinkedCount: Math.max(0, clauseCount - linkedClauses),
      documents: specDocs.map((d) => ({ name: d.original_name, format: d.format, clauses: d.clause_count }))
    },
    boq: { importedLines, unmatched: unmatchedLines },
    asOf
  };
}

/** POST — run the analysis. */
router.post('/projects/:projectId/risk-analysis', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const asOf = req.body?.asOf ? String(req.body.asOf) : new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(asOf) || Number.isNaN(Date.parse(asOf))) {
    throw E.validation('تاريخ التحليل يجب أن يكون بصيغة YYYY-MM-DD.');
  }
  const modelId = req.body?.modelId ? String(req.body.modelId).slice(0, 100) : null;
  if (modelId) {
    const exists = db.prepare('SELECT id FROM ai_bim_model_store WHERE id=? AND project_id=?').get(modelId, req.params.projectId);
    if (!exists) throw E.notFound('نموذج BIM غير موجود في هذا المشروع.');
  }

  const inputs = collectInputs(db, req.params.projectId, modelId, asOf);
  const result = analyseRisks(inputs);

  const analysisId = uid('airisk_an_');
  db.transaction(() => {
    db.prepare(`INSERT INTO ai_risk_analyses
      (id,project_id,model_id,created_by,as_of,risk_count,critical_count,high_count,summary_json,inputs_json,limitations_json,status)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,'draft_requires_review')`).run(
      analysisId, req.params.projectId, inputs.modelId, req.user.id, asOf,
      result.summary.total, result.summary.critical, result.summary.high,
      JSON.stringify(result.summary),
      JSON.stringify({
        modelId: inputs.modelId, elementCount: inputs.model?.elements?.length || 0,
        quantityCount: inputs.quantities.length, activityCount: inputs.schedule.activities.length,
        costTotal: inputs.cost.total, costApproved: inputs.cost.approved,
        specClauses: inputs.specs.clauseCount, boqImportedLines: inputs.boq.importedLines
      }),
      JSON.stringify(result.limitations)
    );
    const addRisk = db.prepare(`INSERT INTO ai_risk_register
      (id,analysis_id,project_id,risk_code,title,category,description,probability,impact,score,level,response,owner_name,evidence_json,source,state)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'proposed')`);
    for (const r of result.risks) {
      addRisk.run(
        uid('airisk_r_'), analysisId, req.params.projectId, r.code, r.title, r.category, r.description,
        r.probability, r.impact, r.score, r.level, r.response, r.owner || null,
        JSON.stringify(r.evidence || []), r.source
      );
    }
    audit(db, req, 'risk_analysis_created', analysisId, { risks: result.summary.total, asOf });
  })();

  const row = db.prepare('SELECT * FROM ai_risk_analyses WHERE id=?').get(analysisId);
  const risks = db.prepare('SELECT * FROM ai_risk_register WHERE analysis_id=? ORDER BY score DESC,risk_code').all(analysisId);
  res.status(201).json({
    analysis: analysisView(row),
    risks: risks.map(riskView),
    limitations: result.limitations,
    notice: 'سجل المخاطر مقترح من بيانات المشروع. راجعه وعدّله ثم اعتمده.'
  });
}));

/** GET — list analyses. */
router.get('/projects/:projectId/risk-analysis', wrap(async (req, res) => {
  requireMember(req);
  const rows = getDB().prepare(
    'SELECT * FROM ai_risk_analyses WHERE project_id=? ORDER BY created_at DESC'
  ).all(req.params.projectId);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    analyses: rows.map(analysisView),
    summary: {
      total: rows.length,
      approved: rows.filter((r) => r.status === 'approved').length,
      latestCritical: rows[0]?.critical_count ?? null
    }
  });
}));

/** GET — one analysis with its register. */
router.get('/projects/:projectId/risk-analysis/:analysisId', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_risk_analyses WHERE id=? AND project_id=?')
    .get(req.params.analysisId, req.params.projectId);
  if (!row) throw E.notFound('تحليل المخاطر غير موجود.');
  const risks = db.prepare('SELECT * FROM ai_risk_register WHERE analysis_id=? ORDER BY score DESC,risk_code').all(row.id);
  const views = risks.map(riskView);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    analysis: analysisView(row),
    risks: views,
    summary: {
      total: views.length,
      critical: views.filter((r) => r.level === 'critical').length,
      high: views.filter((r) => r.level === 'high').length,
      moderate: views.filter((r) => r.level === 'moderate').length,
      low: views.filter((r) => r.level === 'low').length,
      accepted: views.filter((r) => r.state === 'accepted').length,
      proposed: views.filter((r) => r.state === 'proposed').length
    }
  });
}));

/** PATCH — edit one risk (probability, impact, response, owner, state). */
router.patch('/projects/:projectId/risk-analysis/:analysisId/risks/:riskId', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const analysis = db.prepare('SELECT * FROM ai_risk_analyses WHERE id=? AND project_id=?')
    .get(req.params.analysisId, req.params.projectId);
  if (!analysis) throw E.notFound('تحليل المخاطر غير موجود.');
  if (analysis.status === 'approved') {
    throw E.conflict('لا يمكن تعديل سجل مخاطر معتمد. أنشئ تحليلاً جديداً.');
  }
  const risk = db.prepare('SELECT * FROM ai_risk_register WHERE id=? AND analysis_id=?')
    .get(req.params.riskId, analysis.id);
  if (!risk) throw E.notFound('الخطر غير موجود.');

  const num5 = (v, label) => {
    const n = Number(v);
    if (!Number.isInteger(n) || n < 1 || n > 5) throw E.validation(label + ' يجب أن يكون من 1 إلى 5.');
    return n;
  };
  const probability = req.body?.probability === undefined ? risk.probability : num5(req.body.probability, 'الاحتمالية');
  const impact = req.body?.impact === undefined ? risk.impact : num5(req.body.impact, 'الأثر');
  const response = req.body?.response === undefined ? risk.response : String(req.body.response).trim().slice(0, 4000);
  const owner = req.body?.owner === undefined ? risk.owner_name : (String(req.body.owner || '').trim().slice(0, 160) || null);
  const title = req.body?.title === undefined ? risk.title : String(req.body.title).trim().slice(0, 240);
  const description = req.body?.description === undefined ? risk.description : String(req.body.description).trim().slice(0, 4000);
  const state = req.body?.state === undefined ? risk.state : String(req.body.state);
  if (!['proposed', 'accepted', 'rejected', 'closed'].includes(state)) {
    throw E.validation('حالة الخطر يجب أن تكون proposed أو accepted أو rejected أو closed.');
  }
  if (title.length < 3 || description.length < 5) throw E.validation('عنوان الخطر ووصفه مطلوبان.');

  const score = probability * impact;
  const level = levelOf(score).key;
  db.prepare(`UPDATE ai_risk_register SET title=?,description=?,probability=?,impact=?,score=?,level=?,response=?,
    owner_name=?,state=?,decided_by=?,decided_at=unixepoch(),updated_at=unixepoch() WHERE id=?`).run(
    title, description, probability, impact, score, level, response, owner, state, req.user.id, risk.id
  );
  audit(db, req, 'risk_updated', risk.id, { score, level, state });

  // Keep the analysis counters honest after an edit.
  const all = db.prepare('SELECT score FROM ai_risk_register WHERE analysis_id=?').all(analysis.id);
  db.prepare('UPDATE ai_risk_analyses SET critical_count=?,high_count=?,updated_at=unixepoch() WHERE id=?').run(
    all.filter((r) => r.score >= 15).length, all.filter((r) => r.score >= 10 && r.score < 15).length, analysis.id
  );

  res.json({ risk: riskView(db.prepare('SELECT * FROM ai_risk_register WHERE id=?').get(risk.id)) });
}));

/** POST — approve the analysis. */
router.post('/projects/:projectId/risk-analysis/:analysisId/approve', wrap(async (req, res) => {
  const m = requireMember(req);
  if (!APPROVE_ROLES.has(m.role)) {
    throw E.forbidden('اعتماد تحليل المخاطر متاح للمالك ومدير المشروع والمهندس فقط.');
  }
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_risk_analyses WHERE id=? AND project_id=?')
    .get(req.params.analysisId, req.params.projectId);
  if (!row) throw E.notFound('تحليل المخاطر غير موجود.');
  const pending = db.prepare("SELECT COUNT(*) AS n FROM ai_risk_register WHERE analysis_id=? AND state='proposed'")
    .get(row.id).n;
  if (pending > 0) {
    throw E.conflict('يوجد ' + pending + ' خطراً بحالة «مقترح» لم يُحسم. اقبله أو ارفضه قبل الاعتماد.');
  }
  const now = Math.floor(Date.now() / 1000);
  db.transaction(() => {
    db.prepare("UPDATE ai_risk_analyses SET status='approved',approved_by=?,approved_at=?,updated_at=unixepoch() WHERE id=?")
      .run(req.user.id, now, row.id);
    audit(db, req, 'risk_analysis_approved', row.id, { approvedBy: req.user.id });
  })();
  res.json({
    analysis: analysisView(db.prepare('SELECT * FROM ai_risk_analyses WHERE id=?').get(row.id)),
    notice: 'تم اعتماد سجل المخاطر. سُجّل من اعتمد ومتى.'
  });
}));

module.exports = router;
