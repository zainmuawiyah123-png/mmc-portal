'use strict';
/**
 * Specification import and linking API.
 *
 * POST   /projects/:projectId/specifications                 — upload PDF/DOCX/XLSX/TXT
 * GET    /projects/:projectId/specifications                 — list documents
 * GET    /projects/:projectId/specifications/:docId          — one document with clauses and links
 * POST   /projects/:projectId/specifications/:docId/link     — propose links to BOQ lines / rules
 * PATCH  /projects/:projectId/specifications/:docId/links/:linkId — confirm/reject a link
 * POST   /projects/:projectId/specifications/:docId/approve  — engineer approval
 * GET    /projects/:projectId/specifications/for-target      — specs attached to a given item
 * DELETE /projects/:projectId/specifications/:docId          — remove
 */
const express = require('express');
const crypto = require('node:crypto');
const multer = require('multer');
const { getDB, uid } = require('../db');
const { E, wrap } = require('../lib/errors');
const A = require('../lib/auth');
const { extractSpecText, parseClauses, parseSpecTable, proposeSpecLinks } = require('../lib/mmc-ai/spec-import');

const router = express.Router();
const EDIT_ROLES = new Set(['owner', 'project_manager', 'engineer', 'quantity_surveyor']);
const APPROVE_ROLES = new Set(['owner', 'project_manager', 'engineer']);
const MAX_BYTES = 40 * 1024 * 1024;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES, files: 1, fields: 4, fieldSize: 400 },
  fileFilter(req, file, cb) {
    const name = String(file.originalname || '').toLowerCase();
    const ok = ['.pdf', '.docx', '.xlsx', '.txt', '.csv'].some((e) => name.endsWith(e));
    if (!ok) return cb(E.validation('يُدعم استيراد المواصفات من PDF أو DOCX أو XLSX أو TXT/CSV.'));
    cb(null, true);
  }
});

router.use(A.requireAuth);

function member(projectId, userId) {
  return getDB().prepare(
    'SELECT m.role,p.status FROM ai_project_members m JOIN ai_projects p ON p.id=m.project_id WHERE m.project_id=? AND m.user_id=?'
  ).get(projectId, userId) || null;
}
function requireMember(req) {
  const m = member(req.params.projectId, req.user.id);
  if (!m || m.status !== 'active') throw E.notFound('المشروع غير موجود.');
  return m;
}
function requireEdit(req) {
  const m = requireMember(req);
  if (!EDIT_ROLES.has(m.role)) throw E.forbidden('لا تملك صلاحية استيراد المواصفات.');
  return m;
}
function audit(db, req, action, entityId, detail) {
  db.prepare(
    'INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)'
  ).run(uid('aial_'), req.params.projectId, req.user.id, action, 'spec_document', entityId, JSON.stringify(detail || {}));
}

function docView(row) {
  return {
    id: row.id,
    projectId: row.project_id,
    originalName: row.original_name,
    fileExt: row.file_ext,
    sizeBytes: row.size_bytes,
    sha256: row.sha256,
    format: row.format,
    pageCount: row.page_count,
    clauseCount: row.clause_count,
    warnings: JSON.parse(row.warnings_json || '[]'),
    status: row.status,
    approvedBy: row.approved_by,
    approvedAt: row.approved_at,
    createdAt: row.created_at
  };
}

function clauseView(row) {
  return {
    id: row.id,
    code: row.clause_code,
    title: row.title,
    body: row.body,
    section: row.section,
    lineNumber: row.line_number
  };
}

function linkView(row) {
  return {
    id: row.id,
    clauseId: row.clause_id,
    targetType: row.target_type,
    targetId: row.target_id,
    targetLabel: row.target_label,
    confidence: row.confidence,
    signals: JSON.parse(row.signals_json || '{}'),
    state: row.state,
    decidedBy: row.decided_by,
    decidedAt: row.decided_at
  };
}

/** POST — upload and parse a specification. */
router.post('/projects/:projectId/specifications', upload.single('file'), wrap(async (req, res) => {
  requireEdit(req);
  if (!req.file) throw E.validation('اختر ملف مواصفات.');

  let extracted;
  try {
    extracted = await extractSpecText(req.file.buffer, req.file.originalname);
  } catch (err) {
    throw E.validation('تعذّر قراءة ملف المواصفات: ' + err.message);
  }
  // A spreadsheet is a table, not prose: parse it row-by-row so each
  // specification row becomes its own clause. Fall back to the prose parser
  // when the table has no recognisable header.
  let clauses = extracted.tableRows ? parseSpecTable(extracted.tableRows) : [];
  if (!clauses.length) clauses = parseClauses(extracted.text);
  if (!clauses.length) {
    throw E.validation(
      'لم تُستخرج أي بند مواصفة من الملف. ' +
      (extracted.warnings[0] || 'تأكد أن الملف يحتوي نصاً مرقّماً، لا صوراً فقط.')
    );
  }

  const db = getDB();
  const docId = uid('aispec_');
  const sha = crypto.createHash('sha256').update(req.file.buffer).digest('hex');
  const ext = String(req.file.originalname).toLowerCase().split('.').pop().slice(0, 8);

  db.transaction(() => {
    db.prepare(`INSERT INTO ai_spec_documents
      (id,project_id,created_by,original_name,file_ext,size_bytes,sha256,format,page_count,clause_count,warnings_json,status)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,'imported_requires_review')`).run(
      docId, req.params.projectId, req.user.id, String(req.file.originalname).slice(0, 200), ext,
      req.file.size, sha, extracted.format, extracted.pages, clauses.length, JSON.stringify(extracted.warnings || [])
    );
    const addClause = db.prepare(`INSERT INTO ai_spec_clauses
      (id,document_id,project_id,clause_code,title,body,section,line_number) VALUES(?,?,?,?,?,?,?,?)`);
    for (const c of clauses) {
      addClause.run(uid('aispeccl_'), docId, req.params.projectId, c.code, c.title, c.body, c.section, c.lineNumber);
    }
    audit(db, req, 'spec_document_imported', docId, { clauses: clauses.length, format: extracted.format, sha256: sha });
  })();

  const row = db.prepare('SELECT * FROM ai_spec_documents WHERE id=?').get(docId);
  const clauseRows = db.prepare('SELECT * FROM ai_spec_clauses WHERE document_id=? ORDER BY line_number').all(docId);
  res.status(201).json({
    document: docView(row),
    clauses: clauseRows.map(clauseView),
    notice: 'تم استيراد المواصفات للمراجعة. لم يُربط أي بند تلقائياً بعد.'
  });
}));

/** GET — list documents. */
router.get('/projects/:projectId/specifications', wrap(async (req, res) => {
  requireMember(req);
  const rows = getDB().prepare(
    'SELECT * FROM ai_spec_documents WHERE project_id=? ORDER BY created_at DESC'
  ).all(req.params.projectId);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    documents: rows.map(docView),
    summary: {
      total: rows.length,
      approved: rows.filter((r) => r.status === 'approved').length,
      totalClauses: rows.reduce((s, r) => s + r.clause_count, 0)
    }
  });
}));

/**
 * GET — specifications attached to a given item.
 * Query: ?targetType=quantity_rule|boq_line|element_type &targetId=...
 * This is what the BOQ screen calls to show the specs behind a line.
 */
router.get('/projects/:projectId/specifications/for-target', wrap(async (req, res) => {
  requireMember(req);
  const targetType = String(req.query.targetType || '');
  const targetId = String(req.query.targetId || '');
  if (!['quantity_rule', 'boq_line', 'element_type'].includes(targetType) || !targetId) {
    throw E.validation('حدد targetType (quantity_rule أو boq_line أو element_type) و targetId.');
  }
  const db = getDB();
  const rows = db.prepare(`SELECT l.*, c.clause_code, c.title, c.body, c.section, c.line_number,
      d.id AS doc_id, d.original_name, d.status AS doc_status
    FROM ai_spec_links l
    JOIN ai_spec_clauses c ON c.id=l.clause_id
    JOIN ai_spec_documents d ON d.id=c.document_id
    WHERE l.project_id=? AND l.target_type=? AND l.target_id=? AND l.state IN ('proposed','confirmed')
    ORDER BY l.confidence DESC`).all(req.params.projectId, targetType, targetId);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    targetType,
    targetId,
    links: rows.map((r) => ({
      linkId: r.id,
      state: r.state,
      confidence: r.confidence,
      clause: { id: r.clause_id, code: r.clause_code, title: r.title, body: r.body, section: r.section, lineNumber: r.line_number },
      document: { id: r.doc_id, name: r.original_name, status: r.doc_status }
    })),
    confirmedCount: rows.filter((r) => r.state === 'confirmed').length,
    proposedCount: rows.filter((r) => r.state === 'proposed').length
  });
}));

/** GET — one document with clauses and links. */
router.get('/projects/:projectId/specifications/:docId', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_spec_documents WHERE id=? AND project_id=?')
    .get(req.params.docId, req.params.projectId);
  if (!row) throw E.notFound('ملف المواصفات غير موجود.');
  const clauses = db.prepare('SELECT * FROM ai_spec_clauses WHERE document_id=? ORDER BY line_number').all(row.id);
  const links = db.prepare(`SELECT l.* FROM ai_spec_links l JOIN ai_spec_clauses c ON c.id=l.clause_id
    WHERE c.document_id=? ORDER BY l.confidence DESC`).all(row.id);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    document: docView(row),
    clauses: clauses.map(clauseView),
    links: links.map(linkView),
    summary: {
      clauses: clauses.length,
      linked: new Set(links.map((l) => l.clause_id)).size,
      confirmed: links.filter((l) => l.state === 'confirmed').length,
      proposed: links.filter((l) => l.state === 'proposed').length
    }
  });
}));

/** POST — propose links to BOQ lines and measured quantity rules. */
router.post('/projects/:projectId/specifications/:docId/link', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_spec_documents WHERE id=? AND project_id=?')
    .get(req.params.docId, req.params.projectId);
  if (!row) throw E.notFound('ملف المواصفات غير موجود.');

  const clauses = db.prepare('SELECT * FROM ai_spec_clauses WHERE document_id=? ORDER BY line_number').all(row.id)
    .map((c) => ({ code: c.clause_code, title: c.title, body: c.body, section: c.section, lineNumber: c.line_number, id: c.id }));

  // Targets: measured quantity rules (preferred) and imported BOQ lines.
  const targets = [];
  const modelId = req.body?.modelId ? String(req.body.modelId).slice(0, 100) : null;
  if (modelId) {
    const qs = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? AND project_id=?').all(modelId, req.params.projectId);
    for (const q of qs) {
      targets.push({
        id: q.rule_id, code: q.rule_id, description: q.description_ar || q.description,
        unit: q.unit, elementType: q.element_type, discipline: q.discipline, targetType: 'quantity_rule'
      });
    }
  }
  const importId = req.body?.importId ? String(req.body.importId).slice(0, 100) : null;
  if (importId) {
    const lines = db.prepare('SELECT * FROM ai_boq_import_lines WHERE import_id=? AND project_id=?').all(importId, req.params.projectId);
    for (const l of lines) {
      targets.push({
        id: l.id, code: l.item_code, description: l.description, unit: l.unit,
        elementType: null, discipline: null, targetType: 'boq_line'
      });
    }
  }
  if (!targets.length) {
    throw E.validation('لا توجد بنود للمطابقة. حدد modelId لنموذج محصور أو importId لجدول كميات مستورد.');
  }

  const proposal = proposeSpecLinks(clauses, targets);

  db.transaction(() => {
    // Re-proposing replaces only proposals; confirmed/rejected decisions stay.
    db.prepare(`DELETE FROM ai_spec_links WHERE state='proposed' AND clause_id IN
      (SELECT id FROM ai_spec_clauses WHERE document_id=?)`).run(row.id);
    const addLink = db.prepare(`INSERT OR IGNORE INTO ai_spec_links
      (id,project_id,clause_id,target_type,target_id,target_label,confidence,signals_json,state)
      VALUES(?,?,?,?,?,?,?,?,'proposed')`);
    const clauseByCode = new Map(clauses.map((c) => [c.code + '|' + c.lineNumber, c]));
    for (const link of proposal.links) {
      const clause = clauseByCode.get(link.clauseCode + '|' + link.lineNumber);
      if (!clause) continue;
      for (const cand of link.candidates) {
        const target = targets.find((t) => t.id === cand.targetId);
        if (!target) continue;
        addLink.run(
          uid('aispecln_'), req.params.projectId, clause.id, target.targetType, cand.targetId,
          (cand.targetCode ? cand.targetCode + ' — ' : '') + String(cand.targetDescription).slice(0, 200),
          cand.confidence, JSON.stringify(cand.signals)
        );
      }
    }
    audit(db, req, 'spec_links_proposed', row.id, { ...proposal.summary, modelId, importId });
  })();

  const links = db.prepare(`SELECT l.* FROM ai_spec_links l JOIN ai_spec_clauses c ON c.id=l.clause_id
    WHERE c.document_id=? ORDER BY l.confidence DESC`).all(row.id);
  res.json({
    documentId: row.id,
    summary: proposal.summary,
    links: links.map(linkView),
    unlinked: proposal.unlinked,
    notice: 'الروابط مقترحة بدرجة ثقة. أكّدها أو ارفضها قبل الاعتماد.'
  });
}));

/** PATCH — confirm or reject one link. */
router.patch('/projects/:projectId/specifications/:docId/links/:linkId', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const link = db.prepare(`SELECT l.* FROM ai_spec_links l JOIN ai_spec_clauses c ON c.id=l.clause_id
    WHERE l.id=? AND l.project_id=? AND c.document_id=?`)
    .get(req.params.linkId, req.params.projectId, req.params.docId);
  if (!link) throw E.notFound('الرابط غير موجود.');
  const state = String(req.body?.state || '');
  if (!['confirmed', 'rejected', 'proposed'].includes(state)) {
    throw E.validation('الحالة يجب أن تكون confirmed أو rejected أو proposed.');
  }
  db.prepare('UPDATE ai_spec_links SET state=?,decided_by=?,decided_at=unixepoch() WHERE id=?')
    .run(state, req.user.id, link.id);
  audit(db, req, 'spec_link_' + state, link.id, { targetType: link.target_type, targetId: link.target_id });
  res.json({ link: linkView(db.prepare('SELECT * FROM ai_spec_links WHERE id=?').get(link.id)) });
}));

/** POST — approve the document. */
router.post('/projects/:projectId/specifications/:docId/approve', wrap(async (req, res) => {
  const m = requireMember(req);
  if (!APPROVE_ROLES.has(m.role)) {
    throw E.forbidden('اعتماد المواصفات متاح للمالك ومدير المشروع والمهندس فقط.');
  }
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_spec_documents WHERE id=? AND project_id=?')
    .get(req.params.docId, req.params.projectId);
  if (!row) throw E.notFound('ملف المواصفات غير موجود.');
  const pending = db.prepare(`SELECT COUNT(*) AS n FROM ai_spec_links l JOIN ai_spec_clauses c ON c.id=l.clause_id
    WHERE c.document_id=? AND l.state='proposed'`).get(row.id).n;
  if (pending > 0) {
    throw E.conflict('يوجد ' + pending + ' رابطاً مقترحاً لم يُحسم. أكّده أو ارفضه قبل الاعتماد.');
  }
  const now = Math.floor(Date.now() / 1000);
  db.transaction(() => {
    db.prepare("UPDATE ai_spec_documents SET status='approved',approved_by=?,approved_at=?,updated_at=unixepoch() WHERE id=?")
      .run(req.user.id, now, row.id);
    audit(db, req, 'spec_document_approved', row.id, { approvedBy: req.user.id });
  })();
  res.json({
    document: docView(db.prepare('SELECT * FROM ai_spec_documents WHERE id=?').get(row.id)),
    notice: 'تم اعتماد المواصفات. سُجّل من اعتمد ومتى.'
  });
}));

/** DELETE — remove a document. */
router.delete('/projects/:projectId/specifications/:docId', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const row = db.prepare('SELECT id,status FROM ai_spec_documents WHERE id=? AND project_id=?')
    .get(req.params.docId, req.params.projectId);
  if (!row) throw E.notFound('ملف المواصفات غير موجود.');
  if (row.status === 'approved') throw E.conflict('لا يمكن حذف مواصفات معتمدة.');
  db.prepare('DELETE FROM ai_spec_documents WHERE id=?').run(row.id);
  audit(db, req, 'spec_document_deleted', row.id, {});
  res.json({ ok: true, id: row.id });
}));

module.exports = router;
