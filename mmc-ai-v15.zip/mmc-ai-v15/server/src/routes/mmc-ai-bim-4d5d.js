'use strict';
/**
 * BIM 4D (schedule) and 5D (cost) API.
 *
 * 4D: create a schedule for a stored model, import one from CSV, propose
 *     element-to-activity links, confirm or reject each link, and read the
 *     planned-vs-earned quantities at any date.
 * 5D: set unit rates per quantity rule, build the cost model, and read the
 *     planned-vs-actual cost curve.
 *
 * Nothing is approved automatically. A schedule starts `draft` and its links
 * `proposed`; only an explicit approval by an authorised member moves them
 * forward, and the approver and timestamp are recorded.
 */
const express = require('express');
const multer = require('multer');
const { getDB, uid } = require('../db');
const { E, wrap } = require('../lib/errors');
const A = require('../lib/auth');
const {
  buildSchedule, proposeElementLinks, parseScheduleCsv, buildCostModel,
  buildCostCurve, quantitiesAtDate, LINK_RULES, normalizeCalendar, isoDate
} = require('../lib/mmc-ai/bim-4d5d-engine');

const router = express.Router();
const EDIT_ROLES = new Set(['owner', 'project_manager', 'engineer', 'quantity_surveyor']);
const APPROVE_ROLES = new Set(['owner', 'project_manager', 'engineer']);
const MAX_CSV_BYTES = 8 * 1024 * 1024;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_CSV_BYTES, files: 1, fields: 6, fieldSize: 2000 },
  fileFilter(req, file, cb) {
    const name = String(file.originalname || '').toLowerCase();
    if (!name.endsWith('.csv') && !name.endsWith('.txt')) {
      return cb(E.validation('يُدعم استيراد البرنامج الزمني من ملفات CSV النصية (.csv) فقط.'));
    }
    cb(null, true);
  }
});

router.use(A.requireAuth);

function member(projectId, userId) {
  return getDB().prepare(
    'SELECT m.role,p.status FROM ai_project_members m JOIN ai_projects p ON p.id=m.project_id WHERE m.project_id=? AND m.user_id=?'
  ).get(projectId, userId) || null;
}

function requireMember(req) {
  const m = member(req.params.projectId, req.user.id);
  if (!m || m.status !== 'active') throw E.notFound('المشروع غير موجود.');
  return m;
}

function requireEdit(req) {
  const m = requireMember(req);
  if (!EDIT_ROLES.has(m.role)) throw E.forbidden('لا تملك صلاحية تعديل البرنامج الزمني أو التكلفة.');
  return m;
}

function audit(db, req, action, entityId, detail) {
  db.prepare(
    'INSERT INTO ai_audit_log(id,project_id,actor_user_id,action,entity_type,entity_id,detail_json) VALUES(?,?,?,?,?,?,?)'
  ).run(uid('aial_'), req.params.projectId, req.user.id, action, 'bim_4d5d', entityId, JSON.stringify(detail || {}));
}

function requireModel(db, projectId, modelId) {
  const row = db.prepare('SELECT * FROM ai_bim_model_store WHERE id=? AND project_id=?').get(modelId, projectId);
  if (!row) throw E.notFound('نموذج BIM غير موجود.');
  return row;
}

function scheduleView(row) {
  if (!row) return null;
  return {
    id: row.id,
    projectId: row.project_id,
    modelId: row.model_id,
    name: row.name,
    source: row.source,
    sourceFilename: row.source_filename,
    calendar: JSON.parse(row.calendar_json || '{}'),
    dataDate: row.data_date,
    projectStart: row.project_start,
    projectFinish: row.project_finish,
    durationWorkingDays: row.duration_working_days,
    activityCount: row.activity_count,
    status: row.status,
    approvedBy: row.approved_by,
    approvedAt: row.approved_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function activityView(row) {
  // Status is derived, not stored: a stored status would go stale the moment
  // the data date moves past an activity's planned finish.
  const today = new Date().toISOString().slice(0, 10);
  let status;
  if (row.actual_finish) status = 'completed';
  else if (row.actual_start) status = 'in_progress';
  else if (row.percent_complete >= 100) status = 'completed';
  else if (row.planned_finish && row.planned_finish < today) status = 'not_started_late';
  else status = 'planned';
  return {
    id: row.activity_id,
    name: row.name,
    wbs: row.wbs,
    trade: row.trade,
    durationDays: row.duration_days,
    plannedStart: row.planned_start,
    plannedFinish: row.planned_finish,
    actualStart: row.actual_start,
    actualFinish: row.actual_finish,
    percentComplete: row.percent_complete,
    status,
    predecessors: JSON.parse(row.predecessors_json || '[]'),
    elementIds: JSON.parse(row.element_ids_json || '[]'),
    quantityRuleIds: JSON.parse(row.quantity_rule_ids_json || '[]'),
    sourceRow: row.source_row
  };
}

function linkView(row) {
  return {
    id: row.id,
    elementId: row.element_id,
    elementType: row.element_type,
    storeyId: row.storey_id,
    activityId: row.activity_id,
    ruleId: row.rule_id,
    confidence: row.confidence,
    state: row.state,
    reason: row.reason,
    decidedBy: row.decided_by,
    decidedAt: row.decided_at
  };
}

function costRowView(row) {
  return {
    id: row.id,
    ruleId: row.rule_id,
    elementType: row.element_type,
    discipline: row.discipline,
    description: row.description,
    descriptionAr: row.description_ar,
    unit: row.unit,
    quantity: row.quantity,
    unitRate: row.unit_rate,
    total: row.total,
    actualCost: row.actual_cost,
    variance: row.variance,
    currency: row.currency,
    elementIds: JSON.parse(row.element_ids_json || '[]'),
    storeyBreakdown: JSON.parse(row.storey_breakdown_json || '{}'),
    reviewState: row.review_state,
    approvedBy: row.approved_by,
    approvedAt: row.approved_at
  };
}

/** Loads a stored model and its quantity rows in the shape the engine expects. */
function loadModelAndMeasurement(db, modelRow) {
  const model = JSON.parse(modelRow.model_json);
  const quantities = db.prepare('SELECT * FROM ai_bim_quantities WHERE model_id=? ORDER BY unit,rule_id').all(modelRow.id);
  const measurement = {
    projectId: modelRow.project_id,
    modelId: modelRow.id,
    revision: modelRow.revision,
    rows: quantities.map((q) => ({
      ruleId: q.rule_id,
      elementType: q.element_type,
      discipline: q.discipline,
      description: q.description,
      descriptionAr: q.description_ar,
      unit: q.unit,
      quantity: q.quantity,
      formula: q.formula,
      elementCount: q.element_count,
      elementIds: JSON.parse(q.element_ids_json || '[]'),
      storeyBreakdown: JSON.parse(q.storey_breakdown_json || '{}'),
      measurementBasis: q.measurement_basis,
      reviewState: q.review_state
    }))
  };
  return { model, measurement };
}

/** Rebuilds a schedule object from stored activities, for the engine. */
function loadSchedule(db, scheduleRow) {
  const activities = db.prepare('SELECT * FROM ai_bim_activities WHERE schedule_id=? ORDER BY planned_start,activity_id')
    .all(scheduleRow.id);
  return {
    engine: 'mmc-bim-4d-v1',
    calendar: JSON.parse(scheduleRow.calendar_json || '{}'),
    dataDate: scheduleRow.data_date,
    projectStart: scheduleRow.project_start,
    projectFinish: scheduleRow.project_finish,
    projectDurationWorkingDays: scheduleRow.duration_working_days,
    activityCount: activities.length,
    activities: activities.map((a) => ({
      id: a.activity_id,
      name: a.name,
      wbs: a.wbs,
      trade: a.trade,
      durationDays: a.duration_days,
      plannedStart: a.planned_start,
      plannedFinish: a.planned_finish,
      actualStart: a.actual_start,
      actualFinish: a.actual_finish,
      percentComplete: a.percent_complete,
      predecessors: JSON.parse(a.predecessors_json || '[]'),
      elementIds: JSON.parse(a.element_ids_json || '[]'),
      quantityRuleIds: JSON.parse(a.quantity_rule_ids_json || '[]')
    }))
  };
}

/** Persists a built schedule plus its activities. */
function persistSchedule(db, req, { modelRow, built, source, sourceFilename, name }) {
  const scheduleId = uid('aibims_');
  db.transaction(() => {
    db.prepare(`INSERT INTO ai_bim_schedules
      (id,project_id,model_id,created_by,name,source,source_filename,calendar_json,data_date,project_start,project_finish,duration_working_days,activity_count,status)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'draft')`).run(
      scheduleId, req.params.projectId, modelRow.id, req.user.id, name, source, sourceFilename || null,
      JSON.stringify(built.calendar), built.dataDate, built.projectStart, built.projectFinish,
      built.projectDurationWorkingDays, built.activityCount
    );
    const add = db.prepare(`INSERT INTO ai_bim_activities
      (id,schedule_id,activity_id,name,wbs,trade,duration_days,planned_start,planned_finish,actual_start,actual_finish,percent_complete,predecessors_json,element_ids_json,quantity_rule_ids_json,source_row)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const a of built.activities) {
      add.run(
        uid('aibima_'), scheduleId, a.id, a.name, a.wbs || null, a.trade || null,
        a.durationDays || 0, a.plannedStart || null, a.plannedFinish || null,
        a.actualStart || null, a.actualFinish || null, a.percentComplete || 0,
        JSON.stringify(a.predecessors || []), JSON.stringify(a.elementIds || []),
        JSON.stringify(a.quantityRuleIds || []), a.sourceRow === undefined ? null : a.sourceRow
      );
    }
    audit(db, req, 'bim_schedule_created', scheduleId, {
      modelId: modelRow.id, source, activities: built.activityCount, dataDate: built.dataDate
    });
  })();
  return scheduleId;
}

/* ------------------------------------------------------------------ 4D ---- */

/** POST /projects/:projectId/bim/model/:modelId/schedule — build a schedule. */
router.post('/projects/:projectId/bim/model/:modelId/schedule', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const modelRow = requireModel(db, req.params.projectId, req.params.modelId);
  const spec = req.body?.schedule || req.body;
  if (!spec || typeof spec !== 'object') throw E.validation('أرسل مواصفة البرنامج الزمني في الحقل schedule.');
  let built;
  try {
    built = buildSchedule(spec, { dataDate: req.body?.dataDate });
  } catch (err) {
    throw E.validation('تعذّر بناء البرنامج الزمني: ' + err.message);
  }
  const name = String(req.body?.name || spec.name || 'BIM 4D schedule').slice(0, 200);
  const scheduleId = persistSchedule(db, req, { modelRow, built, source: 'manual', name });
  const row = db.prepare('SELECT * FROM ai_bim_schedules WHERE id=?').get(scheduleId);
  const activities = db.prepare('SELECT * FROM ai_bim_activities WHERE schedule_id=? ORDER BY planned_start,activity_id').all(scheduleId);
  res.status(201).json({
    schedule: scheduleView(row),
    activities: activities.map(activityView),
    notice: 'تم بناء البرنامج الزمني. الأنشطة مسودة وتنتظر مراجعة المهندس.'
  });
}));

/** POST /projects/:projectId/bim/model/:modelId/schedule/import — import CSV. */
router.post('/projects/:projectId/bim/model/:modelId/schedule/import', upload.single('file'), wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const modelRow = requireModel(db, req.params.projectId, req.params.modelId);
  if (!req.file) throw E.validation('اختر ملف CSV للبرنامج الزمني.');
  const text = req.file.buffer.toString('utf8');
  let parsed;
  try {
    parsed = parseScheduleCsv(text);
  } catch (err) {
    throw E.validation('تعذّر قراءة ملف CSV: ' + err.message);
  }
  let built;
  try {
    built = buildSchedule({
      name: String(req.body?.name || req.file.originalname || 'Imported schedule').slice(0, 200),
      calendar: req.body?.calendar ? JSON.parse(req.body.calendar) : undefined,
      activities: parsed.activities
    }, { dataDate: req.body?.dataDate });
  } catch (err) {
    throw E.validation('تعذّر بناء البرنامج الزمني من الملف: ' + err.message);
  }
  const name = String(req.body?.name || req.file.originalname || 'Imported schedule').slice(0, 200);
  const scheduleId = persistSchedule(db, req, {
    modelRow, built, source: 'csv_import', sourceFilename: req.file.originalname, name
  });
  const row = db.prepare('SELECT * FROM ai_bim_schedules WHERE id=?').get(scheduleId);
  const activities = db.prepare('SELECT * FROM ai_bim_activities WHERE schedule_id=? ORDER BY planned_start,activity_id').all(scheduleId);
  res.status(201).json({
    schedule: scheduleView(row),
    activities: activities.map(activityView),
    importReport: { columns: parsed.columns, rowsRead: parsed.activityCount, skipped: parsed.skipped },
    notice: 'تم استيراد البرنامج الزمني. راجع الأنشطة المتجاهلة ثم اربط العناصر.'
  });
}));

/** GET /projects/:projectId/bim/model/:modelId/schedule — list schedules. */
router.get('/projects/:projectId/bim/model/:modelId/schedule', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  requireModel(db, req.params.projectId, req.params.modelId);
  const rows = db.prepare('SELECT * FROM ai_bim_schedules WHERE model_id=? ORDER BY created_at DESC').all(req.params.modelId);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    schedules: rows.map(scheduleView),
    summary: {
      total: rows.length,
      draft: rows.filter((r) => r.status === 'draft').length,
      approved: rows.filter((r) => r.status === 'approved').length
    }
  });
}));

/** GET /projects/:projectId/bim/schedule/:scheduleId — one schedule with activities. */
router.get('/projects/:projectId/bim/schedule/:scheduleId', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('البرنامج الزمني غير موجود.');
  const activities = db.prepare('SELECT * FROM ai_bim_activities WHERE schedule_id=? ORDER BY planned_start,activity_id').all(row.id);
  const links = db.prepare('SELECT * FROM ai_bim_element_links WHERE schedule_id=? ORDER BY element_id').all(row.id);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    schedule: scheduleView(row),
    activities: activities.map(activityView),
    links: links.map(linkView),
    linkSummary: {
      total: links.length,
      proposed: links.filter((l) => l.state === 'proposed').length,
      confirmed: links.filter((l) => l.state === 'confirmed').length,
      rejected: links.filter((l) => l.state === 'rejected').length
    }
  });
}));

/** POST /projects/:projectId/bim/schedule/:scheduleId/propose-links — auto-link. */
router.post('/projects/:projectId/bim/schedule/:scheduleId/propose-links', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('البرنامج الزمني غير موجود.');
  const modelRow = requireModel(db, req.params.projectId, row.model_id);
  const model = JSON.parse(modelRow.model_json);
  const schedule = loadSchedule(db, row);
  const proposal = proposeElementLinks(model, schedule);
  const now = Math.floor(Date.now() / 1000);
  db.transaction(() => {
    // Re-proposing replaces only links that are still undecided; a confirmed or
    // rejected link is a human decision and is never overwritten. INSERT OR
    // REPLACE would silently delete the decided row and re-insert it as
    // proposed, so the insert is guarded by the existing state instead.
    db.prepare("DELETE FROM ai_bim_element_links WHERE schedule_id=? AND state='proposed'").run(row.id);
    const add = db.prepare(`INSERT INTO ai_bim_element_links
      (id,project_id,model_id,schedule_id,element_id,element_type,storey_id,activity_id,rule_id,confidence,state,reason,decided_by,decided_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,'proposed',?,NULL,NULL)
      ON CONFLICT(model_id,schedule_id,element_id) DO NOTHING`);
    for (const p of proposal.proposals) {
      add.run(
        uid('aibiml_'), req.params.projectId, modelRow.id, row.id, p.elementId, p.elementType,
        p.storeyId || null, p.activityId, p.ruleId, p.confidence, p.reason || null
      );
    }
    audit(db, req, 'bim_links_proposed', row.id, {
      proposals: proposal.proposalCount, unlinked: proposal.unlinkedCount
    });
  })();
  const links = db.prepare('SELECT * FROM ai_bim_element_links WHERE schedule_id=? ORDER BY element_id').all(row.id);
  res.json({
    scheduleId: row.id,
    proposalCount: proposal.proposalCount,
    unlinkedCount: proposal.unlinkedCount,
    unlinked: proposal.unlinked,
    rules: proposal.rules,
    links: links.map(linkView),
    notice: 'الروابط مقترحة فقط. اعتمدها أو ارفضها قبل نقل أي كمية إلى BOQ.'
  });
}));

/** GET /projects/:projectId/bim/schedule/:scheduleId/links — list links. */
router.get('/projects/:projectId/bim/schedule/:scheduleId/links', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT id FROM ai_bim_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('البرنامج الزمني غير موجود.');
  const state = req.query.state ? String(req.query.state) : null;
  const links = state
    ? db.prepare('SELECT * FROM ai_bim_element_links WHERE schedule_id=? AND state=? ORDER BY element_id').all(row.id, state)
    : db.prepare('SELECT * FROM ai_bim_element_links WHERE schedule_id=? ORDER BY element_id').all(row.id);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    scheduleId: row.id,
    links: links.map(linkView),
    rules: LINK_RULES.map((r) => ({ id: r.id, confidence: r.confidence, label: r.label, description: r.description }))
  });
}));

/** PATCH /projects/:projectId/bim/schedule/:scheduleId/links — decide links. */
router.patch('/projects/:projectId/bim/schedule/:scheduleId/links', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('البرنامج الزمني غير موجود.');
  const decisions = Array.isArray(req.body?.decisions) ? req.body.decisions : null;
  if (!decisions || !decisions.length) throw E.validation('أرسل قائمة decisions تحتوي على elementId و state.');
  const now = Math.floor(Date.now() / 1000);
  const applied = [];
  const rejected = [];
  db.transaction(() => {
    for (const d of decisions) {
      const elementId = String(d?.elementId || '').trim();
      const state = String(d?.state || '').trim();
      if (!elementId || !['confirmed', 'rejected', 'proposed'].includes(state)) {
        rejected.push({ elementId, state, reason: 'invalid_decision' });
        continue;
      }
      const existing = db.prepare('SELECT * FROM ai_bim_element_links WHERE schedule_id=? AND element_id=?')
        .get(row.id, elementId);
      if (!existing) { rejected.push({ elementId, state, reason: 'link_not_found' }); continue; }
      const activityId = d?.activityId ? String(d.activityId).trim() : existing.activity_id;
      if (d?.activityId) {
        const act = db.prepare('SELECT activity_id FROM ai_bim_activities WHERE schedule_id=? AND activity_id=?')
          .get(row.id, activityId);
        if (!act) { rejected.push({ elementId, state, reason: 'activity_not_found' }); continue; }
      }
      db.prepare('UPDATE ai_bim_element_links SET state=?,activity_id=?,decided_by=?,decided_at=? WHERE id=?')
        .run(state, activityId, req.user.id, now, existing.id);
      applied.push({ elementId, state, activityId });
    }
    audit(db, req, 'bim_links_decided', row.id, { applied: applied.length, rejected: rejected.length });
  })();
  const links = db.prepare('SELECT * FROM ai_bim_element_links WHERE schedule_id=? ORDER BY element_id').all(row.id);
  res.json({
    scheduleId: row.id,
    applied,
    rejected,
    links: links.map(linkView),
    notice: 'تم تسجيل قرارات الربط باسمك ووقتها.'
  });
}));

/** GET /projects/:projectId/bim/schedule/:scheduleId/quantities-at — 4D quantities. */
router.get('/projects/:projectId/bim/schedule/:scheduleId/quantities-at', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('البرنامج الزمني غير موجود.');
  const modelRow = requireModel(db, req.params.projectId, row.model_id);
  const { model, measurement } = loadModelAndMeasurement(db, modelRow);
  const schedule = loadSchedule(db, row);
  // Only confirmed links drive the 4D quantity view; a proposal is not evidence.
  const confirmed = db.prepare("SELECT * FROM ai_bim_element_links WHERE schedule_id=? AND state='confirmed'").all(row.id);
  const byActivity = new Map();
  for (const l of confirmed) {
    if (!byActivity.has(l.activity_id)) byActivity.set(l.activity_id, []);
    byActivity.get(l.activity_id).push(l.element_id);
  }
  const effective = {
    ...schedule,
    activities: schedule.activities.map((a) => ({ ...a, elementIds: byActivity.get(a.id) || [] }))
  };
  const at = req.query.at ? String(req.query.at) : (row.data_date || isoDate(Date.now()));
  let result;
  try {
    result = quantitiesAtDate(model, measurement, effective, at);
  } catch (err) {
    throw E.validation('تعذّر حساب الكميات في هذا التاريخ: ' + err.message);
  }
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    scheduleId: row.id,
    modelId: modelRow.id,
    confirmedLinkCount: confirmed.length,
    ...result,
    notice: 'الكميات المخططة والمنجزة محسوبة من الروابط المؤكدة فقط.'
  });
}));

/** POST /projects/:projectId/bim/schedule/:scheduleId/approve — approve schedule. */
router.post('/projects/:projectId/bim/schedule/:scheduleId/approve', wrap(async (req, res) => {
  const m = requireMember(req);
  if (!APPROVE_ROLES.has(m.role)) throw E.forbidden('اعتماد البرنامج الزمني متاح للمالك ومدير المشروع والمهندس فقط.');
  const db = getDB();
  const row = db.prepare('SELECT * FROM ai_bim_schedules WHERE id=? AND project_id=?')
    .get(req.params.scheduleId, req.params.projectId);
  if (!row) throw E.notFound('البرنامج الزمني غير موجود.');
  const pending = db.prepare("SELECT COUNT(*) AS n FROM ai_bim_element_links WHERE schedule_id=? AND state='proposed'").get(row.id).n;
  if (pending > 0 && req.body?.force !== true) {
    throw E.conflict(`يوجد ${pending} رابط لم يُحسم بعد. اعتمدها أو ارفضها، أو أرسل force=true للاعتماد مع تجاهلها.`);
  }
  const now = Math.floor(Date.now() / 1000);
  db.transaction(() => {
    db.prepare("UPDATE ai_bim_schedules SET status='approved',approved_by=?,approved_at=?,updated_at=unixepoch() WHERE id=?")
      .run(req.user.id, now, row.id);
    audit(db, req, 'bim_schedule_approved', row.id, { approvedBy: req.user.id, pendingLinks: pending });
  })();
  res.json({
    schedule: scheduleView(db.prepare('SELECT * FROM ai_bim_schedules WHERE id=?').get(row.id)),
    notice: 'تم اعتماد البرنامج الزمني. سُجّل من اعتمد ومتى.'
  });
}));

/* ------------------------------------------------------------------ 5D ---- */

/** PUT /projects/:projectId/bim/model/:modelId/cost-items — set unit rates. */
router.put('/projects/:projectId/bim/model/:modelId/cost-items', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const modelRow = requireModel(db, req.params.projectId, req.params.modelId);
  const items = Array.isArray(req.body?.items) ? req.body.items : null;
  if (!items || !items.length) throw E.validation('أرسل قائمة items تحتوي على unitRate و ruleId أو elementType.');
  const currency = String(req.body?.currency || 'OMR').slice(0, 8);
  const saved = [];
  db.transaction(() => {
    for (const item of items) {
      const ruleId = item?.ruleId ? String(item.ruleId).trim().slice(0, 80) : null;
      const elementType = item?.elementType ? String(item.elementType).trim().slice(0, 40) : null;
      if (!ruleId && !elementType) throw E.validation('كل بند تكلفة يحتاج ruleId أو elementType.');
      const unit = String(item?.unit || '').trim().slice(0, 12);
      if (!unit) throw E.validation('كل بند تكلفة يحتاج وحدة قياس.');
      const unitRate = Number(item?.unitRate);
      if (!Number.isFinite(unitRate) || unitRate < 0) throw E.validation('سعر الوحدة يجب أن يكون رقماً غير سالب.');
      const actualCost = item?.actualCost === undefined || item?.actualCost === null ? null : Number(item.actualCost);
      if (actualCost !== null && (!Number.isFinite(actualCost) || actualCost < 0)) {
        throw E.validation('التكلفة الفعلية يجب أن تكون رقماً غير سالب.');
      }
      const existing = ruleId
        ? db.prepare('SELECT id FROM ai_bim_cost_items WHERE model_id=? AND rule_id=?').get(modelRow.id, ruleId)
        : db.prepare('SELECT id FROM ai_bim_cost_items WHERE model_id=? AND element_type=? AND rule_id IS NULL').get(modelRow.id, elementType);
      if (existing) {
        db.prepare(`UPDATE ai_bim_cost_items SET unit=?,unit_rate=?,currency=?,actual_cost=?,description=?,source=?,updated_at=unixepoch() WHERE id=?`)
          .run(unit, unitRate, currency, actualCost, item?.description ? String(item.description).slice(0, 300) : null,
            item?.source ? String(item.source).slice(0, 120) : null, existing.id);
        saved.push({ id: existing.id, ruleId, elementType, unit, unitRate, updated: true });
      } else {
        const id = uid('aibimci_');
        db.prepare(`INSERT INTO ai_bim_cost_items
          (id,project_id,model_id,rule_id,element_type,unit,unit_rate,currency,actual_cost,description,source,created_by)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(
          id, req.params.projectId, modelRow.id, ruleId, elementType, unit, unitRate, currency, actualCost,
          item?.description ? String(item.description).slice(0, 300) : null,
          item?.source ? String(item.source).slice(0, 120) : null, req.user.id
        );
        saved.push({ id, ruleId, elementType, unit, unitRate, updated: false });
      }
    }
    audit(db, req, 'bim_cost_items_saved', modelRow.id, { count: saved.length, currency });
  })();
  res.json({ modelId: modelRow.id, currency, saved, notice: 'تم حفظ أسعار الوحدات. لم تُعتمد أي تكلفة بعد.' });
}));

/** GET /projects/:projectId/bim/model/:modelId/cost-items — list unit rates. */
router.get('/projects/:projectId/bim/model/:modelId/cost-items', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const modelRow = requireModel(db, req.params.projectId, req.params.modelId);
  const rows = db.prepare('SELECT * FROM ai_bim_cost_items WHERE model_id=? ORDER BY rule_id,element_type').all(modelRow.id);
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    modelId: modelRow.id,
    items: rows.map((r) => ({
      id: r.id, ruleId: r.rule_id, elementType: r.element_type, unit: r.unit, unitRate: r.unit_rate,
      currency: r.currency, actualCost: r.actual_cost, description: r.description, source: r.source
    }))
  });
}));

/** POST /projects/:projectId/bim/model/:modelId/cost — build the 5D cost model. */
router.post('/projects/:projectId/bim/model/:modelId/cost', wrap(async (req, res) => {
  requireEdit(req);
  const db = getDB();
  const modelRow = requireModel(db, req.params.projectId, req.params.modelId);
  const { measurement } = loadModelAndMeasurement(db, modelRow);
  const items = db.prepare('SELECT * FROM ai_bim_cost_items WHERE model_id=?').all(modelRow.id).map((r) => ({
    ruleId: r.rule_id, elementType: r.element_type, unit: r.unit, unitRate: r.unit_rate,
    currency: r.currency, actualCost: r.actual_cost, description: r.description, source: r.source
  }));
  if (!items.length) throw E.validation('لا توجد أسعار وحدات لهذا النموذج. أضفها أولاً عبر cost-items.');
  const currency = String(req.body?.currency || items[0].currency || 'OMR').slice(0, 8);
  const cost = buildCostModel(measurement, items, { currency });
  db.transaction(() => {
    db.prepare('DELETE FROM ai_bim_cost_rows WHERE model_id=?').run(modelRow.id);
    const add = db.prepare(`INSERT INTO ai_bim_cost_rows
      (id,project_id,model_id,rule_id,element_type,discipline,description,description_ar,unit,quantity,unit_rate,total,actual_cost,variance,currency,element_ids_json,storey_breakdown_json,review_state,element_values_json)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'cost_draft_requires_review',?)`);
    for (const r of cost.rows) {
      // A cost row is priced per rule, not per element, so each contributing
      // element carries an equal share of the row. The viewer shows that share
      // and labels it as a share, never as an independently priced element.
      const ids = Array.isArray(r.elementIds) ? r.elementIds : [];
      const share = ids.length ? Number((r.total / ids.length).toFixed(2)) : 0;
      const elementValues = ids.map((id) => ({ elementId: id, value: share }));
      add.run(
        uid('aibimcr_'), req.params.projectId, modelRow.id, r.ruleId, r.elementType, r.discipline,
        r.description, r.descriptionAr || null, r.unit, r.quantity, r.unitRate, r.total,
        r.actualCost, r.variance, r.currency, JSON.stringify(r.elementIds), JSON.stringify(r.storeyBreakdown),
        JSON.stringify(elementValues)
      );
    }
    audit(db, req, 'bim_cost_built', modelRow.id, {
      rows: cost.rowCount, total: cost.total, currency, unpriced: cost.unpriced.length
    });
  })();
  const rows = db.prepare('SELECT * FROM ai_bim_cost_rows WHERE model_id=? ORDER BY unit,rule_id').all(modelRow.id);
  res.status(201).json({
    modelId: modelRow.id,
    currency: cost.currency,
    rowCount: cost.rowCount,
    total: cost.total,
    actualTotal: cost.actualTotal,
    variance: cost.variance,
    byStorey: cost.byStorey,
    byDiscipline: cost.byDiscipline,
    unpriced: cost.unpriced,
    rows: rows.map(costRowView),
    limitations: cost.limitations,
    notice: 'التكلفة مسودة وتنتظر اعتماد المهندس.'
  });
}));

/** GET /projects/:projectId/bim/model/:modelId/cost — read the cost model. */
router.get('/projects/:projectId/bim/model/:modelId/cost', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const modelRow = requireModel(db, req.params.projectId, req.params.modelId);
  const rows = db.prepare('SELECT * FROM ai_bim_cost_rows WHERE model_id=? ORDER BY unit,rule_id').all(modelRow.id);
  const byStorey = {};
  const byElement = {};
  const byDiscipline = {};
  for (const r of rows) {
    const breakdown = JSON.parse(r.storey_breakdown_json || '{}');
    for (const [storeyId, qty] of Object.entries(breakdown)) {
      const share = r.quantity > 0 ? qty / r.quantity : 0;
      byStorey[storeyId] = Number(((byStorey[storeyId] || 0) + r.total * share).toFixed(6));
    }
    const ids = JSON.parse(r.element_ids_json || '[]');
    if (ids.length) {
      const share = r.total / ids.length;
      for (const id of ids) byElement[id] = Number(((byElement[id] || 0) + share).toFixed(6));
    }
    byDiscipline[r.discipline] = Number(((byDiscipline[r.discipline] || 0) + r.total).toFixed(6));
  }
  const total = Number(rows.reduce((s, r) => s + r.total, 0).toFixed(6));
  const actualTotal = rows.length && rows.every((r) => r.actual_cost !== null)
    ? Number(rows.reduce((s, r) => s + (r.actual_cost || 0), 0).toFixed(6))
    : null;
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    modelId: modelRow.id,
    currency: rows.length ? rows[0].currency : 'OMR',
    rowCount: rows.length,
    total,
    actualTotal,
    variance: actualTotal === null ? null : Number((actualTotal - total).toFixed(6)),
    byStorey,
    byElement,
    byDiscipline,
    rows: rows.map(costRowView)
  });
}));

/** GET /projects/:projectId/bim/model/:modelId/cost-curve — planned vs actual. */
router.get('/projects/:projectId/bim/model/:modelId/cost-curve', wrap(async (req, res) => {
  requireMember(req);
  const db = getDB();
  const modelRow = requireModel(db, req.params.projectId, req.params.modelId);
  const scheduleId = req.query.scheduleId ? String(req.query.scheduleId) : null;
  const scheduleRow = scheduleId
    ? db.prepare('SELECT * FROM ai_bim_schedules WHERE id=? AND project_id=?').get(scheduleId, req.params.projectId)
    : db.prepare('SELECT * FROM ai_bim_schedules WHERE model_id=? ORDER BY created_at DESC LIMIT 1').get(modelRow.id);
  if (!scheduleRow) throw E.notFound('لا يوجد برنامج زمني لهذا النموذج. أنشئ برنامجاً أولاً.');
  const costRows = db.prepare('SELECT * FROM ai_bim_cost_rows WHERE model_id=? ORDER BY unit,rule_id').all(modelRow.id);
  if (!costRows.length) throw E.notFound('لا توجد تكلفة محسوبة لهذا النموذج. ابنِ التكلفة أولاً.');
  const schedule = loadSchedule(db, scheduleRow);
  const costModel = {
    currency: costRows[0].currency,
    total: Number(costRows.reduce((s, r) => s + r.total, 0).toFixed(6)),
    actualTotal: costRows.every((r) => r.actual_cost !== null)
      ? Number(costRows.reduce((s, r) => s + (r.actual_cost || 0), 0).toFixed(6))
      : null,
    rows: costRows.map((r) => ({
      ruleId: r.rule_id, elementType: r.element_type, unit: r.unit, quantity: r.quantity,
      unitRate: r.unit_rate, total: r.total, actualCost: r.actual_cost,
      elementIds: JSON.parse(r.element_ids_json || '[]')
    }))
  };
  let curve;
  try {
    curve = buildCostCurve(schedule, costModel, {
      from: req.query.from, to: req.query.to,
      stepDays: req.query.stepDays ? Number(req.query.stepDays) : undefined
    });
  } catch (err) {
    throw E.validation('تعذّر بناء منحنى التكلفة: ' + err.message);
  }
  res.setHeader('Cache-Control', 'no-store');
  res.json({ modelId: modelRow.id, scheduleId: scheduleRow.id, ...curve });
}));

/** POST /projects/:projectId/bim/model/:modelId/cost/approve — approve cost. */
router.post('/projects/:projectId/bim/model/:modelId/cost/approve', wrap(async (req, res) => {
  const m = requireMember(req);
  if (!APPROVE_ROLES.has(m.role)) throw E.forbidden('اعتماد التكلفة متاح للمالك ومدير المشروع والمهندس فقط.');
  const db = getDB();
  const modelRow = requireModel(db, req.params.projectId, req.params.modelId);
  const count = db.prepare('SELECT COUNT(*) AS n FROM ai_bim_cost_rows WHERE model_id=?').get(modelRow.id).n;
  if (!count) throw E.notFound('لا توجد تكلفة محسوبة لهذا النموذج.');
  const now = Math.floor(Date.now() / 1000);
  db.transaction(() => {
    db.prepare("UPDATE ai_bim_cost_rows SET review_state='approved',approved_by=?,approved_at=? WHERE model_id=?")
      .run(req.user.id, now, modelRow.id);
    audit(db, req, 'bim_cost_approved', modelRow.id, { approvedBy: req.user.id, rows: count });
  })();
  const rows = db.prepare('SELECT * FROM ai_bim_cost_rows WHERE model_id=? ORDER BY unit,rule_id').all(modelRow.id);
  res.json({
    modelId: modelRow.id,
    rows: rows.map(costRowView),
    notice: 'تم اعتماد التكلفة. سُجّل من اعتمد ومتى.'
  });
}));

/** GET /projects/:projectId/bim/4d5d/rules — the linking and calendar vocabulary. */
router.get('/projects/:projectId/bim/4d5d/rules', wrap(async (req, res) => {
  requireMember(req);
  res.setHeader('Cache-Control', 'private, max-age=300');
  res.json({
    linkRules: LINK_RULES.map((r) => ({ id: r.id, confidence: r.confidence, label: r.label, description: r.description })),
    defaultCalendar: normalizeCalendar({}),
    csvColumns: [
      'id', 'name', 'duration_days', 'planned_start', 'planned_finish', 'predecessors',
      'percent_complete', 'actual_start', 'actual_finish', 'trade', 'wbs', 'element_ids'
    ],
    limitations: [
      'Finish-to-start dependencies only; no lag or lead.',
      'Working week is configurable; no holiday calendar is inferred.',
      'Cost is quantity x unit rate only; no overhead, profit or tax.'
    ]
  });
}));

module.exports = router;
