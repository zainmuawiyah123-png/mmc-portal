'use strict';
/**
 * Four capabilities API test: BOQ import, aluminium schedule, specification
 * import and risk analysis — through the real HTTP routes with real auth.
 *
 * The point of these tests is not that the endpoints answer 200. It is that:
 *  - a real .xlsx BOQ is parsed with its columns detected, not assumed;
 *  - an imported line is matched to a measured quantity with a confidence, and
 *    the match is a proposal until a human decides;
 *  - the aluminium schedule's numbers are arithmetically checkable;
 *  - a specification's clauses are extracted and linked with a confidence;
 *  - the risk register is derived from the project's own data and cannot be
 *    approved while a risk is still `proposed`.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mmc-ai-four-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json';
process.env.DB_PATH = path.join(TMP, 'test.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false';
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'mmc-ai-four-capabilities-test-secret';
process.env.BCRYPT_ROUNDS = '4';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { closeDB, getDB } = require('../src/db');
const { buildWorkbook } = require('../src/lib/mmc-ai/xlsx-writer');

let server, base;
const jar = {};

async function call(user, method, url, body) {
  const headers = { ...(jar[user] ? { Cookie: jar[user] } : {}) };
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) jar[user] = first;
  }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data, headers: r.headers };
}

/** Multipart upload helper. */
async function upload(user, url, filename, buffer, fields = {}) {
  const form = new FormData();
  form.append('file', new Blob([buffer]), filename);
  for (const [k, v] of Object.entries(fields)) form.append(k, String(v));
  const r = await fetch(base + url, {
    method: 'POST',
    headers: { ...(jar[user] ? { Cookie: jar[user] } : {}) },
    body: form,
    redirect: 'manual'
  });
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data, headers: r.headers };
}

const uniq = () => Math.random().toString(36).slice(2, 10);

async function register(key) {
  const email = key + uniq() + '@test.local';
  const r = await call(key, 'POST', '/api/auth/register', { name: key, email, password: 'Password123', company: key });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const db = getDB();
  const user = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now, user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);
  const login = await call(key, 'POST', '/api/auth/login', { email, password: 'Password123' });
  assert.equal(login.status, 200, JSON.stringify(login.data));
  return user.id;
}

function sampleModel() {
  return {
    name: 'Four capabilities building',
    storeys: [
      { id: 'GF', name: 'Ground Floor', elevation: 0 },
      { id: 'FF', name: 'First Floor', elevation: 3.2 }
    ],
    elements: [
      { id: 'F1', type: 'footing', storeyId: 'GF', origin: { x: 0, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'F2', type: 'footing', storeyId: 'GF', origin: { x: 5, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'C1', type: 'column', storeyId: 'GF', origin: { x: 0, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'C2', type: 'column', storeyId: 'GF', origin: { x: 5, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'C3', type: 'column', storeyId: 'FF', origin: { x: 0, y: 0, z: 3.2 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'S1', type: 'slab', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0 }, length: 5, width: 4, height: 0.25 },
      { id: 'W1', type: 'wall', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0.25 }, length: 5, width: 0.2, height: 3.2 },
      { id: 'O1', type: 'opening', storeyId: 'GF', hostId: 'W1', origin: { x: 1.5, y: 0, z: 1.15 }, length: 1.2, width: 0.2, height: 1.5, sillHeight: 0.9 },
      { id: 'O2', type: 'opening', storeyId: 'GF', hostId: 'W1', origin: { x: 3.5, y: 0, z: 0 }, length: 0.9, width: 0.2, height: 2.1, sillHeight: 0 },
      { id: 'B1', type: 'beam', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 3.2 }, length: 5, width: 0.3, height: 0.5 }
    ]
  };
}

let projectId, modelId, quantities;

test.before(async () => {
  migrate();
  const app = createApp();
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = 'http://127.0.0.1:' + server.address().port;
});

test.after(async () => {
  if (server) await new Promise((r) => server.close(r));
  closeDB();
  fs.rmSync(TMP, { recursive: true, force: true });
});

test('setup: owner, project and a BIM model with two openings', async () => {
  await register('owner');
  const p = await call('owner', 'POST', '/api/mmc-ai/projects', { name: 'Four capabilities', currency: 'OMR' });
  assert.equal(p.status, 201, JSON.stringify(p.data));
  projectId = p.data.project.project_id;

  const m = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  assert.equal(m.status, 201, JSON.stringify(m.data));
  modelId = m.data.model.id;
  quantities = m.data.quantities;
  assert.equal(m.data.model.elementCount, 10);
  assert.ok(quantities.length > 0);
});

/* ============================== 1. BOQ IMPORT ============================== */

/** Builds a realistic BOQ workbook: title rows, a two-row header, then lines. */
function boqWorkbook() {
  return buildWorkbook({
    sheets: [{
      name: 'BOQ',
      title: 'BILL OF QUANTITIES',
      note: 'Project: Four capabilities · Rev C',
      columns: [
        { header: 'Item No', width: 10 }, { header: 'Description', width: 46 },
        { header: 'Unit', width: 10 }, { header: 'Qty', width: 12 },
        { header: 'Unit Rate', width: 12 }, { header: 'Amount', width: 14 }
      ],
      rows: [
        ['1.1', 'Excavation for footings', 'm3', 2.7, 8.5, 22.95],
        ['1.2', 'Plain concrete for footings', 'm3', 2.7, 45, 121.5],
        ['2.1', 'Reinforced concrete columns', 'm3', 1.536, 180, 276.48],
        ['2.2', 'Reinforced concrete beams', 'm3', 0.75, 195, 146.25],
        ['3.1', 'Blockwork walls', 'm2', 16, 22, 352],
        ['4.1', 'Aluminium windows', 'nr', 2, 320, 640]
      ],
      totals: ['', 'Total', '', '', '', 1559.18]
    }]
  });
}

let importId;

test('BOQ import: a real xlsx is parsed with its columns detected', async () => {
  const buf = boqWorkbook();
  const r = await upload('owner', `/api/mmc-ai/projects/${projectId}/boq-imports`, 'boq.xlsx', buf);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  importId = r.data.import.id;

  assert.equal(r.data.import.lineCount, 6);
  assert.equal(r.data.import.status, 'imported_requires_review');
  // The header row is found, not assumed to be row 1.
  assert.ok(r.data.import.headerRow >= 3, 'header row should be below the title block');
  const map = r.data.import.columnMap;
  assert.equal(map.description, 1);
  assert.equal(map.unit, 2);
  assert.equal(map.quantity, 3);
  assert.equal(map.rate, 4);
  assert.equal(map.total, 5);

  const first = r.data.lines[0];
  assert.equal(first.itemCode, '1.1');
  assert.equal(first.description, 'Excavation for footings');
  assert.equal(first.unit, 'm3');
  assert.equal(first.quantity, 2.7);
  assert.equal(first.rate, 8.5);
  assert.equal(first.total, 22.95);
  // Nothing is linked yet.
  assert.equal(first.linkState, 'unmatched');
  assert.equal(first.match, null);
});

test('BOQ import: units are normalised and an unknown unit is flagged, not coerced', async () => {
  const buf = buildWorkbook({
    sheets: [{
      name: 'BOQ',
      columns: [
        { header: 'Description', width: 40 }, { header: 'Unit', width: 10 },
        { header: 'Quantity', width: 12 }, { header: 'Rate', width: 12 }
      ],
      rows: [
        ['Blockwork walls', 'م²', 16, 22],
        ['Aluminium windows', 'عدد', 2, 320],
        ['Some odd item', 'furlong', 3, 10]
      ]
    }]
  });
  const r = await upload('owner', `/api/mmc-ai/projects/${projectId}/boq-imports`, 'units.xlsx', buf);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const byDesc = Object.fromEntries(r.data.lines.map((l) => [l.description, l]));
  assert.equal(byDesc['Blockwork walls'].unit, 'm2');
  assert.equal(byDesc['Blockwork walls'].unitKnown, true);
  assert.equal(byDesc['Aluminium windows'].unit, 'nr');
  assert.equal(byDesc['Some odd item'].unit, 'furlong');
  assert.equal(byDesc['Some odd item'].unitKnown, false);
  assert.equal(byDesc['Some odd item'].unitRaw, 'furlong');
});

test('BOQ import: a file with no header row is refused, not guessed', async () => {
  const buf = buildWorkbook({
    sheets: [{ name: 'Notes', columns: [{ header: 'A', width: 40 }], rows: [['This is a letter, not a BOQ.'], ['Nothing numeric here.']] }]
  });
  const r = await upload('owner', `/api/mmc-ai/projects/${projectId}/boq-imports`, 'notes.xlsx', buf);
  assert.equal(r.status, 422, JSON.stringify(r.data));
  assert.match(JSON.stringify(r.data), /لم تُقرأ أي بنود/);
});

test('BOQ import: matching proposes links with confidence, never applies them', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/match`, { modelId });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok(r.data.summary.importedLines === 6);
  assert.ok(r.data.summary.proposed > 0, 'at least one line should match a measured quantity');

  const proposed = r.data.lines.filter((l) => l.linkState === 'proposed');
  assert.ok(proposed.length > 0);
  for (const l of proposed) {
    assert.ok(l.match && l.match.ruleId, 'a proposed link names a rule');
    assert.ok(l.match.confidence > 0 && l.match.confidence <= 1);
    assert.ok(typeof l.match.signals.unitMatch === 'boolean');
  }
  // A line whose unit cannot match anything stays unmatched with a reason.
  const unmatched = r.data.lines.filter((l) => l.linkState === 'unmatched');
  for (const l of unmatched) assert.equal(l.match, null);
});

test('BOQ import: a human confirms one link and rejects another', async () => {
  const list = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}`);
  const proposed = list.data.lines.filter((l) => l.linkState === 'proposed');
  assert.ok(proposed.length >= 2, 'need two proposals to decide on');

  const confirm = await call('owner', 'PATCH',
    `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/lines/${proposed[0].id}`, { state: 'confirmed' });
  assert.equal(confirm.status, 200, JSON.stringify(confirm.data));
  assert.equal(confirm.data.line.linkState, 'confirmed');
  assert.ok(confirm.data.line.decidedBy);
  assert.ok(confirm.data.line.decidedAt);

  const reject = await call('owner', 'PATCH',
    `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/lines/${proposed[1].id}`, { state: 'rejected' });
  assert.equal(reject.status, 200, JSON.stringify(reject.data));
  assert.equal(reject.data.line.linkState, 'rejected');
});

test('BOQ import: re-running the match does not overwrite a human decision', async () => {
  const before = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}`);
  const confirmedBefore = before.data.lines.filter((l) => l.linkState === 'confirmed').map((l) => l.id);
  const rejectedBefore = before.data.lines.filter((l) => l.linkState === 'rejected').map((l) => l.id);
  assert.ok(confirmedBefore.length && rejectedBefore.length);

  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/match`, { modelId });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const after = r.data.lines;
  for (const id of confirmedBefore) assert.equal(after.find((l) => l.id === id).linkState, 'confirmed');
  for (const id of rejectedBefore) assert.equal(after.find((l) => l.id === id).linkState, 'rejected');
});

test('BOQ import: approval is blocked while a proposal is undecided', async () => {
  const list = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}`);
  const pending = list.data.lines.filter((l) => l.linkState === 'proposed');
  if (pending.length) {
    const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/approve`);
    assert.equal(r.status, 409, JSON.stringify(r.data));
    assert.match(JSON.stringify(r.data), /لم يُحسم/);
  }
  // Decide everything that is left, then approval succeeds and records who/when.
  for (const l of pending) {
    await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/lines/${l.id}`, { state: 'rejected' });
  }
  const ok = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}/approve`);
  assert.equal(ok.status, 200, JSON.stringify(ok.data));
  assert.equal(ok.data.import.status, 'approved');
  assert.ok(ok.data.import.approvedBy);
  assert.ok(ok.data.import.approvedAt);
});

test('BOQ import: an approved import cannot be deleted', async () => {
  const r = await call('owner', 'DELETE', `/api/mmc-ai/projects/${projectId}/boq-imports/${importId}`);
  assert.equal(r.status, 409, JSON.stringify(r.data));
});

/* =========================== 2. ALUMINIUM SCHEDULE ======================== */

let scheduleId;

test('aluminium: a schedule is built from the model openings with checkable numbers', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/aluminium/schedules`, {
    modelId, name: 'Aluminium — GF', currency: 'OMR'
  });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  scheduleId = r.data.schedule.id;
  assert.equal(r.data.schedule.status, 'draft_requires_review');
  assert.equal(r.data.openings.length, 2);

  const o1 = r.data.openings.find((o) => o.id === 'O1');
  // O1 is 1.2 x 1.5. Frame perimeter = 2*(1.2+1.5) = 5.4 m.
  assert.equal(o1.width, 1.2);
  assert.equal(o1.height, 1.5);
  assert.equal(o1.areaM2, 1.8);
  assert.equal(o1.lengths.frameM, 5.4);
  // Glass: one pane per panel (default 2), inset 50 mm all round.
  // pane = (1.2-0.1)/2 = 0.55 wide, (1.5-0.1) = 1.4 high -> 0.77 m2 per pane, 1.54 total.
  assert.equal(o1.glassM2, 1.54);

  const o2 = r.data.openings.find((o) => o.id === 'O2');
  // O2 is 0.9 x 2.1, a door by name? It is an opening with no door hint, so window.
  assert.equal(o2.areaM2, 1.89);
  assert.equal(o2.lengths.frameM, 6.0);

  // Totals are the sum of the openings, not a separate calculation.
  const frameLine = r.data.lines.find((l) => l.category === 'profile' && l.code === 'FR-50');
  assert.ok(frameLine);
  assert.equal(frameLine.lengthM, 11.4); // 5.4 + 6.0
  // 11.4 m at 6 m bars = 2 bars.
  assert.equal(frameLine.bars, 2);
  assert.equal(frameLine.orderedLengthM, 12);
  assert.equal(frameLine.total, 51.3); // 11.4 * 4.5

  const glassLine = r.data.lines.find((l) => l.category === 'glass');
  // O1 glass 1.54 + O2 glass 1.60 = 3.14 m2 (glass is inset by the frame, so it
  // is smaller than the 1.8 + 1.89 m2 of the openings themselves).
  assert.equal(glassLine.quantity, 3.14);
  assert.equal(glassLine.total, 37.68); // 3.14 * 12

  // The schedule total is the sum of its own lines.
  const sum = Number(r.data.lines.reduce((s, l) => s + l.total, 0).toFixed(3));
  assert.equal(r.data.schedule.total, sum);
});

test('aluminium: editing a profile price rebuilds the lines and the total', async () => {
  const before = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${scheduleId}`);
  const beforeTotal = before.data.schedule.total;
  const beforeFrame = before.data.lines.find((l) => l.code === 'FR-50');

  const r = await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${scheduleId}`, {
    profiles: { frame: { code: 'FR-50', name: 'إطار 50 مم', barLengthM: 6, unitPrice: 9.0 } }
  });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const afterFrame = r.data.lines.find((l) => l.code === 'FR-50');
  assert.equal(afterFrame.unitPrice, 9.0);
  assert.equal(afterFrame.total, 102.6); // 11.4 * 9
  // The total moved by exactly the difference on the frame line.
  const delta = Number((afterFrame.total - beforeFrame.total).toFixed(3));
  assert.equal(Number((r.data.schedule.total - beforeTotal).toFixed(3)), delta);
  // The other lines are untouched.
  const beforeGlass = before.data.lines.find((l) => l.category === 'glass');
  const afterGlass = r.data.lines.find((l) => l.category === 'glass');
  assert.equal(afterGlass.total, beforeGlass.total);
});

test('aluminium: bar waste raises the ordered bars, not the measured length', async () => {
  const r = await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${scheduleId}`, {
    barWastePercent: 20
  });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const frame = r.data.lines.find((l) => l.code === 'FR-50');
  // 11.4 m measured is unchanged; 11.4 * 1.2 = 13.68 -> 3 bars of 6 m.
  assert.equal(frame.lengthM, 11.4);
  assert.equal(frame.bars, 3);
  assert.equal(frame.orderedLengthM, 18);
});

test('aluminium: a model with no openings is refused with a clear message', async () => {
  const noOpenings = {
    name: 'No openings',
    storeys: [{ id: 'GF', name: 'Ground', elevation: 0 }],
    elements: [{ id: 'W1', type: 'wall', storeyId: 'GF', origin: { x: 0, y: 0, z: 0 }, length: 4, width: 0.2, height: 3 }]
  };
  const m = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: noOpenings });
  assert.equal(m.status, 201, JSON.stringify(m.data));
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/aluminium/schedules`, {
    modelId: m.data.model.id
  });
  assert.equal(r.status, 422, JSON.stringify(r.data));
  assert.match(JSON.stringify(r.data), /فتحة/);
});

test('aluminium: approval records who and when, and locks the schedule', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${scheduleId}/approve`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.schedule.status, 'approved');
  assert.ok(r.data.schedule.approvedBy);
  assert.ok(r.data.schedule.approvedAt);

  const edit = await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${scheduleId}`, {
    barWastePercent: 5
  });
  assert.equal(edit.status, 409, JSON.stringify(edit.data));
});

test('aluminium: the Excel export opens and carries the schedule', async () => {
  const r = await fetch(base + `/api/mmc-ai/projects/${projectId}/aluminium/schedules/${scheduleId}/export.xlsx`, {
    headers: { Cookie: jar.owner }
  });
  assert.equal(r.status, 200);
  const buf = Buffer.from(await r.arrayBuffer());
  assert.ok(buf.length > 2000);
  assert.equal(buf.slice(0, 2).toString(), 'PK');
  const { readXlsx } = require('../src/lib/mmc-ai/xlsx-reader');
  const wb = readXlsx(buf);
  assert.equal(wb.sheets.length, 3);
  assert.equal(wb.sheets[0].name, 'جدول الألمنيوم');
  assert.equal(wb.sheets[1].name, 'الفتحات');
  // The openings sheet has one row per opening plus its header.
  assert.ok(wb.sheets[1].rows.length >= 3);
});

/* ========================= 3. SPECIFICATION IMPORT ======================== */

let specDocId;

function specText() {
  return [
    'SECTION 03 — CONCRETE',
    '',
    '3.1 Reinforced concrete columns',
    'All reinforced concrete columns shall be Grade C30 with 400 MPa reinforcement. Concrete cover to reinforcement shall be 40 mm minimum. Columns shall be cast in one continuous pour.',
    '',
    '3.2 Reinforced concrete beams',
    'Reinforced concrete beams shall be Grade C30. Formwork shall remain in place for not less than 14 days. Beams shall be supported at third points during curing.',
    '',
    'SECTION 04 — MASONRY',
    '',
    '4.1 Blockwork walls',
    'Blockwork walls shall be 200 mm hollow concrete blocks with cement mortar 1:4. Walls shall be reinforced with horizontal joint reinforcement every third course.',
    '',
    'SECTION 08 — JOINERY',
    '',
    '8.1 Aluminium windows',
    'Aluminium windows shall be thermally broken profiles with 6 mm clear glazing. All windows shall be factory assembled and tested for water tightness before delivery.'
  ].join('\n');
}

test('specifications: a text specification is split into numbered clauses', async () => {
  const r = await upload('owner', `/api/mmc-ai/projects/${projectId}/specifications`, 'spec.txt', Buffer.from(specText(), 'utf8'));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  specDocId = r.data.document.id;
  assert.equal(r.data.document.status, 'imported_requires_review');
  assert.equal(r.data.document.clauseCount, 4);

  const codes = r.data.clauses.map((c) => c.code);
  assert.deepEqual(codes, ['3.1', '3.2', '4.1', '8.1']);
  const col = r.data.clauses.find((c) => c.code === '3.1');
  assert.match(col.title, /Reinforced concrete columns/);
  assert.match(col.body, /C30/);
  assert.match(col.body, /40 mm/);
});

test('specifications: clauses are linked to measured quantities with confidence', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/specifications/${specDocId}/link`, { modelId });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok(r.data.links.length > 0, 'at least one clause should link to a quantity rule');

  for (const l of r.data.links) {
    assert.equal(l.state, 'proposed');
    assert.ok(l.confidence > 0 && l.confidence <= 1);
    assert.ok(l.targetId);
    assert.ok(l.targetLabel);
  }
  // The concrete column clause must reach the column quantity rule.
  const colClause = r.data.links.filter((l) => l.targetId === 'Q-COLUMN-VOLUME');
  assert.ok(colClause.length > 0, 'column clause should link to the column volume rule');
  assert.ok(colClause.some((l) => l.signals.tradeMatch === true));
});

test('specifications: a link is confirmed and then visible on its target', async () => {
  const list = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/specifications/${specDocId}`);
  const target = list.data.links.find((l) => l.targetId === 'Q-COLUMN-VOLUME');
  assert.ok(target);

  const r = await call('owner', 'PATCH',
    `/api/mmc-ai/projects/${projectId}/specifications/${specDocId}/links/${target.id}`, { state: 'confirmed' });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.link.state, 'confirmed');
  assert.ok(r.data.link.decidedBy);

  const forTarget = await call('owner', 'GET',
    `/api/mmc-ai/projects/${projectId}/specifications/for-target?targetType=quantity_rule&targetId=Q-COLUMN-VOLUME`);
  assert.equal(forTarget.status, 200, JSON.stringify(forTarget.data));
  assert.ok(forTarget.data.links.length > 0);
  assert.ok(forTarget.data.confirmedCount >= 1);
  const hit = forTarget.data.links.find((l) => l.linkId === target.id);
  assert.ok(hit);
  assert.match(hit.clause.body, /C30/);
  assert.ok(hit.document.name);
});

test('specifications: approval is blocked while a link is still proposed', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/specifications/${specDocId}/approve`);
  assert.equal(r.status, 409, JSON.stringify(r.data));
  assert.match(JSON.stringify(r.data), /لم يُحسم/);
});

test('specifications: a scanned PDF with no text layer is refused, not invented', async () => {
  // A minimal PDF with no text operators at all.
  const pdf = Buffer.from(
    '%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n' +
    '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n' +
    '3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]>>endobj\n' +
    'trailer<</Root 1 0 R>>\n%%EOF\n', 'latin1'
  );
  const r = await upload('owner', `/api/mmc-ai/projects/${projectId}/specifications`, 'scanned.pdf', pdf);
  assert.equal(r.status, 422, JSON.stringify(r.data));
  assert.match(JSON.stringify(r.data), /لم تُستخرج أي بند/);
});

/* ============================ 4. RISK ANALYSIS ============================ */

let analysisId;

test('risk: analysis derives a register from the project data', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/risk-analysis`, { modelId, asOf: '2026-11-18' });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  analysisId = r.data.analysis.id;
  assert.equal(r.data.analysis.status, 'draft_requires_review');
  assert.ok(r.data.risks.length > 0);

  for (const risk of r.data.risks) {
    assert.ok(risk.probability >= 1 && risk.probability <= 5);
    assert.ok(risk.impact >= 1 && risk.impact <= 5);
    assert.equal(risk.score, risk.probability * risk.impact);
    assert.ok(risk.evidence.length > 0, 'every risk carries its evidence');
    assert.equal(risk.state, 'proposed');
    assert.ok(risk.response.length > 10, 'every risk has a response plan');
  }
  // The register is sorted by score, worst first.
  for (let i = 1; i < r.data.risks.length; i += 1) {
    assert.ok(r.data.risks[i - 1].score >= r.data.risks[i].score);
  }
  // With no schedule and no cost, those gaps must be reported.
  const codes = r.data.risks.map((x) => x.code);
  assert.ok(codes.includes('R-SCH-001'), 'missing schedule must be a risk');
  assert.ok(codes.includes('R-COST-001'), 'missing cost must be a risk');
});

test('risk: a risk is edited and its score recomputed', async () => {
  const list = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}`);
  const risk = list.data.risks[0];
  const r = await call('owner', 'PATCH',
    `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}/risks/${risk.id}`, {
    probability: 5, impact: 5, response: 'خطة استجابة معدّلة: مراجعة أسبوعية مع المقاول.', owner: 'مدير المشروع'
  });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.risk.score, 25);
  assert.equal(r.data.risk.level, 'critical');
  assert.equal(r.data.risk.owner, 'مدير المشروع');
});

test('risk: an out-of-range probability is refused', async () => {
  const list = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}`);
  const risk = list.data.risks[0];
  const r = await call('owner', 'PATCH',
    `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}/risks/${risk.id}`, { probability: 9 });
  assert.equal(r.status, 422, JSON.stringify(r.data));
});

test('risk: approval is blocked until every risk is decided', async () => {
  const blocked = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}/approve`);
  assert.equal(blocked.status, 409, JSON.stringify(blocked.data));

  const list = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}`);
  for (const risk of list.data.risks) {
    await call('owner', 'PATCH',
      `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}/risks/${risk.id}`, { state: 'accepted' });
  }
  const ok = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}/approve`);
  assert.equal(ok.status, 200, JSON.stringify(ok.data));
  assert.equal(ok.data.analysis.status, 'approved');
  assert.ok(ok.data.analysis.approvedBy);
  assert.ok(ok.data.analysis.approvedAt);
});

test('risk: an approved register cannot be edited', async () => {
  const list = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}`);
  const risk = list.data.risks[0];
  const r = await call('owner', 'PATCH',
    `/api/mmc-ai/projects/${projectId}/risk-analysis/${analysisId}/risks/${risk.id}`, { probability: 1 });
  assert.equal(r.status, 409, JSON.stringify(r.data));
});

/* ============================== ACCESS CONTROL ============================ */

test('access: a non-member cannot read any of the four capabilities', async () => {
  await register('outsider');
  const urls = [
    `/api/mmc-ai/projects/${projectId}/boq-imports`,
    `/api/mmc-ai/projects/${projectId}/aluminium/schedules`,
    `/api/mmc-ai/projects/${projectId}/specifications`,
    `/api/mmc-ai/projects/${projectId}/risk-analysis`
  ];
  for (const url of urls) {
    const r = await call('outsider', 'GET', url);
    assert.equal(r.status, 404, url + ' -> ' + JSON.stringify(r.data));
  }
});

test('access: an unauthenticated request is refused', async () => {
  const r = await fetch(base + `/api/mmc-ai/projects/${projectId}/risk-analysis`);
  assert.equal(r.status, 401);
});
