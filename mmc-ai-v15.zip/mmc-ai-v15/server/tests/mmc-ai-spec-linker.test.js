'use strict';
/**
 * Unit tests for specification → BOQ item linking.
 *
 * Two real defects found by uploading an Arabic specification sheet and
 * inspecting the proposed links:
 *   1. "بلاطات السقف" (roof slabs) linked to COLUMN volume, because the rule
 *      code "Q-COLUMN-VOLUME" was included in the comparison text and injected
 *      the English word "column" into every candidate.
 *   2. "خرسانة الأساسات" (footing concrete) linked to footing COUNT rather than
 *      footing VOLUME, because the Arabic article broke literal token matching.
 */

const test = require('node:test');
const assert = require('node:assert');
const { parseSpecTable, proposeSpecLinks } = require('../src/lib/mmc-ai/spec-import');

const QUANTITIES = [
  { ruleId: 'Q-FOOTING-VOLUME', description: 'Footing concrete volume', descriptionAr: 'حجم خرسانة الأساسات', label: { ar: 'حجم الأساسات', en: 'Footing volume' }, unit: 'm3', elementType: 'footing', discipline: 'structural' },
  { ruleId: 'Q-FOOTING-COUNT', description: 'Footing count', descriptionAr: 'عدد الأساسات', label: { ar: 'عدد الأساسات', en: 'Footing count' }, unit: 'nr', elementType: 'footing', discipline: 'structural' },
  { ruleId: 'Q-COLUMN-VOLUME', description: 'Column concrete volume', descriptionAr: 'حجم خرسانة الأعمدة', label: { ar: 'حجم الأعمدة', en: 'Column volume' }, unit: 'm3', elementType: 'column', discipline: 'structural' },
  { ruleId: 'Q-COLUMN-COUNT', description: 'Column count', descriptionAr: 'عدد الأعمدة', label: { ar: 'عدد الأعمدة', en: 'Column count' }, unit: 'nr', elementType: 'column', discipline: 'structural' },
  { ruleId: 'Q-SLAB-VOLUME', description: 'Slab concrete volume', descriptionAr: 'حجم خرسانة البلاطات', label: { ar: 'حجم البلاطات', en: 'Slab volume' }, unit: 'm3', elementType: 'slab', discipline: 'structural' },
  { ruleId: 'Q-SLAB-AREA', description: 'Slab top area', descriptionAr: 'مساحة سطح البلاطة', label: { ar: 'مساحة البلاطات', en: 'Slab area' }, unit: 'm2', elementType: 'slab', discipline: 'architectural' },
  { ruleId: 'Q-WALL-NET-AREA', description: 'Wall face area net of openings', descriptionAr: 'مساحة وجه الجدار بعد خصم الفتحات', label: { ar: 'مساحة الجدران الصافية', en: 'Wall net area' }, unit: 'm2', elementType: 'wall', discipline: 'architectural' },
  { ruleId: 'Q-WALL-LENGTH', description: 'Wall centreline length', descriptionAr: 'طول محور الجدار', label: { ar: 'طول الجدران', en: 'Wall length' }, unit: 'm', elementType: 'wall', discipline: 'architectural' },
  { ruleId: 'Q-OPENING-COUNT', description: 'Opening count', descriptionAr: 'عدد الفتحات', label: { ar: 'عدد الفتحات', en: 'Opening count' }, unit: 'nr', elementType: 'opening', discipline: 'architectural' },
  { ruleId: 'Q-OPENING-AREA', description: 'Opening area', descriptionAr: 'مساحة الفتحات', label: { ar: 'مساحة الفتحات', en: 'Opening area' }, unit: 'm2', elementType: 'opening', discipline: 'architectural' }
];

const TARGETS = QUANTITIES.map((r) => ({
  id: r.ruleId, code: r.ruleId, description: r.description, descriptionAr: r.descriptionAr,
  label: r.label, unit: r.unit, elementType: r.elementType, discipline: r.discipline
}));

function bestFor(title, body) {
  const clauses = parseSpecTable([['القسم', 'البند', 'المواصفة'], ['قسم', title, body]]);
  const r = proposeSpecLinks(clauses, TARGETS);
  return r.links[0] ? r.links[0].candidates[0] : null;
}

test('spec link: a roof-slab clause links to a SLAB rule, never a column rule', () => {
  const best = bestFor('بلاطات السقف', 'خرسانة مسلحة سماكة 200 مم');
  assert.ok(best, 'expected a link');
  assert.match(best.targetCode, /^Q-SLAB-/, 'linked to ' + best.targetCode);
});

test('spec link: footing concrete links to footing VOLUME, not footing count', () => {
  const best = bestFor('خرسانة الأساسات', 'خرسانة مسلحة C30/37 مقاومة للكبريتات');
  assert.ok(best);
  assert.equal(best.targetCode, 'Q-FOOTING-VOLUME');
});

test('spec link: column concrete links to a column rule', () => {
  const best = bestFor('خرسانة الأعمدة', 'خرسانة مسلحة C35/45');
  assert.ok(best);
  assert.match(best.targetCode, /^Q-COLUMN-/);
});

test('spec link: a block-wall clause links to a wall rule', () => {
  const best = bestFor('جدران البلوك', 'بلوك خرساني 200 مم، مونة أسمنتية 1:4');
  assert.ok(best);
  assert.match(best.targetCode, /^Q-WALL-/);
});

test('spec link: a windows clause links to an opening rule', () => {
  const best = bestFor('النوافذ', 'قطاعات ألمنيوم مؤكسدة 50 مم، زجاج مزدوج');
  assert.ok(best);
  assert.match(best.targetCode, /^Q-OPENING-/);
});

test('spec link: the rule code is not used as comparison text', () => {
  // If the code leaked in, "Q-COLUMN-VOLUME" would make every clause a column
  // candidate. A slab clause must not have a column rule as its best match.
  const best = bestFor('بلاطات السقف', 'خرسانة مسلحة');
  assert.ok(best);
  assert.ok(!/COLUMN/.test(best.targetCode), 'code leaked into matching: ' + best.targetCode);
});

test('spec link: confidence and its signals are reported', () => {
  const best = bestFor('خرسانة الأساسات', 'خرسانة مسلحة C30/37');
  assert.ok(best);
  assert.ok(best.confidence > 0 && best.confidence <= 1);
  assert.ok(typeof best.signals.conceptOverlap === 'number');
  assert.ok(typeof best.signals.keywordOverlap === 'number');
});
