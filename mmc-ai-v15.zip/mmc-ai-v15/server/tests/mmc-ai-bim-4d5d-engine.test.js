'use strict';
/**
 * BIM 4D/5D engine tests: calendar arithmetic, schedule resolution, element
 * linking, CSV import, cost model and cost curve.
 *
 * The numbers asserted here are hand-computed from the fixture, not copied
 * from the engine's own output.
 */
const test = require('node:test');
const assert = require('node:assert/strict');

const {
  normalizeCalendar, isWorkingDay, addWorkingDays, workingDaysBetween,
  parseDate, isoDate, buildSchedule, proposeElementLinks, parseScheduleCsv,
  buildCostModel, buildCostCurve, quantitiesAtDate, plannedFraction, earnedFraction
} = require('../src/lib/mmc-ai/bim-4d5d-engine');
const { buildModel, measureModel } = require('../src/lib/mmc-ai/bim-model');

// 2026-01-04 is a Sunday. The default calendar works Sun-Thu and takes Friday
// off, so 2026-01-09 (Friday) is the only off day in that week.
const SUN = '2026-01-04';
const MON = '2026-01-05';
const TUE = '2026-01-06';
const WED = '2026-01-07';
const THU = '2026-01-08';
const FRI = '2026-01-09';
const SAT = '2026-01-10';

test('calendar: default week is Sun-Thu with Friday off', () => {
  const cal = normalizeCalendar({});
  assert.equal(cal.workingDaysPerWeek, 6);
  assert.deepEqual(cal.offWeekdays, [5]);
  assert.equal(isWorkingDay(parseDate(SUN), cal), true);
  assert.equal(isWorkingDay(parseDate(FRI), cal), false);
  assert.equal(isWorkingDay(parseDate(SAT), cal), true);
});

test('calendar: rejects an inconsistent week', () => {
  assert.throws(() => normalizeCalendar({ workingDaysPerWeek: 5, offWeekdays: [5] }), /inconsistent/);
});

test('calendar: addWorkingDays skips Friday', () => {
  const cal = normalizeCalendar({});
  // Thu + 1 working day = Sat (Friday is skipped).
  assert.equal(isoDate(addWorkingDays(parseDate(THU), 1, cal)), SAT);
  // Sun + 4 working days = Thu of the same week.
  assert.equal(isoDate(addWorkingDays(parseDate(SUN), 4, cal)), THU);
  // Sun + 5 working days = Sat, because Friday is skipped.
  assert.equal(isoDate(addWorkingDays(parseDate(SUN), 5, cal)), SAT);
});

test('calendar: workingDaysBetween counts working days only', () => {
  const cal = normalizeCalendar({});
  // Sun -> Thu is 4 working days (Mon, Tue, Wed, Thu).
  assert.equal(workingDaysBetween(parseDate(SUN), parseDate(THU), cal), 4);
  // Sun -> Sat spans Friday off, so 5 working days.
  assert.equal(workingDaysBetween(parseDate(SUN), parseDate(SAT), cal), 5);
  assert.equal(workingDaysBetween(parseDate(THU), parseDate(SUN), cal), 0);
});

test('schedule: duration-driven activities chain finish-to-start', () => {
  const built = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A', name: 'Excavate', durationDays: 2 },
      { id: 'B', name: 'Footings', durationDays: 3, predecessors: ['A'] },
      { id: 'C', name: 'Columns', durationDays: 2, predecessors: ['B'] }
    ]
  });
  const byId = Object.fromEntries(built.activities.map((a) => [a.id, a]));
  assert.equal(byId.A.plannedStart, SUN);
  // 2 working days from Sun = Tue.
  assert.equal(byId.A.plannedFinish, TUE);
  assert.equal(byId.B.plannedStart, TUE);
  // 3 working days from Tue = Sat (Friday skipped).
  assert.equal(byId.B.plannedFinish, SAT);
  assert.equal(byId.C.plannedStart, SAT);
  assert.equal(built.projectStart, SUN);
  assert.equal(built.projectFinish, byId.C.plannedFinish);
});

test('schedule: rejects a dependency cycle', () => {
  assert.throws(() => buildSchedule({
    activities: [
      { id: 'A', name: 'A', durationDays: 1, predecessors: ['B'] },
      { id: 'B', name: 'B', durationDays: 1, predecessors: ['A'] }
    ]
  }), /cycle/);
});

test('schedule: rejects an unknown predecessor', () => {
  assert.throws(() => buildSchedule({
    activities: [{ id: 'A', name: 'A', durationDays: 1, predecessors: ['ZZ'] }]
  }), /unknown predecessor/);
});

test('schedule: date-driven activity keeps its dates and derives duration', () => {
  const built = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [{ id: 'A', name: 'Fixed', plannedStart: SUN, plannedFinish: THU }]
  });
  assert.equal(built.activities[0].plannedStart, SUN);
  assert.equal(built.activities[0].plannedFinish, THU);
  assert.equal(built.activities[0].durationDays, 4);
});

test('progress: planned fraction is linear in working days', () => {
  const cal = normalizeCalendar({});
  const a = {
    plannedStart: parseDate(SUN), plannedFinish: parseDate(THU),
    actualStart: null, actualFinish: null, percentComplete: 100
  };
  assert.equal(plannedFraction(a, parseDate(SUN), cal), 0);
  // 2 of 4 working days done = 0.5.
  assert.equal(plannedFraction(a, parseDate(TUE), cal), 0.5);
  assert.equal(plannedFraction(a, parseDate(THU), cal), 1);
  assert.equal(plannedFraction(a, parseDate(SAT), cal), 1);
});

test('progress: earned fraction is capped by reported percent complete', () => {
  const cal = normalizeCalendar({});
  const a = {
    plannedStart: parseDate(SUN), plannedFinish: parseDate(THU),
    actualStart: null, actualFinish: null, percentComplete: 50
  };
  // Half the time has passed but only 50% is reported, so earned = 0.25.
  assert.equal(earnedFraction(a, parseDate(TUE), cal), 0.25);
  // After the finish, earned equals the reported 50%, not 100%.
  assert.equal(earnedFraction(a, parseDate(SAT), cal), 0.5);
});

test('progress: an activity that has not started earns nothing', () => {
  const cal = normalizeCalendar({});
  const a = {
    plannedStart: parseDate(WED), plannedFinish: parseDate(SAT),
    actualStart: null, actualFinish: null, percentComplete: 100
  };
  assert.equal(earnedFraction(a, parseDate(TUE), cal), 0);
});

test('progress: an actual start later than plan delays earned quantity', () => {
  const cal = normalizeCalendar({});
  const a = {
    plannedStart: parseDate(SUN), plannedFinish: parseDate(THU),
    actualStart: parseDate(WED), actualFinish: null, percentComplete: 100
  };
  // Planned says half done by Tue, but work only started on Wed.
  assert.equal(earnedFraction(a, parseDate(TUE), cal), 0);
});

function fixtureModel() {
  return buildModel({
    name: '4D fixture',
    storeys: [
      { id: 'GF', name: 'Ground Floor', elevation: 0 },
      { id: 'FF', name: 'First Floor', elevation: 3.2 }
    ],
    elements: [
      { id: 'F1', type: 'footing', storeyId: 'GF', origin: { x: 0, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'F2', type: 'footing', storeyId: 'GF', origin: { x: 5, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'C1', type: 'column', storeyId: 'GF', origin: { x: 0, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'C2', type: 'column', storeyId: 'GF', origin: { x: 5, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'C3', type: 'column', storeyId: 'FF', origin: { x: 0, y: 0, z: 3.2 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'S1', type: 'slab', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0 }, length: 5, width: 4, height: 0.25 },
      { id: 'W1', type: 'wall', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0.25 }, length: 5, width: 0.2, height: 3.2 },
      { id: 'O1', type: 'opening', storeyId: 'GF', hostId: 'W1', origin: { x: 1.5, y: 0, z: 1.15 }, length: 1.2, width: 0.2, height: 1.5, sillHeight: 0.9 },
      { id: 'B1', type: 'beam', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 3.2 }, length: 5, width: 0.3, height: 0.5 }
    ]
  });
}

test('linking: element id match wins with confidence 1.0', () => {
  const model = fixtureModel();
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'Footings', durationDays: 3, elementIds: ['F1'] },
      { id: 'A2', name: 'Columns', durationDays: 3 }
    ]
  });
  const proposal = proposeElementLinks(model, schedule);
  const f1 = proposal.proposals.find((p) => p.elementId === 'F1');
  assert.equal(f1.activityId, 'A1');
  assert.equal(f1.ruleId, 'L-ELEMENT-ID');
  assert.equal(f1.confidence, 1);
  assert.equal(f1.state, 'proposed');
});

test('linking: type + storey beats type alone', () => {
  const model = fixtureModel();
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'Ground Floor Columns', durationDays: 3 },
      { id: 'A2', name: 'First Floor Columns', durationDays: 3 }
    ]
  });
  const proposal = proposeElementLinks(model, schedule);
  const c1 = proposal.proposals.find((p) => p.elementId === 'C1');
  const c3 = proposal.proposals.find((p) => p.elementId === 'C3');
  assert.equal(c1.activityId, 'A1');
  assert.equal(c1.ruleId, 'L-TYPE-STOREY');
  assert.equal(c1.confidence, 0.85);
  assert.equal(c3.activityId, 'A2');
});

test('linking: an element with no matching activity is reported unlinked', () => {
  const model = fixtureModel();
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [{ id: 'A1', name: 'Footings only', durationDays: 3 }]
  });
  const proposal = proposeElementLinks(model, schedule);
  const unlinkedIds = proposal.unlinked.map((u) => u.elementId);
  assert.ok(unlinkedIds.includes('C1'));
  assert.ok(unlinkedIds.includes('W1'));
  assert.equal(proposal.proposals.length + proposal.unlinkedCount, model.elements.length);
});

test('linking: an element is linked to at most one activity', () => {
  const model = fixtureModel();
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'Columns', durationDays: 3 },
      { id: 'A2', name: 'All columns again', durationDays: 3 }
    ]
  });
  const proposal = proposeElementLinks(model, schedule);
  const ids = proposal.proposals.map((p) => p.elementId);
  assert.equal(new Set(ids).size, ids.length);
});

test('csv: parses a schedule with quoted fields and predecessors', () => {
  const csv = [
    'id,name,duration_days,predecessors,percent_complete,trade',
    'A1,"Excavate, bulk",2,,100,earthworks',
    'A2,Footings,3,A1,50,concrete',
    'A3,Columns,2,A2,0,concrete'
  ].join('\n');
  const parsed = parseScheduleCsv(csv);
  assert.equal(parsed.activityCount, 3);
  assert.equal(parsed.activities[0].name, 'Excavate, bulk');
  assert.deepEqual(parsed.activities[1].predecessors, ['A1']);
  assert.equal(parsed.activities[1].percentComplete, 50);
  assert.equal(parsed.activities[2].trade, 'concrete');
});

test('csv: rejects a file with no name column', () => {
  assert.throws(() => parseScheduleCsv('id,duration\nA1,2'), /name column/);
});

test('csv: skips rows with an empty name and reports them', () => {
  const parsed = parseScheduleCsv('id,name,duration_days\nA1,Real,2\nA2,,3');
  assert.equal(parsed.activityCount, 1);
  assert.equal(parsed.skipped.length, 1);
  assert.equal(parsed.skipped[0].reason, 'empty_name');
});

test('cost: quantity x unit rate, with unit mismatch reported unpriced', () => {
  const model = fixtureModel();
  const measurement = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const cost = buildCostModel(measurement, [
    { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 120 },
    { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 100 },
    { ruleId: 'Q-WALL-NET-AREA', unit: 'm2', unitRate: 25 },
    // Deliberately wrong unit: must be reported, not silently priced.
    { ruleId: 'Q-SLAB-AREA', unit: 'm3', unitRate: 50 }
  ]);
  const col = cost.rows.find((r) => r.ruleId === 'Q-COLUMN-VOLUME');
  // 3 columns x 0.4 x 0.4 x 3.2 = 1.536 m3
  assert.equal(col.quantity, 1.536);
  assert.equal(col.total, 184.32);
  const slab = cost.unpriced.find((u) => u.ruleId === 'Q-SLAB-AREA');
  assert.ok(slab);
  assert.equal(slab.reason, 'unit_mismatch');
  assert.equal(cost.rows.some((r) => r.ruleId === 'Q-SLAB-AREA'), false);
});

test('cost: a rule with no cost item is reported unpriced', () => {
  const model = fixtureModel();
  const measurement = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const cost = buildCostModel(measurement, [{ ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 120 }]);
  assert.ok(cost.unpriced.some((u) => u.ruleId === 'Q-FOOTING-VOLUME' && u.reason === 'no_cost_item'));
});

test('cost: totals and storey split add up', () => {
  const model = fixtureModel();
  const measurement = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const cost = buildCostModel(measurement, [
    { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 120 },
    { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 100 },
    { ruleId: 'Q-WALL-NET-AREA', unit: 'm2', unitRate: 25 },
    { ruleId: 'Q-WALL-NET-VOLUME', unit: 'm3', unitRate: 300 },
    { ruleId: 'Q-SLAB-AREA', unit: 'm2', unitRate: 50 },
    { ruleId: 'Q-SLAB-VOLUME', unit: 'm3', unitRate: 110 },
    { ruleId: 'Q-BEAM-VOLUME', unit: 'm3', unitRate: 130 },
    { ruleId: 'Q-BEAM-LENGTH', unit: 'm', unitRate: 40 },
    { ruleId: 'Q-WALL-LENGTH', unit: 'm', unitRate: 30 },
    { ruleId: 'Q-COLUMN-COUNT', unit: 'nr', unitRate: 15 },
    { ruleId: 'Q-FOOTING-COUNT', unit: 'nr', unitRate: 20 },
    { ruleId: 'Q-OPENING-COUNT', unit: 'nr', unitRate: 10 },
    { ruleId: 'Q-OPENING-AREA', unit: 'm2', unitRate: 5 }
  ]);
  const sum = Number(cost.rows.reduce((s, r) => s + r.total, 0).toFixed(6));
  assert.equal(cost.total, sum);
  const storeySum = Number(Object.values(cost.byStorey).reduce((s, v) => s + v, 0).toFixed(4));
  assert.ok(Math.abs(storeySum - cost.total) < 0.01, `storey split ${storeySum} vs total ${cost.total}`);
});

test('cost curve: starts at zero and ends at the full planned cost', () => {
  const model = fixtureModel();
  const measurement = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const cost = buildCostModel(measurement, [
    { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 120 },
    { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 100 }
  ]);
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'Footings', durationDays: 3, elementIds: ['F1', 'F2'] },
      { id: 'A2', name: 'Columns', durationDays: 3, predecessors: ['A1'], elementIds: ['C1', 'C2', 'C3'] }
    ]
  });
  const curve = buildCostCurve(schedule, cost, { stepDays: 1 });
  assert.equal(curve.points[0].plannedCost, 0);
  const last = curve.points[curve.points.length - 1];
  assert.ok(Math.abs(last.plannedCost - cost.total) < 0.01, `final ${last.plannedCost} vs ${cost.total}`);
  // Planned cost must never decrease.
  for (let i = 1; i < curve.points.length; i += 1) {
    assert.ok(curve.points[i].plannedCost >= curve.points[i - 1].plannedCost - 1e-9);
  }
});

test('cost curve: actual cost only appears after an actual start', () => {
  const model = fixtureModel();
  const measurement = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const cost = buildCostModel(measurement, [{ ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 100, actualCost: 500 }]);
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'Footings', durationDays: 3, elementIds: ['F1', 'F2'], actualStart: WED, percentComplete: 20 }
    ]
  });
  const curve = buildCostCurve(schedule, cost, { stepDays: 1 });
  const before = curve.points.find((p) => p.date === TUE);
  const after = curve.points.find((p) => p.date === THU);
  assert.equal(before.actualCost, 0);
  assert.ok(after.actualCost > 0);
});

test('quantities at date: planned and earned split by linked elements', () => {
  const model = fixtureModel();
  const measurement = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'Footings', durationDays: 4, elementIds: ['F1', 'F2'], percentComplete: 100 }
    ]
  });
  const at = quantitiesAtDate(model, measurement, schedule, TUE);
  const foot = at.rows.find((r) => r.ruleId === 'Q-FOOTING-VOLUME');
  // 2 of 4 working days = 50% planned; earned is capped by 100% progress so also 50%.
  assert.equal(foot.plannedShare, 0.5);
  assert.equal(foot.earnedShare, 0.5);
  assert.equal(foot.plannedQuantity, Number((foot.totalQuantity * 0.5).toFixed(6)));
  const col = at.rows.find((r) => r.ruleId === 'Q-COLUMN-VOLUME');
  // Columns are not linked to any activity, so nothing is planned or earned.
  assert.equal(col.plannedQuantity, 0);
  assert.equal(col.earnedQuantity, 0);
  assert.equal(col.unlinkedElements, 3);
});

test('linking: a preparatory activity does not claim the elements it names', () => {
  const model = fixtureModel();
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'Excavation for footings', durationDays: 3, trade: 'earthworks' },
      { id: 'A2', name: 'Pad footings concrete', durationDays: 3, predecessors: ['A1'], trade: 'concrete' }
    ]
  });
  const proposal = proposeElementLinks(model, schedule);
  const f1 = proposal.proposals.find((p) => p.elementId === 'F1');
  // Excavation names footings but does not place them; the concrete activity owns them.
  assert.equal(f1.activityId, 'A2');
  assert.equal(proposal.skippedActivities.length, 1);
  assert.equal(proposal.skippedActivities[0].activityId, 'A1');
  assert.equal(proposal.skippedActivities[0].reason, 'non_building_activity');
});

test('linking: an Arabic preparatory activity is also excluded', () => {
  const model = fixtureModel();
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'أعمال الحفر للأساسات', durationDays: 3 },
      { id: 'A2', name: 'صب الأساسات', durationDays: 3, predecessors: ['A1'] }
    ]
  });
  const proposal = proposeElementLinks(model, schedule);
  assert.equal(proposal.skippedActivities.length, 1);
  const f1 = proposal.proposals.find((p) => p.elementId === 'F1');
  assert.equal(f1.activityId, 'A2');
});

test('cost curve: the final point is the finish date even when the step overshoots', () => {
  const model = fixtureModel();
  const measurement = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const cost = buildCostModel(measurement, [{ ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 100 }]);
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [{ id: 'A1', name: 'Footings', durationDays: 5, elementIds: ['F1', 'F2'] }]
  });
  // A 7-day step over a 5-working-day programme would otherwise stop at day 0.
  const curve = buildCostCurve(schedule, cost, { stepDays: 7 });
  const last = curve.points[curve.points.length - 1];
  assert.equal(last.date, schedule.projectFinish);
  assert.ok(Math.abs(last.plannedCost - cost.total) < 0.01);
});

test('quantities at date: totals by unit are consistent', () => {
  const model = fixtureModel();
  const measurement = measureModel(model, { modelId: 'm1', projectId: 'p1' });
  const schedule = buildSchedule({
    calendar: { dataDate: SUN },
    activities: [
      { id: 'A1', name: 'Footings', durationDays: 4, elementIds: ['F1', 'F2'], percentComplete: 100 },
      { id: 'A2', name: 'Columns', durationDays: 4, elementIds: ['C1', 'C2', 'C3'], percentComplete: 50 }
    ]
  });
  const at = quantitiesAtDate(model, measurement, schedule, THU);
  for (const [unit, t] of Object.entries(at.totalsByUnit)) {
    assert.ok(t.planned <= t.total + 1e-6, `${unit} planned ${t.planned} > total ${t.total}`);
    assert.ok(t.earned <= t.total + 1e-6, `${unit} earned ${t.earned} > total ${t.total}`);
    assert.ok(Math.abs(t.remaining - (t.total - t.earned)) < 1e-6, `${unit} remaining mismatch`);
  }
});
