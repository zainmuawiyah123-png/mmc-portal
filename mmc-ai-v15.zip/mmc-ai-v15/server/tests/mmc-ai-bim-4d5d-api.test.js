'use strict';
/**
 * BIM 4D/5D API test: build a model, create a schedule, propose links, decide
 * them, read 4D quantities, set unit rates, build cost, read the cost curve and
 * approve — all through the real HTTP routes with real authentication.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mmc-ai-4d5d-api-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json';
process.env.DB_PATH = path.join(TMP, 'test.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false';
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'mmc-ai-4d5d-api-test-secret';
process.env.BCRYPT_ROUNDS = '4';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { closeDB, getDB } = require('../src/db');

let server, base;
const jar = {};

async function call(user, method, url, body) {
  const headers = { ...(jar[user] ? { Cookie: jar[user] } : {}) };
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) jar[user] = first;
  }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data, headers: r.headers };
}

const uniq = () => Math.random().toString(36).slice(2, 10);

async function register(key) {
  const email = key + uniq() + '@test.local';
  const r = await call(key, 'POST', '/api/auth/register', { name: key, email, password: 'Password123', company: key });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const db = getDB();
  const user = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now, user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);
  const login = await call(key, 'POST', '/api/auth/login', { email, password: 'Password123' });
  assert.equal(login.status, 200, JSON.stringify(login.data));
  return user.id;
}

function sampleModel() {
  return {
    name: '4D/5D API building',
    storeys: [
      { id: 'GF', name: 'Ground Floor', elevation: 0 },
      { id: 'FF', name: 'First Floor', elevation: 3.2 }
    ],
    elements: [
      { id: 'F1', type: 'footing', storeyId: 'GF', origin: { x: 0, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'F2', type: 'footing', storeyId: 'GF', origin: { x: 5, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'C1', type: 'column', storeyId: 'GF', origin: { x: 0, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'C2', type: 'column', storeyId: 'GF', origin: { x: 5, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'C3', type: 'column', storeyId: 'FF', origin: { x: 0, y: 0, z: 3.2 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'S1', type: 'slab', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0 }, length: 5, width: 4, height: 0.25 },
      { id: 'W1', type: 'wall', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0.25 }, length: 5, width: 0.2, height: 3.2 },
      { id: 'O1', type: 'opening', storeyId: 'GF', hostId: 'W1', origin: { x: 1.5, y: 0, z: 1.15 }, length: 1.2, width: 0.2, height: 1.5, sillHeight: 0.9 },
      { id: 'B1', type: 'beam', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 3.2 }, length: 5, width: 0.3, height: 0.5 }
    ]
  };
}

let projectId, modelId, scheduleId;

test.before(async () => {
  migrate();
  const app = createApp();
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = 'http://127.0.0.1:' + server.address().port;
});

test.after(async () => {
  if (server) await new Promise((r) => server.close(r));
  closeDB();
  fs.rmSync(TMP, { recursive: true, force: true });
});

test('setup: register an owner and create a project', async () => {
  await register('owner');
  const r = await call('owner', 'POST', '/api/mmc-ai/projects', { name: '4D5D project', currency: 'OMR' });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  projectId = r.data.project.project_id;
  assert.ok(projectId);
});

test('setup: build a BIM model', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  modelId = r.data.model.id;
  assert.equal(r.data.model.elementCount, 9);
  assert.ok(r.data.quantities.length > 0);
});

test('4D: create a schedule with a dependency chain', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/schedule`, {
    name: 'Construction programme',
    dataDate: '2026-01-04',
    schedule: {
      calendar: { dataDate: '2026-01-04' },
      activities: [
        { id: 'A1', name: 'Footings', durationDays: 3, trade: 'concrete', percentComplete: 100, actualStart: '2026-01-04', actualFinish: '2026-01-06' },
        { id: 'A2', name: 'Ground Floor Columns', durationDays: 4, predecessors: ['A1'], trade: 'concrete', percentComplete: 50, actualStart: '2026-01-07' },
        { id: 'A3', name: 'First Floor Columns', durationDays: 3, predecessors: ['A2'], trade: 'concrete' },
        { id: 'A4', name: 'Walls', durationDays: 5, predecessors: ['A2'], trade: 'blockwork' }
      ]
    }
  });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  scheduleId = r.data.schedule.id;
  assert.equal(r.data.schedule.status, 'draft');
  assert.equal(r.data.activities.length, 4);
  const a1 = r.data.activities.find((a) => a.id === 'A1');
  assert.equal(a1.plannedStart, '2026-01-04');
  // 3 working days from Sunday = Wednesday 2026-01-07.
  assert.equal(a1.plannedFinish, '2026-01-07');
  const a2 = r.data.activities.find((a) => a.id === 'A2');
  assert.equal(a2.plannedStart, '2026-01-07');
});

test('4D: propose element links with confidence and rules', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/propose-links`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok(r.data.proposalCount > 0);
  assert.ok(r.data.links.every((l) => l.state === 'proposed'));
  assert.ok(r.data.links.every((l) => l.confidence > 0 && l.ruleId));
  const f1 = r.data.links.find((l) => l.elementId === 'F1');
  assert.equal(f1.activityId, 'A1');
  // The activity is named "Footings" with no storey, so only the type matches.
  assert.equal(f1.ruleId, 'L-TYPE');
  assert.equal(f1.confidence, 0.6);
  // An activity that names its storey gets the stronger type+storey rule.
  const c1 = r.data.links.find((l) => l.elementId === 'C1');
  assert.equal(c1.activityId, 'A2');
  assert.equal(c1.ruleId, 'L-TYPE-STOREY');
  assert.equal(c1.confidence, 0.85);
});

test('4D: a proposed link does not drive quantities until confirmed', async () => {
  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/quantities-at?at=2026-01-08`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.confirmedLinkCount, 0);
  const foot = r.data.rows.find((x) => x.ruleId === 'Q-FOOTING-VOLUME');
  assert.equal(foot.plannedQuantity, 0);
});

test('4D: confirming links makes quantities appear', async () => {
  const links = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`);
  const decisions = links.data.links.map((l) => ({ elementId: l.elementId, state: 'confirmed' }));
  const r = await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, { decisions });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.applied.length, decisions.length);
  assert.equal(r.data.rejected.length, 0);
  assert.ok(r.data.links.every((l) => l.state === 'confirmed'));
  assert.ok(r.data.links.every((l) => l.decidedBy && l.decidedAt));
});

test('4D: quantities at a date are planned and earned', async () => {
  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/quantities-at?at=2026-01-08`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok(r.data.confirmedLinkCount > 0);
  const foot = r.data.rows.find((x) => x.ruleId === 'Q-FOOTING-VOLUME');
  // Footings finished on 2026-01-06, so by 2026-01-08 they are fully earned.
  assert.equal(foot.earnedQuantity, foot.totalQuantity);
  assert.equal(foot.remainingQuantity, 0);
  const col = r.data.rows.find((x) => x.ruleId === 'Q-COLUMN-VOLUME');
  // Columns started 2026-01-07 at 50% reported; by 2026-01-08 some is earned.
  assert.ok(col.earnedQuantity > 0);
  assert.ok(col.earnedQuantity < col.totalQuantity);
});

test('4D: rejecting a link removes it from the quantity basis', async () => {
  const r = await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, {
    decisions: [{ elementId: 'F1', state: 'rejected' }]
  });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const f1 = r.data.links.find((l) => l.elementId === 'F1');
  assert.equal(f1.state, 'rejected');
  const q = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/quantities-at?at=2026-01-08`);
  const foot = q.data.rows.find((x) => x.ruleId === 'Q-FOOTING-VOLUME');
  // One of the two footings is no longer linked, so earned is half.
  assert.ok(foot.earnedQuantity < foot.totalQuantity);
  // Restore it for the remaining tests.
  await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, {
    decisions: [{ elementId: 'F1', state: 'confirmed' }]
  });
});

test('4D: re-proposing does not overwrite a human decision', async () => {
  await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, {
    decisions: [{ elementId: 'C1', state: 'rejected' }]
  });
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/propose-links`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const c1 = r.data.links.find((l) => l.elementId === 'C1');
  assert.equal(c1.state, 'rejected');
  await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, {
    decisions: [{ elementId: 'C1', state: 'confirmed' }]
  });
});

test('4D: approving a schedule with pending links is refused', async () => {
  // Create a fresh schedule so it has undecided proposals.
  const s = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/schedule`, {
    name: 'Second programme',
    schedule: { calendar: { dataDate: '2026-01-04' }, activities: [{ id: 'B1', name: 'Footings', durationDays: 2 }] }
  });
  assert.equal(s.status, 201, JSON.stringify(s.data));
  const sid = s.data.schedule.id;
  await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/schedule/${sid}/propose-links`);
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/schedule/${sid}/approve`, {});
  assert.equal(r.status, 409, JSON.stringify(r.data));
  assert.match(r.data.error.message, /رابط/);
});

test('4D: approving a schedule records who and when', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/approve`, {});
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.schedule.status, 'approved');
  assert.ok(r.data.schedule.approvedBy);
  assert.ok(r.data.schedule.approvedAt);
});

test('4D: CSV import builds a schedule', async () => {
  const csv = [
    'id,name,duration_days,predecessors,percent_complete,trade',
    'X1,Excavation,2,,100,earthworks',
    'X2,Blinding and footings,3,X1,40,concrete',
    'X3,Columns,4,X2,0,concrete'
  ].join('\n');
  const form = new FormData();
  form.append('file', new Blob([csv], { type: 'text/csv' }), 'programme.csv');
  form.append('name', 'Imported programme');
  const r = await fetch(`${base}/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/schedule/import`, {
    method: 'POST', headers: { Cookie: jar.owner }, body: form
  });
  const data = await r.json();
  assert.equal(r.status, 201, JSON.stringify(data));
  assert.equal(data.activities.length, 3);
  assert.equal(data.importReport.rowsRead, 3);
  const x2 = data.activities.find((a) => a.id === 'X2');
  assert.equal(x2.percentComplete, 40);
  assert.deepEqual(x2.predecessors, ['X1']);
});

test('5D: setting unit rates rejects a negative rate', async () => {
  const r = await call('owner', 'PUT', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost-items`, {
    items: [{ ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: -5 }]
  });
  assert.equal(r.status, 422, JSON.stringify(r.data));
});

test('5D: setting unit rates stores them', async () => {
  const r = await call('owner', 'PUT', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost-items`, {
    currency: 'OMR',
    items: [
      { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 95, actualCost: 300 },
      { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 130 },
      { ruleId: 'Q-WALL-NET-AREA', unit: 'm2', unitRate: 22 },
      { ruleId: 'Q-WALL-NET-VOLUME', unit: 'm3', unitRate: 280 },
      { ruleId: 'Q-SLAB-AREA', unit: 'm2', unitRate: 45 },
      { ruleId: 'Q-SLAB-VOLUME', unit: 'm3', unitRate: 105 },
      { ruleId: 'Q-BEAM-VOLUME', unit: 'm3', unitRate: 125 },
      { ruleId: 'Q-BEAM-LENGTH', unit: 'm', unitRate: 35 },
      { ruleId: 'Q-WALL-LENGTH', unit: 'm', unitRate: 28 },
      { ruleId: 'Q-COLUMN-COUNT', unit: 'nr', unitRate: 12 },
      { ruleId: 'Q-FOOTING-COUNT', unit: 'nr', unitRate: 18 },
      { ruleId: 'Q-OPENING-COUNT', unit: 'nr', unitRate: 8 },
      { ruleId: 'Q-OPENING-AREA', unit: 'm2', unitRate: 4 }
    ]
  });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.saved.length, 13);
  assert.equal(r.data.currency, 'OMR');
});

test('5D: building the cost model produces rows and a total', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost`, { currency: 'OMR' });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.ok(r.data.rowCount > 0);
  assert.ok(r.data.total > 0);
  assert.equal(r.data.currency, 'OMR');
  const col = r.data.rows.find((x) => x.ruleId === 'Q-COLUMN-VOLUME');
  // 3 columns x 0.4 x 0.4 x 3.2 = 1.536 m3 x 130 = 199.68
  assert.equal(col.quantity, 1.536);
  assert.equal(col.total, 199.68);
  assert.equal(col.reviewState, 'cost_draft_requires_review');
  const sum = Number(r.data.rows.reduce((s, x) => s + x.total, 0).toFixed(6));
  assert.equal(r.data.total, sum);
});

test('5D: cost curve runs from zero to the full planned cost', async () => {
  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost-curve?scheduleId=${scheduleId}&stepDays=1`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok(r.data.pointCount > 1);
  assert.equal(r.data.points[0].plannedCost, 0);
  const last = r.data.points[r.data.points.length - 1];
  assert.ok(Math.abs(last.plannedCost - r.data.totals.planned) < 0.01);
  for (let i = 1; i < r.data.points.length; i += 1) {
    assert.ok(r.data.points[i].plannedCost >= r.data.points[i - 1].plannedCost - 1e-9);
  }
});

test('5D: approving cost records who and when', async () => {
  const r = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost/approve`, {});
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok(r.data.rows.every((x) => x.reviewState === 'approved'));
  assert.ok(r.data.rows.every((x) => x.approvedBy && x.approvedAt));
});

test('permissions: a non-member cannot read the schedule', async () => {
  await register('outsider');
  const r = await call('outsider', 'GET', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}`);
  assert.equal(r.status, 404, JSON.stringify(r.data));
});

test('permissions: a viewer cannot create a schedule', async () => {
  const db = getDB();
  const viewerId = await register('viewer');
  db.prepare("INSERT INTO ai_project_members(project_id,user_id,role,invited_by) VALUES(?,?,'viewer',?)")
    .run(projectId, viewerId, viewerId);
  const r = await call('viewer', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/schedule`, {
    schedule: { activities: [{ id: 'Z1', name: 'Z', durationDays: 1 }] }
  });
  assert.equal(r.status, 403, JSON.stringify(r.data));
});

test('rules endpoint exposes the linking vocabulary', async () => {
  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/4d5d/rules`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.linkRules.length, 4);
  assert.ok(r.data.csvColumns.includes('duration_days'));
  assert.equal(r.data.defaultCalendar.workingDaysPerWeek, 6);
});
