'use strict';
/**
 * Approved BOQ + cost Excel export — API test.
 *
 * Exercises the real HTTP route with real authentication and a real database:
 *   build model -> measure -> approve -> set rates -> build cost -> approve cost
 *   -> export .xlsx -> read the bytes back and assert what is inside.
 *
 * The assertions that matter:
 *   - only approved rows are in the BOQ sheet;
 *   - an unapproved row is excluded and reported, not silently dropped;
 *   - every row carries its drawing sheet/page and source file;
 *   - the exported total equals the stored cost total;
 *   - the file is a real XLSX (ZIP) and its parts are well-formed XML.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mmc-ai-boq-export-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json';
process.env.DB_PATH = path.join(TMP, 'test.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false';
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'mmc-ai-boq-export-test-secret';
process.env.BCRYPT_ROUNDS = '4';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { closeDB } = require('../src/db');

let server, base;
const jar = {};

async function call(user, method, url, body) {
  const headers = { ...(jar[user] ? { Cookie: jar[user] } : {}) };
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) jar[user] = first;
  }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data, headers: r.headers };
}

async function callBinary(user, url) {
  const headers = { ...(jar[user] ? { Cookie: jar[user] } : {}) };
  const r = await fetch(base + url, { headers, redirect: 'manual' });
  const buf = Buffer.from(await r.arrayBuffer());
  return { status: r.status, buf, headers: r.headers };
}

const uniq = () => Math.random().toString(36).slice(2, 10);

async function register(key) {
  const email = key + uniq() + '@test.local';
  const r = await call(key, 'POST', '/api/auth/register', { name: key, email, password: 'Password123', company: key });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const db = require('../src/db').getDB();
  const user = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now, user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);
  const login = await call(key, 'POST', '/api/auth/login', { email, password: 'Password123' });
  assert.equal(login.status, 200, JSON.stringify(login.data));
  return user.id;
}

/** Reads a ZIP's entries without any dependency, so the test checks the bytes. */
function readZip(buf) {
  const entries = new Map();
  let i = 0;
  while (i < buf.length - 4) {
    if (buf.readUInt32LE(i) !== 0x04034b50) break;
    const method = buf.readUInt16LE(i + 8);
    const compSize = buf.readUInt32LE(i + 18);
    const nameLen = buf.readUInt16LE(i + 26);
    const extraLen = buf.readUInt16LE(i + 28);
    const name = buf.slice(i + 30, i + 30 + nameLen).toString('utf8');
    const dataStart = i + 30 + nameLen + extraLen;
    const raw = buf.slice(dataStart, dataStart + compSize);
    entries.set(name, method === 8 ? zlib.inflateRawSync(raw) : raw);
    i = dataStart + compSize;
  }
  return entries;
}

function sheetRows(xml) {
  const rows = [];
  const rowRe = /<row[^>]*>([\s\S]*?)<\/row>/g;
  let m;
  while ((m = rowRe.exec(xml))) {
    const cells = [];
    const cellRe = /<c r="([A-Z]+)\d+"[^>]*?(?:\/>|>([\s\S]*?)<\/c>)/g;
    let c;
    while ((c = cellRe.exec(m[1]))) {
      const inner = c[2] || '';
      const v = /<v>([\s\S]*?)<\/v>/.exec(inner);
      const t = /<t[^>]*>([\s\S]*?)<\/t>/.exec(inner);
      cells.push(v ? Number(v[1]) : t ? t[1] : '');
    }
    rows.push(cells);
  }
  return rows;
}

function sampleModel() {
  return {
    name: 'Export test building',
    storeys: [{ id: 'GF', name: 'Ground Floor', elevation: 0 }],
    elements: [
      {
        id: 'F1', type: 'footing', storeyId: 'GF', origin: { x: 0, y: 0, z: -0.6 },
        length: 1.5, width: 1.5, height: 0.6,
        source: { sheetNumber: 'S-201', sheetName: 'Foundation Plan', pageNumber: 2, documentName: 'struct.pdf', revision: 'B' }
      },
      {
        id: 'C1', type: 'column', storeyId: 'GF', origin: { x: 0, y: 0, z: 0 },
        length: 0.4, width: 0.4, height: 3.2,
        source: { sheetNumber: 'S-201', sheetName: 'Foundation Plan', pageNumber: 2, documentName: 'struct.pdf', revision: 'B' }
      },
      {
        id: 'W1', type: 'wall', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0.25 },
        length: 5, width: 0.2, height: 3.2,
        source: { sheetNumber: 'A-101', sheetName: 'Ground Floor Plan', pageNumber: 1, documentName: 'arch.pdf', revision: 'C' }
      },
      {
        id: 'O1', type: 'opening', storeyId: 'GF', hostId: 'W1', origin: { x: 1.5, y: 0, z: 1.15 },
        length: 1.2, width: 0.2, height: 1.5, sillHeight: 0.9,
        source: { sheetNumber: 'A-101', sheetName: 'Ground Floor Plan', pageNumber: 1, documentName: 'arch.pdf', revision: 'C' }
      },
      {
        id: 'S1', type: 'slab', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0 },
        length: 5, width: 4, height: 0.25,
        source: { sheetNumber: 'S-202', sheetName: 'Slab Plan', pageNumber: 3, documentName: 'struct.pdf', revision: 'B' }
      }
    ]
  };
}

test.before(async () => {
  migrate();
  const app = createApp();
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      base = 'http://127.0.0.1:' + server.address().port;
      resolve();
    });
  });
});

test.after(async () => {
  if (server) await new Promise((r) => server.close(r));
  closeDB();
  fs.rmSync(TMP, { recursive: true, force: true });
});

test('approved BOQ exports to Excel with per-row drawing provenance', async () => {
  const owner = await register('owner');
  const project = await call('owner', 'POST', '/api/mmc-ai/projects', { name: 'Export project', currency: 'OMR' });
  assert.equal(project.status, 201, JSON.stringify(project.data));
  const projectId = project.data.project.project_id;

  const built = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  assert.equal(built.status, 201, JSON.stringify(built.data));
  const modelId = built.data.model.id;
  assert.equal(built.data.model.elementCount, 5);

  // Provenance must survive the round trip through the database.
  const detail = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}`);
  assert.equal(detail.status, 200);
  const wall = detail.data.elements.find((e) => e.id === 'W1');
  assert.equal(wall.source.sheetNumber, 'A-101');
  assert.equal(wall.source.documentName, 'arch.pdf');
  const wallArea = detail.data.quantities.find((q) => q.ruleId === 'Q-WALL-NET-AREA');
  assert.ok(wallArea.sources.length >= 1, 'quantity row must carry its sources');
  assert.equal(wallArea.sources[0].sheetNumber, 'A-101');
  assert.match(wallArea.sourceLabel, /A-101/);

  // Before approval, the export must contain nothing in the BOQ sheet.
  const before = await callBinary('owner', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-export.xlsx`);
  assert.equal(before.status, 200);
  assert.equal(before.headers.get('x-export-approved-rows'), '0');
  const beforeZip = readZip(before.buf);
  const beforeBoq = sheetRows(beforeZip.get('xl/worksheets/sheet1.xml').toString('utf8'));
  const beforeData = beforeBoq.filter((r) => typeof r[0] === 'number');
  assert.equal(beforeData.length, 0, 'no approved rows means no BOQ rows');

  // Approve the quantities.
  const approved = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/approve`);
  assert.equal(approved.status, 200, JSON.stringify(approved.data));

  // Set unit rates and build the cost.
  const rates = [
    { ruleId: 'Q-WALL-NET-AREA', unit: 'm2', unitRate: 10 },
    { ruleId: 'Q-WALL-NET-VOLUME', unit: 'm3', unitRate: 80 },
    { ruleId: 'Q-WALL-LENGTH', unit: 'm', unitRate: 5 },
    { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 150 },
    { ruleId: 'Q-COLUMN-COUNT', unit: 'nr', unitRate: 20 },
    { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 130 },
    { ruleId: 'Q-FOOTING-COUNT', unit: 'nr', unitRate: 30 },
    { ruleId: 'Q-SLAB-AREA', unit: 'm2', unitRate: 18 },
    { ruleId: 'Q-SLAB-VOLUME', unit: 'm3', unitRate: 125 },
    { ruleId: 'Q-OPENING-COUNT', unit: 'nr', unitRate: 45 },
    { ruleId: 'Q-OPENING-AREA', unit: 'm2', unitRate: 25 }
  ];
  const putRates = await call('owner', 'PUT', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost-items`, { items: rates });
  assert.equal(putRates.status, 200, JSON.stringify(putRates.data));
  const cost = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost`, { currency: 'OMR' });
  assert.equal(cost.status, 201, JSON.stringify(cost.data));
  const costTotal = cost.data.total;
  assert.ok(costTotal > 0);

  // Cost is a draft: the export must show it as not approved, not as a price.
  const draftExport = await callBinary('owner', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-export.xlsx`);
  const draftZip = readZip(draftExport.buf);
  const draftRows = sheetRows(draftZip.get('xl/worksheets/sheet1.xml').toString('utf8'));
  const draftHeader = draftRows.find((r) => r[0] === 'م');
  const draftData = draftRows.slice(draftRows.indexOf(draftHeader) + 1).filter((r) => typeof r[0] === 'number');
  assert.ok(draftData.length > 0);
  const rateCol = draftHeader.indexOf('سعر الوحدة');
  assert.ok(draftData.every((r) => r[rateCol] === 'غير معتمد'), 'draft cost must not be exported as a price');

  // Approve the cost, then export for real.
  const costApproved = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost/approve`);
  assert.equal(costApproved.status, 200, JSON.stringify(costApproved.data));

  const res = await callBinary('owner', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-export.xlsx`);
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /spreadsheetml\.sheet/);
  assert.match(res.headers.get('content-disposition'), /\.xlsx"/);
  assert.equal(res.buf.slice(0, 2).toString(), 'PK', 'must be a ZIP container');

  const zip = readZip(res.buf);
  for (const part of ['[Content_Types].xml', 'xl/workbook.xml', 'xl/styles.xml', 'xl/worksheets/sheet1.xml']) {
    assert.ok(zip.has(part), 'missing part ' + part);
  }
  // Every XML part must be well-formed enough to close its root element.
  for (const [name, data] of zip) {
    if (!name.endsWith('.xml') && !name.endsWith('.rels')) continue;
    const text = data.toString('utf8');
    assert.ok(text.startsWith('<?xml'), name + ' must start with an XML declaration');
    assert.ok(text.trimEnd().endsWith('>'), name + ' must be complete');
  }

  const workbookXml = zip.get('xl/workbook.xml').toString('utf8');
  assert.match(workbookXml, /جدول الكميات المعتمد/);
  assert.match(workbookXml, /غير المعتمد/);

  const rows = sheetRows(zip.get('xl/worksheets/sheet1.xml').toString('utf8'));
  const header = rows.find((r) => r[0] === 'م');
  assert.ok(header, 'BOQ sheet must have a header row');
  const data = rows.slice(rows.indexOf(header) + 1).filter((r) => typeof r[0] === 'number');
  assert.ok(data.length >= 8, 'expected the measured rules as rows, got ' + data.length);

  const col = (name) => header.indexOf(name);
  const sheetCol = col('رقم اللوحة');
  const provCol = col('اللوحة المصدر');
  const fileCol = col('ملف المصدر');
  const pageCol = col('الصفحة');
  const totalCol = col('الإجمالي');
  const qtyCol = col('الكمية');
  const unitCol = col('الوحدة');
  const byCol = col('اعتمد بواسطة');
  const atCol = col('تاريخ الاعتماد');

  // Provenance on every row, and both drawings represented.
  assert.ok(data.every((r) => String(r[sheetCol] || '').trim()), 'every row needs a sheet number');
  const sheets = new Set(data.map((r) => String(r[sheetCol])));
  assert.ok(sheets.has('A-101'), 'architectural sheet must appear: ' + [...sheets]);
  assert.ok(sheets.has('S-201'), 'structural sheet must appear: ' + [...sheets]);
  assert.ok(data.every((r) => String(r[fileCol] || '').trim()), 'every row needs a source file');
  assert.ok(data.every((r) => /^\d+$/.test(String(r[pageCol] || ''))), 'every row needs a page number');
  assert.ok(data.every((r) => /صفحة\s*\d/.test(String(r[provCol] || ''))), 'provenance label must name the page');

  // Units are the rule's own unit, not a generic label.
  const unitMap = { 'Q-WALL-NET-AREA': 'م²', 'Q-WALL-NET-VOLUME': 'م³', 'Q-WALL-LENGTH': 'م', 'Q-COLUMN-VOLUME': 'م³', 'Q-COLUMN-COUNT': 'عدد', 'Q-FOOTING-VOLUME': 'م³', 'Q-FOOTING-COUNT': 'عدد', 'Q-SLAB-AREA': 'م²', 'Q-SLAB-VOLUME': 'م³', 'Q-OPENING-COUNT': 'عدد', 'Q-OPENING-AREA': 'م²' };
  for (const r of data) {
    const expected = unitMap[String(r[1])];
    if (expected) assert.equal(String(r[unitCol]), expected, 'unit for ' + r[1]);
  }

  // Quantities and totals must match what the API reports.
  const quantities = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/quantities`);
  const qtyByRule = new Map(quantities.data.quantities.map((q) => [q.ruleId, q.quantity]));
  for (const r of data) {
    const expected = qtyByRule.get(String(r[1]));
    if (expected === undefined) continue;
    assert.ok(Math.abs(Number(r[qtyCol]) - expected) < 1e-6, 'quantity for ' + r[1]);
  }
  const exportedTotal = data.reduce((s, r) => s + (typeof r[totalCol] === 'number' ? r[totalCol] : 0), 0);
  assert.ok(Math.abs(exportedTotal - costTotal) < 0.01, `exported total ${exportedTotal} vs engine ${costTotal}`);

  // Approval trail on every row.
  assert.ok(data.every((r) => String(r[byCol] || '').trim()), 'every row must name the approver');
  assert.ok(data.every((r) => /^\d{4}-\d{2}-\d{2}$/.test(String(r[atCol] || ''))), 'every row must carry the approval date');

  // The export is logged.
  const preview = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-export/preview`);
  assert.equal(preview.status, 200);
  assert.equal(preview.data.approvedCount, data.length);
  assert.ok(preview.data.exports.length >= 1, 'export must be recorded');
  assert.equal(preview.data.exports[0].sha256, res.headers.get('x-export-sha256'));
});

test('an unapproved row is excluded from the BOQ and reported, never dropped silently', async () => {
  const owner = await register('owner2');
  const project = await call('owner2', 'POST', '/api/mmc-ai/projects', { name: 'Exclusion project', currency: 'OMR' });
  const projectId = project.data.project.project_id;
  const built = await call('owner2', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  const modelId = built.data.model.id;

  // Approve, then push one row back to needs_review to simulate a late edit.
  await call('owner2', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/approve`);
  const db = require('../src/db').getDB();
  db.prepare("UPDATE ai_bim_quantities SET review_state='measured_ready_for_review',approved_by=NULL,approved_at=NULL WHERE model_id=? AND rule_id='Q-SLAB-AREA'")
    .run(modelId);

  const res = await callBinary('owner2', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-export.xlsx`);
  assert.equal(res.status, 200);
  assert.equal(res.headers.get('x-export-excluded-rows'), '1');

  const zip = readZip(res.buf);
  const boqRows = sheetRows(zip.get('xl/worksheets/sheet1.xml').toString('utf8'));
  const header = boqRows.find((r) => r[0] === 'م');
  const data = boqRows.slice(boqRows.indexOf(header) + 1).filter((r) => typeof r[0] === 'number');
  assert.ok(!data.some((r) => String(r[1]) === 'Q-SLAB-AREA'), 'unapproved row must not be in the BOQ');

  const excludedRows = sheetRows(zip.get('xl/worksheets/sheet4.xml').toString('utf8'));
  const excluded = excludedRows.filter((r) => String(r[0] || '').includes('Q-SLAB-AREA'));
  assert.equal(excluded.length, 1, 'unapproved row must be listed on the exclusion sheet');
  assert.match(String(excluded[0][4]), /لم تُعتمد/);

  // The preview must agree with the file.
  const preview = await call('owner2', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-export/preview`);
  assert.equal(preview.data.excludedCount, 1);
  assert.equal(preview.data.excluded[0].ruleId, 'Q-SLAB-AREA');
});

test('a model with no recorded source says so instead of inventing a sheet', async () => {
  const owner = await register('owner3');
  const project = await call('owner3', 'POST', '/api/mmc-ai/projects', { name: 'No source project', currency: 'OMR' });
  const projectId = project.data.project.project_id;
  const spec = sampleModel();
  for (const el of spec.elements) delete el.source;
  const built = await call('owner3', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: spec });
  const modelId = built.data.model.id;
  await call('owner3', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/approve`);

  const res = await callBinary('owner3', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-export.xlsx`);
  const zip = readZip(res.buf);
  const rows = sheetRows(zip.get('xl/worksheets/sheet1.xml').toString('utf8'));
  const header = rows.find((r) => r[0] === 'م');
  const data = rows.slice(rows.indexOf(header) + 1).filter((r) => typeof r[0] === 'number');
  const provCol = header.indexOf('اللوحة المصدر');
  assert.ok(data.length > 0);
  assert.ok(data.every((r) => String(r[provCol]) === 'غير مسجّل'),
    'a row with no source must say غير مسجّل, got: ' + JSON.stringify([...new Set(data.map((r) => r[provCol]))]));
});

test('export requires project membership', async () => {
  const owner = await register('owner4');
  const project = await call('owner4', 'POST', '/api/mmc-ai/projects', { name: 'Private project', currency: 'OMR' });
  const projectId = project.data.project.project_id;
  const built = await call('owner4', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  const modelId = built.data.model.id;

  await register('outsider');
  const res = await callBinary('outsider', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/boq-export.xlsx`);
  assert.equal(res.status, 404, 'a non-member must not be able to export');
});
