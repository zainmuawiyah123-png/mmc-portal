'use strict';
/**
 * 3D viewer API test: the element-context payload the browser viewer consumes.
 *
 * The viewer must be able to draw the geometry the quantities were measured
 * from, and must show each element's own quantity, cost share and activity —
 * never the whole row total repeated on every element, and never an invented
 * link.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mmc-ai-viewer-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json';
process.env.DB_PATH = path.join(TMP, 'test.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false';
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'mmc-ai-viewer-test-secret';
process.env.BCRYPT_ROUNDS = '4';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { closeDB } = require('../src/db');

let server, base;
const jar = {};

async function call(user, method, url, body) {
  const headers = { ...(jar[user] ? { Cookie: jar[user] } : {}) };
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) jar[user] = first;
  }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data };
}

const uniq = () => Math.random().toString(36).slice(2, 10);

async function register(key) {
  const email = key + uniq() + '@test.local';
  const r = await call(key, 'POST', '/api/auth/register', { name: key, email, password: 'Password123', company: key });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const db = require('../src/db').getDB();
  const user = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now, user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);
  const login = await call(key, 'POST', '/api/auth/login', { email, password: 'Password123' });
  assert.equal(login.status, 200, JSON.stringify(login.data));
  return user.id;
}

function sampleModel() {
  return {
    name: 'Viewer test building',
    storeys: [
      { id: 'GF', name: 'Ground Floor', elevation: 0 },
      { id: 'FF', name: 'First Floor', elevation: 3.2 }
    ],
    elements: [
      { id: 'F1', type: 'footing', storeyId: 'GF', origin: { x: 0, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'F2', type: 'footing', storeyId: 'GF', origin: { x: 5, y: 0, z: -0.6 }, length: 1.5, width: 1.5, height: 0.6 },
      { id: 'C1', type: 'column', storeyId: 'GF', origin: { x: 0, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'C2', type: 'column', storeyId: 'GF', origin: { x: 5, y: 0, z: 0 }, length: 0.4, width: 0.4, height: 3.2 },
      { id: 'W1', type: 'wall', storeyId: 'GF', origin: { x: 2.5, y: 0, z: 0 }, length: 5, width: 0.2, height: 3 },
      { id: 'O1', type: 'opening', storeyId: 'GF', hostId: 'W1', origin: { x: 2.5, y: 0, z: 1.1 }, length: 1.2, width: 0.2, height: 1.4, sillHeight: 0.9 },
      { id: 'S1', type: 'slab', storeyId: 'FF', origin: { x: 2.5, y: 0, z: 3.2 }, length: 5, width: 4, height: 0.25 }
    ]
  };
}

let projectId, modelId, scheduleId;

test('setup: server, users, project and model', async () => {
  migrate();
  const app = createApp();
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = 'http://127.0.0.1:' + server.address().port;
  await register('owner');
  await register('outsider');
  const p = await call('owner', 'POST', '/api/mmc-ai/projects', { name: 'Viewer project', country: 'OM', currency: 'OMR' });
  assert.equal(p.status, 201, JSON.stringify(p.data));
  projectId = p.data.project.project_id;
  const m = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model`, { model: sampleModel() });
  assert.equal(m.status, 201, JSON.stringify(m.data));
  modelId = m.data.model.id;
});

test('element-context returns every element with its measured geometry', async () => {
  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.elements.length, 7);
  for (const e of r.data.elements) {
    assert.ok(e.vertices.length >= 8, `${e.id} has no vertices`);
    assert.ok(e.faces.length >= 6, `${e.id} has no faces`);
  }
  // The wall's opening is deducted, so the wall carries a net area.
  const wall = r.data.elements.find((e) => e.id === 'W1');
  assert.ok(wall.netArea > 0);
  assert.equal(wall.netArea, 15 - 1.2 * 1.4);
});

test('each element carries its own quantity, not the row total', async () => {
  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  const els = r.data.elements;
  const footings = els.filter((e) => e.type === 'footing');
  const q = footings[0].quantities.find((x) => x.ruleId === 'Q-FOOTING-VOLUME');
  assert.ok(q, 'footing has no volume quantity');
  // One footing is 1.5 x 1.5 x 0.6 = 1.35 m3, not the 2.7 m3 row total.
  assert.equal(q.quantity, 1.35);
  assert.equal(q.rowTotal, 2.7);
  const sum = footings.reduce((s, e) => s + e.quantities.find((x) => x.ruleId === 'Q-FOOTING-VOLUME').quantity, 0);
  assert.equal(Number(sum.toFixed(6)), 2.7);
});

test('an element with no quantity comes back empty, not invented', async () => {
  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  const opening = r.data.elements.find((e) => e.id === 'O1');
  assert.ok(opening);
  // The opening has its own count/area rules, so it does carry quantities —
  // but nothing may be attributed to it that the model did not measure.
  for (const q of opening.quantities) {
    assert.ok(['Q-OPENING-COUNT', 'Q-OPENING-AREA'].includes(q.ruleId), 'unexpected rule on an opening: ' + q.ruleId);
  }
});

test('cost shares sum to the cost model total', async () => {
  const rates = await call('owner', 'PUT', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost-items`, {
    currency: 'OMR',
    items: [
      { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 95 },
      { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 130 },
      { ruleId: 'Q-WALL-NET-AREA', unit: 'm2', unitRate: 22 },
      { ruleId: 'Q-WALL-NET-VOLUME', unit: 'm3', unitRate: 280 },
      { ruleId: 'Q-SLAB-AREA', unit: 'm2', unitRate: 45 },
      { ruleId: 'Q-SLAB-VOLUME', unit: 'm3', unitRate: 105 },
      { ruleId: 'Q-OPENING-COUNT', unit: 'nr', unitRate: 40 },
      { ruleId: 'Q-OPENING-AREA', unit: 'm2', unitRate: 150 },
      { ruleId: 'Q-WALL-LENGTH', unit: 'm', unitRate: 18 },
      { ruleId: 'Q-COLUMN-COUNT', unit: 'nr', unitRate: 60 },
      { ruleId: 'Q-FOOTING-COUNT', unit: 'nr', unitRate: 80 }
    ]
  });
  assert.equal(rates.status, 200, JSON.stringify(rates.data));
  const cost = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost`, {});
  assert.ok([200, 201].includes(cost.status), JSON.stringify(cost.data));
  const total = cost.data.rows.reduce((s, x) => s + x.total, 0);

  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  const perElement = r.data.elements.reduce((s, e) => s + e.costs.reduce((a, c) => a + (c.total || 0), 0), 0);
  assert.ok(Math.abs(perElement - total) < 0.05, `${perElement} vs ${total}`);
  // Every cost entry is labelled as a share, never as an independently priced element.
  for (const e of r.data.elements) for (const c of e.costs) assert.equal(c.isShare, true);
});

test('element activities come from the confirmed schedule links', async () => {
  const s = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/schedule`, {
    name: 'Viewer programme',
    dataDate: '2026-01-04',
    schedule: {
      calendar: { dataDate: '2026-01-04' },
      activities: [
        { id: 'A1', name: 'Footings', durationDays: 3, trade: 'concrete' },
        { id: 'A2', name: 'Ground Floor Columns', durationDays: 4, predecessors: ['A1'], trade: 'concrete' },
        { id: 'A3', name: 'Ground Floor Walls', durationDays: 5, predecessors: ['A2'], trade: 'blockwork' }
      ]
    }
  });
  assert.equal(s.status, 201, JSON.stringify(s.data));
  scheduleId = s.data.schedule.id;
  const prop = await call('owner', 'POST', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/propose-links`);
  assert.equal(prop.status, 200, JSON.stringify(prop.data));
  await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, {
    decisions: prop.data.links.map((l) => ({ elementId: l.elementId, state: 'confirmed' }))
  });

  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  const footing = r.data.elements.find((e) => e.id === 'F1');
  assert.equal(footing.activities.length, 1);
  assert.equal(footing.activities[0].activityId, 'A1');
  const schedAct = s.data.activities.find((a) => a.id === 'A1');
  assert.equal(footing.activities[0].plannedStart, schedAct.plannedStart);
  assert.equal(footing.activities[0].plannedFinish, schedAct.plannedFinish);
});

test('a rejected link is not shown on the element', async () => {
  const r0 = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  const before = r0.data.elements.find((e) => e.id === 'C1').activities.length;
  assert.ok(before > 0);
  await call('owner', 'PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, {
    decisions: [{ elementId: 'C1', state: 'rejected' }]
  });
  const r = await call('owner', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  assert.equal(r.data.elements.find((e) => e.id === 'C1').activities.length, 0);
});

test('a non-member cannot read the viewer payload', async () => {
  const r = await call('outsider', 'GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  assert.equal(r.status, 404);
});

test('teardown', async () => {
  if (server) await new Promise((r) => server.close(r));
  closeDB();
});
