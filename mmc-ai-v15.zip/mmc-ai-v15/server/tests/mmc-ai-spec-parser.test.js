'use strict';
/**
 * Unit tests for specification parsing.
 *
 * The first version fed a spreadsheet through the prose clause parser, which
 * needs a numbered heading at the start of a line. A five-row specification
 * table therefore collapsed into ONE clause whose body was the other four rows.
 * Found by uploading a real Arabic specification sheet through the UI.
 */

const test = require('node:test');
const assert = require('node:assert');
const { parseSpecTable, parseClauses } = require('../src/lib/mmc-ai/spec-import');

const TABLE = [
  ['القسم', 'البند', 'المواصفة'],
  ['أعمال الخرسانة', 'خرسانة الأساسات', 'خرسانة مسلحة C30/37 مقاومة للكبريتات، غطاء 50 مم'],
  ['أعمال الخرسانة', 'خرسانة الأعمدة', 'خرسانة مسلحة C35/45، حديد تسليح B500B'],
  ['أعمال الجدران', 'جدران البلوك', 'بلوك خرساني 200 مم، مونة أسمنتية 1:4'],
  ['أعمال الألمنيوم', 'النوافذ', 'قطاعات ألمنيوم مؤكسدة 50 مم، زجاج مزدوج 6-12-6']
];

test('spec table: every data row becomes its own clause', () => {
  const clauses = parseSpecTable(TABLE);
  assert.equal(clauses.length, 4, 'expected 4 clauses, got ' + clauses.length);
});

test('spec table: the header row is not a clause', () => {
  const clauses = parseSpecTable(TABLE);
  assert.ok(!clauses.some((c) => c.title === 'البند'), 'header leaked into clauses');
});

test('spec table: section, title and body are mapped to the right columns', () => {
  const clauses = parseSpecTable(TABLE);
  const footing = clauses.find((c) => c.title === 'خرسانة الأساسات');
  assert.ok(footing, 'footing clause missing');
  assert.equal(footing.section, 'أعمال الخرسانة');
  assert.match(footing.body, /C30\/37/);
});

test('spec table: an English header is recognised too', () => {
  const clauses = parseSpecTable([
    ['Section', 'Title', 'Specification'],
    ['Concrete', 'Footings', 'Reinforced concrete C30/37'],
    ['Masonry', 'Block walls', '200 mm hollow block']
  ]);
  assert.equal(clauses.length, 2);
  assert.equal(clauses[0].section, 'Concrete');
  assert.equal(clauses[0].title, 'Footings');
});

test('spec table: a table with no recognisable header yields nothing', () => {
  // The caller then falls back to the prose parser rather than inventing rows.
  const clauses = parseSpecTable([['a', 'b'], ['c', 'd']]);
  assert.equal(clauses.length, 0);
});

test('spec table: blank rows are skipped', () => {
  const clauses = parseSpecTable([
    ['القسم', 'البند', 'المواصفة'],
    ['', '', ''],
    ['أعمال الخرسانة', 'خرسانة الأساسات', 'خرسانة C30/37'],
    ['', '', '']
  ]);
  assert.equal(clauses.length, 1);
});

test('prose parser still works on a numbered document', () => {
  const clauses = parseClauses('1. أعمال الخرسانة\nخرسانة مسلحة C30/37 للأسقف.\n2. أعمال الجدران\nبلوك خرساني 200 مم.');
  assert.equal(clauses.length, 2);
  assert.equal(clauses[0].code, '1');
});
