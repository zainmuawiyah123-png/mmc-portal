'use strict';
/**
 * Unit tests for the BOQ line matcher.
 *
 * These exist because the first version of the matcher scored ZERO on every
 * Arabic line (it compared literal tokens against English rule descriptions),
 * and it linked "أعمال الحفر للأساسات" (excavation for footings) to footing
 * CONCRETE because both mention footings. Both defects were found by running
 * the matcher on a real Arabic BOQ against the real model, not by the API
 * tests, which only asserted that *some* link came back.
 */

const test = require('node:test');
const assert = require('node:assert');
const { proposeBoqLinks } = require('../src/lib/mmc-ai/boq-import');

/** The real model's measured rows, trimmed to what the matcher reads. */
const QUANTITIES = [
  { ruleId: 'Q-FOOTING-VOLUME', description: 'Footing concrete volume', descriptionAr: 'حجم خرسانة الأساسات', label: { ar: 'حجم الأساسات', en: 'Footing volume' }, unit: 'm3', quantity: 7.776 },
  { ruleId: 'Q-COLUMN-VOLUME', description: 'Column concrete volume', descriptionAr: 'حجم خرسانة الأعمدة', label: { ar: 'حجم الأعمدة', en: 'Column volume' }, unit: 'm3', quantity: 3.6 },
  { ruleId: 'Q-SLAB-VOLUME', description: 'Slab concrete volume', descriptionAr: 'حجم خرسانة البلاطات', label: { ar: 'حجم البلاطات', en: 'Slab volume' }, unit: 'm3', quantity: 2.88 },
  { ruleId: 'Q-WALL-NET-AREA', description: 'Wall face area net of openings', descriptionAr: 'مساحة وجه الجدار بعد خصم الفتحات', label: { ar: 'مساحة الجدران الصافية', en: 'Wall net area' }, unit: 'm2', quantity: 100.2 },
  { ruleId: 'Q-SLAB-AREA', description: 'Slab top area', descriptionAr: 'مساحة سطح البلاطة', label: { ar: 'مساحة البلاطات', en: 'Slab area' }, unit: 'm2', quantity: 48 },
  { ruleId: 'Q-OPENING-AREA', description: 'Opening area', descriptionAr: 'مساحة الفتحات', label: { ar: 'مساحة الفتحات', en: 'Opening area' }, unit: 'm2', quantity: 1.8 },
  { ruleId: 'Q-OPENING-COUNT', description: 'Opening count', descriptionAr: 'عدد الفتحات', label: { ar: 'عدد الفتحات', en: 'Opening count' }, unit: 'nr', quantity: 1 }
];

function linkFor(description, unit, quantity) {
  const r = proposeBoqLinks([{ rowNumber: 2, itemCode: '1', description, unit, quantity }], QUANTITIES);
  return r.links[0] || null;
}

test('matcher: an Arabic line links to the right rule (bilingual concepts)', () => {
  const link = linkFor('خرسانة الأساسات', 'm3', 7.776);
  assert.ok(link, 'expected a link, got none');
  assert.equal(link.ruleId, 'Q-FOOTING-VOLUME');
  // Exact quantity + unit + concept agreement must be a high-confidence link.
  assert.ok(link.confidence >= 0.75, 'confidence ' + link.confidence);
});

test('matcher: an English line links to the same rule', () => {
  const link = linkFor('Footing concrete', 'm3', 7.776);
  assert.ok(link);
  assert.equal(link.ruleId, 'Q-FOOTING-VOLUME');
});

test('matcher: excavation is NOT linked to footing concrete', () => {
  // Both mention footings; only one is concrete work. The work-type veto must
  // keep this below the proposal threshold rather than linking it.
  const link = linkFor('أعمال الحفر للأساسات', 'm3', 42.25);
  assert.equal(link, null, 'excavation must not link to a concrete rule');
});

test('matcher: backfill is NOT linked to footing concrete', () => {
  const link = linkFor('ردم حول الأساسات', 'm3', 42.25);
  assert.equal(link, null);
});

test('matcher: a wall line links to wall area, not slab area', () => {
  const link = linkFor('أعمال الجدران', 'm2', 100.2);
  assert.ok(link);
  assert.equal(link.ruleId, 'Q-WALL-NET-AREA');
});

test('matcher: a slab line links to slab area, not wall area', () => {
  const link = linkFor('أعمال البلاطات', 'm2', 48);
  assert.ok(link);
  assert.equal(link.ruleId, 'Q-SLAB-AREA');
});

test('matcher: a unit mismatch cannot produce a confident link', () => {
  // A wall AREA rule is m2; a line claiming m3 must not be a confident match.
  const link = linkFor('أعمال الجدران', 'm3', 100.2);
  assert.ok(!link || link.confidence < 0.5, 'unit mismatch must not be confident');
});

test('matcher: an unrelated line is left unmatched', () => {
  const link = linkFor('أعمال الدهانات الخارجية', 'm2', 12);
  assert.equal(link, null);
});

test('matcher: the confidence is reported with its signals', () => {
  const link = linkFor('خرسانة الأعمدة', 'm3', 3.6);
  assert.ok(link);
  assert.equal(link.ruleId, 'Q-COLUMN-VOLUME');
  assert.equal(link.signals.unitMatch, true);
  assert.ok(link.signals.descriptionSimilarity > 0);
  assert.equal(link.signals.quantityAgreement, 1);
  assert.equal(link.state, 'proposed');
});
