'use strict';
/**
 * Tests for the exact opening cut.
 *
 * The point of these tests is that the cut is *geometry*, not a label: the
 * removed volume must equal the opening's own volume, the kept volume must
 * equal gross minus removed, and a ray through the middle of the hole must
 * pass through the host without hitting it.
 */
const test = require('node:test');
const assert = require('node:assert');

const { cutBoxByOpenings, attachOpeningGeometry, openingOffsets } = require('../src/lib/mmc-ai/opening-cut');
const { buildModel, measureModel } = require('../src/lib/mmc-ai/bim-model');
const { writeIfc } = require('../src/lib/mmc-ai/ifc-writer');
const { importIfc } = require('../src/lib/mmc-ai/ifc-importer');
const { parseStep, StepGraph } = require('../src/lib/mmc-ai/ifc-step-parser');

const wall = (over = {}) => ({
  id: 'W1', type: 'wall', name: 'Wall W1', storeyId: 'L0',
  origin: { x: 0, y: 0, z: 0 }, length: 8, width: 0.2, height: 3, rotationDeg: 0,
  ...over
});

const opening = (over = {}) => ({
  id: 'O1', type: 'opening', name: 'Window O1', storeyId: 'L0',
  origin: { x: 0, y: 0, z: 0.9 }, length: 1.5, width: 0.2, height: 1.2,
  rotationDeg: 0, hostId: 'W1', sillHeight: 0.9, offsetAlongHost: 0,
  ...over
});

/** Ray/box intersection count along +y through a point, for a triangle soup. */
function rayHitsY(vertices, faces, px, pz) {
  let hits = 0;
  for (const f of faces) {
    for (let i = 1; i + 1 < f.length; i += 1) {
      const a = vertices[f[0]];
      const b = vertices[f[i]];
      const c = vertices[f[i + 1]];
      // Project to x-z plane and test point-in-triangle, then read the y span.
      const d = (b.z - c.z) * (a.x - c.x) + (c.x - b.x) * (a.z - c.z);
      if (Math.abs(d) < 1e-12) continue;
      const u = ((b.z - c.z) * (px - c.x) + (c.x - b.x) * (pz - c.z)) / d;
      const v = ((c.z - a.z) * (px - c.x) + (a.x - c.x) * (pz - c.z)) / d;
      const w = 1 - u - v;
      if (u < -1e-9 || v < -1e-9 || w < -1e-9) continue;
      hits += 1;
    }
  }
  return hits;
}

test('cuts a window out of a wall and removes exactly the opening volume', () => {
  const cut = cutBoxByOpenings(wall(), [opening()], { mode: 'elevation' });
  assert.ok(cut, 'a cut body is produced');
  assert.equal(cut.openingsApplied, 1);
  assert.equal(cut.removedVolume, 0.36, '1.5 x 1.2 x 0.2 = 0.36 m3 removed');
  assert.equal(cut.volume, 4.44, '4.8 gross - 0.36 removed');
  assert.ok(Math.abs(cut.volume + cut.removedVolume - 4.8) < 1e-9, 'kept + removed = gross');
  assert.ok(cut.boxCount > 1, 'the host is split into more than one box');
});

test('the hole is real: a ray through its centre misses the host', () => {
  const cut = cutBoxByOpenings(wall(), [opening()], { mode: 'elevation' });
  // Centre of the opening: x = 0, z = 0.9 + 0.6 = 1.5
  assert.equal(rayHitsY(cut.vertices, cut.faces, 0, 1.5), 0, 'nothing blocks the hole');
  // Solid part of the wall, well away from the opening: x = 3, z = 1.5
  assert.ok(rayHitsY(cut.vertices, cut.faces, 3, 1.5) > 0, 'the wall is still there beside the hole');
  // Above the opening: x = 0, z = 2.6
  assert.ok(rayHitsY(cut.vertices, cut.faces, 0, 2.6) > 0, 'the lintel above the hole is solid');
  // Below the opening: x = 0, z = 0.4
  assert.ok(rayHitsY(cut.vertices, cut.faces, 0, 0.4) > 0, 'the sill below the hole is solid');
});

test('two openings in one wall are both cut, and their volumes add up', () => {
  const cut = cutBoxByOpenings(wall(), [
    opening({ id: 'O1', offsetAlongHost: -2 }),
    opening({ id: 'O2', offsetAlongHost: 2, length: 1, height: 2, sillHeight: 0.5 })
  ], { mode: 'elevation' });
  assert.equal(cut.openingsApplied, 2);
  assert.equal(cut.removedVolume, 0.36 + 0.4, '0.36 + (1 x 2 x 0.2)');
  assert.equal(cut.volume, 4.8 - 0.76);
  assert.equal(rayHitsY(cut.vertices, cut.faces, -2, 1.5), 0);
  assert.equal(rayHitsY(cut.vertices, cut.faces, 2, 1.5), 0);
});

test('overlapping openings are not double-counted', () => {
  const cut = cutBoxByOpenings(wall(), [
    opening({ id: 'O1', offsetAlongHost: 0 }),
    opening({ id: 'O2', offsetAlongHost: 0.5 })
  ], { mode: 'elevation' });
  // Union of two 1.5-wide windows offset by 0.5 is 2.0 wide.
  assert.equal(cut.removedVolume, 2.0 * 1.2 * 0.2);
  assert.equal(cut.volume, 4.8 - 0.48);
});

test('an opening outside the host removes nothing and is reported', () => {
  const cut = cutBoxByOpenings(wall(), [opening({ offsetAlongHost: 40 })], { mode: 'elevation' });
  assert.equal(cut.removedVolume, 0);
  assert.equal(cut.volume, 4.8);
  assert.equal(cut.openingsApplied, 0);
  assert.equal(cut.openingsIgnored.length, 1);
  assert.equal(cut.openingsIgnored[0].reason, 'outside_host');
});

test('an opening taller than the wall is clamped, never over-subtracted', () => {
  const cut = cutBoxByOpenings(wall(), [opening({ sillHeight: 2, height: 5 })], { mode: 'elevation' });
  assert.ok(Math.abs(cut.removedVolume - 1.5 * 1 * 0.2) < 1e-9, 'clamped to the 1 m left above the sill');
  assert.ok(cut.volume > 0);
});

test('a rotated wall cuts in its own frame, not the world frame', () => {
  const cut = cutBoxByOpenings(wall({ rotationDeg: 90 }), [opening()], { mode: 'elevation' });
  assert.equal(cut.removedVolume, 0.36, 'rotation does not change the removed volume');
  // The hole must be at the rotated position: x = 0, y = 0 (wall runs along +y).
  const xs = cut.vertices.map((v) => v.x);
  const ys = cut.vertices.map((v) => v.y);
  assert.ok(Math.max(...xs) - Math.min(...xs) <= 0.2 + 1e-6, 'thickness is along x after a 90 deg turn');
  assert.ok(Math.max(...ys) - Math.min(...ys) >= 8 - 1e-6, 'length is along y after a 90 deg turn');
});

test('a slab opening is cut in plan, through the full thickness', () => {
  const slab = {
    id: 'S1', type: 'slab', origin: { x: 0, y: 0, z: 0 },
    length: 6, width: 4, height: 0.2, rotationDeg: 0
  };
  const hole = { id: 'O9', length: 1, width: 1, offsetAlongHost: 0, offsetAcrossHost: 0 };
  const cut = cutBoxByOpenings(slab, [hole], { mode: 'plan' });
  assert.equal(cut.removedVolume, 1 * 1 * 0.2);
  assert.ok(Math.abs(cut.volume - (6 * 4 * 0.2 - 0.2)) < 1e-9);
});

test('a host with no openings is one box, unchanged', () => {
  const cut = cutBoxByOpenings(wall(), [], { mode: 'elevation' });
  assert.equal(cut.boxCount, 1);
  assert.equal(cut.volume, 4.8);
  assert.equal(cut.removedVolume, 0);
});

test('buildModel attaches the cut but leaves every quantity untouched', () => {
  const spec = {
    name: 'Cut test',
    storeys: [{ id: 'L0', name: 'Ground', elevation: 0 }],
    elements: [wall(), opening()]
  };
  const model = buildModel(spec);
  const host = model.elements.find((e) => e.id === 'W1');
  assert.ok(host.displaySolid, 'the host carries a cut body');
  assert.equal(host.displaySolid.removedVolume, 0.36);
  assert.equal(host.grossVolume, 4.8, 'the measured gross solid is untouched');
  assert.equal(host.netVolume, 4.44, 'the net volume is still the deducted one');
  assert.equal(model.openingCuts.hosts, 1);
  assert.equal(model.openingCuts.openingsApplied, 1);

  const measured = measureModel(model, { modelId: 'm', projectId: 'p' });
  const netVol = measured.rows.find((r) => r.ruleId === 'Q-WALL-NET-VOLUME');
  assert.equal(netVol.quantity, 4.44, 'the quantity rule still reports the net volume');
});

test('the cut does not change any measured quantity versus a model without it', () => {
  const spec = {
    name: 'Cut invariance',
    storeys: [{ id: 'L0', name: 'Ground', elevation: 0 }],
    elements: [wall(), opening()]
  };
  const withCut = buildModel(spec);
  const before = measureModel(withCut, { modelId: 'm', projectId: 'p' });
  // Strip the display geometry and measure again: the numbers must be identical.
  for (const el of withCut.elements) delete el.displaySolid;
  const after = measureModel(withCut, { modelId: 'm', projectId: 'p' });
  assert.deepEqual(
    before.rows.map((r) => [r.ruleId, r.quantity]),
    after.rows.map((r) => [r.ruleId, r.quantity])
  );
});

test('IFC export carries a real boolean subtraction for a host with openings', () => {
  const model = buildModel({
    name: 'Boolean export',
    storeys: [{ id: 'L0', name: 'Ground', elevation: 0 }],
    elements: [wall(), opening()]
  });
  const { text } = writeIfc(model, { projectName: 'Boolean export' });
  assert.match(text, /IFCBOOLEANRESULT\(\.DIFFERENCE\./, 'the body is a difference');
  assert.match(text, /'CSG'/, 'the representation type says CSG');
  assert.match(text, /IFCRELVOIDSELEMENT/, 'the semantic void link is still there');

  const graph = new StepGraph(parseStep(text));
  assert.equal(graph.byType('IFCBOOLEANRESULT').length, 1);
  // The wall's body must reference the boolean, not the raw extrusion.
  const wallRec = graph.byType('IFCWALL')[0];
  const shape = graph.refArg(wallRec, 6);
  const repRefs = graph.listArg(shape, 2);
  const rep = graph.entity(repRefs[0]);
  const items = graph.listArg(rep, 3);
  const item = graph.entity(items[0]);
  assert.equal(item.type, 'IFCBOOLEANRESULT');
});

test('IFC round trip keeps the quantities and the opening link', () => {
  const model = buildModel({
    name: 'Round trip cut',
    storeys: [{ id: 'L0', name: 'Ground', elevation: 0 }],
    elements: [wall(), opening()]
  });
  const before = measureModel(model, { modelId: 'm', projectId: 'p' });
  const { text } = writeIfc(model, { projectName: 'Round trip cut' });
  const { model: back, report } = importIfc(text, { name: 'back', projectId: 'p' });
  assert.equal(report.importedElementCount, 2);
  const op = back.elements.find((e) => e.type === 'opening');
  assert.ok(op.hostId, 'the opening still knows its host');
  const after = measureModel(back, { modelId: 'm', projectId: 'p' });
  const b = Object.fromEntries(before.rows.map((r) => [r.ruleId, r.quantity]));
  const a = Object.fromEntries(after.rows.map((r) => [r.ruleId, r.quantity]));
  assert.equal(a['Q-WALL-NET-VOLUME'], b['Q-WALL-NET-VOLUME']);
  assert.equal(a['Q-WALL-NET-AREA'], b['Q-WALL-NET-AREA']);
});

test('the real project IFC cuts its window and matches the file\'s own net volume', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const ifcPath = path.join(__dirname, '..', 'proof', 'bim-real-project', 'model.ifc');
  const { model, report } = importIfc(fs.readFileSync(ifcPath, 'utf8'), { name: 'real' });
  const host = model.elements.find((e) => e.type === 'wall' && e.name.includes('W3'));
  assert.ok(host, 'the wall that hosts the window is imported');
  assert.ok(host.displaySolid, 'it carries a cut body');
  // The file itself declares NetVolume 4.44 for this wall.
  assert.equal(host.displaySolid.volume, 4.44);
  assert.equal(host.displaySolid.removedVolume, 0.36);
  assert.equal(report.openingCuts.hosts, 1);
  assert.equal(report.openingCuts.openingsApplied, 1);
  assert.equal(report.openingCuts.ignored.length, 0);
});

test('openingOffsets recovers the offset from world origins', () => {
  const host = wall({ origin: { x: 4, y: 6, z: 0 }, rotationDeg: 0 });
  const op = opening({ origin: { x: 3.75, y: 6, z: 0.9 } });
  const off = openingOffsets(host, op);
  assert.equal(off.offsetAlongHost, -0.25);
  assert.equal(off.sillHeight, 0.9);
});
