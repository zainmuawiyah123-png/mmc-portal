'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// The marketing site is served from WEB_ROOT/mmc-ai/site. These tests read the
// files exactly as the server sends them, so a broken link or a missing asset
// fails here rather than in a browser.
const webRoot = path.join(__dirname, '../../webpages/technical-proposal-kit_v5');
const siteDir = path.join(webRoot, 'mmc-ai/site');

const read = (rel) => fs.readFileSync(path.join(siteDir, rel), 'utf8');

const pages = {
  'index.html': read('index.html'),
  'product.html': read('product.html'),
  'pricing.html': read('pricing.html'),
  'ar/index.html': read('ar/index.html'),
  'ar/product.html': read('ar/product.html'),
  'ar/pricing.html': read('ar/pricing.html')
};

test('the site ships all six pages in both languages', () => {
  for (const rel of Object.keys(pages)) {
    assert.ok(fs.existsSync(path.join(siteDir, rel)), 'missing page: ' + rel);
  }
});

test('each page declares the right language and direction', () => {
  for (const rel of ['index.html', 'product.html', 'pricing.html']) {
    assert.match(pages[rel], /<html lang="en" dir="ltr">/, rel + ' must be English LTR');
  }
  for (const rel of ['ar/index.html', 'ar/product.html', 'ar/pricing.html']) {
    assert.match(pages[rel], /<html lang="ar" dir="rtl">/, rel + ' must be Arabic RTL');
  }
});

test('every page links the shared stylesheet and script that exist on disk', () => {
  assert.ok(fs.existsSync(path.join(siteDir, 'assets/site.css')), 'site.css missing');
  assert.ok(fs.existsSync(path.join(siteDir, 'assets/site.js')), 'site.js missing');
  for (const [rel, html] of Object.entries(pages)) {
    assert.match(html, /assets\/site\.css/, rel + ' must load the stylesheet');
    assert.match(html, /assets\/site\.js/, rel + ' must load the script');
  }
});

test('every internal link on every page resolves to a file that exists', () => {
  const missing = [];
  for (const [rel, html] of Object.entries(pages)) {
    const baseDir = path.dirname(path.join(siteDir, rel));
    const hrefs = [...html.matchAll(/href="([^"]+)"/g)].map((m) => m[1]);
    for (const href of hrefs) {
      if (/^(https?:|mailto:|#)/.test(href)) continue;
      const clean = href.split('#')[0];
      if (!clean) continue;
      const target = path.resolve(baseDir, clean);
      if (!fs.existsSync(target)) missing.push(rel + ' -> ' + href);
    }
  }
  assert.deepEqual(missing, [], 'broken internal links: ' + missing.join(', '));
});

test('the language switch points at the counterpart page in the other language', () => {
  // English pages must offer the Arabic counterpart and vice versa.
  assert.match(pages['index.html'], /href="ar\/index\.html"/);
  assert.match(pages['product.html'], /href="ar\/product\.html"/);
  assert.match(pages['pricing.html'], /href="ar\/pricing\.html"/);
  assert.match(pages['ar/index.html'], /href="\.\.\/index\.html"/);
  assert.match(pages['ar/product.html'], /href="\.\.\/product\.html"/);
  assert.match(pages['ar/pricing.html'], /href="\.\.\/pricing\.html"/);
});

test('the workspace is reachable from the site and the site from the workspace', () => {
  // The site's "open workspace" links go up two levels to /mmc-ai/index.html.
  assert.match(pages['index.html'], /href="\.\.\/index\.html"/);
  assert.match(pages['ar/index.html'], /href="\.\.\/\.\.\/index\.html"/);
  const workspace = fs.readFileSync(path.join(webRoot, 'mmc-ai/index.html'), 'utf8');
  assert.match(workspace, /href="site\/index\.html"/, 'workspace must link back to the site');
});

test('pricing states plainly that no payment is taken on the page', () => {
  // A page must never imply a charge or a subscription that does not happen.
  assert.match(pages['pricing.html'], /no payment will be\s+taken|no payment was taken/i);
  assert.match(pages['ar/pricing.html'], /لن يُحصَّل أي مبلغ|لم يُنشأ اشتراك/);
  assert.match(pages['pricing.html'], /not connected yet|not wired up/i);
});

test('the free plan is exactly two activities and the picker enforces it', () => {
  const html = pages['pricing.html'];
  const boxes = [...html.matchAll(/<input type="checkbox" value="([a-z]+)">/g)].map((m) => m[1]);
  assert.equal(boxes.length, 8, 'eight activities must be offered');
  assert.match(html, /id="planActivityList"/);
  assert.match(html, /id="selectFreePlan"[^>]*disabled/);
  const js = fs.readFileSync(path.join(siteDir, 'assets/site.js'), 'utf8');
  assert.match(js, /checked\.length > 2/, 'the picker must reject a third selection');
  assert.match(js, /freeBtn\.disabled = checked !== 2/, 'the button unlocks only at exactly two');
});

test('the site claims no capability the engine does not have', () => {
  // The product page must state the limits rather than only the strengths.
  const product = pages['product.html'];
  assert.match(product, /What it does not do/);
  assert.match(product, /No clash detection/);
  assert.match(product, /No 3D viewer in the browser/);
  assert.match(product, /Geometry is rectangular/);
  const productAr = pages['ar/product.html'];
  assert.match(productAr, /ما لا يفعله/);
  assert.match(productAr, /لا كشف تعارضات/);
});

test('the evidence figures on the site match the reference project', () => {
  // These numbers come from the shipped proof run; a marketing page that
  // inflates them would be a false claim.
  for (const rel of ['index.html', 'ar/index.html']) {
    const html = pages[rel];
    assert.match(html, /27|٢٧/, rel + ' must state 27 elements');
    assert.match(html, /13|١٣/, rel + ' must state 13 quantity lines');
    assert.match(html, /343|٣٤٣/, rel + ' must state the test count');
  }
});

test('the workspace keeps every capability panel after the visual refresh', () => {
  const workspace = fs.readFileSync(path.join(webRoot, 'mmc-ai/index.html'), 'utf8');
  const required = [
    'bimPanel', 'bim4d5dPanel', 'boqPanel', 'riskPanel', 'schedulePanel',
    'bimExportBoq', 'bimImportIfc', 'bimDownloadIfc',
    'b45Curve', 'b45ImportCsv', 'b45ApproveCost', 'b45ApproveSchedule'
  ];
  for (const id of required) {
    assert.match(workspace, new RegExp('id="' + id + '"'), 'workspace lost #' + id);
  }
  // The capability scripts must still be present and unmodified in name.
  for (const script of ['mmc-ai-bim-model-engine', 'mmc-ai-four-capabilities', 'mmc-ai-language-switch']) {
    assert.match(workspace, new RegExp(script), 'workspace lost script ' + script);
  }
});

test('the workspace has a working mobile navigation drawer', () => {
  const workspace = fs.readFileSync(path.join(webRoot, 'mmc-ai/index.html'), 'utf8');
  assert.match(workspace, /id="uiMenuBtn"/);
  assert.match(workspace, /id="uiSidebar"/);
  assert.match(workspace, /id="uiScrim"/);
  assert.match(workspace, /id="mmc-ai-mobile-nav"/);
  assert.match(workspace, /aria-expanded/);
});

test('the workspace loads no remote image that could break offline', () => {
  const workspace = fs.readFileSync(path.join(webRoot, 'mmc-ai/index.html'), 'utf8');
  const remote = [...workspace.matchAll(/<img[^>]+src="(https?:\/\/[^"]+)"/g)].map((m) => m[1]);
  assert.deepEqual(remote, [], 'remote images found: ' + remote.join(', '));
});

test('every local image referenced by the workspace exists on disk', () => {
  const workspace = fs.readFileSync(path.join(webRoot, 'mmc-ai/index.html'), 'utf8');
  const local = [...workspace.matchAll(/<img[^>]+src="(assets\/[^"]+)"/g)].map((m) => m[1]);
  assert.ok(local.length > 0, 'the workspace should reference local activity images');
  const missing = local.filter((rel) => !fs.existsSync(path.join(webRoot, 'mmc-ai', rel)));
  assert.deepEqual(missing, [], 'missing images: ' + missing.join(', '));
});
