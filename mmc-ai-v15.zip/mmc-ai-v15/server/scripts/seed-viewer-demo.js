'use strict';
/**
 * Seeds the local development database with a demo account and a fully linked
 * model, so the 3D viewer can be exercised in a real browser.
 *
 *   node scripts/seed-viewer-demo.js
 *
 * Idempotent: re-running reuses the account and project and rebuilds the model.
 */
const fs = require('node:fs');
const path = require('node:path');

// Local demo seeding must not depend on a live mail server.
process.env.MAIL_HOST = process.env.MAIL_HOST || 'json';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { getDB, closeDB } = require('../src/db');

const IFC_PATH = path.join(__dirname, '..', 'proof', 'bim-real-project', 'model.ifc');
const EMAIL = 'demo@mmc.local';
const PASSWORD = 'DemoPass123';

let base;
let server;
const jar = {};

async function call(method, url, body) {
  const headers = { ...(jar.c ? { Cookie: jar.c } : {}) };
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) jar.c = first;
  }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data };
}

async function main() {
  migrate();
  const app = createApp();
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = 'http://127.0.0.1:' + server.address().port;

  const db = getDB();
  let user = db.prepare('SELECT id FROM users WHERE email=?').get(EMAIL);
  if (!user) {
    const reg = await call('POST', '/api/auth/register', {
      name: 'Demo Engineer', email: EMAIL, password: PASSWORD, company: 'MMC Demo'
    });
    if (reg.status !== 201) throw new Error('register: ' + JSON.stringify(reg.data));
    user = db.prepare('SELECT id FROM users WHERE email=?').get(EMAIL);
  }
  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now, user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);

  const login = await call('POST', '/api/auth/login', { email: EMAIL, password: PASSWORD });
  if (login.status !== 200) throw new Error('login: ' + JSON.stringify(login.data));

  let project = db.prepare('SELECT id FROM ai_projects WHERE created_by=? ORDER BY created_at LIMIT 1').get(user.id);
  if (!project) {
    const p = await call('POST', '/api/mmc-ai/projects', {
      name: 'Demo Tower — Real IFC', country: 'OM', currency: 'OMR'
    });
    if (p.status !== 201) throw new Error('project: ' + JSON.stringify(p.data));
    project = { id: p.data.project.project_id };
  }
  const projectId = project.id;

  const ifc = fs.readFileSync(IFC_PATH);
  const form = new FormData();
  form.append('file', new Blob([ifc], { type: 'application/octet-stream' }), 'model.ifc');
  form.append('name', 'Demo Tower IFC');
  const imp = await fetch(`${base}/api/mmc-ai/projects/${projectId}/bim/model/import`, {
    method: 'POST', headers: { Cookie: jar.c }, body: form
  });
  const impData = await imp.json();
  if (imp.status !== 201) throw new Error('import: ' + JSON.stringify(impData));
  const modelId = impData.model.id;

  const sched = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/schedule`, {
    name: 'Demo programme',
    dataDate: '2026-01-04',
    schedule: {
      calendar: { dataDate: '2026-01-04' },
      activities: [
        { id: 'A1', name: 'Footings', durationDays: 5, trade: 'concrete', percentComplete: 100, actualStart: '2026-01-04', actualFinish: '2026-01-08' },
        { id: 'A2', name: 'Ground Floor Columns', durationDays: 6, predecessors: ['A1'], trade: 'concrete', percentComplete: 45, actualStart: '2026-01-11' },
        { id: 'A3', name: 'Ground Floor Walls', durationDays: 7, predecessors: ['A2'], trade: 'blockwork' },
        { id: 'A4', name: 'Ground Floor Slab', durationDays: 4, predecessors: ['A2'], trade: 'concrete' },
        { id: 'A5', name: 'Ground Floor Beams', durationDays: 4, predecessors: ['A2'], trade: 'concrete' }
      ]
    }
  });
  if (sched.status !== 201) throw new Error('schedule: ' + JSON.stringify(sched.data));
  const scheduleId = sched.data.schedule.id;

  const prop = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/propose-links`);
  if (prop.status !== 200) throw new Error('propose: ' + JSON.stringify(prop.data));
  await call('PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, {
    decisions: prop.data.links.map((l) => ({ elementId: l.elementId, state: 'confirmed' }))
  });

  await call('PUT', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost-items`, {
    currency: 'OMR',
    items: [
      { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 95 },
      { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 130 },
      { ruleId: 'Q-WALL-NET-AREA', unit: 'm2', unitRate: 22 },
      { ruleId: 'Q-WALL-NET-VOLUME', unit: 'm3', unitRate: 280 },
      { ruleId: 'Q-SLAB-AREA', unit: 'm2', unitRate: 45 },
      { ruleId: 'Q-SLAB-VOLUME', unit: 'm3', unitRate: 105 },
      { ruleId: 'Q-BEAM-VOLUME', unit: 'm3', unitRate: 125 },
      { ruleId: 'Q-BEAM-LENGTH', unit: 'm', unitRate: 35 },
      { ruleId: 'Q-WALL-LENGTH', unit: 'm', unitRate: 18 },
      { ruleId: 'Q-COLUMN-COUNT', unit: 'nr', unitRate: 60 },
      { ruleId: 'Q-FOOTING-COUNT', unit: 'nr', unitRate: 80 },
      { ruleId: 'Q-OPENING-COUNT', unit: 'nr', unitRate: 40 },
      { ruleId: 'Q-OPENING-AREA', unit: 'm2', unitRate: 150 }
    ]
  });
  const cost = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost`, {});
  if (![200, 201].includes(cost.status)) throw new Error('cost: ' + JSON.stringify(cost.data));

  const ctx = await call('GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  if (ctx.status !== 200) throw new Error('context: ' + JSON.stringify(ctx.data));

  console.log(JSON.stringify({
    email: EMAIL,
    password: PASSWORD,
    projectId,
    modelId,
    scheduleId,
    elements: ctx.data.elements.length,
    coverage: ctx.data.coverage,
    costTotal: cost.data.total
  }, null, 2));
}

main()
  .catch((e) => { console.error('SEED FAILED:', e.message); process.exitCode = 1; })
  .finally(async () => {
    try { if (server) server.close(); } catch (_) {}
    try { closeDB(); } catch (_) {}
  });
