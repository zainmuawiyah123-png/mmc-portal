'use strict';
/**
 * Real-project proof for the approved BOQ + cost Excel export.
 *
 * Runs on the project's own architectural DXF fixture — the same drawing the
 * BIM and 4D/5D proofs use — so the numbers are not hand-written.
 *
 * What it proves, in order:
 *   1. a model is built from the drawing with real provenance on every element
 *      (sheet number, sheet name, page, source file);
 *   2. quantities are measured from the model geometry;
 *   3. the model is approved, unit rates are set, and the cost is approved;
 *   4. the Excel file is produced and every approved row carries its sheet;
 *   5. an unapproved row is added on purpose and must NOT appear in the BOQ
 *      sheet — it must appear on the "not approved" sheet instead;
 *   5b. the file is re-read with an independent reader (openpyxl) to confirm it
 *      opens and the values are what the engine computed.
 *
 * Run: node scripts/bim-boq-export-proof.js
 * Writes: proof/bim-boq-export/{boq.xlsx,report.json,rows.json}
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');

const { buildModel, measureModel } = require('../src/lib/mmc-ai/bim-model');
const { takeoffDxf } = require('../src/lib/mmc-ai/dxf-takeoff');
const { buildCostModel } = require('../src/lib/mmc-ai/bim-4d5d-engine');
const { buildApprovedBoqWorkbook, partitionRows, provenanceOf } = require('../src/lib/mmc-ai/boq-export');

const OUT = path.join(__dirname, '..', 'proof', 'bim-boq-export');
fs.mkdirSync(OUT, { recursive: true });

const DXF_PATH = path.join(__dirname, '..', 'tests', 'fixtures', 'synthetic-architectural-sample.dxf');
const DXF_NAME = 'synthetic-architectural-sample.dxf';
const SHEET = { sheetNumber: 'A-101', sheetName: 'Ground Floor Plan', pageNumber: 1, documentName: DXF_NAME, revision: 'C' };

const takeoff = takeoffDxf(fs.readFileSync(DXF_PATH, 'utf8'), {});
const WALL_THICKNESS = 0.2;
const WALL_HEIGHT = 3.0;

const elements = [];
let wallNo = 0;
for (const item of takeoff.rows.filter((i) => i.layer === 'A-WALLS' && i.geometry.type === 'LINE')) {
  const { start, end } = item.geometry;
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const length = Math.hypot(dx, dy);
  if (!(length > 0.05)) continue;
  wallNo += 1;
  elements.push({
    id: `W${wallNo}`, type: 'wall', name: `Wall W${wallNo}`, storeyId: 'GF',
    origin: { x: (start.x + end.x) / 2, y: (start.y + end.y) / 2, z: 0 },
    length: Number(length.toFixed(4)), width: WALL_THICKNESS, height: WALL_HEIGHT,
    rotationDeg: Number(((Math.atan2(dy, dx) * 180) / Math.PI).toFixed(4)),
    properties: { sourceLayer: 'A-WALLS' },
    source: { ...SHEET, layer: 'A-WALLS', engine: 'dxf' }
  });
}

let openNo = 0;
for (const item of takeoff.rows.filter((i) => i.layer === 'A-WINDOWS' && i.geometry.type === 'LWPOLYLINE')) {
  const vs = item.geometry.vertices;
  if (!vs || vs.length < 3) continue;
  const xs = vs.map((v) => v.x);
  const ys = vs.map((v) => v.y);
  const w = Math.max(...xs) - Math.min(...xs);
  const h = Math.max(...ys) - Math.min(...ys);
  if (!(w > 0.1)) continue;
  const cx = (Math.max(...xs) + Math.min(...xs)) / 2;
  const cy = (Math.max(...ys) + Math.min(...ys)) / 2;
  let best = null;
  let bestD = Infinity;
  for (const wl of elements) {
    if (wl.type !== 'wall') continue;
    const d = Math.hypot(wl.origin.x - cx, wl.origin.y - cy);
    if (d < bestD) { bestD = d; best = wl; }
  }
  if (!best) continue;
  openNo += 1;
  elements.push({
    id: `O${openNo}`, type: 'opening', name: `Window O${openNo}`, storeyId: 'GF', hostId: best.id,
    origin: { x: cx, y: cy, z: 0.9 }, length: Number(w.toFixed(4)), width: WALL_THICKNESS,
    height: Number(Math.max(h, 1.2).toFixed(4)), sillHeight: 0.9,
    properties: { sourceLayer: 'A-WINDOWS' },
    source: { ...SHEET, layer: 'A-WINDOWS', engine: 'dxf' }
  });
}

// Structural elements come from the structural sheet, so the export has to show
// two different sheets — that is the point of the provenance column.
const STRUCT = { sheetNumber: 'S-201', sheetName: 'Foundation & Framing Plan', pageNumber: 2, documentName: DXF_NAME, revision: 'C' };
let colNo = 0;
let footNo = 0;
for (const x of [0, 4, 8]) {
  for (const y of [0, 3, 6]) {
    colNo += 1; footNo += 1;
    elements.push({
      id: `C${colNo}`, type: 'column', name: `Column C${colNo}`, storeyId: 'GF',
      origin: { x, y, z: 0 }, length: 0.3, width: 0.3, height: WALL_HEIGHT,
      properties: { concreteGrade: 'C30/37' },
      source: { ...STRUCT, layer: 'S-COLS', engine: 'dxf' }
    });
    elements.push({
      id: `F${footNo}`, type: 'footing', name: `Pad footing F${footNo}`, storeyId: 'GF',
      origin: { x, y, z: -0.6 }, length: 1.2, width: 1.2, height: 0.6,
      properties: { concreteGrade: 'C30/37' },
      source: { ...STRUCT, layer: 'S-FOUND', engine: 'dxf' }
    });
  }
}
elements.push({
  id: 'S1', type: 'slab', name: 'Ground slab', storeyId: 'GF',
  origin: { x: 4, y: 3, z: 0 }, length: 8, width: 6, height: 0.2,
  properties: { concreteGrade: 'C25/30' },
  source: { ...STRUCT, layer: 'S-SLAB', engine: 'dxf' }
});
elements.push({
  id: 'B1', type: 'beam', name: 'Beam B1 (south)', storeyId: 'GF',
  origin: { x: 4, y: 0, z: WALL_HEIGHT }, length: 8, width: 0.3, height: 0.5,
  source: { ...STRUCT, layer: 'S-BEAMS', engine: 'dxf' }
});
elements.push({
  id: 'B2', type: 'beam', name: 'Beam B2 (north)', storeyId: 'GF',
  origin: { x: 4, y: 6, z: WALL_HEIGHT }, length: 8, width: 0.3, height: 0.5,
  source: { ...STRUCT, layer: 'S-BEAMS', engine: 'dxf' }
});

const model = buildModel({
  name: 'Real DXF reconstruction — 8x6 m single storey',
  projectId: 'proof-project',
  storeys: [{ id: 'GF', name: 'Ground Floor', elevation: 0 }],
  elements
});
const measurement = measureModel(model, { modelId: 'proof-model', projectId: 'proof-project', revision: 'C' });

// ---- Approve every quantity row, as an engineer would ---------------------
const APPROVER = { id: 'user-engineer-1', name: 'م. سالم الحارثي' };
const APPROVED_AT = Math.floor(Date.parse('2026-11-16T09:30:00Z') / 1000);

const RATES = {
  'Q-WALL-NET-AREA': { rate: 12.5, unit: 'm2' },
  'Q-WALL-NET-VOLUME': { rate: 78.0, unit: 'm3' },
  'Q-WALL-LENGTH': { rate: 4.25, unit: 'm' },
  'Q-COLUMN-VOLUME': { rate: 145.0, unit: 'm3' },
  'Q-COLUMN-COUNT': { rate: 22.0, unit: 'nr' },
  'Q-FOOTING-VOLUME': { rate: 132.0, unit: 'm3' },
  'Q-FOOTING-COUNT': { rate: 35.0, unit: 'nr' },
  'Q-SLAB-AREA': { rate: 18.75, unit: 'm2' },
  'Q-SLAB-VOLUME': { rate: 128.0, unit: 'm3' },
  'Q-BEAM-VOLUME': { rate: 152.0, unit: 'm3' },
  'Q-BEAM-LENGTH': { rate: 9.5, unit: 'm' },
  'Q-OPENING-COUNT': { rate: 48.0, unit: 'nr' },
  'Q-OPENING-AREA': { rate: 26.0, unit: 'm2' }
};

const costItems = measurement.rows.map((r) => {
  const rate = RATES[r.ruleId];
  if (!rate) throw new Error('no rate for rule ' + r.ruleId);
  if (rate.unit !== r.unit) throw new Error('unit mismatch for ' + r.ruleId + ': ' + rate.unit + ' vs ' + r.unit);
  return { ruleId: r.ruleId, unit: r.unit, unitRate: rate.rate, currency: 'OMR', source: 'proof rate book' };
});
const cost = buildCostModel(measurement, costItems, { currency: 'OMR' });
if (cost.unpriced.length) throw new Error('unpriced rows: ' + JSON.stringify(cost.unpriced));

const quantityRows = measurement.rows.map((r) => ({
  ...r,
  reviewState: 'approved',
  approvedBy: APPROVER.id,
  approvedAt: APPROVED_AT
}));
const costRows = cost.rows.map((r) => ({
  ...r,
  reviewState: 'approved',
  approvedBy: APPROVER.id,
  approvedAt: APPROVED_AT
}));

// ---- Deliberately add one unapproved row --------------------------------
// This is the negative control: it must be excluded from the BOQ sheet and
// reported on the "not approved" sheet. If it leaked into the BOQ, the export
// would be lying about what has been approved.
const unapprovedRow = {
  ruleId: 'Q-TEST-UNAPPROVED',
  elementType: 'wall',
  discipline: 'architectural',
  description: 'Unapproved test row',
  descriptionAr: 'بند اختباري غير معتمد',
  unit: 'm2',
  quantity: 99.99,
  formula: 'test',
  elementCount: 1,
  elementIds: ['W1'],
  storeyBreakdown: { GF: 99.99 },
  sources: [{ ...SHEET, label: 'A-101 — Ground Floor Plan — p.1' }],
  reviewState: 'measured_ready_for_review',
  approvedBy: null,
  approvedAt: null
};

const built = buildApprovedBoqWorkbook({
  projectName: 'مشروع الاختبار الحقيقي — مبنى 8×6 م',
  modelName: model.name,
  modelRevision: 'C',
  currency: 'OMR',
  quantities: [...quantityRows, unapprovedRow],
  costRows,
  storeys: model.storeys,
  generatedBy: APPROVER,
  generatedAt: APPROVED_AT,
  scope: 'approved_only'
});

const xlsxPath = path.join(OUT, 'boq.xlsx');
fs.writeFileSync(xlsxPath, built.buffer);
const sha256 = crypto.createHash('sha256').update(built.buffer).digest('hex');

// ---- Independent verification with openpyxl -----------------------------
// The project's own writer is not used to check its own output.
const verifyScript = `
import json, sys
import openpyxl
wb = openpyxl.load_workbook(sys.argv[1], data_only=True)
out = {"sheets": wb.sheetnames, "rows": {}}
for name in wb.sheetnames:
    ws = wb[name]
    out["rows"][name] = [[c for c in row] for row in ws.iter_rows(values_only=True)]
print(json.dumps(out, ensure_ascii=False, default=str))
`;
const verifyPath = path.join(OUT, '_verify.py');
fs.writeFileSync(verifyPath, verifyScript);
let external = null;
let externalError = null;
try {
  const raw = execFileSync('python3', [verifyPath, xlsxPath], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  external = JSON.parse(raw);
} catch (err) {
  externalError = err.message;
}

// ---- Assertions ---------------------------------------------------------
const checks = [];
const check = (name, pass, detail) => checks.push({ name, pass: Boolean(pass), detail });

check('workbook has 5 sheets', external && external.sheets.length === 5, external ? external.sheets : externalError);
check('file is a valid ZIP/XLSX', built.buffer.slice(0, 2).toString() === 'PK', built.buffer.slice(0, 2).toString('hex'));

const boqSheetName = external ? external.sheets[0] : null;
const boqRows = external ? external.rows[boqSheetName] : [];
const headerRow = boqRows.find((r) => r && r[0] === 'م');
const dataRows = headerRow ? boqRows.slice(boqRows.indexOf(headerRow) + 1).filter((r) => r && typeof r[0] === 'number') : [];

check('BOQ sheet has one row per approved quantity', dataRows.length === quantityRows.length,
  { exported: dataRows.length, approved: quantityRows.length });
check('unapproved row is NOT in the BOQ sheet',
  !dataRows.some((r) => String(r[1] || '').includes('Q-TEST-UNAPPROVED')),
  dataRows.map((r) => r[1]).filter((x) => String(x).includes('TEST')));

const excludedSheetName = external ? external.sheets.find((s) => s.includes('غير المعتمد')) : null;
const excludedRows = excludedSheetName ? external.rows[excludedSheetName] : [];
check('unapproved row IS on the not-approved sheet',
  excludedRows.some((r) => r && String(r[0] || '').includes('Q-TEST-UNAPPROVED')),
  excludedRows.filter((r) => r && String(r[0] || '').includes('TEST')));

// Provenance: every exported row must name a sheet, and both sheets must appear.
const sheetCol = headerRow ? headerRow.indexOf('رقم اللوحة') : -1;
const provCol = headerRow ? headerRow.indexOf('اللوحة المصدر') : -1;
const fileCol = headerRow ? headerRow.indexOf('ملف المصدر') : -1;
const sheetValues = new Set(dataRows.map((r) => String(r[sheetCol] || '')));
check('every exported row names a sheet number',
  dataRows.every((r) => String(r[sheetCol] || '').trim().length > 0),
  dataRows.filter((r) => !String(r[sheetCol] || '').trim()).map((r) => r[1]));
check('both source sheets appear (A-101 and S-201)',
  sheetValues.has('A-101') && sheetValues.has('S-201'), [...sheetValues]);
check('source file name appears on every row',
  dataRows.every((r) => String(r[fileCol] || '') === DXF_NAME),
  [...new Set(dataRows.map((r) => String(r[fileCol] || '')))]);
check('provenance label includes the page',
  dataRows.every((r) => /صفحة\s*\d/.test(String(r[provCol] || ''))),
  dataRows.slice(0, 3).map((r) => r[provCol]));

// Cost: the exported total must equal the engine's total, to the cent.
const totalCol = headerRow ? headerRow.indexOf('الإجمالي') : -1;
const exportedTotal = dataRows.reduce((s, r) => s + (typeof r[totalCol] === 'number' ? r[totalCol] : 0), 0);
check('exported cost total equals the engine total',
  Math.abs(exportedTotal - cost.total) < 0.01,
  { exported: Number(exportedTotal.toFixed(2)), engine: cost.total });

// Quantities: each exported quantity must equal the measured quantity.
const qtyCol = headerRow ? headerRow.indexOf('الكمية') : -1;
const byRule = new Map(quantityRows.map((r) => [r.ruleId, r.quantity]));
const qtyMismatch = dataRows.filter((r) => {
  const expected = byRule.get(String(r[1]));
  return expected === undefined || Math.abs(Number(r[qtyCol]) - expected) > 1e-6;
});
check('every exported quantity equals the measured quantity', qtyMismatch.length === 0,
  qtyMismatch.map((r) => ({ rule: r[1], exported: r[qtyCol], expected: byRule.get(String(r[1])) })));

// Units must be the correct unit for the rule, not a generic label.
const unitCol = headerRow ? headerRow.indexOf('الوحدة') : -1;
const unitMismatch = dataRows.filter((r) => {
  const row = quantityRows.find((q) => q.ruleId === String(r[1]));
  const expected = { m: 'م', m2: 'م²', m3: 'م³', nr: 'عدد' }[row.unit];
  return String(r[unitCol]) !== expected;
});
check('every exported unit matches the rule unit', unitMismatch.length === 0,
  unitMismatch.map((r) => ({ rule: r[1], unit: r[unitCol] })));

// Approval trail must be present on every row.
const byCol = headerRow ? headerRow.indexOf('اعتمد بواسطة') : -1;
const atCol = headerRow ? headerRow.indexOf('تاريخ الاعتماد') : -1;
check('every exported row records who approved it and when',
  dataRows.every((r) => String(r[byCol] || '').trim() && /^\d{4}-\d{2}-\d{2}$/.test(String(r[atCol] || ''))),
  dataRows.slice(0, 2).map((r) => [r[byCol], r[atCol]]));

const failed = checks.filter((c) => !c.pass);

const report = {
  engine: 'mmc-bim-boq-export-proof-v1',
  generatedAt: new Date().toISOString(),
  source: { drawing: DXF_NAME, sheets: [SHEET.sheetNumber, STRUCT.sheetNumber] },
  model: {
    name: model.name,
    elementCount: model.elementCount,
    countsByType: model.countsByType,
    storeys: model.storeys
  },
  measurement: {
    rowCount: measurement.rowCount,
    totalsByUnit: measurement.totalsByUnit
  },
  cost: {
    rowCount: cost.rowCount,
    total: cost.total,
    currency: cost.currency,
    unpriced: cost.unpriced.length
  },
  export: {
    file: 'boq.xlsx',
    bytes: built.buffer.length,
    sha256,
    stats: built.stats
  },
  externalVerification: external
    ? { reader: 'openpyxl', sheets: external.sheets, ok: true }
    : { reader: 'openpyxl', ok: false, error: externalError },
  checks,
  passed: failed.length === 0,
  failedCount: failed.length,
  limitations: [
    'The drawing is the project fixture, not a client-issued sheet; sheet numbers A-101/S-201 are the labels recorded on the elements.',
    'Unit rates are a proof rate book, not market prices.',
    'The export transcribes stored approved rows; it does not re-measure or re-price.'
  ]
};

fs.writeFileSync(path.join(OUT, 'report.json'), JSON.stringify(report, null, 2));
fs.writeFileSync(path.join(OUT, 'rows.json'), JSON.stringify({
  approved: built.approved.map((r) => ({
    ruleId: r.ruleId, unit: r.unit, quantity: r.quantity,
    unitRate: r.cost ? r.cost.unitRate : null, total: r.cost ? r.cost.total : null,
    provenance: provenanceOf(r)
  })),
  excluded: built.excluded
}, null, 2));
fs.unlinkSync(verifyPath);

console.log(JSON.stringify({
  passed: report.passed,
  failedCount: report.failedCount,
  checks: checks.map((c) => (c.pass ? 'PASS ' : 'FAIL ') + c.name),
  export: report.export,
  external: report.externalVerification.ok
}, null, 2));

if (failed.length) process.exitCode = 1;
