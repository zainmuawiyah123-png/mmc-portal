'use strict';
/**
 * Proof for the in-browser 3D viewer.
 *
 * Runs the real HTTP routes against a throwaway database, imports the real
 * project IFC file, builds a schedule, proposes and confirms element links,
 * prices the quantities, and then reads the element-context payload the viewer
 * consumes. Every number printed here comes from the running server, not from
 * a fixture.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mmc-viewer-proof-'));
process.env.NODE_ENV = 'test';
process.env.MAIL_HOST = 'json';
process.env.DB_PATH = path.join(TMP, 'proof.db');
process.env.REQUIRE_ORG_VERIFICATION = 'false';
process.env.UPLOAD_DIR = path.join(TMP, 'uploads');
process.env.JWT_SECRET = 'mmc-viewer-proof-secret';
process.env.BCRYPT_ROUNDS = '4';

const { migrate } = require('../src/migrate');
const { createApp } = require('../src/index');
const { closeDB } = require('../src/db');

const IFC_PATH = path.join(__dirname, '..', 'proof', 'bim-real-project', 'model.ifc');
const OUT = path.join(__dirname, '..', 'proof', 'viewer3d');
const jar = {};
let base;
let server;

async function call(method, url, body) {
  const headers = { ...(jar.owner ? { Cookie: jar.owner } : {}) };
  let payload;
  if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  for (const c of (r.headers.getSetCookie ? r.headers.getSetCookie() : [])) {
    const first = c.split(';')[0];
    if (first.startsWith('tpkit_session=')) jar.owner = first;
  }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('application/json') ? await r.json() : await r.text();
  return { status: r.status, data };
}

const checks = [];
function check(name, ok, detail) {
  checks.push({ name, ok: Boolean(ok), detail });
  console.log((ok ? 'PASS  ' : 'FAIL  ') + name + (detail ? '  — ' + detail : ''));
}

async function main() {
  migrate();
  const app = createApp();
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = 'http://127.0.0.1:' + server.address().port;

  const email = 'viewer' + Math.random().toString(36).slice(2, 8) + '@test.local';
  let r = await call('POST', '/api/auth/register', { name: 'Viewer', email, password: 'Password123', company: 'Viewer Co' });
  if (r.status !== 201) throw new Error('register failed: ' + JSON.stringify(r.data));
  const db = require('../src/db').getDB();
  const user = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  const now = Math.floor(Date.now() / 1000);
  db.prepare('UPDATE email_verifications SET verified_at=? WHERE user_id=?').run(now, user.id);
  db.prepare("UPDATE users SET account_status='active' WHERE id=?").run(user.id);
  r = await call('POST', '/api/auth/login', { email, password: 'Password123' });
  if (r.status !== 200) throw new Error('login failed: ' + JSON.stringify(r.data));

  r = await call('POST', '/api/mmc-ai/projects', { name: 'Viewer proof project', country: 'OM', currency: 'OMR' });
  if (r.status !== 201) throw new Error('project failed: ' + JSON.stringify(r.data));
  const projectId = r.data.project.project_id;

  // ---- Import the real IFC file through the real multipart route.
  const ifcBuffer = fs.readFileSync(IFC_PATH);
  const form = new FormData();
  form.append('file', new Blob([ifcBuffer], { type: 'application/octet-stream' }), 'model.ifc');
  form.append('name', 'Real project IFC');
  const imp = await fetch(`${base}/api/mmc-ai/projects/${projectId}/bim/model/import`, {
    method: 'POST', headers: { Cookie: jar.owner }, body: form
  });
  const impData = await imp.json();
  if (imp.status !== 201) throw new Error('ifc import failed: ' + JSON.stringify(impData));
  const modelId = impData.model.id;
  check('real IFC imported', impData.model.elementCount > 0, impData.model.elementCount + ' elements');
  check('quantities measured from the imported model', impData.quantities.length > 0, impData.quantities.length + ' rows');

  // ---- 4D: schedule + links.
  const sched = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/schedule`, {
    name: 'Proof programme',
    dataDate: '2026-01-04',
    schedule: {
      calendar: { dataDate: '2026-01-04' },
      activities: [
        { id: 'A1', name: 'Footings', durationDays: 4, trade: 'concrete', percentComplete: 100, actualStart: '2026-01-04', actualFinish: '2026-01-07' },
        { id: 'A2', name: 'Ground Floor Columns', durationDays: 5, predecessors: ['A1'], trade: 'concrete', percentComplete: 40, actualStart: '2026-01-08' },
        { id: 'A3', name: 'Ground Floor Walls', durationDays: 6, predecessors: ['A2'], trade: 'blockwork' },
        { id: 'A4', name: 'Ground Floor Slab', durationDays: 3, predecessors: ['A2'], trade: 'concrete' },
        { id: 'A5', name: 'Ground Floor Beams', durationDays: 3, predecessors: ['A2'], trade: 'concrete' }
      ]
    }
  });
  if (sched.status !== 201) throw new Error('schedule failed: ' + JSON.stringify(sched.data));
  const scheduleId = sched.data.schedule.id;
  check('schedule created', sched.data.activities.length === 5, sched.data.activities.length + ' activities');

  const prop = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/propose-links`);
  if (prop.status !== 200) throw new Error('propose failed: ' + JSON.stringify(prop.data));
  check('element links proposed', prop.data.proposalCount > 0, prop.data.proposalCount + ' proposals');

  const confirm = await call('PATCH', `/api/mmc-ai/projects/${projectId}/bim/schedule/${scheduleId}/links`, {
    decisions: prop.data.links.map((l) => ({ elementId: l.elementId, state: 'confirmed' }))
  });
  if (confirm.status !== 200) throw new Error('confirm failed: ' + JSON.stringify(confirm.data));
  check('links confirmed', confirm.data.applied.length === prop.data.links.length, confirm.data.applied.length + ' confirmed');

  // ---- 5D: unit rates.
  const rates = await call('PUT', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost-items`, {
    currency: 'OMR',
    items: [
      { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 95 },
      { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 130 },
      { ruleId: 'Q-WALL-NET-AREA', unit: 'm2', unitRate: 22 },
      { ruleId: 'Q-WALL-NET-VOLUME', unit: 'm3', unitRate: 280 },
      { ruleId: 'Q-SLAB-AREA', unit: 'm2', unitRate: 45 },
      { ruleId: 'Q-SLAB-VOLUME', unit: 'm3', unitRate: 105 },
      { ruleId: 'Q-BEAM-VOLUME', unit: 'm3', unitRate: 125 },
      { ruleId: 'Q-BEAM-LENGTH', unit: 'm', unitRate: 35 },
      { ruleId: 'Q-WALL-LENGTH', unit: 'm', unitRate: 18 },
      { ruleId: 'Q-COLUMN-COUNT', unit: 'nr', unitRate: 60 },
      { ruleId: 'Q-FOOTING-COUNT', unit: 'nr', unitRate: 80 },
      { ruleId: 'Q-OPENING-COUNT', unit: 'nr', unitRate: 40 },
      { ruleId: 'Q-OPENING-AREA', unit: 'm2', unitRate: 150 }
    ]
  });
  if (rates.status !== 200) throw new Error('rates failed: ' + JSON.stringify(rates.data));
  const cost = await call('POST', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/cost`, {});
  if (cost.status !== 200 && cost.status !== 201) throw new Error('cost failed: ' + JSON.stringify(cost.data));
  check('cost rows built', (cost.data.rows || []).length > 0, (cost.data.rows || []).length + ' rows');

  // ---- The payload the viewer consumes.
  const ctx = await call('GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/element-context`);
  if (ctx.status !== 200) throw new Error('element-context failed: ' + JSON.stringify(ctx.data));
  const payload = ctx.data;
  const els = payload.elements;

  check('element-context returns every element', els.length === impData.model.elementCount, els.length + ' elements');
  check('every element carries explicit geometry', els.every((e) => e.vertices.length >= 8 && e.faces.length >= 6),
    els.filter((e) => e.vertices.length >= 8).length + '/' + els.length + ' with solids');
  // The viewer must draw the geometry the quantities were measured from, not a
  // box rebuilt from length/width/height. Compare against the stored model.
  const stored = JSON.parse(db.prepare('SELECT model_json FROM ai_bim_model_store WHERE id=?').get(modelId).model_json);
  const storedById = new Map(stored.elements.map((e) => [e.id, e]));
  let geomMismatch = 0;
  for (const e of els) {
    const s = storedById.get(e.id);
    const sv = s?.solid?.vertices || s?.vertices || [];
    if (!s || sv.length !== e.vertices.length) { geomMismatch += 1; continue; }
    for (let i = 0; i < sv.length; i += 1) {
      if (Math.abs(sv[i].x - e.vertices[i].x) > 1e-9 ||
          Math.abs(sv[i].y - e.vertices[i].y) > 1e-9 ||
          Math.abs(sv[i].z - e.vertices[i].z) > 1e-9) { geomMismatch += 1; break; }
    }
  }
  check('viewer geometry is the measured mesh, vertex for vertex', geomMismatch === 0,
    geomMismatch + ' elements differ from the stored model');
  check('elements carry quantities', payload.coverage.withQuantities > 0,
    payload.coverage.withQuantities + '/' + payload.coverage.total);
  check('elements carry costs', payload.coverage.withCosts > 0,
    payload.coverage.withCosts + '/' + payload.coverage.total);
  check('elements carry schedule activities', payload.coverage.withActivities > 0,
    payload.coverage.withActivities + '/' + payload.coverage.total);

  // Cross-check: the sum of per-element quantity values must equal the model total.
  const qTotals = {};
  for (const q of impData.quantities) qTotals[q.ruleId] = q.quantity;
  const perElement = {};
  for (const e of els) for (const q of e.quantities) {
    if (q.quantity === null) continue;
    perElement[q.ruleId] = (perElement[q.ruleId] || 0) + q.quantity;
  }
  let mismatch = 0;
  for (const [ruleId, total] of Object.entries(qTotals)) {
    const sum = perElement[ruleId] || 0;
    if (Math.abs(sum - total) > 1e-6) mismatch += 1;
  }
  check('per-element quantities sum to the model totals', mismatch === 0, mismatch + ' mismatched rules');

  // Cross-check: cost totals. Each element carries its share of a rule's money.
  const costTotal = (cost.data.rows || []).reduce((s, x) => s + x.total, 0);
  const perElementCost = els.reduce((s, e) => s + e.costs.reduce((a, c) => a + (c.total || 0), 0), 0);
  check('per-element cost shares sum to the cost model total',
    Math.abs(perElementCost - costTotal) < 0.05,
    perElementCost.toFixed(2) + ' vs ' + costTotal.toFixed(2));

  // Cross-check: an element's activity dates match the schedule.
  const withAct = els.find((e) => e.activities.length);
  const act = withAct.activities[0];
  const schedAct = sched.data.activities.find((a) => a.id === act.activityId);
  check('element activity matches the schedule row',
    schedAct && schedAct.plannedStart === act.plannedStart && schedAct.plannedFinish === act.plannedFinish,
    act.activityId + ' ' + act.plannedStart + '→' + act.plannedFinish);

  // An element with no link must come back empty, not invented.
  const unlinked = els.filter((e) => !e.quantities.length);
  check('unlinked elements are empty, not invented',
    unlinked.every((e) => e.quantities.length === 0 && e.costs.length === 0),
    unlinked.length + ' unlinked elements');

  // ---- Opening cut: the hole must be real geometry, and the numbers must not move.
  const hosts = els.filter((e) => e.openingCut && e.openingCut.openingsApplied > 0);
  check('a host carries a cut body', hosts.length > 0, hosts.length + ' hosts with a cut');
  const host = hosts[0];
  check('the cut body is real geometry, not a label',
    Array.isArray(host.displayVertices) && host.displayVertices.length > host.vertices.length,
    host.displayVertices.length + ' cut vertices vs ' + host.vertices.length + ' measured');
  check('the cut removed the opening volume',
    Math.abs(host.openingCut.removedVolume - 0.36) < 1e-6,
    host.openingCut.removedVolume + ' m3 removed');
  // The measured solid must be untouched: the cut is display-only. An imported
  // model does not pre-store netVolume, so the deduction is derived from the
  // opening's own volume rather than read from a field that may be absent.
  const storedHost = storedById.get(host.id);
  const openingVol = stored.elements
    .filter((e) => e.type === 'opening' && e.hostId === host.id)
    .reduce((s, o) => s + o.length * o.height * o.width, 0);
  const expectedNet = storedHost.grossVolume - openingVol;
  check('the measured solid is unchanged by the cut',
    Math.abs(storedHost.grossVolume - 4.8) < 1e-9 && Math.abs(expectedNet - 4.44) < 1e-9,
    'gross ' + storedHost.grossVolume + ' / net ' + expectedNet.toFixed(2));
  // A ray through the middle of the hole must hit nothing.
  const rayHits = (verts, faces, px, pz) => {
    let n = 0;
    for (const f of faces) {
      for (let i = 1; i + 1 < f.length; i += 1) {
        const a = verts[f[0]]; const b = verts[f[i]]; const c = verts[f[i + 1]];
        const d = (b.z - c.z) * (a.x - c.x) + (c.x - b.x) * (a.z - c.z);
        if (Math.abs(d) < 1e-12) continue;
        const u = ((b.z - c.z) * (px - c.x) + (c.x - b.x) * (pz - c.z)) / d;
        const v = ((c.z - a.z) * (px - c.x) + (a.x - c.x) * (pz - c.z)) / d;
        if (u < -1e-9 || v < -1e-9 || 1 - u - v < -1e-9) continue;
        n += 1;
      }
    }
    return n;
  };
  // The window sits at x = 3.75, z = 0.9..2.1 on wall W3 (origin x=4, length 8).
  const holeHits = rayHits(host.displayVertices, host.displayFaces, 3.75, 1.5);
  const solidHits = rayHits(host.displayVertices, host.displayFaces, 6.5, 1.5);
  check('a ray through the hole passes through the wall', holeHits === 0, holeHits + ' hits');
  check('the wall beside the hole is still solid', solidHits > 0, solidHits + ' hits');

  // ---- IFC export must carry the boolean subtraction.
  const exp = await call('GET', `/api/mmc-ai/projects/${projectId}/bim/model/${modelId}/ifc`);
  if (exp.status !== 200 && exp.status !== 201) throw new Error('ifc export failed: ' + JSON.stringify(exp.data));
  const exported = typeof exp.data === 'string' ? exp.data : (exp.data.ifc || exp.data.text || '');
  check('IFC export carries a boolean subtraction',
    /IFCBOOLEANRESULT\(\.DIFFERENCE\./.test(exported),
    (exported.match(/IFCBOOLEANRESULT/g) || []).length + ' boolean results');
  check('IFC export keeps the semantic void link',
    /IFCRELVOIDSELEMENT/.test(exported), 'IfcRelVoidsElement present');

  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, 'element-context.json'), JSON.stringify(payload, null, 2));
  fs.writeFileSync(path.join(OUT, 'proof-report.json'), JSON.stringify({
    generatedAt: new Date().toISOString(),
    ifcFile: 'server/proof/bim-real-project/model.ifc',
    ifcBytes: ifcBuffer.length,
    model: payload.model,
    coverage: payload.coverage,
    totals: {
      quantities: impData.quantities.length,
      costTotal: Number(costTotal.toFixed(2)),
      perElementCost: Number(perElementCost.toFixed(2)),
      activities: sched.data.activities.length,
      links: confirm.data.applied.length
    },
    checks
  }, null, 2));

  const failed = checks.filter((c) => !c.ok);
  console.log('\n' + (checks.length - failed.length) + '/' + checks.length + ' checks passed');
  if (failed.length) process.exitCode = 1;
}

main()
  .catch((err) => { console.error('PROOF FAILED:', err.message); process.exitCode = 1; })
  .finally(async () => {
    try { if (server) server.close(); } catch (_) {}
    try { closeDB(); } catch (_) {}
  });
