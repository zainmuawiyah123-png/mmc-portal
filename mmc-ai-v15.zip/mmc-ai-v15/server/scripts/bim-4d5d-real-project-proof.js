'use strict';
/**
 * Real-project 4D/5D proof.
 *
 * Takes the project's own BIM model (reconstructed from the architectural DXF
 * fixture by bim-real-project-proof.js), builds a construction programme for
 * it, proposes and confirms element links, measures planned-vs-earned
 * quantities at a data date, prices the quantities, and produces the
 * planned-vs-actual cost curve.
 *
 * Every number in the report is computed by the engine from the model; nothing
 * is hard-coded. The report also states the arithmetic checks that were run.
 *
 * Run: node scripts/bim-4d5d-real-project-proof.js
 * Writes: proof/bim-4d5d/{schedule.json,links.json,quantities-at.json,cost.json,curve.json,report.json}
 */
const fs = require('node:fs');
const path = require('node:path');

const { buildModel, measureModel } = require('../src/lib/mmc-ai/bim-model');
const {
  buildSchedule, proposeElementLinks, buildCostModel, buildCostCurve,
  quantitiesAtDate, parseScheduleCsv, workingDaysBetween, normalizeCalendar, parseDate
} = require('../src/lib/mmc-ai/bim-4d5d-engine');

const OUT = path.join(__dirname, '..', 'proof', 'bim-4d5d');
fs.mkdirSync(OUT, { recursive: true });

// ---- 1. The project's own model, rebuilt from its DXF fixture -------------
// This mirrors bim-real-project-proof.js so the 4D/5D proof runs on the same
// real geometry rather than a hand-written toy model.
const { takeoffDxf } = require('../src/lib/mmc-ai/dxf-takeoff');
const dxfPath = path.join(__dirname, '..', 'tests', 'fixtures', 'synthetic-architectural-sample.dxf');
const takeoff = takeoffDxf(fs.readFileSync(dxfPath, 'utf8'), {});

const WALL_THICKNESS = 0.2;
const WALL_HEIGHT = 3.0;
const elements = [];
let wallNo = 0;
for (const item of takeoff.rows.filter((i) => i.layer === 'A-WALLS' && i.geometry.type === 'LINE')) {
  const { start, end } = item.geometry;
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const length = Math.hypot(dx, dy);
  if (!(length > 0.05)) continue;
  wallNo += 1;
  elements.push({
    id: `W${wallNo}`, type: 'wall', name: `Wall W${wallNo}`, storeyId: 'GF',
    origin: { x: (start.x + end.x) / 2, y: (start.y + end.y) / 2, z: 0 },
    length: Number(length.toFixed(4)), width: WALL_THICKNESS, height: WALL_HEIGHT,
    rotationDeg: Number(((Math.atan2(dy, dx) * 180) / Math.PI).toFixed(4)),
    properties: { sourceLayer: 'A-WALLS' }
  });
}
let openNo = 0;
for (const item of takeoff.rows.filter((i) => i.layer === 'A-WINDOWS' && i.geometry.type === 'LWPOLYLINE')) {
  const vs = item.geometry.vertices;
  if (!vs || vs.length < 3) continue;
  const xs = vs.map((v) => v.x);
  const ys = vs.map((v) => v.y);
  const w = Math.max(...xs) - Math.min(...xs);
  const h = Math.max(...ys) - Math.min(...ys);
  if (!(w > 0.1)) continue;
  const cx = (Math.max(...xs) + Math.min(...xs)) / 2;
  const cy = (Math.max(...ys) + Math.min(...ys)) / 2;
  let best = null;
  let bestD = Infinity;
  for (const wl of elements) {
    if (wl.type !== 'wall') continue;
    const d = Math.hypot(wl.origin.x - cx, wl.origin.y - cy);
    if (d < bestD) { bestD = d; best = wl; }
  }
  if (!best) continue;
  openNo += 1;
  elements.push({
    id: `O${openNo}`, type: 'opening', name: `Window O${openNo}`, storeyId: 'GF', hostId: best.id,
    origin: { x: cx, y: cy, z: 0.9 }, length: Number(w.toFixed(4)), width: WALL_THICKNESS,
    height: Number(Math.max(h, 1.2).toFixed(4)), sillHeight: 0.9, properties: { sourceLayer: 'A-WINDOWS' }
  });
}
let colNo = 0;
let footNo = 0;
for (const x of [0, 4, 8]) {
  for (const y of [0, 3, 6]) {
    colNo += 1; footNo += 1;
    elements.push({
      id: `C${colNo}`, type: 'column', name: `Column C${colNo}`, storeyId: 'GF',
      origin: { x, y, z: 0 }, length: 0.3, width: 0.3, height: WALL_HEIGHT,
      properties: { concreteGrade: 'C30/37' }
    });
    elements.push({
      id: `F${footNo}`, type: 'footing', name: `Pad footing F${footNo}`, storeyId: 'GF',
      origin: { x, y, z: -0.6 }, length: 1.2, width: 1.2, height: 0.6,
      properties: { concreteGrade: 'C30/37' }
    });
  }
}
elements.push({
  id: 'S1', type: 'slab', name: 'Ground slab', storeyId: 'GF',
  origin: { x: 4, y: 3, z: 0 }, length: 8, width: 6, height: 0.2, properties: { concreteGrade: 'C25/30' }
});
elements.push({
  id: 'B1', type: 'beam', name: 'Beam B1 (south)', storeyId: 'GF',
  origin: { x: 4, y: 0, z: WALL_HEIGHT }, length: 8, width: 0.3, height: 0.5
});
elements.push({
  id: 'B2', type: 'beam', name: 'Beam B2 (north)', storeyId: 'GF',
  origin: { x: 4, y: 6, z: WALL_HEIGHT }, length: 8, width: 0.3, height: 0.5
});

const model = buildModel({
  name: 'Real DXF reconstruction — 8x6 m single storey',
  projectId: 'proof-project',
  storeys: [{ id: 'GF', name: 'Ground Floor', elevation: 0 }],
  elements
});
const measurement = measureModel(model, { modelId: 'proof-model', projectId: 'proof-project', revision: 'A' });

// ---- 2. A construction programme for that model ---------------------------
// The data date is a fixed date so the proof is reproducible.
const DATA_DATE = '2026-01-04';
const scheduleSpec = {
  name: 'Real project construction programme',
  calendar: { dataDate: DATA_DATE, workingDaysPerWeek: 6, offWeekdays: [5] },
  activities: [
    { id: 'A10', name: 'Site setup and setting out', durationDays: 3, trade: 'general', percentComplete: 100, actualStart: '2026-01-04', actualFinish: '2026-01-06' },
    { id: 'A20', name: 'Excavation for footings', durationDays: 4, predecessors: ['A10'], trade: 'earthworks', percentComplete: 100, actualStart: '2026-01-07', actualFinish: '2026-01-11' },
    { id: 'A30', name: 'Pad footings concrete', durationDays: 5, predecessors: ['A20'], trade: 'concrete', percentComplete: 60, actualStart: '2026-01-12' },
    { id: 'A40', name: 'Ground floor columns', durationDays: 6, predecessors: ['A30'], trade: 'concrete', percentComplete: 0 },
    { id: 'A50', name: 'Ground slab', durationDays: 4, predecessors: ['A40'], trade: 'concrete', percentComplete: 0 },
    { id: 'A60', name: 'Roof beams', durationDays: 4, predecessors: ['A40'], trade: 'concrete', percentComplete: 0 },
    { id: 'A70', name: 'Blockwork walls', durationDays: 8, predecessors: ['A50'], trade: 'blockwork', percentComplete: 0 },
    { id: 'A80', name: 'Windows and openings', durationDays: 3, predecessors: ['A70'], trade: 'glazing', percentComplete: 0 }
  ]
};
const schedule = buildSchedule(scheduleSpec);

// ---- 3. Element links: propose, then confirm the high-confidence ones -----
const proposal = proposeElementLinks(model, schedule);
// A reviewer confirms everything at or above 0.6 and rejects the rest. This is
// the same decision a quantity surveyor would make on this model.
const decisions = proposal.proposals.map((p) => ({
  elementId: p.elementId,
  activityId: p.activityId,
  state: p.confidence >= 0.6 ? 'confirmed' : 'rejected',
  ruleId: p.ruleId,
  confidence: p.confidence
}));
const confirmed = decisions.filter((d) => d.state === 'confirmed');
const rejected = decisions.filter((d) => d.state === 'rejected');

// The 4D quantity view only reads confirmed links.
const byActivity = new Map();
for (const d of confirmed) {
  if (!byActivity.has(d.activityId)) byActivity.set(d.activityId, []);
  byActivity.get(d.activityId).push(d.elementId);
}
const effectiveSchedule = {
  ...schedule,
  activities: schedule.activities.map((a) => ({ ...a, elementIds: byActivity.get(a.id) || [] }))
};

// ---- 4. 4D quantities at three dates -------------------------------------
const dates = ['2026-01-08', '2026-01-20', '2026-02-10'];
const quantitiesByDate = {};
for (const d of dates) {
  quantitiesByDate[d] = quantitiesAtDate(model, measurement, effectiveSchedule, d);
}

// ---- 5. 5D cost: unit rates in Omani Rial ---------------------------------
// Rates are plausible Omani market rates for a small reinforced-concrete
// building; they are inputs to the proof, not claims about the market.
const COST_ITEMS = [
  { ruleId: 'Q-FOOTING-VOLUME', unit: 'm3', unitRate: 95, actualCost: 4200, description: 'Pad footing concrete C30/37' },
  { ruleId: 'Q-FOOTING-COUNT', unit: 'nr', unitRate: 18, description: 'Footing excavation and blinding' },
  { ruleId: 'Q-COLUMN-VOLUME', unit: 'm3', unitRate: 130, description: 'Column concrete C30/37' },
  { ruleId: 'Q-COLUMN-COUNT', unit: 'nr', unitRate: 12, description: 'Column formwork setup' },
  { ruleId: 'Q-SLAB-AREA', unit: 'm2', unitRate: 45, description: 'Slab soffit formwork' },
  { ruleId: 'Q-SLAB-VOLUME', unit: 'm3', unitRate: 105, description: 'Slab concrete C25/30' },
  { ruleId: 'Q-BEAM-VOLUME', unit: 'm3', unitRate: 125, description: 'Beam concrete C30/37' },
  { ruleId: 'Q-BEAM-LENGTH', unit: 'm', unitRate: 35, description: 'Beam formwork' },
  { ruleId: 'Q-WALL-NET-AREA', unit: 'm2', unitRate: 22, description: 'Blockwork wall, 200 mm' },
  { ruleId: 'Q-WALL-NET-VOLUME', unit: 'm3', unitRate: 280, description: 'Wall concrete/blockwork volume' },
  { ruleId: 'Q-WALL-LENGTH', unit: 'm', unitRate: 28, description: 'Wall setting out and lintels' },
  { ruleId: 'Q-OPENING-COUNT', unit: 'nr', unitRate: 8, description: 'Opening preparation' },
  { ruleId: 'Q-OPENING-AREA', unit: 'm2', unitRate: 4, description: 'Opening area allowance' }
];
const cost = buildCostModel(measurement, COST_ITEMS, { currency: 'OMR' });
const curve = buildCostCurve(schedule, cost, { stepDays: 7 });

// ---- 6. Arithmetic checks -------------------------------------------------
const checks = [];
const push = (name, pass, detail) => checks.push({ name, pass, detail });

// 6a. Every quantity row is either priced or explicitly unpriced.
push('every quantity row is priced or reported unpriced',
  cost.rows.length + cost.unpriced.length === measurement.rows.length,
  `${cost.rows.length} priced + ${cost.unpriced.length} unpriced = ${measurement.rows.length} measured`);

// 6b. The cost total equals the sum of its rows.
const rowSum = Number(cost.rows.reduce((s, r) => s + r.total, 0).toFixed(6));
push('cost total equals the sum of its rows', Math.abs(rowSum - cost.total) < 1e-6, `${rowSum} vs ${cost.total}`);

// 6c. The storey split adds back to the total.
const storeySum = Number(Object.values(cost.byStorey).reduce((s, v) => s + v, 0).toFixed(4));
push('storey cost split adds back to the total', Math.abs(storeySum - cost.total) < 0.01, `${storeySum} vs ${cost.total}`);

// 6d. The curve starts at zero and ends at the full planned cost.
push('cost curve starts at zero', curve.points[0].plannedCost === 0, String(curve.points[0].plannedCost));
const lastPoint = curve.points[curve.points.length - 1];
push('cost curve ends at the full planned cost',
  Math.abs(lastPoint.plannedCost - cost.total) < 0.01, `${lastPoint.plannedCost} vs ${cost.total}`);

// 6e. Planned cost never decreases.
let monotonic = true;
for (let i = 1; i < curve.points.length; i += 1) {
  if (curve.points[i].plannedCost < curve.points[i - 1].plannedCost - 1e-9) monotonic = false;
}
push('planned cost never decreases along the curve', monotonic, `${curve.pointCount} points`);

// 6f. Earned quantity never exceeds total quantity, at any date.
let earnedWithinTotal = true;
for (const d of dates) {
  for (const r of quantitiesByDate[d].rows) {
    if (r.earnedQuantity > r.totalQuantity + 1e-6) earnedWithinTotal = false;
    if (r.plannedQuantity > r.totalQuantity + 1e-6) earnedWithinTotal = false;
  }
}
push('planned and earned quantity never exceed the measured total', earnedWithinTotal, `${dates.length} dates checked`);

// 6g. Earned quantity is non-decreasing over time.
let earnedMonotonic = true;
for (let i = 1; i < dates.length; i += 1) {
  const prev = quantitiesByDate[dates[i - 1]].totalsByUnit;
  const cur = quantitiesByDate[dates[i]].totalsByUnit;
  for (const unit of Object.keys(cur)) {
    if (prev[unit] && cur[unit].earned < prev[unit].earned - 1e-6) earnedMonotonic = false;
  }
}
push('earned quantity never decreases over time', earnedMonotonic, dates.join(' -> '));

// 6h. Every confirmed link points at a real element and a real activity.
const elementIds = new Set(model.elements.map((e) => e.id));
const activityIds = new Set(schedule.activities.map((a) => a.id));
push('every confirmed link points at a real element and activity',
  confirmed.every((d) => elementIds.has(d.elementId) && activityIds.has(d.activityId)),
  `${confirmed.length} confirmed links`);

// 6i. No element is linked twice.
const linkedIds = confirmed.map((d) => d.elementId);
push('no element is linked to more than one activity', new Set(linkedIds).size === linkedIds.length,
  `${linkedIds.length} links, ${new Set(linkedIds).size} distinct elements`);

// 6j. The schedule's own duration matches the calendar arithmetic.
const cal = normalizeCalendar(scheduleSpec.calendar);
const recomputed = workingDaysBetween(parseDate(schedule.projectStart), parseDate(schedule.projectFinish), cal);
push('project duration matches the working-day calendar',
  recomputed === schedule.projectDurationWorkingDays,
  `${recomputed} vs ${schedule.projectDurationWorkingDays} working days`);

// 6k. A CSV round trip of the same programme produces the same dates.
const csv = [
  'id,name,duration_days,predecessors,percent_complete,trade',
  ...scheduleSpec.activities.map((a) => [
    a.id, `"${a.name}"`, a.durationDays, (a.predecessors || []).join(';'), a.percentComplete || 0, a.trade || ''
  ].join(','))
].join('\n');
const parsed = parseScheduleCsv(csv);
const rebuilt = buildSchedule({ calendar: scheduleSpec.calendar, activities: parsed.activities });
const sameDates = rebuilt.activities.every((a) => {
  const orig = schedule.activities.find((x) => x.id === a.id);
  return orig && orig.plannedStart === a.plannedStart && orig.plannedFinish === a.plannedFinish;
});
push('CSV round trip reproduces the same planned dates', sameDates, `${parsed.activityCount} activities`);

const allPassed = checks.every((c) => c.pass);

// ---- 7. Write the proof ---------------------------------------------------
const report = {
  generatedAt: new Date().toISOString(),
  source: {
    drawing: path.relative(path.join(__dirname, '..'), dxfPath),
    dxfEntities: takeoff.rows.length,
    wallsFromDrawing: wallNo,
    windowsFromDrawing: openNo
  },
  model: {
    name: model.name,
    elements: model.elementCount,
    countsByType: model.countsByType,
    quantityRows: measurement.rows.length,
    totalsByUnit: measurement.totalsByUnit
  },
  schedule: {
    dataDate: schedule.dataDate,
    projectStart: schedule.projectStart,
    projectFinish: schedule.projectFinish,
    durationWorkingDays: schedule.projectDurationWorkingDays,
    activityCount: schedule.activityCount,
    activities: schedule.activities.map((a) => ({
      id: a.id, name: a.name, durationDays: a.durationDays,
      plannedStart: a.plannedStart, plannedFinish: a.plannedFinish,
      actualStart: a.actualStart, actualFinish: a.actualFinish,
      percentComplete: a.percentComplete, status: a.status,
      plannedFractionAtDataDate: a.plannedFractionAtDataDate,
      earnedFractionAtDataDate: a.earnedFractionAtDataDate
    }))
  },
  links: {
    proposed: proposal.proposalCount,
    unlinked: proposal.unlinkedCount,
    confirmed: confirmed.length,
    rejected: rejected.length,
    byRule: proposal.proposals.reduce((acc, p) => {
      acc[p.ruleId] = (acc[p.ruleId] || 0) + 1;
      return acc;
    }, {}),
    unlinkedElements: proposal.unlinked.map((u) => u.elementId)
  },
  quantitiesAt: Object.fromEntries(dates.map((d) => [d, {
    totalsByUnit: quantitiesByDate[d].totalsByUnit,
    rows: quantitiesByDate[d].rows.map((r) => ({
      ruleId: r.ruleId, unit: r.unit, total: r.totalQuantity,
      planned: r.plannedQuantity, earned: r.earnedQuantity, remaining: r.remainingQuantity
    }))
  }])),
  cost: {
    currency: cost.currency,
    rowCount: cost.rowCount,
    total: cost.total,
    actualTotal: cost.actualTotal,
    variance: cost.variance,
    byStorey: cost.byStorey,
    byDiscipline: cost.byDiscipline,
    unpriced: cost.unpriced,
    rows: cost.rows.map((r) => ({
      ruleId: r.ruleId, unit: r.unit, quantity: r.quantity,
      unitRate: r.unitRate, total: r.total, actualCost: r.actualCost
    }))
  },
  curve: {
    from: curve.from,
    to: curve.to,
    stepDays: curve.stepDays,
    pointCount: curve.pointCount,
    points: curve.points.map((p) => ({
      date: p.date, planned: p.plannedCost, earned: p.earnedCost, actual: p.actualCost
    }))
  },
  checks,
  allChecksPassed: allPassed
};

fs.writeFileSync(path.join(OUT, 'schedule.json'), JSON.stringify(schedule, null, 2));
fs.writeFileSync(path.join(OUT, 'links.json'), JSON.stringify({ proposal, decisions }, null, 2));
fs.writeFileSync(path.join(OUT, 'quantities-at.json'), JSON.stringify(quantitiesByDate, null, 2));
fs.writeFileSync(path.join(OUT, 'cost.json'), JSON.stringify(cost, null, 2));
fs.writeFileSync(path.join(OUT, 'curve.json'), JSON.stringify(curve, null, 2));
fs.writeFileSync(path.join(OUT, 'report.json'), JSON.stringify(report, null, 2));

console.log('=== BIM 4D/5D REAL PROJECT PROOF ===');
console.log('Model:', model.elementCount, 'elements', JSON.stringify(model.countsByType));
console.log('Quantities:', measurement.rows.length, 'rows', JSON.stringify(measurement.totalsByUnit));
console.log('Schedule:', schedule.activityCount, 'activities,', schedule.projectStart, '->', schedule.projectFinish,
  `(${schedule.projectDurationWorkingDays} working days)`);
console.log('Links: proposed', proposal.proposalCount, '| confirmed', confirmed.length, '| rejected', rejected.length,
  '| unlinked', proposal.unlinkedCount);
for (const d of dates) {
  const t = quantitiesByDate[d].totalsByUnit;
  console.log(`  at ${d}:`, Object.entries(t).map(([u, v]) => `${u} planned ${v.planned} / earned ${v.earned} of ${v.total}`).join(' | '));
}
console.log('Cost:', cost.currency, cost.total, 'over', cost.rowCount, 'rows; actual', cost.actualTotal,
  'variance', cost.variance);
console.log('Curve:', curve.pointCount, 'points', curve.from, '->', curve.to);
console.log('--- checks ---');
for (const c of checks) console.log(`  ${c.pass ? 'PASS' : 'FAIL'}  ${c.name}  (${c.detail})`);
console.log('All checks passed:', allPassed);
if (!allPassed) process.exitCode = 1;
console.log('Written to', path.relative(process.cwd(), OUT));
