/* MMC AI marketing site — shared behaviour.
   Deliberately tiny: mobile nav toggle, scroll-reveal, and the free-plan
   activity picker. No framework, no build step. */
(function () {
  'use strict';

  /* ---- mobile navigation ---- */
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    nav.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---- reveal on scroll ---- */
  var revealables = document.querySelectorAll('[data-reveal]');
  if (revealables.length && 'IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    revealables.forEach(function (el) { io.observe(el); });
  } else {
    revealables.forEach(function (el) { el.classList.add('is-visible'); });
  }

  /* ---- free-plan activity picker (pricing page) ---- */
  var picker = document.getElementById('planActivityList');
  if (picker) {
    var boxes = picker.querySelectorAll('input[type="checkbox"]');
    var counter = document.getElementById('planActivityCount');
    var freeBtn = document.getElementById('selectFreePlan');
    var feedback = document.getElementById('planFeedback');
    var isAr = document.documentElement.lang === 'ar';

    function sync() {
      var checked = picker.querySelectorAll('input[type="checkbox"]:checked').length;
      if (counter) {
        counter.textContent = isAr
          ? checked + ' / 2 مختارة'
          : checked + ' / 2 selected';
      }
      if (freeBtn) freeBtn.disabled = checked !== 2;
      if (feedback && checked > 2) {
        feedback.textContent = isAr
          ? 'الباقة المجانية تسمح بخدمتين فقط. أزل واحدة للمتابعة.'
          : 'The Free plan allows exactly two activities. Remove one to continue.';
      }
    }

    boxes.forEach(function (box) {
      box.addEventListener('change', function () {
        var checked = picker.querySelectorAll('input[type="checkbox"]:checked');
        if (checked.length > 2) {
          box.checked = false;
          if (feedback) {
            feedback.textContent = isAr
              ? 'الباقة المجانية تسمح بخدمتين فقط. أزل واحدة للمتابعة.'
              : 'The Free plan allows exactly two activities. Remove one to continue.';
          }
        }
        sync();
      });
    });

    if (freeBtn) {
      freeBtn.addEventListener('click', function () {
        var chosen = [];
        picker.querySelectorAll('input[type="checkbox"]:checked').forEach(function (b) {
          chosen.push(b.value);
        });
        if (feedback) {
          feedback.textContent = isAr
            ? 'تم اختيار: ' + chosen.join(' · ') + '. هذه معاينة للاختيار فقط — لم يُنشأ اشتراك ولم يُحصَّل أي مبلغ.'
            : 'Selected: ' + chosen.join(' · ') + '. This is a selection preview only — no subscription was created and no payment was taken.';
        }
      });
    }

    sync();
  }

  /* ---- current year in footer ---- */
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = String(new Date().getFullYear());
  });
})();
