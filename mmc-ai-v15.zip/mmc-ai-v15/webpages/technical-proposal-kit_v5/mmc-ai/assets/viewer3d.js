/**
 * MMC AI — in-browser BIM viewer.
 *
 * Draws the model's real solids (the vertices and faces the server measured the
 * quantities from), not a re-guessed box, so what you see is what was measured.
 *
 * Clicking an element shows the quantity rows, the cost rows and the schedule
 * activity that reference it. An element with no link shows an explicit
 * "not linked" line — the viewer never invents a relationship.
 *
 * Self-hosted three.js: no CDN, so the viewer works offline and inside the
 * sandbox test.
 */
import * as THREE from './vendor/three/three.module.js';
import { OrbitControls } from './vendor/three/OrbitControls.js';

const TYPE_COLORS = {
  wall: 0x8fb8d8,
  column: 0xe0a458,
  footing: 0x9a8f7d,
  slab: 0x7fc9a6,
  beam: 0xc98fb8,
  opening: 0x2b3a4a
};

const TYPE_LABELS = {
  wall: { en: 'Wall', ar: 'جدار' },
  column: { en: 'Column', ar: 'عمود' },
  footing: { en: 'Footing', ar: 'أساس' },
  slab: { en: 'Slab', ar: 'بلاطة' },
  beam: { en: 'Beam', ar: 'كمرة' },
  opening: { en: 'Opening', ar: 'فتحة' }
};

let state = null;

function disposeState() {
  if (!state) return;
  cancelAnimationFrame(state.raf);
  state.controls?.dispose();
  state.renderer?.dispose();
  state.scene?.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      if (Array.isArray(o.material)) o.material.forEach((m) => m.dispose());
      else o.material.dispose();
    }
  });
  state = null;
}

function buildGeometry(el) {
  // Prefer the cut body: the host with its openings actually removed. Falling
  // back to the measured solid keeps older models (saved before the cut
  // existed) drawable instead of blank.
  const verts = el.displayVertices || el.vertices || [];
  const faces = el.displayFaces || el.faces || [];
  if (verts.length < 4 || faces.length < 4) return null;
  const positions = [];
  for (const face of faces) {
    // Fan-triangulate the polygon face.
    for (let i = 1; i < face.length - 1; i += 1) {
      for (const idx of [face[0], face[i], face[i + 1]]) {
        const v = verts[idx];
        if (!v) return null;
        positions.push(v.x, v.y, v.z);
      }
    }
  }
  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geom.computeVertexNormals();
  geom.computeBoundingSphere();
  return geom;
}

function fmt(n, digits = 2) {
  if (n === null || n === undefined || !Number.isFinite(Number(n))) return '—';
  return Number(n).toLocaleString(undefined, { maximumFractionDigits: digits });
}

function el(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function renderDetail(host, element, lang) {
  host.replaceChildren();
  const ar = lang === 'ar';
  const head = el('div', 'v3d-detail-head');
  const swatch = el('span', 'v3d-swatch');
  swatch.style.background = '#' + (TYPE_COLORS[element.type] || 0x888888).toString(16).padStart(6, '0');
  head.append(swatch, el('strong', null, element.name || element.id));
  host.appendChild(head);

  const meta = el('div', 'v3d-detail-meta');
  meta.textContent = [
    (TYPE_LABELS[element.type] || { en: element.type, ar: element.type })[ar ? 'ar' : 'en'],
    element.id,
    (ar ? 'الطابق ' : 'Storey ') + (element.storeyId || '—')
  ].join(' · ');
  host.appendChild(meta);

  const dims = el('div', 'v3d-detail-meta');
  dims.textContent = (ar ? 'الأبعاد: ' : 'Dimensions: ') +
    `${fmt(element.dimensions.length)} × ${fmt(element.dimensions.width)} × ${fmt(element.dimensions.height)} m`;
  host.appendChild(dims);

  const section = (title, rows, emptyText) => {
    host.appendChild(el('div', 'v3d-detail-title', title));
    if (!rows.length) {
      host.appendChild(el('div', 'v3d-detail-empty', emptyText));
      return;
    }
    const list = el('div', 'v3d-detail-list');
    for (const r of rows) list.appendChild(r);
    host.appendChild(list);
  };

  section(ar ? 'الكميات' : 'Quantities', element.quantities.map((q) => {
    const row = el('div', 'v3d-detail-row');
    const label = (ar && q.descriptionAr ? q.descriptionAr : q.description) || q.ruleId;
    const value = q.quantity === null || q.quantity === undefined
      ? (ar ? 'مساهمة غير مسجّلة' : 'contribution not recorded')
      : `${fmt(q.quantity, 3)} ${q.unit}`;
    row.append(el('span', 'v3d-detail-key', label), el('span', 'v3d-detail-val', value));
    return row;
  }), ar ? 'لا توجد كمية مرتبطة بهذا العنصر.' : 'No quantity is linked to this element.');

  section(ar ? 'التكلفة' : 'Cost', element.costs.map((c) => {
    const row = el('div', 'v3d-detail-row');
    const label = c.isShare
      ? (ar ? `حصة من بند بسعر ${fmt(c.unitRate)} / ${c.unit}` : `share of a row at ${fmt(c.unitRate)} / ${c.unit}`)
      : `${fmt(c.quantity, 3)} ${c.unit} × ${fmt(c.unitRate)}`;
    const value = c.total === null || c.total === undefined
      ? (ar ? 'غير مسعّر' : 'not priced')
      : `${fmt(c.total)} ${c.currency}`;
    row.append(el('span', 'v3d-detail-key', label), el('span', 'v3d-detail-val', value));
    return row;
  }), ar ? 'لا توجد تكلفة مرتبطة بهذا العنصر.' : 'No cost is linked to this element.');

  section(ar ? 'النشاط الزمني' : 'Schedule activity', element.activities.map((a) => {
    const row = el('div', 'v3d-detail-row');
    row.append(
      el('span', 'v3d-detail-key', a.name || a.activityId),
      el('span', 'v3d-detail-val', `${a.plannedStart || '—'} → ${a.plannedFinish || '—'} · ${a.percentComplete}%`)
    );
    return row;
  }), ar ? 'لا يوجد نشاط مرتبط بهذا العنصر.' : 'No activity is linked to this element.');
}

/**
 * Mounts the viewer.
 * opts = { projectId, modelId, lang, onStatus }
 */
export async function mount(container, opts) {
  disposeState();
  const lang = opts.lang === 'ar' ? 'ar' : 'en';
  const ar = lang === 'ar';
  const status = opts.onStatus || (() => {});

  container.replaceChildren();
  const canvasHost = el('div', 'v3d-canvas-host');
  const side = el('div', 'v3d-side');
  const toolbar = el('div', 'v3d-toolbar');
  const detail = el('div', 'v3d-detail');
  detail.appendChild(el('p', 'v3d-detail-empty', ar ? 'انقر على أي عنصر في النموذج لعرض كميته وتكلفته ونشاطه.' : 'Click any element in the model to see its quantity, cost and activity.'));
  side.append(toolbar, detail);
  container.append(canvasHost, side);

  status(ar ? 'جارٍ تحميل النموذج…' : 'Loading model…');

  let payload;
  try {
    const res = await fetch(
      `/api/mmc-ai/projects/${encodeURIComponent(opts.projectId)}/bim/model/${encodeURIComponent(opts.modelId)}/element-context`,
      { credentials: 'same-origin', headers: { Accept: 'application/json' } }
    );
    payload = await res.json();
    if (!res.ok) throw new Error(payload.message || (ar ? 'تعذّر تحميل النموذج.' : 'Could not load the model.'));
  } catch (err) {
    status(err.message);
    container.replaceChildren(el('p', 'v3d-error', err.message));
    return null;
  }

  const elements = payload.elements || [];
  if (!elements.length) {
    status(ar ? 'النموذج لا يحتوي عناصر.' : 'The model has no elements.');
    return null;
  }

  const width = canvasHost.clientWidth || 640;
  const height = Math.max(360, Math.min(620, Math.round(width * 0.62)));

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a1420);

  const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 5000);
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(width, height);
  canvasHost.appendChild(renderer.domElement);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.screenSpacePanning = true;

  scene.add(new THREE.HemisphereLight(0xdfefff, 0x1a2430, 1.15));
  const key = new THREE.DirectionalLight(0xffffff, 1.5);
  key.position.set(60, 90, 50);
  scene.add(key);
  const fill = new THREE.DirectionalLight(0x9fd0ff, 0.55);
  fill.position.set(-70, 40, -60);
  scene.add(fill);

  // Ground grid sized to the model footprint.
  const bbox = payload.model.bbox;
  const size = bbox ? Math.max(bbox.size.x, bbox.size.y, 1) : 20;
  const grid = new THREE.GridHelper(Math.ceil(size * 1.6), 20, 0x1e3a52, 0x14283a);
  grid.position.y = bbox ? bbox.min.z - 0.01 : 0;
  scene.add(grid);

  const storeyGroups = new Map();
  const meshes = [];
  const edgeMaterial = new THREE.LineBasicMaterial({ color: 0x0a1420, transparent: true, opacity: 0.45 });

  for (const element of elements) {
    const geom = buildGeometry(element);
    if (!geom) continue;
    const isOpening = element.type === 'opening';
    // An opening is no longer a translucent box: its host is drawn with the
    // hole actually cut out, so the void is real geometry. The opening itself
    // is drawn as a thin wireframe outline only, which keeps it clickable (so
    // its own quantity and cost are still reachable) without putting a ghost
    // solid back in front of the hole.
    const material = isOpening
      ? new THREE.MeshBasicMaterial({ visible: false })
      : new THREE.MeshStandardMaterial({
        color: TYPE_COLORS[element.type] || 0x9aa7b4,
        roughness: 0.72,
        metalness: 0.06,
        side: THREE.DoubleSide
      });
    const mesh = new THREE.Mesh(geom, material);
    mesh.userData.element = element;
    mesh.userData.baseColor = isOpening ? 0x4cc9f0 : material.color.getHex();

    const edges = new THREE.LineSegments(
      new THREE.EdgesGeometry(geom, 25),
      isOpening
        ? new THREE.LineBasicMaterial({ color: 0x4cc9f0, transparent: true, opacity: 0.85 })
        : edgeMaterial
    );
    mesh.add(edges);

    const storeyId = element.storeyId || 'L0';
    if (!storeyGroups.has(storeyId)) {
      const group = new THREE.Group();
      group.name = storeyId;
      storeyGroups.set(storeyId, group);
      scene.add(group);
    }
    storeyGroups.get(storeyId).add(mesh);
    meshes.push(mesh);
  }

  // Frame the model: fit the bounding sphere to the vertical AND horizontal
  // field of view, so a wide building is not cropped and a small one is not a
  // speck in the corner.
  const box = new THREE.Box3();
  for (const m of meshes) box.expandByObject(m);
  if (box.isEmpty()) box.setFromCenterAndSize(new THREE.Vector3(0, 0, 0), new THREE.Vector3(10, 10, 10));
  const center = box.getCenter(new THREE.Vector3());
  const sphere = box.getBoundingSphere(new THREE.Sphere());
  const vFov = (camera.fov * Math.PI) / 180;
  const hFov = 2 * Math.atan(Math.tan(vFov / 2) * camera.aspect);
  const fitDist = Math.max(
    sphere.radius / Math.sin(vFov / 2),
    sphere.radius / Math.sin(hFov / 2)
  ) * 1.12;
  const dist = Math.max(fitDist, 4);
  const placeCamera = () => {
    camera.position.set(center.x + dist * 0.62, center.y - dist * 0.78, center.z + dist * 0.72);
    controls.target.copy(center);
    controls.update();
  };
  camera.up.set(0, 0, 1);
  placeCamera();

  // Storey toggles.
  const storeyNames = new Map((payload.model.storeys || []).map((s) => [s.id, s.name || s.id]));
  const toggleWrap = el('div', 'v3d-toggles');
  toggleWrap.appendChild(el('span', 'v3d-toolbar-label', ar ? 'الطوابق' : 'Storeys'));
  for (const [storeyId, group] of storeyGroups) {
    const btn = el('button', 'v3d-toggle is-on', storeyNames.get(storeyId) || storeyId);
    btn.type = 'button';
    btn.setAttribute('aria-pressed', 'true');
    btn.addEventListener('click', () => {
      group.visible = !group.visible;
      btn.classList.toggle('is-on', group.visible);
      btn.setAttribute('aria-pressed', String(group.visible));
      if (state) state.wake();
    });
    toggleWrap.appendChild(btn);
  }
  toolbar.appendChild(toggleWrap);

  const actions = el('div', 'v3d-actions');
  const resetBtn = el('button', 'v3d-action', ar ? 'إعادة الضبط' : 'Reset view');
  resetBtn.type = 'button';
  resetBtn.addEventListener('click', () => {
    placeCamera();
    if (state) state.wake();
  });
  const isoBtn = el('button', 'v3d-action', ar ? 'منظر علوي' : 'Top view');
  isoBtn.type = 'button';
  isoBtn.addEventListener('click', () => {
    camera.position.set(center.x, center.y, center.z + dist * 1.15);
    controls.target.copy(center);
    controls.update();
    if (state) state.wake();
  });
  actions.append(resetBtn, isoBtn);
  toolbar.appendChild(actions);

  const coverage = payload.coverage || {};
  const cov = el('div', 'v3d-coverage');
  cov.textContent = ar
    ? `${coverage.total} عنصر · ${coverage.withQuantities} بكمية · ${coverage.withCosts} بتكلفة · ${coverage.withActivities} بنشاط`
    : `${coverage.total} elements · ${coverage.withQuantities} with quantity · ${coverage.withCosts} with cost · ${coverage.withActivities} with activity`;
  toolbar.appendChild(cov);

  // Click → element detail.
  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  let selected = null;

  function clearSelection() {
    if (selected) {
      selected.material.emissive?.setHex(0x000000);
      selected.material.color?.setHex(selected.userData.baseColor);
      selected = null;
    }
  }

  function pick(event) {
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const visible = meshes.filter((m) => m.parent && m.parent.visible);
    const hits = raycaster.intersectObjects(visible, false);
    if (!hits.length) return;
    const mesh = hits[0].object;
    clearSelection();
    selected = mesh;
    mesh.material.color?.setHex(0x4cc9f0);
    mesh.material.emissive?.setHex(0x123a4a);
    renderDetail(detail, mesh.userData.element, lang);
    if (opts.onSelect) opts.onSelect(mesh.userData.element);
    if (state) state.wake();
  }

  renderer.domElement.addEventListener('click', pick);
  renderer.domElement.addEventListener('pointerdown', (e) => { renderer.domElement.dataset.downX = e.clientX; renderer.domElement.dataset.downY = e.clientY; });
  renderer.domElement.addEventListener('pointerup', (e) => {
    const dx = Math.abs(e.clientX - Number(renderer.domElement.dataset.downX || 0));
    const dy = Math.abs(e.clientY - Number(renderer.domElement.dataset.downY || 0));
    if (dx > 4 || dy > 4) return; // a drag, not a click
    pick(e);
  });

  function resize() {
    const w = canvasHost.clientWidth || width;
    const h = Math.max(320, Math.min(620, Math.round(w * 0.62)));
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    if (state) state.wake();
  }
  const ro = new ResizeObserver(resize);
  ro.observe(canvasHost);
  // The host is often still 0-wide when the panel is first shown, so the
  // initial size above can be a guess. Re-measure once layout has settled.
  requestAnimationFrame(() => { resize(); placeCamera(); });
  setTimeout(() => { resize(); placeCamera(); }, 120);

  function loop() {
    state.raf = requestAnimationFrame(loop);
    controls.update();
    renderer.render(scene, camera);
  }

  // Render on demand rather than in a permanent animation loop: a BIM model is
  // static, so a continuous loop burns battery and keeps the page busy for no
  // visual gain. Damping needs a few frames after a drag, so the loop runs only
  // while the camera is moving.
  let idleFrames = 0;
  function tick() {
    state.raf = requestAnimationFrame(tick);
    const moved = controls.update();
    renderer.render(scene, camera);
    if (moved) idleFrames = 0;
    else idleFrames += 1;
    if (idleFrames > 3) {
      cancelAnimationFrame(state.raf);
      state.raf = 0;
      state.running = false;
    }
  }
  function wake() {
    if (state && !state.running) {
      state.running = true;
      idleFrames = 0;
      state.raf = requestAnimationFrame(tick);
    }
  }
  controls.addEventListener('change', wake);
  controls.addEventListener('start', wake);

  state = { scene, camera, renderer, controls, raf: 0, running: false, meshes, storeyGroups, dispose: disposeState, wake };
  renderer.render(scene, camera);
  wake();

  status(ar
    ? `تم تحميل ${elements.length} عنصراً. اسحب للتدوير، عجلة الفأرة للتقريب، وانقر عنصراً لعرض بياناته.`
    : `Loaded ${elements.length} elements. Drag to orbit, scroll to zoom, click an element for its data.`);

  return {
    dispose: disposeState,
    selectElement(id) {
      const mesh = meshes.find((m) => m.userData.element.id === id);
      if (!mesh) return false;
      clearSelection();
      selected = mesh;
      mesh.material.color?.setHex(0x4cc9f0);
      mesh.material.emissive?.setHex(0x123a4a);
      renderDetail(detail, mesh.userData.element, lang);
      return true;
    },
    get elementCount() { return meshes.length; }
  };
}

export function unmount() {
  disposeState();
}

window.MMCViewer3D = { mount, unmount };
